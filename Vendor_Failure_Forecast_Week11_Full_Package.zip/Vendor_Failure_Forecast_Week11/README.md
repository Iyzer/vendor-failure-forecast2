# Vendor Failure Forecast: Weeks 10 and 11

MS Analytics, Saint Louis University. Team: Mirza Ali and Debra Senteu.

| Folder | What it is |
|---|---|
| `Week11_Vendor_Risk_Forecast/` | **Week 11 submission** (Model Evaluation and Decision Support), due Mon 2 Nov 2026, 11:59 pm. Start with its `README.md`. |
| `Week10_frozen/` | The Week 10 submission, unchanged, so the earlier version stays identifiable. |

To see the app, open `Week11_Vendor_Risk_Forecast/app/index.html` in a browser (Week 10 version: `Week10_frozen/app/index.html`). The evaluation report is `Week11_Vendor_Risk_Forecast/report/Week11_Evaluation_Report.pdf`.

Not finished, because it needs people: the structured test with someone outside the group, the narration recording, the contributions confirmation, and the hosted-app and shared-repository links with instructor access. The checklist is at the bottom of the Week 11 `README.md`.

Size note: the silent demo recordings and the screenshot images are left out of this repository; they are in the submission folder, and `qa/wk11_visual.js` regenerates the screenshots.
