# Week 10 — KPIs, predictor explanations, and progress

**Vendor Failure Forecast** · Mirza Ali and Debra Senteu · MS Analytics, Saint Louis University

This document covers assignment items 1, 2(a), 3(a), 3(b) and 4. Items 2(b) and 2(c) —
the choice of algorithm and the rationale for it — are argued with citations in
`report/Week10_One_Page_Report.pdf` and are not repeated here.

All data is synthetic. Every figure below validates the method and its checks, not the
performance of any real property.

---

## 1. The two KPIs

The decision-maker is the Purchasing & Receiving Manager at an independent seasonal
resort. Each Monday she can review **k** vendors — about 4 in peak season, up to 12
off-peak — out of roughly 44 with recent deliveries. She is choosing which vendors to
review, and which to start qualifying alternates for. Two quantities decide that, and
they are different questions requiring different models.

### KPI 1 — Probability of a material vendor failure next week

**What it measures.** For one vendor in one week, the chance that at least one material
failure occurs in the following week: a rejected delivery, a shortfall above the agreed
tolerance, or a late arrival beyond the coverage window. Measured per vendor-week, as of
that Monday, using only information available on that Monday.

**Why it matters to her.** Her constraint is attention, not money. She cannot review 44
vendors; she can review between 4 and 12, and the number is *smallest in peak season*,
when a failure costs most. A ranking of failure probability is what converts a list of 44
into a list of k. Without it, the list is built from last week's loudest complaint.

**How it supports the organisation.** Operationally it moves review effort from vendors
that are merely visible to vendors that are likely to fail. On the 2026 holdout the
ranked list captured **54.7%** of addressable next-week failure cost against **30.7%**
for current on-time-and-fill practice — on a fixed review budget, so the gain costs no
additional staff time.

### KPI 2 — Expected cost of a failure, given one occurs

**What it measures.** The dollar cost of a single material failure in a given week:
emergency purchase premium, lost contribution margin, guest compensation and
firefighting labour, summed. It is a *conditional* quantity — the cost if a failure
happens, not the cost expected on average.

**Why it matters to her.** Probability alone ranks badly when consequences differ. A
produce vendor failing in a 95%-occupancy banquet week is not equivalent to the same
failure in a quarter-full February. Multiplying the two KPIs gives expected dollars,
which is the quantity that makes vendors in different categories and weeks comparable on
one list.

**How it supports the organisation.** Financially it ties the review queue to money at
risk rather than event counts, and it is what justifies the effort: the tool reports
dollars captured, not failures flagged. It is also what makes the seasonal story
operational — the same failure genuinely costs more when the hotel is full, so the
ranking shifts with occupancy without anyone re-tuning it.

**Why two KPIs and not one.** They are modelled separately on purpose. Probability is
estimated first and cost applied afterwards, following Elkan (2001): fitting a single
model to expected cost would let large-dollar weeks dominate the fit and corrupt the
probability estimate, which is the part that must stay calibrated.

---

## 2(a). Predictors, and why each is relevant

### KPI 1 — failure probability

| Predictor | Why it belongs |
|---|---|
| **Deliveries per week** (13-week average, logged) | Exposure. Each delivery is an opportunity to fail, so a vendor delivering three times a week has more chances than one delivering monthly. Including it is what stops the model mistaking "delivers often" for "unreliable". |
| **Rejection rate, last 4 weeks** | Recent quality. The only input carrying vendor-specific deterioration — what a corrective action is meant to change. |
| **Rejection rate, last 13 weeks** | Longer-run quality, to separate a bad month from a bad vendor. |
| **Category** (7 levels) | Perishability and coverage differ sharply by category; produce fails on a different clock from MRO supplies. |
| **Vendor identity** (random intercept, shrunk) | Whatever is left of a vendor's own record once category is accounted for, shrunk toward its category so thin histories are not over-read. |

Deliberately excluded: the manager's own open corrective actions and any field derived
from the counterfactual table. Including her past decisions would let the model learn her
habits rather than vendor behaviour, and would make the evaluation circular. Adding the
open-corrective-action flag was tested and changed AUC by 0.000.

### KPI 2 — cost of a failure

| Predictor | Why it belongs |
|---|---|
| **Occupancy that week** | Demand drives the size of the service recovery — more covers affected, more rooms exposed. |
| **Banquet flag** | A failure during a banquet week hits a contracted, high-visibility event, so guest compensation is larger and less avoidable. |

Both are known in advance — occupancy on the books and banquet orders are confirmed well
before the week starts — so the cost model uses no information the manager lacks on
Monday.

---

## 3(a). Predictor importance and contributions

The app distinguishes two different questions, on two different screens, because
conflating them is the usual way an explanation panel misleads.

### Overall importance — *Model performance* tab

Mean absolute contribution of each input across all 6,978 training vendor-weeks, on the
log-hazard scale. This describes the model's general behaviour.

| Predictor | Mean abs. contribution |
|---|---|
| Category | 1.295 |
| Deliveries per week | 0.306 |
| Vendor identity | 0.151 |
| Rejection rate, last 4 weeks | 0.051 |
| Rejection rate, last 13 weeks | 0.0002 |

### Contributions to one prediction — *What-if forecast* tab

The forecast on screen is decomposed from a reference vendor-week (every input at its
training average) down to this specific one. For Produce 002 in week 2026-W26:

| Step | Contribution | Running chance |
|---|---|---|
| Reference vendor-week | — | 1.6% |
| Category: Produce | +1.61 | 7.8% |
| This vendor specifically | +0.31 | 10.5% |
| Deliveries per week | +0.45 | 16.0% |
| Rejection rate, last 4 weeks | +0.21 | 19.4% |
| Rejection rate, last 13 weeks | +0.00 | 19.4% |
| **This vendor-week, all terms added** | **+2.59** | **19.4%** |

The reference vendor-week sits at 1.6%, below the 4.6% overall failure rate, because it
averages the inputs on the log-hazard scale: most vendor-weeks are low-risk and a few
high-risk ones pull the average chance up. The walk still closes exactly on the
forecast the app shows (19.4%).

### Why these are exact rather than approximated

The forecast is a complementary log-log GLM, so it is **linear in its link**. For a model
linear in the link, the Shapley value of input *j* is exactly

```
phi_j = beta_j * (x_j - mean_j)
```

There is no sampling, no kernel approximation, and no background dataset to choose and
defend — the three things that make tree-SHAP results arguable.
`code/14_add_explanations.py` verifies this rather than asserting it: it checks that the
standardisation really is centred on the training mean (a property of how the scaler was
fitted, not an assumption), then confirms the decomposition closes on **every one of the
6,978 training rows**, worst residual **2×10⁻¹⁵**.

Contributions add exactly on the log-hazard scale only. The running-chance column walks
the same path in probability terms, in a stated order; probabilities do not add, so that
column is one route to the number rather than a ranking.

---

## 3(b). What the contributions mean, in context

Effect of a typical change in each input, as a multiplier on a vendor's weekly failure
rate, with 95% intervals:

| Change | Rate multiplier | Reading |
|---|---|---|
| Deliveries per week **+10%** | **1.03** [1.00, 1.06] | Busier vendors fail somewhat more often, far less than in proportion. If failures simply scaled with deliveries this would be 1.10; the estimated elasticity is 0.30 [0.01, 0.59] and proportional scaling is rejected at z = −4.7. This is the single most consequential finding about the model's structure. |
| Rejection rate, last 4 weeks **+5 points** | **1.29** [1.08, 1.55] | The one input carrying genuine vendor-specific signal. A vendor whose recent rejections rise five points is about 29% more likely to fail next week. The interval excludes 1.00, so the direction is established even though the magnitude is loose. |
| Rejection rate, last 13 weeks **+5 points** | **1.00** [0.67, 1.50] | No detectable effect once the 4-week rate is known. Retained because dropping it changed nothing, and removing an input after seeing the holdout would overstate how well the model was specified in advance. |

**Direction and magnitude in practice.** Category is the largest contributor by a wide
margin — about four times the next input. That is an honest limitation, not a feature: it
means the model mostly knows that produce is riskier than linen, and knows relatively
little about which produce vendor is in trouble. The 4-week rejection rate is the only
input that moves a vendor away from its category, and it moves it modestly.

**None of this is causal.** These are associations learned from observational history.
A contribution of +0.37 from the 4-week rejection rate says that vendors with that
history have had higher failure rates in this dataset. It does **not** say that reducing
rejections would reduce failures, and the app says so on both panels. The what-if screen
is explicitly labelled as the model's arithmetic under changed inputs, not a forecast of
what an intervention would achieve.

---

## 3(c), 3(d). What-if and automatic summaries

The what-if screen was already in place before this round: changing deliveries, either
rejection rate, an all-vendor failure-rate shift or the cost of a failure re-scores the
vendor in the browser, with intervals on every figure and a clearly labelled baseline
("= No change against the recorded values").

Added this round: a **scenario summary** that rewrites itself on every input change,
covering the four required elements —

1. **The scenario inputs** — each changed input with its before and after value.
2. **The updated prediction** — with its interval at the chosen confidence level.
3. **The change from baseline** — in absolute and relative terms, and explicitly stating
   when an input moved but the prediction did not.
4. **Implications and limits** — where the vendor now lands on that week's review list
   and whether it survives at the low end of its interval; plus any extrapolation beyond
   the trained range, the zero-failure categories, and a standing note that this is model
   arithmetic rather than a prediction about an intervention.

---

## 4. Progress report

**Where the project stands.** The application is complete and runs offline from a single
HTML file. Data generation, validation, modelling, evaluation and the app build are
automated in `code/run_all.sh` (about 40 seconds end to end). Two independent clean runs
produce all eight derived files byte-identical.

**Completed by week 10**

- Weeks 5–6: decision framing, data plan, blueprint for the screens.
- Weeks 7–8: synthetic data generation and a 52-check validation suite.
- Week 9: first prototype — ranked weekly queue and vendor detail panel.
- Week 10: two predictive models, fitted on 2023–2025 and scored once on a 2026 holdout;
  three application screens; predictor importance and per-prediction contributions;
  automatic scenario summaries.

**What the holdout shows.** The ranked list captured 54.7% [42.9, 65.7] of addressable
next-week failure cost against 30.7% for current practice — a gain of +23.9 points
[11.4, 36.6]. AUC 0.749 [0.715, 0.786].

**Known limitations, stated rather than managed around**

1. The data is synthetic. Results validate the method, not real-world performance.
2. Most of the skill is category and volume structure. Against ranking by delivery volume
   alone the gain is +4.1 points [−2.3, +11.6] — not distinguishable from zero.
3. 2026 ran 26% above forecast; the drift monitor first left its band in week 22.
4. Weekly dollar intervals covered 71% of weeks against a nominal 80%.
5. Individual-vendor deterioration is weak: about 83% of scored vendor-weeks have a
   flawless 13-week on-time record, so there is little to detect.

**Corrected this round.** The gradient-boosting benchmark did not rebuild to the same
figures on every machine. Debra's rebuild gave **AUC 0.742** and **41.4%** cost capture;
the first package reported 0.743 and 43.0%. `run_all.sh` now pins `OMP_NUM_THREADS=1`,
which is the safe setting for a threaded learner. A rebuild in a second environment
(scikit-learn 1.9.1) gives the same 0.742 and 41.4% at 1, 2, 3, 4 and 8 threads, so the
shift is better explained by the library build than by the thread count; the older
figure came from scikit-learn 1.8.0, which could not be reinstalled to confirm. Treat the
benchmark as depending on the library build, and the pin as harmless insurance. The tested
versions are listed in `requirements-tested.txt`. The conclusion is unchanged and slightly
strengthened: the interpretable model leads the boosted benchmark by 13.3 points of
cost capture, up from 11.7. The main model was never affected; its coefficients agree
across builds to 16 significant figures.

**Still open**

- A seven-minute demonstration video. A two-minute script and silent screen capture exist
  and cover the model-performance and what-if screens; both need extending to cover the
  new importance and contribution panels.
- The hosted copy is a private link. A shared folder or repository with instructor access
  is still required.

---

## 4. Contributions

**Mirza Ali** — Week 10 modelling and application. Built the as-of model table and
validation, specified and fitted the complementary log-log GLM with partial pooling,
tested and rejected the exposure offset, ran the holdout evaluation with its baselines,
calibration, interval coverage and drift monitor, built all three application screens and
the browser test suite, and wrote the one-page report and the research notes.

**Debra Senteu** — Weeks 5–9 foundations and week 10 explanation layer. Led the decision
framing, data plan and validation design in weeks 5–8, and the first prototype in week 9.
For week 10: reviewed the submitted package against the assignment, identified and fixed
the reproducibility defect in the benchmark, specified and built the predictor-importance
and per-prediction contribution panels with their exactness proof, built the automatic
scenario summaries, and wrote this document.
