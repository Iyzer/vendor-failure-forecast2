# Change log

## v3 (26 Oct 2026) — Mirza, after reviewing Debra's package

Checked Debra's package against the first submission before changing anything: her rebuild
reproduced exactly (all derived files, her gradient-boosting figures of 0.742 and 41.4%, the
decomposition residual of 2e-15, and the app's JavaScript against the Python model to 1e-7).

**Changed**

- Reference-vendor-week label in the contribution panel. It used to say "average training
  vendor-week" at 1.6%, which read as contradicting the 4.6% overall failure rate. It now
  says why they differ (the walk averages inputs on the log-hazard scale).
- Scenario summary gained an expected-cost line, so both KPIs (chance of a failure, cost of
  a failure) are stated in the summary, not only on the cards.
- `docs/Week10_KPIs_and_Progress.md`: worked example corrected to the figures the app shows
  (4-week rejection term +0.21, running chance 19.4%, total +2.59); reproducibility paragraph
  reworded to what was and was not established.
- One-page report: boosted-trees benchmark updated to 2026 AUC 0.742 and 41% of cost.
- README: reproducibility wording, private-link note, placeholder for the shared repository.
- Added `requirements-tested.txt`.
- QA scripts and the video capture script read the browser path from `CHROMIUM_PATH` when set.

**Not changed:** the model, the data, the evaluation, or any holdout figure other than the
boosted-trees benchmark.

## v2 — Debra

Pinned `OMP_NUM_THREADS=1` in `run_all.sh`; added predictor importance, per-prediction
contributions with an exactness check (`code/14_add_explanations.py`, `app/src/04b_explain.js`),
automatic scenario summaries, and `docs/Week10_KPIs_and_Progress.md`.

## v1 — Mirza

First Week 10 package: model, evaluation, three-screen app, report, video script.
