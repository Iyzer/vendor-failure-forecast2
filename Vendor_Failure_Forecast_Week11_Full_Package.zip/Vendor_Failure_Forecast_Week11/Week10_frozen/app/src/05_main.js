/* ------------------------------------------------------------------ shell: tabs, resize, parity hooks */
const VIEWS = ['performance', 'whatif', 'weekly'];
let ACTIVE = 'performance';
function showView(name) {
  if (!VIEWS.includes(name)) name = 'performance';
  ACTIVE = name; hideTip();
  VIEWS.forEach(v => { $('#view-' + v).hidden = v !== name; });
  $$('.tab').forEach(t => { const on = t.dataset.view === name; t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; });
  redraw();
  try { history.replaceState(null, '', '#' + name); } catch (e) { /* sandboxed frame: ignore */ }
}
function redraw() {
  if (ACTIVE === 'performance') drawPerfCharts();
  else if (ACTIVE === 'whatif') wiRender();
  else wkRender();
}
function initShell() {
  $$('.tab').forEach(t => {
    t.addEventListener('click', () => { showView(t.dataset.view); window.scrollTo(0, 0); });
    t.addEventListener('keydown', e => {
      const i = VIEWS.indexOf(t.dataset.view);
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        const n = VIEWS[(i + (e.key === 'ArrowRight' ? 1 : VIEWS.length - 1)) % VIEWS.length];
        showView(n); $('#tab-' + n).focus(); e.preventDefault();
      }
    });
  });
  let timer = null, lastW = 0;
  const onSize = () => { const w = document.body.clientWidth; if (w === lastW) return; lastW = w; clearTimeout(timer); timer = setTimeout(redraw, 80); };
  if ('ResizeObserver' in window) new ResizeObserver(onSize).observe(document.body); else window.addEventListener('resize', onSize);
}

/* parity hooks: the QA step replays Python's numbers through the same functions the screens use */
function parityReport() {
  let maxP = 0, maxEta = 0, maxSe = 0, maxLo = 0, maxHi = 0;
  D.parity.forEach(c => {
    const f = forecast(c.vendor, c.expo, c.rej4, c.rej13, 0, 1.2816);
    maxEta = Math.max(maxEta, Math.abs(f.eta - c.eta)); maxSe = Math.max(maxSe, Math.abs(f.se - c.se)); maxP = Math.max(maxP, Math.abs(f.p - c.p));
    maxLo = Math.max(maxLo, Math.abs(f.lo - c.lo80)); maxHi = Math.max(maxHi, Math.abs(f.hi - c.hi80));
  });
  let maxRow = 0;
  D.parity_rows.forEach(r => {
    const vi = D.vendors.findIndex(v => v.id === r.v), wi = weekIndex[r.w], rec = recorded(wi, vi);
    if (!rec) { maxRow = Infinity; return; }
    maxRow = Math.max(maxRow, Math.abs(forecast(vi, rec.expo, rec.rej4, rec.rej13, 0, 1.2816).p - r.p));
  });
  return { cases: D.parity.length, rows: D.parity_rows.length, maxEta, maxSe, maxP, maxLo, maxHi, maxRow };
}
window.__vr = { D, forecast, weekScores, weekSimulation, costMean, parityReport, WI, WK, showView, wiRender, wkRender, RQ };

try {
  renderPerfStatic(); renderImportance(); initWhatIf(); initWeekly();
  const h = (location.hash || '').replace('#', '');
  initShell(); showView(VIEWS.includes(h) ? h : 'performance');
} catch (err) {
  console.error(err);
  const box = document.createElement('div'); box.className = 'limits'; box.style.margin = '16px';
  box.innerHTML = '<h3>The page could not start</h3><p>' + esc(err && err.message || err) + '</p>'; document.body.prepend(box);
}
