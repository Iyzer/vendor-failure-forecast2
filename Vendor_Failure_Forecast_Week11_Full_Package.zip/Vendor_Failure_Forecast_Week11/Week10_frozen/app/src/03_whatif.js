/* ------------------------------------------------------------------ SCREEN 2: what-if forecast with uncertainty */
const WI = { wi: weekIndex['2026-W26'] ?? 25, vi: 0, expo: 1, rej4: 0, rej13: 0, shift: 0, cost: 0, level: 80, rec: null };

function wiVendorOptions() {
  const sel = $('#wi-vendor'), sc = weekScores(WI.wi), keep = WI.vi;
  let html = '';
  D.cats.forEach((c, ci) => {
    html += `<optgroup label="${esc(D.cat_labels[ci])}">`;
    D.vendors.forEach((v, vi) => {
      if (v.cat !== ci) return;
      const s = sc[vi];
      html += `<option value="${vi}">${esc(v.name)} · ${s ? pct(s.p, 1) : 'not scored'}</option>`;
    });
    html += '</optgroup>';
  });
  sel.innerHTML = html; sel.value = String(keep);
}
function wiWeekMeta() {
  const w = D.weeks[WI.wi];
  $('#wi-week-meta').textContent = `${w.season} season · occupancy ${pct(w.occ, 0)}${w.banq ? ' · banquet week' : ''} · review capacity ${w.k} vendors`;
}
function wiSliderSetup() {
  const v = D.vendors[WI.vi], rg = D.ranges[D.cats[v.cat]], rec = WI.rec;
  const S = { expo: $('#s-expo'), rej4: $('#s-rej4'), rej13: $('#s-rej13') };
  const eMin = Math.max(0.05, Math.floor(rg.expo[0] * 0.5 * 20) / 20), eMax = Math.ceil(rg.expo[1] * 1.6 * 10) / 10;
  Object.assign(S.expo, { min: eMin, max: eMax, step: eMax > 4 ? 0.1 : 0.05, disabled: !rec });
  Object.assign(S.rej4, { min: 0, max: 0.3, step: 0.005, disabled: !rec });
  Object.assign(S.rej13, { min: 0, max: 0.3, step: 0.005, disabled: !rec });
  const seen = (a, b, f) => `<span>${f(a)}</span><span>usual range up to ${f(b)}</span>`;
  $('#n-expo').innerHTML = `<span>${eMin}</span><span>usual range ${rg.expo[0]} to ${rg.expo[1]}</span><span>${eMax}</span>`;
  $('#n-rej4').innerHTML = seen(0, rg.rej4[1], x => pct(x, 1));
  $('#n-rej13').innerHTML = seen(0, rg.rej13[1], x => pct(x, 1));
  $('#s-shift').disabled = !rec; $('#s-cost').disabled = !rec;
}
function wiLoadRecorded() {
  WI.rec = recorded(WI.wi, WI.vi);
  if (WI.rec) { WI.expo = WI.rec.expo; WI.rej4 = WI.rec.rej4; WI.rej13 = WI.rec.rej13; }
  wiSliderSetup(); wiSyncSliders();
}
function wiSyncSliders() {
  $('#s-expo').value = WI.expo; $('#s-rej4').value = WI.rej4; $('#s-rej13').value = WI.rej13; $('#s-shift').value = Math.round(WI.shift * 100);
  $('#v-expo').textContent = WI.rec ? WI.expo.toFixed(2) + ' / wk' : '—';
  $('#v-rej4').textContent = WI.rec ? pct(WI.rej4, 1) : '—';
  $('#v-rej13').textContent = WI.rec ? pct(WI.rej13, 1) : '—';
  $('#v-shift').textContent = (WI.shift >= 0 ? '+' : '−') + Math.abs(Math.round(WI.shift * 100)) + '%';
  $('#s-cost').value = Math.round(WI.cost * 100);
  $('#v-cost').textContent = (WI.cost >= 0 ? '+' : '−') + Math.abs(Math.round(WI.cost * 100)) + '%';
}
const shiftToEta = s => Math.log(1 + s);           // a +26% change in the failure rate is +0.231 on the log-hazard scale

function wiSeries(kind, n = 41) {
  const lo = Number((kind === 'expo' ? $('#s-expo') : $('#s-rej4')).min), hi = Number((kind === 'expo' ? $('#s-expo') : $('#s-rej4')).max), pts_ = [];
  for (let i = 0; i < n; i++) {
    const x = lo + (hi - lo) * i / (n - 1);
    pts_.push(Object.assign({ x }, forecast(WI.vi, kind === 'expo' ? x : WI.expo, kind === 'rej' ? x : WI.rej4, WI.rej13, shiftToEta(WI.shift), Z[WI.level])));
  }
  return pts_;
}

function drawSensitivity(el, kind) {
  const w = chartWidth(el); if (!w || !WI.rec) { if (el) el.innerHTML = '<p class="muted small">Not scored this week.</p>'; return; }
  const h = 230, m = { l: 44, r: 14, t: 12, b: 38 }, S = wiSeries(kind), v = D.vendors[WI.vi], rg = D.ranges[D.cats[v.cat]];
  const seenLo = kind === 'expo' ? rg.expo[0] : 0, seenHi = kind === 'expo' ? rg.expo[1] : rg.rej4[1];
  const ymax = niceMax(Math.max(...S.map(d => d.hi)) * 1.05), X = linScale(S[0].x, S[S.length - 1].x, m.l, w - m.r), Y = linScale(0, ymax, h - m.b, m.t);
  const fmtX = kind === 'expo' ? (x => x.toFixed(1)) : (x => pct(x, 0));
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Forecast chance against ${kind === 'expo' ? 'deliveries per week' : '4-week rejection rate'}, with interval">`;
  for (let i = 0; i <= 4; i++) { const t = ymax * i / 4; s += `<line class="gridline" x1="${m.l}" x2="${w - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${pct(t, t < 0.1 ? 1 : 0)}</text>`; }
  for (let i = 0; i <= 4; i++) { const x = S[0].x + (S[S.length - 1].x - S[0].x) * i / 4; s += `<text x="${X(x)}" y="${h - 20}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${fmtX(x)}</text>`; }
  s += `<text class="t2" x="${(m.l + w - m.r) / 2}" y="${h - 4}" text-anchor="middle">${kind === 'expo' ? 'Deliveries per week (13-week average)' : 'Rejection rate, last 4 weeks'}</text>`;
  s += `<path d="${S.map((d, i) => (i ? 'L' : 'M') + X(d.x).toFixed(1) + ' ' + Y(d.hi).toFixed(1)).join('')}${S.slice().reverse().map(d => 'L' + X(d.x).toFixed(1) + ' ' + Y(d.lo).toFixed(1)).join('')}Z" fill="var(--accent)" opacity="0.2"/>`;
  s += `<path d="${S.map((d, i) => (i ? 'L' : 'M') + X(d.x).toFixed(1) + ' ' + Y(d.p).toFixed(1)).join('')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-dasharray="4 4" stroke-linejoin="round"/>`;
  const inside = S.filter(d => d.x >= seenLo - 1e-9 && d.x <= seenHi + 1e-9);
  if (inside.length > 1) s += `<path d="${inside.map((d, i) => (i ? 'L' : 'M') + X(d.x).toFixed(1) + ' ' + Y(d.p).toFixed(1)).join('')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>`;
  const recX = kind === 'expo' ? WI.rec.expo : WI.rec.rej4, curX = kind === 'expo' ? WI.expo : WI.rej4;
  const at = x => forecast(WI.vi, kind === 'expo' ? x : WI.expo, kind === 'rej' ? x : WI.rej4, WI.rej13, shiftToEta(WI.shift), Z[WI.level]);
  const rp = at(recX), cp = at(curX);
  s += `<circle cx="${X(recX)}" cy="${Y(rp.p)}" r="5" fill="var(--mute-mark)" stroke="var(--surface)" stroke-width="2"/>`;
  s += `<circle cx="${X(curX)}" cy="${Y(cp.p)}" r="6" fill="var(--alt)" stroke="var(--surface)" stroke-width="2"/>`;
  s += `<line class="cross" y1="${m.t}" y2="${h - m.b}" stroke="var(--ink-3)" stroke-width="1" style="display:none"/><rect class="hit" x="${m.l}" y="${m.t}" width="${w - m.l - m.r}" height="${h - m.t - m.b}" fill="transparent" style="touch-action:pan-y"/></svg>`;
  el.innerHTML = s;
  hoverSeries(el, w, X(S[0].x), X(S[S.length - 1].x), S.length, i => { const d = S[i], seen = d.x >= seenLo && d.x <= seenHi;
    return `<b>${kind === 'expo' ? d.x.toFixed(2) + ' deliveries / week' : pct(d.x, 1) + ' rejected'}</b>` + tipRow('Chance next week', pct(d.p, 1)) + tipRow(WI.level + '% interval', `${pct(d.lo, 1)} to ${pct(d.hi, 1)}`) + (seen ? '' : `<div style="color:var(--warn-ink);margin-top:3px">Beyond the usual range: extrapolated</div>`); });
}

function rankAmong(others, p) { let r = 1; for (const o of others) if (o > p) r++; return r; }

function wiRender() {
  const v = D.vendors[WI.vi], w = D.weeks[WI.wi], cat = D.cats[v.cat], ans = $('#wi-answer'), cards = $('#wi-cards'), notes = $('#wi-notes');
  if (!WI.rec) {
    ans.innerHTML = `<div class="label">${esc(v.name)} · ${esc(w.id)}</div><div class="big" style="font-size:26px">Not enough data to score</div><div class="line">This vendor had no deliveries in the 13 weeks before this Monday. The tool marks it "insufficient data" instead of treating missing history as zero risk. Pick another week or vendor.</div>`;
    cards.innerHTML = ''; notes.innerHTML = ''; $('#ch-s-expo').innerHTML = ''; $('#ch-s-rej').innerHTML = ''; $('#wi-queue').innerHTML = ''; $('#wi-queue-cap').textContent = ''; return;
  }
  const sh = shiftToEta(WI.shift), z = Z[WI.level];
  const f = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, sh, z), base = forecast(WI.vi, WI.rec.expo, WI.rec.rej4, WI.rec.rej13, 0, z);
  const dlt = f.p - base.p, dcls = Math.abs(dlt) < 0.0005 ? 'flat' : dlt > 0 ? 'up' : 'down', dic = dcls === 'flat' ? '=' : dlt > 0 ? '▲' : '▼';
  const per100 = f.p * 100, lo100 = f.lo * 100, hi100 = f.hi * 100, r0 = x => x < 10 ? x.toFixed(1).replace('.0', '') : Math.round(x);
  ans.innerHTML = `<div class="label">Chance of a material failure next week · ${esc(v.name)} · ${esc(w.id)}</div>
    <div class="big">${pct(f.p, 1)}<small>${WI.level}% interval ${pct(f.lo, 1)} to ${pct(f.hi, 1)}</small></div>
    <div class="line">About <b>${r0(per100)} in 100</b> weeks with these conditions end with a material failure at this vendor. We are ${WI.level}% sure the true figure lies between <b>${r0(lo100)}</b> and <b>${r0(hi100)}</b> in 100.</div>
    <div class="line"><span class="delta ${dcls}"><span aria-hidden="true">${dic}</span> ${dcls === 'flat' ? 'No change' : pts(dlt, 1) + ' points'}</span> against the recorded values (${pct(base.p, 1)}).${WI.shift ? ` Includes a ${WI.shift > 0 ? '+' : '−'}${Math.abs(Math.round(WI.shift * 100))}% shift in everyone's failure rate.` : ''}</div>`;

  const h4 = 4, hl = D.lead[v.cat], f4 = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, sh, z, h4), fl = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, sh, z, hl);
  const mu = costMean(WI.wi) * (1 + WI.cost), c10 = mu * RQ[10], c90 = mu * RQ[90];
  cards.innerHTML = [
    ['Over a corrective-action window', pct(f4.p, 0), `${h4} weeks · interval ${pct(f4.lo, 0)} to ${pct(f4.hi, 0)}`, 'Chance of at least one failure if conditions persist.'],
    ['Over an alternate’s lead time', pct(fl.p, 0), `${hl} weeks · interval ${pct(fl.lo, 0)} to ${pct(fl.hi, 0)}`, `Time to qualify a backup in ${esc(D.cat_labels[v.cat].toLowerCase())}.`],
    ['Expected cost next week', usd(f.p * mu), `interval ${usd(f.lo * mu)} to ${usd(f.hi * mu)}`, `If it does fail: about ${usd(mu)}; 80% of cases ${usd(c10)} to ${usd(c90)}.`]
  ].map(c => `<div class="card"><div class="k">${c[0]}</div><div class="v">${c[1]}</div><div class="r">${c[2]}</div><div class="r" style="color:var(--ink-3)">${c[3]}</div></div>`).join('');

  // where it lands on the week's list
  const sc = weekScores(WI.wi, sh), k = w.k;
  const others = []; sc.forEach((s, vi) => { if (s && vi !== WI.vi && s.cap === 0) others.push(s.p); });
  const held = WI.rec.cap === 1, rk = rankAmong(others, f.p), rkLo = rankAmong(others, f.lo), rkHi = rankAmong(others, f.hi);
  const N = [];
  if (held) N.push(['warn', '!', `This vendor already has an open corrective action in ${w.id}, so the weekly list would hold it out. The forecast above still applies.`]);
  else if (rkLo <= k) N.push(['', 'i', `<b>Review candidate.</b> It ranks ${rk} of ${others.length + 1} against a list of ${k}, and still ranks ${rkLo} at the low end of its interval.`]);
  else if (rk <= k) N.push(['warn', '!', `<b>Borderline.</b> It makes the list at the point estimate (rank ${rk} of ${others.length + 1}, list of ${k}) but would fall to rank ${rkLo} if the true risk is at the low end of the interval.`]);
  else if (rkHi <= k) N.push(['warn', '!', `<b>Watch.</b> It sits outside the list at the point estimate (rank ${rk}) but would reach rank ${rkHi} if the true risk is at the high end of the interval. A cheap precaution fits better than a corrective action.`]);
  else N.push(['', 'i', `<b>Outside the list</b> across the whole interval (rank ${rk}, best case ${rkHi}, list of ${k}).`]);
  if (ZCAP[cat] === undefined && f.lo > 0.002 && f.hi / f.lo > 2.5) N.push(['', 'i', `<b>The interval is wide</b> (its top is ${(f.hi / f.lo).toFixed(1)} times its bottom). The model cannot separate this vendor from its category average, so act on the cheap end of the interval for low-cost precautions and wait for the low end to clear the bar before costly ones such as qualifying an alternate.`]);
  const q = [];
  if (WI.expo < rg().expo[0] || WI.expo > rg().expo[1]) q.push(`deliveries per week (${WI.expo.toFixed(2)}; usual range ${rg().expo[0]} to ${rg().expo[1]})`);
  if (WI.rej4 > rg().rej4[1] + 1e-9) q.push(`4-week rejection rate (${pct(WI.rej4, 1)}; only 1% of this category's history was above ${pct(rg().rej4[1], 1)})`);
  if (WI.rej13 > rg().rej13[1] + 1e-9) q.push(`13-week rejection rate (${pct(WI.rej13, 1)}; only 1% of this category's history was above ${pct(rg().rej13[1], 1)})`);
  if (q.length) N.push(['crit', '!', `<b>Outside what the model has seen:</b> ${q.join('; ')}. The forecast is an extrapolation and the interval understates the real uncertainty.`]);
  if (WI.cost) N.push(['', 'i', `The cost change is a scenario you set (for example a price spike), not a forecast. Dollar figures scale with it; the dollar interval does not include any uncertainty about it.`]);
  if (WI.shift) N.push(['', 'i', `A shift multiplies every vendor's failure rate. It changes the level of risk and the dollars at stake but not the ranking. The 2026 value (+26%) was measured on the same weeks it describes, so treat it as a scenario, not a validated correction.`]);
  if (ZCAP[cat] !== undefined) { const nz = D.ranges[cat].n, up = 1 - Math.pow(0.05, 1 / nz); N.push(['warn', '!', `No failure was ever recorded in ${esc(D.cat_labels[v.cat])} (${nz.toLocaleString()} vendor-weeks of history), so the model has almost nothing to learn a rate from. What the data do rule out is a high rate: the exact 95% upper limit on the weekly chance is about ${pct(up, 1)}. Read it as "unknown, probably very low".`]); }
  notes.innerHTML = N.map(n => `<div class="note ${n[0]}"><span class="ic" aria-hidden="true">${n[1]}</span><span>${n[2]}</span></div>`).join('');

  drawSensitivity($('#ch-s-expo'), 'expo'); drawSensitivity($('#ch-s-rej'), 'rej');

  // list preview with the scenario inserted
  const rowsAll = []; sc.forEach((s, vi) => { if (s && vi !== WI.vi && s.cap === 0) rowsAll.push({ vi, p: s.p, scen: false }); });
  if (!held) rowsAll.push({ vi: WI.vi, p: f.p, scen: true });
  rowsAll.sort((a, b) => b.p - a.p);
  const showN = k + 3, idxScen = rowsAll.findIndex(r => r.scen);
  const view = rowsAll.slice(0, showN).map((r, i) => ({ ...r, rank: i + 1 }));
  if (idxScen >= showN) view.push({ ...rowsAll[idxScen], rank: idxScen + 1, gap: true });
  $('#wi-queue-cap').textContent = `${w.id} is a ${w.season} week with room to review ${k} vendors. ${held ? 'The chosen vendor is held out, so the list shown is the real one.' : 'Your scenario is highlighted; everyone else keeps their recorded values.'} Vendors under an open corrective action are not ranked.`;
  let tb = `<table><thead><tr><th class="n">#</th><th>Vendor</th><th class="hide-sm">Category</th><th class="n">Chance next week</th><th>Status</th></tr></thead><tbody>`;
  view.forEach((r, i) => {
    if (r.gap) tb += `<tr><td colspan="5" class="muted" style="text-align:center">…</td></tr>`;
    const vv = D.vendors[r.vi];
    tb += `<tr class="${r.scen ? 'sel' : ''}"><td class="n">${r.rank}</td><td>${esc(vv.name)}${r.scen ? ' <span class="pill in">your scenario</span>' : ''}</td><td class="hide-sm">${esc(D.cat_labels[vv.cat])}</td><td class="n">${pct(r.p, 1)}</td><td>${r.rank <= k ? '<span class="pill in">In list</span>' : '<span class="pill out">Not in list</span>'}</td></tr>`;
    if (r.rank === k && !r.gap) tb += `<tr class="capline"><td colspan="5"></td></tr>`;
  });
  $('#wi-queue').innerHTML = tb + '</tbody></table>';
  renderExplain();   // per-prediction contributions + the automatic scenario summary
}
const rg = () => D.ranges[D.cats[D.vendors[WI.vi].cat]];

function initWhatIf() {
  const wsel = $('#wi-week');
  wsel.innerHTML = D.weeks.map((w, i) => `<option value="${i}">${esc(weekLabel(w))} · ${w.season}</option>`).join('');
  wsel.value = String(WI.wi);
  // default vendor: the top-ranked eligible vendor of the default week
  const sc = weekScores(WI.wi); let best = -1, bp = -1;
  sc.forEach((s, vi) => { if (s && s.cap === 0 && s.p > bp) { bp = s.p; best = vi; } });
  WI.vi = Math.max(best, 0);
  wiVendorOptions(); wiWeekMeta(); wiLoadRecorded(); wiRender();

  wsel.addEventListener('change', () => { WI.wi = Number(wsel.value); wiVendorOptions(); wiWeekMeta(); wiLoadRecorded(); wiRender(); });
  $('#wi-vendor').addEventListener('change', e => { WI.vi = Number(e.target.value); wiLoadRecorded(); wiRender(); });
  const bind = (id, key, conv) => $(id).addEventListener('input', e => { WI[key] = conv(Number(e.target.value)); wiSyncSliders(); wiRender(); });
  bind('#s-expo', 'expo', x => x); bind('#s-rej4', 'rej4', x => x); bind('#s-rej13', 'rej13', x => x); bind('#s-shift', 'shift', x => x / 100); bind('#s-cost', 'cost', x => x / 100);
  $('#q-drift').addEventListener('click', () => { WI.shift = 0.26; wiSyncSliders(); wiRender(); });
  $('#wi-quick').addEventListener('click', e => {
    const b = e.target.closest('button[data-q]'); if (!b || (!WI.rec && b.dataset.q !== 'reset')) return;
    const q = b.dataset.q, ex = $('#s-expo');
    if (q === 'expo+25') WI.expo = Math.min(Number(ex.max), WI.expo * 1.25);
    if (q === 'rej+3') WI.rej4 = Math.min(0.3, WI.rej4 + 0.03);
    if (q === 'calm') { WI.rej4 = 0; WI.rej13 = 0; }
    if (q === 'reset') { WI.shift = 0; WI.cost = 0; wiLoadRecorded(); wiRender(); return; }
    wiSyncSliders(); wiRender();
  });
  $('#seg-level').addEventListener('click', e => {
    const b = e.target.closest('button[data-level]'); if (!b) return;
    WI.level = Number(b.dataset.level); $$('#seg-level button').forEach(x => x.setAttribute('aria-pressed', String(x === b))); wiRender();
  });
}
