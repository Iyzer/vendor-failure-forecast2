/* ------------------------------------------------------------------ SCREEN 1: model performance (2026 holdout, frozen model) */
const CAP_KEYS = [
  ['Model: expected cost (this tool)', 'This model', true],
  ['Spend proxy (delivery volume)', 'Rank by delivery volume', false],
  ['Gradient-boosted trees x cost', 'Boosted trees × cost', false],
  ['Current practice (on-time/fill + loud-failure override)', 'Current practice', false],
  ['Trailing rejection rate', 'Rank by recent rejections', false],
  ['Random', 'Random pick', false]
];

function renderPerfStatic() {
  const h = E.holdout, cap = E.capture, me = cap['Model: expected cost (this tool)'], cur = cap['Current practice (on-time/fill + loud-failure override)'];
  $('#perf-intro').textContent =
    `The model was fitted on 2023–2025 (${E.n_dev.toLocaleString()} scored vendor-weeks, ${E.pos_dev} next-week failures) and then frozen. ` +
    `It was scored once on 2026: ${E.n_val.toLocaleString()} vendor-weeks and ${E.pos_val} next-week failures it had never seen. ` +
    `Intervals come from resampling whole weeks, because vendors in the same week share the same shocks.`;
  const tiles = [
    { hero: true, v: pct(me.cost, 0), k: 'of next-week failure cost landed inside the weekly review list',
      d: `95% interval ${pct(me.cost_ci[0], 0)} to ${pct(me.cost_ci[1], 0)}. Today's rules: ${pct(cur.cost, 0)}.` },
    { v: h.glm.auc.toFixed(2), k: 'Ranking quality (AUC; 0.5 is a coin flip)',
      d: `95% interval ${h.ci.auc[0].toFixed(2)} to ${h.ci.auc[1].toFixed(2)}. Category averages alone: ${h.cat.auc.toFixed(2)}.` },
    { v: `${pct(h.calib.obs_rate)} <small>against ${pct(h.calib.pred_mean)} forecast</small>`, k: 'Failures ran above forecast in 2026',
      d: `${Math.exp(h.calib.shift).toFixed(2)}× the forecast rate. Calibration slope ${h.calib.slope.toFixed(2)} (ideal 1.00).` },
    { v: pct(E.weekly_count_cov80, 0), k: 'of weeks the real failure count fell inside the 80% interval',
      d: `For weekly dollars: ${pct(E.weekly_cost_cov80, 0)}. Both should be near 80%.` }
  ];
  $('#perf-tiles').innerHTML = tiles.map(t => `<div class="tile${t.hero ? ' hero' : ''}"><div class="v num">${t.v}</div><div class="k">${t.k}</div><div class="d">${t.d}</div></div>`).join('');

  // capture bars (HTML, interval whiskers)
  const rows = CAP_KEYS.map(([key, label, pick]) => {
    const c = cap[key], d = key.startsWith('Model') ? '' : `, model ${pts(c.model_minus_this_cost, 1)} points [${pts(c.model_minus_this_ci[0], 1)} to ${pts(c.model_minus_this_ci[1], 1)}]`;
    const tip = `<b>${label}</b>` + tipRow('Cost captured', pct(c.cost)) + tipRow('95% interval', `${pct(c.cost_ci[0], 0)} to ${pct(c.cost_ci[1], 0)}`) + tipRow('Failures captured', pct(c.count, 0));
    return `<div class="brow wide${pick ? ' pick' : ''}" data-tip="${esc(tip)}"><span>${label}</span><div class="track"><div class="fill" style="width:${c.cost * 100}%"></div><span class="ci" style="left:${c.cost_ci[0] * 100}%;width:${(c.cost_ci[1] - c.cost_ci[0]) * 100}%"></span></div><span class="nv">${pct(c.cost, 0)}<span class="ci-txt"> [${(c.cost_ci[0] * 100).toFixed(0)}–${(c.cost_ci[1] * 100).toFixed(0)}]</span></span></div>`;
  });
  $('#ch-capture').innerHTML = `<div class="bars">${rows.join('')}</div><p class="small muted" style="margin-top:8px">Perfect hindsight would capture 100%. Addressable cost is ${pct(E.addressable_share, 0)} of the ${usd(E.cost_total_actual)} that 2026 failures cost the following week; the rest sat at vendors already under corrective action. Average list size ${E.mean_k.toFixed(1)} of about 44 eligible vendors.</p>`;
  bindTips($('#ch-capture'));
  $('#tb-capture').innerHTML = table(['Method', 'Cost captured', '95% interval', 'Failures captured', 'Model minus this'],
    CAP_KEYS.map(([key, label]) => { const c = cap[key]; return [label, pct(c.cost), `${pct(c.cost_ci[0], 0)} to ${pct(c.cost_ci[1], 0)}`, pct(c.count, 0), key.startsWith('Model') ? '—' : `${pts(c.model_minus_this_cost)} pts [${pts(c.model_minus_this_ci[0])} to ${pts(c.model_minus_this_ci[1])}]`]; }), [1, 3]);

  // reliability table
  $('#tb-rel').innerHTML = table(['Group', 'Vendor-weeks', 'Forecast', 'Observed', '95% interval'],
    h.reliability.map(r => [r.bin, r.n, pct(r.pred, 2), pct(r.obs, 2), `${pct(r.lo, 1)} to ${pct(r.hi, 1)}`]), [0, 1, 2, 3]);

  // weekly series caption + table
  const wc = E.weekly_counts, outside = wc.filter(w => w.actual < w.lo || w.actual > w.hi).length;
  $('#cap-week').textContent = `Each column is one 2026 week. The line is the expected number of vendors with a material failure the following week; the shaded bar is the 80% predictive interval; the dot is what happened. The real count was outside the interval in ${outside} of ${wc.length} weeks (${pct(outside / wc.length, 0)}); the ideal is about 20%. Totals: ${Math.round(wc.reduce((t, w) => t + w.expected, 0))} expected failures, ${wc.reduce((t, w) => t + w.actual, 0)} actual.`;
  $('#tb-week').innerHTML = table(['Week', 'Season', 'Expected', '80% interval', 'Actual', 'Expected cost', 'Actual cost'],
    wc.map(w => [w.week.replace('2026-', ''), D.weeks[weekIndex[w.week]].season, w.expected.toFixed(1), `${w.lo}–${w.hi}`, w.actual, usd(w.exp_cost), usd(w.actual_cost)]), [2, 3, 4, 5, 6]);

  // drift
  const oe = E.oe, first = oe.findIndex(o => o.oe > 1.25 || o.oe < 0.8), last = oe[oe.length - 1];
  $('#cap-drift').textContent = `Observed failures divided by what the frozen model expected, over a rolling 26 weeks. The ratio first left the 0.80–1.25 band in ${first >= 0 ? oe[first].week.replace('2026-', '') : 'no week'} and ended the year at ${last.oe.toFixed(2)}. A refit at each quarter start would have lowered log-loss only from ${E.refit.frozen.logloss.toFixed(4)} to ${E.refit.quarterly.logloss.toFixed(4)}.`;
  const lab = Object.fromEntries(D.cats.map((c, i) => [c, D.cat_labels[i]]));
  $('#tb-drift').innerHTML = table(['Category', '2023–25 rate', '2026 forecast', '2026 actual', 'Failures', 'Vendor-weeks'],
    E.catdrift.map(c => [lab[c.category], pct(c.dev_rate), pct(c.val_pred), pct(c.val_rate), c.val_fail, c.val_n]), [1, 2, 3, 4, 5]);

  // benchmarks
  const b = E.bench, f3 = x => x == null ? '—' : x.toFixed(3);
  const brow = (name, o, note) => [name + (note ? ` <span class="muted small">${note}</span>` : ''), f3(o.auc), f3(o.ap), o.brier == null ? '—' : o.brier.toFixed(4), o.logloss == null ? '—' : o.logloss.toFixed(4)];
  $('#tb-bench').innerHTML = table(['Method', 'AUC', 'Avg precision', 'Brier', 'Log-loss'], [
    brow('<b>This model</b>', b['GLM (this model)']),
    brow('Gradient-boosted trees', b['Gradient-boosted trees']),
    brow('Category average only', b['Category base rate']),
    brow('Delivery volume', b['Delivery volume (spend proxy)']),
    brow('Today’s on-time and fill score', b['Trailing on-time + fill (current practice score)']),
    brow('13-week rejection rate', b['Trailing 13-wk rejection rate']),
    brow('4-week rejection rate', b['Trailing 4-wk rejection rate']),
    brow('This model plus open-corrective-action flag', b['GLM + open-CAP flag (excluded by S7)'], 'excluded by design, adds nothing')
  ], [1, 2, 3, 4]);

  // effects note + limits
  const e0 = D.effects[0];
  $('#eff-note').textContent = `If failures simply scaled with deliveries the first row would sit at ${(1.10).toFixed(2)}. It is ${e0.est.toFixed(2)}: busier vendors fail somewhat more often, far less than in proportion (estimated elasticity ${E.offset_check.g.toFixed(2)}, interval ${(E.offset_check.g - 1.96 * E.offset_check.se).toFixed(2)} to ${(E.offset_check.g + 1.96 * E.offset_check.se).toFixed(2)}, against 1.00 for proportional).`;
  const pr = E.catdrift.find(c => c.category === 'protein'), dd = E.holdout.ci.d_brier;
  const vol = cap['Spend proxy (delivery volume)'];
  $('#limits-list').innerHTML = [
    `<b>The data is synthetic.</b> It demonstrates the method and its checks. It says nothing about how a real property would score.`,
    `<b>Most of the skill is structure.</b> Against a forecast that only knows each category's average failure rate, the Brier score moves by ${(h.glm.brier - h.cat.brier).toFixed(5)} (interval ${dd[0].toFixed(4)} to ${dd[1] >= 0 ? '+' : ''}${dd[1].toFixed(4)}), and the weekly list captures about as much cost as ranking by delivery volume (${pts(vol.model_minus_this_cost)} points, interval ${pts(vol.model_minus_this_ci[0])} to ${pts(vol.model_minus_this_ci[1])}). The clear gain is over today's rules: ${pts(cur2().model_minus_this_cost)} points, interval ${pts(cur2().model_minus_this_ci[0])} to ${pts(cur2().model_minus_this_ci[1])}.`,
    `<b>2026 drifted.</b> Failures ran ${((Math.exp(h.calib.shift) - 1) * 100).toFixed(0)}% above forecast, led by protein (${pct(pr.val_rate)} against ${pct(pr.val_pred)} forecast). Weekly dollar intervals covered ${pct(E.weekly_cost_cov80, 0)} of weeks, not 80%. Treat the drift monitor as part of the tool.`,
    `<b>Little individual-vendor signal.</b> Most scored vendor-weeks have a flawless 13-week on-time record, so there is little deterioration to read. Only the 4-week rejection rate earned a place as a predictor.`,
    `<b>MRO supplies never failed</b> in three years of data. Their forecast is almost all prior; read a wide interval there as "unknown, probably low".`,
    `<b>Intervals are conditional on the model.</b> They reflect uncertainty in the fitted coefficients, not a wrong model, inputs outside the trained range (the What-if screen flags those), or a regime change.`
  ].map(t => `<li>${t}</li>`).join('');
}
const cur2 = () => E.capture['Current practice (on-time/fill + loud-failure override)'];

/* ------------------------------------------------------------------ charts that depend on width */
function hoverSeries(el, svgW, x0, x1, n, tipFn) {
  const svg = el.querySelector('svg'), cross = svg.querySelector('.cross'), hit = svg.querySelector('.hit');
  if (!hit) return;
  const move = ev => {
    const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) * (svgW / r.width);
    const i = clamp(Math.round((px - x0) / (x1 - x0) * (n - 1)), 0, n - 1), cx = x0 + (x1 - x0) * i / (n - 1);
    cross.setAttribute('x1', cx); cross.setAttribute('x2', cx); cross.style.display = '';
    showTip(tipFn(i), ev);
  };
  hit.addEventListener('pointermove', move); hit.addEventListener('pointerdown', move);
  hit.addEventListener('pointerleave', () => { cross.style.display = 'none'; hideTip(); });
}

function drawReliability() {
  const el = $('#ch-rel'), w = chartWidth(el); if (!w) return;
  const h = Math.min(Math.max(w * 0.9, 260), 340), m = { l: 48, r: 14, t: 10, b: 40 }, rel = E.holdout.reliability, MAXV = 0.25;
  const sq = Math.sqrt, X = linScale(0, sq(MAXV), m.l, w - m.r), Y = linScale(0, sq(MAXV), h - m.b, m.t);
  const ticks = [0, 0.01, 0.05, 0.1, 0.2];
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Reliability diagram: forecast against observed failure share by decile">`;
  for (const t of ticks) {
    s += `<line class="gridline" x1="${m.l}" x2="${w - m.r}" y1="${Y(sq(t))}" y2="${Y(sq(t))}"/><text x="${m.l - 8}" y="${Y(sq(t)) + 4}" text-anchor="end">${(t * 100).toFixed(0)}%</text>`;
    s += `<text x="${X(sq(t))}" y="${h - m.b + 16}" text-anchor="middle">${(t * 100).toFixed(0)}%</text>`;
  }
  s += `<line class="axisline" x1="${m.l}" x2="${w - m.r}" y1="${Y(0)}" y2="${Y(0)}"/>`;
  s += `<line x1="${X(0)}" y1="${Y(0)}" x2="${X(sq(MAXV))}" y2="${Y(sq(MAXV))}" stroke="var(--axis)" stroke-width="1.5" stroke-dasharray="5 4"/>`;
  s += `<text class="t2" x="${(m.l + w - m.r) / 2}" y="${h - 6}" text-anchor="middle">Forecast chance of failure next week</text>`;
  s += `<text class="t2" transform="translate(12 ${(m.t + h - m.b) / 2}) rotate(-90)" text-anchor="middle">Observed share that failed</text>`;
  rel.forEach(r => {
    const cx = X(sq(r.pred)), yl = Y(sq(Math.min(r.lo, MAXV))), yh = Y(sq(Math.min(r.hi, MAXV)));
    const tip = `<b>Group ${r.bin} of 10</b>` + tipRow('Vendor-weeks', r.n) + tipRow('Forecast', pct(r.pred, 1)) + tipRow('Observed', pct(r.obs, 1)) + tipRow('95% interval', `${pct(r.lo, 1)} to ${pct(r.hi, 1)}`);
    s += `<g class="mark-hit" data-tip="${esc(tip)}"><line x1="${cx}" x2="${cx}" y1="${yl}" y2="${yh}" stroke="var(--ink-3)" stroke-width="1.5"/><line x1="${cx - 4}" x2="${cx + 4}" y1="${yl}" y2="${yl}" stroke="var(--ink-3)" stroke-width="1.5"/><line x1="${cx - 4}" x2="${cx + 4}" y1="${yh}" y2="${yh}" stroke="var(--ink-3)" stroke-width="1.5"/>`;
    s += `<circle cx="${cx}" cy="${Y(sq(r.obs))}" r="5" fill="var(--accent)" stroke="var(--surface)" stroke-width="2"/><rect x="${cx - 12}" y="${Math.min(yh, yl) - 4}" width="24" height="${Math.abs(yl - yh) + 8}" fill="transparent"/></g>`;
  });
  el.innerHTML = s + '</svg>'; bindTips(el);
}

function drawWeekChart() {
  const el = $('#ch-week'), w = chartWidth(el); if (!w) return;
  const wc = E.weekly_counts, n = wc.length, h = 250, m = { l: 34, r: 12, t: 12, b: 28 };
  const ymax = Math.max(4, ...wc.map(d => Math.max(d.hi, d.actual))) + 1;
  const X = i => m.l + (w - m.l - m.r) * (i + 0.5) / n, Y = linScale(0, ymax, h - m.b, m.t);
  const step = (w - m.l - m.r) / n;
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Weekly count of failing vendors, forecast interval against actual">`;
  peakRuns().forEach(([a, b]) => {
    if (a >= n) return; const x0 = m.l + step * a, x1 = m.l + step * Math.min(b + 1, n);
    s += `<rect x="${x0}" y="${m.t}" width="${x1 - x0}" height="${h - m.t - m.b}" fill="var(--surface-2)"/><text x="${(x0 + x1) / 2}" y="${m.t + 12}" text-anchor="middle">Peak</text>`;
  });
  for (let t = 0; t <= ymax; t += ymax > 8 ? 2 : 1) s += `<line class="gridline" x1="${m.l}" x2="${w - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${t}</text>`;
  monthTicks(wc.map(d => d.week)).forEach(([i, lab]) => { s += `<text x="${X(i)}" y="${h - 8}" text-anchor="middle">${lab}</text>`; });
  const bw = Math.max(3, Math.min(8, step * 0.5));
  wc.forEach((d, i) => { s += `<rect x="${X(i) - bw / 2}" y="${Y(d.hi)}" width="${bw}" height="${Math.max(2, Y(d.lo) - Y(d.hi))}" rx="${bw / 2}" fill="var(--accent)" opacity="0.28"/>`; });
  s += `<path d="${wc.map((d, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(d.expected).toFixed(1)).join('')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>`;
  wc.forEach((d, i) => { s += `<circle cx="${X(i)}" cy="${Y(d.actual)}" r="4.5" fill="var(--alt)" stroke="var(--surface)" stroke-width="2"/>`; });
  s += `<line class="cross" y1="${m.t}" y2="${h - m.b}" stroke="var(--ink-3)" stroke-width="1" style="display:none"/><rect class="hit" x="${m.l}" y="${m.t}" width="${w - m.l - m.r}" height="${h - m.t - m.b}" fill="transparent" style="touch-action:pan-y"/></svg>`;
  el.innerHTML = s;
  hoverSeries(el, w, X(0), X(n - 1), n, i => { const d = wc[i], wk = D.weeks[weekIndex[d.week]];
    return `<b>${weekLabel(wk)}</b> · ${wk.season}` + tipRow('Expected', d.expected.toFixed(1)) + tipRow('80% interval', `${d.lo} to ${d.hi}`) + tipRow('Actual', `<span style="color:var(--alt-ink)">${d.actual}</span>`) + tipRow('Cost, expected', usd(d.exp_cost)) + tipRow('Cost, actual', usd(d.actual_cost)); });
}

function drawDrift() {
  const el = $('#ch-drift'), w = chartWidth(el); if (!w) return;
  const oe = E.oe, n = oe.length, h = 230, m = { l: 38, r: 12, t: 12, b: 28 }, lo = 0.6, hi = 1.6;
  const X = i => m.l + (w - m.l - m.r) * (i + 0.5) / n, Y = linScale(lo, hi, h - m.b, m.t);
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Rolling observed over expected failures against the acceptable band">`;
  s += `<rect x="${m.l}" y="${Y(1.25)}" width="${w - m.l - m.r}" height="${Y(0.8) - Y(1.25)}" fill="var(--accent)" opacity="0.14"/>`;
  for (const t of [0.6, 0.8, 1.0, 1.25, 1.6]) s += `<line class="gridline" x1="${m.l}" x2="${w - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${t.toFixed(2).replace(/0$/, '')}</text>`;
  monthTicks(oe.map(d => d.week)).forEach(([i, lab]) => { s += `<text x="${X(i)}" y="${h - 8}" text-anchor="middle">${lab}</text>`; });
  s += `<path d="${oe.map((d, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(d.oe).toFixed(1)).join('')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>`;
  const first = oe.findIndex(o => o.oe > 1.25 || o.oe < 0.8);
  oe.forEach((d, i) => { if (d.oe > 1.25 || d.oe < 0.8) s += `<circle cx="${X(i)}" cy="${Y(d.oe)}" r="4" fill="var(--alt)" stroke="var(--surface)" stroke-width="2"/>`; });
  if (first >= 0) s += `<text class="strong" x="${Math.min(X(first), w - 120)}" y="${Y(1.6) + 14}" text-anchor="${X(first) > w - 120 ? 'start' : 'middle'}">First outside: ${oe[first].week.replace('2026-', '')}</text>`;
  s += `<line class="cross" y1="${m.t}" y2="${h - m.b}" stroke="var(--ink-3)" stroke-width="1" style="display:none"/><rect class="hit" x="${m.l}" y="${m.t}" width="${w - m.l - m.r}" height="${h - m.t - m.b}" fill="transparent" style="touch-action:pan-y"/></svg>`;
  el.innerHTML = s;
  hoverSeries(el, w, X(0), X(n - 1), n, i => { const d = oe[i]; const wk = D.weeks[weekIndex[d.week]];
    return `<b>${weekLabel(wk)}</b>` + tipRow('Observed ÷ expected', d.oe.toFixed(2)) + tipRow('Failures in window', d.n) + tipRow('Status', d.oe > 1.25 || d.oe < 0.8 ? 'recalibrate' : 'within band'); });
}

function drawEffects() {
  const el = $('#ch-effects'), w = chartWidth(el); if (!w) return;
  const eff = D.effects, rowH = 58, m = { l: 14, r: 14, t: 8, b: 30 }, h = m.t + rowH * eff.length + m.b;
  const X = linScale(Math.log(0.6), Math.log(1.7), m.l, w - m.r), tx = v => X(Math.log(v));
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Hazard ratios with 95% intervals">`;
  [0.67, 1, 1.5].forEach(t => { s += `<line class="${t === 1 ? 'axisline' : 'gridline'}" x1="${tx(t)}" x2="${tx(t)}" y1="${m.t}" y2="${h - m.b}"/><text x="${tx(t)}" y="${h - 10}" text-anchor="middle">${t.toFixed(t === 1 ? 2 : 2)}</text>`; });
  eff.forEach((e, i) => {
    const y = m.t + rowH * i + 38, tip = `<b>${esc(e.label)}</b>` + tipRow('Rate multiplied by', e.est.toFixed(2)) + tipRow('95% interval', `${e.lo.toFixed(2)} to ${e.hi.toFixed(2)}`);
    s += `<text class="t2" x="${m.l}" y="${y - 20}">${esc(e.label)}</text>`;
    s += `<g class="mark-hit" data-tip="${esc(tip)}"><line x1="${tx(e.lo)}" x2="${tx(e.hi)}" y1="${y}" y2="${y}" stroke="var(--ink-3)" stroke-width="2"/><circle cx="${tx(e.est)}" cy="${y}" r="5.5" fill="var(--accent)" stroke="var(--surface)" stroke-width="2"/><rect x="${tx(e.lo) - 4}" y="${y - 12}" width="${tx(e.hi) - tx(e.lo) + 8}" height="24" fill="transparent"/></g>`;
    s += `<text class="strong" x="${Math.min(tx(e.hi) + 8, w - 90)}" y="${y - 8}" text-anchor="start" ${tx(e.hi) + 8 > w - 90 ? `transform="translate(0 0)"` : ''}>${e.est.toFixed(2)}</text>`;
    if (e.key === 'elasticity') s += `<circle cx="${tx(1.10)}" cy="${y}" r="5" fill="none" stroke="var(--alt)" stroke-width="2"/><text x="${Math.min(tx(1.10) + 9, w - m.r - 130)}" y="${y + 18}" style="fill:var(--alt-ink)">1.10 if proportional to deliveries</text>`;
  });
  el.innerHTML = s + '</svg>'; bindTips(el);
}

function drawPerfCharts() { drawReliability(); drawWeekChart(); drawDrift(); drawEffects(); }
