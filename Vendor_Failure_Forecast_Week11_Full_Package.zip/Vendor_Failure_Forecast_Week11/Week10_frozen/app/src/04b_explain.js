/* ==================================================================
   Per-prediction contributions, overall importance, and the automatic
   scenario summary.

   The forecast is linear in its link, so the Shapley value of each input
   is exactly beta_j * (x_j - mean_j). 14_add_explanations.py computes the
   baseline and asserts the decomposition closes on every training row
   (worst residual 2e-15), so nothing here is approximated or sampled.

   Two different quantities are shown, and the app says which is which:
     - OVERALL importance: mean |contribution| across the 6,978 training
       vendor-weeks. How much each input moves forecasts in general.
     - THIS prediction's contributions: the decomposition of the single
       vendor-week on screen. How much each input moved THIS number.
   ================================================================== */

const EXP = D.explain;

/* contributions for one vendor-week, on the log-hazard scale.
   Returns the terms in the fixed order the waterfall walks them. */
function contributions(vi, expo, rej4, rej13) {
  const v = D.vendors[vi], cat = D.cats[v.cat];
  const bCat = BETA[IDX['cat:' + cat]];
  const bVen = IDX['v:' + v.id] === undefined ? 0 : BETA[IDX['v:' + v.id]];
  return [
    { key: 'category', label: 'Category: ' + D.cat_labels[v.cat],
      val: bCat - EXP.mean_cat,
      why: 'How this category compares with the average category in the training data.' },
    { key: 'vendor', label: 'This vendor specifically',
      val: bVen - EXP.mean_ven,
      why: 'What is left once the category is accounted for — this vendor’s own record, shrunk toward its category.' },
    { key: 'log_exposure', label: 'Deliveries per week',
      val: BETA[IDX.log_exposure] * zf('log_exposure', Math.log(Math.max(expo, 1e-3))),
      why: 'More deliveries means more chances to fail. Not a judgement about the vendor.' },
    { key: 'rej_4wk', label: 'Rejection rate, last 4 weeks',
      val: BETA[IDX.rej_4wk] * zf('rej_4wk', rej4),
      why: 'Recent quality. The only input carrying vendor-specific deterioration.' },
    { key: 'rej_13wk', label: 'Rejection rate, last 13 weeks',
      val: BETA[IDX.rej_13wk] * zf('rej_13wk', rej13),
      why: 'Longer-run quality. Its fitted coefficient is near zero, so it rarely moves a forecast.' }
  ];
}

/* ---------------------------------------- overall importance (performance tab) */
function renderImportance() {
  const el = $('#imp-panel'); if (!el) return;
  const LBL = { category: 'Category', log_exposure: 'Deliveries per week', vendor: 'Vendor identity',
                rej_4wk: 'Rejection rate, last 4 weeks', rej_13wk: 'Rejection rate, last 13 weeks' };
  const rows = Object.entries(EXP.importance).map(([k, v]) => ({ k, v, lbl: LBL[k] || k }))
                     .sort((a, b) => b.v - a.v);
  const max = rows[0].v;
  el.innerHTML = rows.map(r => {
    const w = Math.max(1, (r.v / max) * 100);
    return `<div class="imp-row">
      <div class="imp-lbl">${esc(r.lbl)}</div>
      <div class="imp-track"><i style="width:${w.toFixed(1)}%"></i></div>
      <div class="imp-val">${r.v.toFixed(3)}</div>
    </div>`;
  }).join('');
}

/* ---------------------------------------- this prediction (what-if tab) */
function renderContributions() {
  const el = $('#wi-contrib'); if (!el) return;
  if (!WI.rec) { el.innerHTML = '<p class="muted small">This vendor was not scored in this week, so there is no prediction to break down.</p>'; return; }

  const terms = contributions(WI.vi, WI.expo, WI.rej4, WI.rej13);
  const shiftEta = shiftToEta(WI.shift);
  const base = EXP.eta_base;
  const maxAbs = Math.max(...terms.map(t => Math.abs(t.val)), 1e-6);

  // cumulative walk, so the reader can follow the baseline to the final number
  let run = base;
  const steps = terms.map(t => { run += t.val; return { ...t, cum: run }; });
  if (Math.abs(shiftEta) > 1e-9) {
    run += shiftEta;
    steps.push({ key: 'shift', label: 'Your failure-rate shift', val: shiftEta, cum: run,
                 why: 'A condition you set on the left, not something the model learned.' });
  }
  const pAt = e => pOf(e);

  const row = (lbl, val, cum, why, isTotal) => {
    const pos = val >= 0, w = Math.min(50, (Math.abs(val) / maxAbs) * 50);
    // The total is a SUM of the rows above, not another contribution, so it gets no
    // bar: drawn on the same scale it exceeds the axis and spills into the numbers.
    const bar = isTotal ? '' : `<i class="${pos ? 'pos' : 'neg'}" style="${pos ? 'left:50%' : 'right:50%'};width:${w.toFixed(1)}%"></i>`;
    return `<div class="cb-row${isTotal ? ' cb-total' : ''}">
      <div class="cb-lbl">${esc(lbl)}${why ? `<span class="cb-why">${esc(why)}</span>` : ''}</div>
      <div class="cb-bar"><span class="cb-mid"></span>${bar}</div>
      <div class="cb-num">${val >= 0 ? '+' : '−'}${Math.abs(val).toFixed(2)}</div>
      <div class="cb-cum">${pct(pAt(cum), 1)}</div>
    </div>`;
  };

  el.innerHTML = `
    <div class="cb-head">
      <div></div><div>Contribution<br><span class="cb-unit">log-hazard</span></div><div>Running<br><span class="cb-unit">chance</span></div>
    </div>
    <div class="cb-row cb-base">
      <div class="cb-lbl">Reference vendor-week: every input at its training average<span class="cb-why">Where the walk starts. It sits below the ${((D.meta.pos_dev / D.meta.n_dev) * 100).toFixed(1)}% overall failure rate because it averages the inputs on the log-hazard scale, where most vendor-weeks are low-risk and a few high-risk ones pull the average chance up.</span></div>
      <div class="cb-bar"><span class="cb-mid"></span></div>
      <div class="cb-num">—</div>
      <div class="cb-cum">${pct(pAt(base), 1)}</div>
    </div>
    ${steps.map(s => row(s.label, s.val, s.cum, s.why, false)).join('')}
    ${row('This vendor-week, all terms added', run - base, run, '', true)}
  `;
}

/* ---------------------------------------- the automatic scenario summary */
function changedInputs() {
  const r = WI.rec; if (!r) return [];
  const out = [];
  const d = (now, was, fmt, lbl) => {
    if (Math.abs(now - was) < 1e-9) return;
    out.push({ lbl, from: fmt(was), to: fmt(now), up: now > was });
  };
  d(WI.expo, r.expo, x => x.toFixed(2) + '/wk', 'Deliveries per week');
  d(WI.rej4, r.rej4, x => pct(x, 1), 'Rejection rate, last 4 weeks');
  d(WI.rej13, r.rej13, x => pct(x, 1), 'Rejection rate, last 13 weeks');
  if (Math.abs(WI.shift) > 1e-9) out.push({ lbl: 'Failure-rate shift, all vendors', from: '0%', to: (WI.shift >= 0 ? '+' : '−') + Math.abs(Math.round(WI.shift * 100)) + '%', up: WI.shift > 0 });
  if (Math.abs(WI.cost) > 1e-9) out.push({ lbl: 'Cost of a failure, all vendors', from: '0%', to: (WI.cost >= 0 ? '+' : '−') + Math.abs(Math.round(WI.cost * 100)) + '%', up: WI.cost > 0 });
  return out;
}

function renderSummary() {
  const el = $('#wi-summary'); if (!el) return;
  const v = D.vendors[WI.vi], w = D.weeks[WI.wi], r = WI.rec;
  if (!r) { el.innerHTML = '<p class="muted small">No recorded values for this vendor in this week, so there is no baseline to compare a scenario against.</p>'; return; }

  const z = Z[WI.level];
  const basef = forecast(WI.vi, r.expo, r.rej4, r.rej13, 0, z);
  const nowf = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, shiftToEta(WI.shift), z);
  const ch = changedInputs();
  const dp = nowf.p - basef.p;
  const rel = basef.p > 0 ? dp / basef.p : 0;

  // out-of-range flags: the same rule the notes use, restated here so the summary stands alone
  const rg = D.ranges[D.cats[v.cat]];
  const oor = [];
  if (WI.expo > rg.expo[1] || WI.expo < rg.expo[0]) oor.push(`deliveries at ${WI.expo.toFixed(2)}/wk is outside the ${rg.expo[0].toFixed(2)}–${rg.expo[1].toFixed(2)} range the model was trained on for ${D.cat_labels[v.cat].toLowerCase()}`);
  if (WI.rej4 > rg.rej4[1]) oor.push(`a 4-week rejection rate of ${pct(WI.rej4, 1)} is above the ${pct(rg.rej4[1], 1)} the model has seen`);
  if (WI.rej13 > rg.rej13[1]) oor.push(`a 13-week rejection rate of ${pct(WI.rej13, 1)} is above the ${pct(rg.rej13[1], 1)} the model has seen`);

  const inputs = ch.length === 0
    ? `<li>No input was changed. The scenario is the week as recorded: ${r.expo.toFixed(2)} deliveries a week, ${pct(r.rej4, 1)} rejections over 4 weeks, ${pct(r.rej13, 1)} over 13.</li>`
    : ch.map(c => `<li><b>${esc(c.lbl)}</b>: ${esc(c.from)} → ${esc(c.to)}</li>`).join('');

  const movement = ch.length === 0
    ? `The forecast is the baseline: <b>${pct(basef.p, 1)}</b> (${WI.level}% interval ${pct(basef.lo, 1)} to ${pct(basef.hi, 1)}).`
    : Math.abs(dp) < 0.0005
      ? `The forecast stays at <b>${pct(nowf.p, 1)}</b> — the change is smaller than a tenth of a percentage point. An input can move without moving the prediction.`
      : `The forecast moves from <b>${pct(basef.p, 1)}</b> to <b>${pct(nowf.p, 1)}</b>, a change of <b>${dp >= 0 ? '+' : '−'}${pct(Math.abs(dp), 1)}</b> (${rel >= 0 ? 'up' : 'down'} ${Math.abs(rel * 100).toFixed(0)}% in relative terms). The ${WI.level}% interval moves from ${pct(basef.lo, 1)}–${pct(basef.hi, 1)} to ${pct(nowf.lo, 1)}–${pct(nowf.hi, 1)}.`;

  // Second KPI: expected cost = chance of failing x typical cost of a failure that week.
  const muBase = costMean(WI.wi), muNow = muBase * (1 + WI.cost);
  const ecBase = basef.p * muBase, ecNow = nowf.p * muNow, dEc = ecNow - ecBase;
  const costMove = Math.abs(dEc) < 0.5
    ? `Expected cost next week is <b>${usd(ecNow)}</b>: the chance above times a typical failure cost of ${usd(muNow)} that week.`
    : `Expected cost next week moves from <b>${usd(ecBase)}</b> to <b>${usd(ecNow)}</b> (${dEc >= 0 ? '+' : '−'}${usd(Math.abs(dEc))}): the chance above times a typical failure cost of ${usd(muNow)} that week.`;

  // What it means for the decision actually on the table.
  // Built the SAME way as the review-candidate note above it: the shift is passed
  // into the scoring, and vendors already under an open corrective action are
  // excluded, because the weekly list holds those out. Computing the denominator
  // any other way would put two different vendor counts on one screen.
  const sc = weekScores(WI.wi, shiftToEta(WI.shift));
  const others = []; sc.forEach((s, vi) => { if (s && vi !== WI.vi && s.cap === 0) others.push(s.p); });
  const rankNow = rankAmong(others, nowf.p), rankLo = rankAmong(others, nowf.lo);
  const implication = r.cap === 1
    ? `This vendor already has an open corrective action in ${esc(w.id)}, so the weekly list holds it out regardless of where this scenario puts its forecast.`
    : rankNow <= w.k
      ? `At ${pct(nowf.p, 1)} this vendor ranks ${rankNow} of ${others.length + 1} against a review list of ${w.k}, so it <b>stays on the list</b>${rankLo <= w.k ? ' even at the low end of its interval' : `, though at the low end of its interval it would rank ${rankLo} and drop off`}.`
      : `At ${pct(nowf.p, 1)} this vendor ranks ${rankNow} of ${others.length + 1} against a review list of ${w.k}, so it <b>does not make the list</b> in this scenario.`;

  const limits = [
    'This is the model’s arithmetic under changed inputs, not a prediction of what would happen if someone actually changed them. Nothing here establishes cause.',
    `The interval covers uncertainty in the fitted coefficients only. It does not cover a wrong model, a changed regime, or the 2026 drift the monitor flagged in week 22.`
  ];
  if (oor.length) limits.unshift(`Outside the trained range: ${oor.join('; ')}. The forecast there is an extrapolation.`);
  if (D.model.zero_cap && D.model.zero_cap[D.cats[v.cat]] !== undefined) limits.unshift(`${D.cat_labels[v.cat]} recorded no failures in training, so the upper end of this interval is an exact statistical limit rather than a fitted one.`);

  el.innerHTML = `
    <h3>Scenario summary</h3>
    <p class="cap">Written automatically from the inputs on the left, each time you change one.</p>
    <div class="sum-grid">
      <div><h4>Scenario</h4><ul class="sum-list">${inputs}</ul>
        <p class="sum-ctx">${esc(v.name)} · ${esc(weekLabel(w))} · ${esc(w.season)} season · review capacity ${w.k}</p></div>
      <div><h4>Result against the baseline</h4>
        <p class="sum-move">${movement}</p>
        <p class="sum-move">${costMove}</p>
        <p class="sum-move">${implication}</p></div>
    </div>
    <div class="sum-lim"><h4>What this does and does not tell you</h4>
      <ul class="sum-list">${limits.map(l => `<li>${l}</li>`).join('')}</ul></div>`;
}

function renderExplain() { renderContributions(); renderSummary(); }
