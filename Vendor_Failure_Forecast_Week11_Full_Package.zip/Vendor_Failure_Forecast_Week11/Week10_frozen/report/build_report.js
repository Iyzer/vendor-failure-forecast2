const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, AlignmentType, LevelFormat } = require('docx');

const FONT = 'Arial', SZ = 17;          // 8.5 pt body
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: o.size || SZ, bold: o.bold, italics: o.italics, color: o.color });
// inline **bold** markup
const rich = (s, o = {}) => s.split(/(\*\*[^*]+\*\*)/).filter(Boolean).map(p => p.startsWith('**') ? run(p.slice(2, -2), { ...o, bold: true }) : run(p, o));
const para = (s, o = {}) => new Paragraph({ children: rich(s, o), spacing: { after: o.after ?? 50, line: o.line ?? 238 }, alignment: o.align });
const head = t => new Paragraph({ children: [run(t, { bold: true, size: 19, color: '1C4F8F' })], spacing: { before: 90, after: 40 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'B8C4D6', space: 1 } } });
const bullet = s => new Paragraph({ children: rich(s), numbering: { reference: 'b', level: 0 }, spacing: { after: 36, line: 234 } });

const W = 12240 - 2 * 760;            // text width in DXA
const colW = [2350, W - 2350];
const cell = (t, w, o = {}) => new TableCell({
  width: { size: w, type: WidthType.DXA },
  shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: 'auto' } : undefined,
  margins: { top: 25, bottom: 25, left: 70, right: 70 },
  borders: { top: { style: BorderStyle.SINGLE, size: 2, color: 'D0D7E2' }, bottom: { style: BorderStyle.SINGLE, size: 2, color: 'D0D7E2' }, left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' }, right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' } },
  children: [new Paragraph({ children: rich(t, { size: 16, bold: o.bold }), spacing: { after: 0, line: 220 } })]
});
const rows = [
  ['List capture (k = that week’s capacity)', '**55%** of addressable next-week failure cost [95% CI 43–66%]; today’s on-time/fill rules 31% [21–42], recent-rejection ranking 29% [20–39], random 21%. Average list 9.7 of 44 eligible vendors.'],
  ['Against ranking by delivery volume', '50% [39–62]; difference +4 points [−2, +12]: not distinguishable. Against today’s rules: +24 points [+11, +37].'],
  ['Ranking quality (AUC)', '0.75 [0.72–0.79]; a forecast using only category averages scores 0.74, and its Brier score is the same (difference 0.00001, interval −0.0006 to +0.0005).'],
  ['Calibration', '2026 failures ran 5.6% against 4.4% forecast (×1.26, slope 0.76). The data generator shifted in 2026; the drift monitor left its 0.80–1.25 band in week 22.'],
  ['Interval coverage', 'Weekly count of failing vendors fell inside the 80% interval in 85% of weeks; weekly dollars in 71% (under-covers).']
];
const table = new Table({
  width: { size: W, type: WidthType.DXA }, columnWidths: colW,
  rows: rows.map(r => new TableRow({ children: [cell(r[0], colW[0], { bold: true, fill: 'EEF2F8' }), cell(r[1], colW[1])] }))
});

const doc = new Document({
  creator: 'Mirza Ali and Debra Senteu', title: 'Vendor Failure Forecast - Week 10 one-page report',
  numbering: { config: [{ reference: 'b', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 260, hanging: 200 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 560, bottom: 520, left: 760, right: 760 } } },
    children: [
      new Paragraph({ children: [run('Vendor Failure Forecast', { bold: true, size: 30 }), run('   Week 10: predictive model, what-if analysis and uncertainty', { size: 19, color: '52514E' })], spacing: { after: 10 } }),
      para('Mirza Ali and Debra Senteu · MS Analytics, Saint Louis University · synthetic data for an independent seasonal resort · app: three screens (model performance, what-if forecast, weekly review list)', { size: 15, after: 30 }),

      head('The decision the model serves'),
      para('Each Monday the Purchasing & Receiving Manager can review only k vendors (about 4 in peak season, up to 12 off-peak) out of roughly 44 with recent deliveries. The model estimates, for every vendor-week, the chance of a material failure next week and converts it to expected dollars. The screens then show the review list, what changes if inputs move, and how sure the model is.'),

      head('(i) Why this predictive approach'),
      bullet('**Leakage-safe data.** 50 vendors × 209 weeks; features are as of Monday only. The manager’s own open corrective action and the counterfactual (oracle) table are excluded; vendor-weeks with no deliveries are “insufficient data”, never zero. Model selection used only 2023–25 (6,978 scored vendor-weeks, 320 failures, rolling-origin cross-validation); the 2026 holdout (2,441 vendor-weeks, 136 failures) was scored once.'),
      bullet('**Binomial GLM with a complementary log-log link.** Failures are rare (4.6%) and vendors deliver at different rates. P = 1 − exp(−hazard) is the exact form when failures arrive as a Poisson process (Charpentier 2015), and each coefficient is a rate multiplier a manager can read: +5 points of 4-week rejections multiplies a vendor’s failure rate by 1.29 [1.08–1.55]. Vendor intercepts are shrunk toward their category (ridge penalty set by cross-validation; Efron & Morris 1977), so thin histories are not over-read. A Laplace posterior gives credible intervals that carry through to multi-week and dollar views.'),
      bullet('**We tested the textbook exposure offset instead of adopting it** (Parry, Cornell CSCU). An offset assumes failures scale in proportion to deliveries. Estimated elasticity is 0.30 [0.01–0.59]; proportional (1.0) is rejected (z = −4.7), so the model estimates it freely.'),
      bullet('**Interpretable beats opaque here.** A gradient-boosted benchmark did no better (2026 AUC 0.742 against 0.749; list captured 41% of cost against 55%) and gives no coefficients or intervals. Probability is modelled first and cost applied afterwards (Elkan 2001): expected cost of a failing vendor-week comes from that week’s occupancy and banquet flag.'),
      bullet('**Judged on the decision.** Brier score, log-loss and calibration (Van Calster et al. 2019), plus the share of next-week failure cost inside the weekly top-k list, because AUC ignores the capacity limit (Hand 2009). Intervals are bootstrapped over whole weeks.'),

      head('What the 2026 holdout shows'),
      table,
      para('Honest reading: most of the skill is category and volume structure plus the 4-week rejection signal. The clear gain is over today’s rules; fine-grained vendor deterioration is only weakly detectable. The data are synthetic, so these numbers validate the method, not real-world performance.', { size: 16, after: 20, line: 224 }),

      head('(ii) How performance and uncertainty let the manager decide'),
      bullet('**Use the list, with the right expectations.** The list catches about half of costly failures (62 of 121 addressable failures in 2026), not all, and some weeks catch none (peak week 26: 0 of 1; week 14: 4 of 6). Probabilities appear as natural frequencies (Gigerenzer & Hoffrage 1995): “about 8 in 100 weeks like this end in a failure; we are 80% sure the true figure is between 5 and 13.”'),
      bullet('**What-if with intervals.** Changing deliveries, 4-week rejections, a failure-rate shift or the cost of a failure re-scores the vendor, shows 4-week and lead-time chances and expected dollars, and tests the rank at the low and high end of the interval: review candidate, borderline, watch, or outside. Cheap precautions can act on the high end; costly steps such as qualifying an alternate (4–8 weeks) should wait until the low end clears the cut. Intervals alone did not improve decisions in one planning experiment (Goodwin et al. 2010), so each one carries a plain-language reading and an 80% default.'),
      bullet('**Honest limits on screen.** Inputs outside the trained range are flagged as extrapolation; MRO supplies, which never failed, show an exact 95% upper limit (about 0.5% a week) instead of a made-up interval; “in list %” reports how stable a vendor’s rank is across 600 posterior draws.'),
      bullet('**Drift is part of the tool.** Intervals reflect uncertainty in the fitted coefficients, not a wrong or shifted model, so they understate risk when the world moves (weekly dollar coverage was 71%, not 80%). A 26-week observed-to-expected monitor says when to refit (calibration drifts even when ranking holds; Davis et al. 2017), and the +26% slider shows the level effect.'),

      para('References: Charpentier (2015) Modelling occurrence of events with some exposure, Freakonometrics · Parry (2018) To offset or not, Cornell CSCU · Efron & Morris (1977) Stein’s paradox in statistics · Van Calster et al. (2019) BMC Medicine 17:230 · Hand (2009) Machine Learning 77:103 · Elkan (2001) IJCAI · Gigerenzer & Hoffrage (1995) Psych. Review 102:684 · Goodwin, Önkal & Thomson (2010) EJOR 205:195 · Davis et al. (2017) AMIA Proc.', { size: 13, after: 0, line: 190 })
    ]
  }]
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync('Week10_One_Page_Report.docx', b); console.log('ok'); });
