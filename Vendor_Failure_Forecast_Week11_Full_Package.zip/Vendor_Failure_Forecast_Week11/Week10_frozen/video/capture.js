const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
// Records a silent, captioned 2-minute walkthrough of the app that follows the narration script (Week10_Video_Script.md).
const { chromium } = require('playwright');
const fs = require('fs');
const CAP = {
  1: ['Mirza', 'Each Monday our purchasing and receiving manager can review only a handful of vendors, as few as four in peak season and up to twelve off-season. Our tool forecasts which vendors are most likely to fail next week, in dollars, and says how sure it is.'],
  2: ['Debra', 'We trained on 2023 to 2025 and tested once on 2026. The weekly list captured 55 percent of failure cost, against 31 percent for today’s on-time and fill rules. We are upfront about limits: it does no better than ranking by delivery volume, and 2026 ran 26 percent above forecast, which the drift monitor flagged in week 22.'],
  3: ['Mirza', 'On the what-if screen we pick Produce 002 in a peak week: a 19 percent chance of failure, and we are 80 percent sure it lies between about 16 and 24. Now raise recent rejections three points and deliveries by a quarter. The chance rises to about 24 percent, the interval moves to 18 to 30, and the four-week chance is 66 percent. It stays a review candidate even at the low end, and the tool warns that nine deliveries a week is beyond what the model has seen.'],
  4: ['Debra', 'The weekly list ranks every vendor with its interval and how often it makes the cut. In week 14 the list of eleven caught four of six failures, about ten and a half thousand of twelve thousand dollars. In peak week 26 it caught none, so the hindsight check keeps us honest.'],
  5: ['Mirza', 'Under the hood it is a rate-based model with partial pooling. The data rejected the usual delivery-offset assumption. And since the data is synthetic, this validates our method, not a real resort.']
};
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const tCtx = Date.now();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, recordVideo: { dir: 'raw', size: { width: 1280, height: 720 } }, colorScheme: 'light' });
  const page = await ctx.newPage();
  await page.goto(APP + '#performance'); await page.waitForTimeout(600);
  await page.evaluate(() => {
    const c = document.createElement('div'); c.id = 'fake-cursor';
    c.style.cssText = 'position:fixed;left:-50px;top:-50px;width:18px;height:18px;border-radius:50%;background:rgba(235,104,52,.55);border:2px solid #eb6834;z-index:100000;pointer-events:none;transform:translate(-50%,-50%)';
    document.body.appendChild(c);
    document.addEventListener('mousemove', e => { c.style.left = e.clientX + 'px'; c.style.top = e.clientY + 'px'; }, true);
    const k = document.createElement('div'); k.id = 'fake-cap';
    k.style.cssText = 'position:fixed;left:50%;bottom:8px;transform:translateX(-50%);width:min(1220px,96vw);background:rgba(10,10,10,.84);color:#fff;font:13.5px/1.38 system-ui,sans-serif;padding:7px 14px;border-radius:8px;z-index:100000;pointer-events:none';
    document.body.style.paddingBottom = '90px';
    document.body.appendChild(k);
    window.__cap = (who, txt) => { k.innerHTML = '<b style="color:#8ab8f0">' + who + '</b> · ' + txt; };
  });
  const t0 = Date.now(), offset = (t0 - tCtx) / 1000;
  const until = async t => { const w = t * 1000 - (Date.now() - t0); if (w > 0) await page.waitForTimeout(w); };
  const cap = n => page.evaluate(([w, t]) => window.__cap(w, t), CAP[n]);
  const scrollTo = async (sel, off = 80) => { await page.evaluate(([s, o]) => { const e = document.querySelector(s); window.scrollTo({ top: e.getBoundingClientRect().top + window.scrollY - o, behavior: 'smooth' }); }, [sel, off]); };
  const moveTo = async (sel, fx = 0.5, fy = 0.5, steps = 28) => { const b = await (await page.$(sel)).boundingBox(); await page.mouse.move(b.x + b.width * fx, b.y + b.height * fy, { steps }); };
  const click = async sel => { await moveTo(sel); await page.waitForTimeout(250); await page.click(sel); };
  await page.mouse.move(640, 300);

  await cap(1); await until(2); await moveTo('#perf-tiles .tile.hero', 0.5, 0.4); await until(8); await moveTo('#perf-tiles .tile:nth-child(3)', 0.5, 0.4);
  await until(18); await cap(2); await scrollTo('#ch-capture', 150); await until(21); await moveTo('#ch-capture .brow:nth-child(1) .track', 0.4, 0.5);
  await until(26); await moveTo('#ch-capture .brow:nth-child(4) .track', 0.2, 0.5);
  await until(31); await scrollTo('#ch-drift', 120); await until(34); await moveTo('#ch-drift svg .hit', 0.52, 0.45, 40);
  await until(40); await page.mouse.move(700, 200, { steps: 20 });
  await until(43); await cap(3); await click('#tab-whatif'); await until(46); await moveTo('#wi-answer .big', 0.1, 0.5);
  await until(53); await click('button[data-q="rej+3"]');
  await until(59); await click('button[data-q="expo+25"]');
  await until(65); await scrollTo('#wi-notes', 90); await until(68); await moveTo('#wi-notes .note:nth-child(2)', 0.4, 0.5);
  await until(72); await scrollTo('#ch-s-expo', 120); await until(75); await moveTo('#ch-s-expo svg .hit', 0.93, 0.4, 40);
  await until(80); await cap(4); await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'smooth' })); await click('#tab-weekly');
  await until(83); await page.selectOption('#wk-week', '13'); await until(86); await moveTo('#wk-tiles .tile:nth-child(4)', 0.5, 0.4);
  await until(91); await scrollTo('#wk-table', 110); await until(94); await moveTo('#wk-table tbody tr:nth-child(2) .rng', 0.5, 0.5, 30);
  await until(100); await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'smooth' })); await until(102); await page.selectOption('#wk-week', '25'); await until(104); await moveTo('#wk-tiles .tile:nth-child(4)', 0.5, 0.4);
  await until(108); await cap(5); await click('#tab-performance'); await until(111); await scrollTo('.limits', 160); await until(113); await page.mouse.move(600, 400, { steps: 25 });
  await until(120);
  await ctx.close();
  const vid = fs.readdirSync('raw').filter(f => f.endsWith('.webm')).map(f => 'raw/' + f).sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0];
  fs.writeFileSync('offset.txt', String(offset)); fs.renameSync(vid, 'capture.webm');
  await browser.close(); console.log('done offset', offset);
})();
