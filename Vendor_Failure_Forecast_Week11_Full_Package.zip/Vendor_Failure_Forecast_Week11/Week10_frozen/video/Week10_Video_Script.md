# Week 10 Video Script: Two-Minute Demo

**Vendor Failure Forecast** · Mirza Ali (M) and Debra Senteu (D)

> **This script is the two-minute version and is now SHORT of the requirement.** The week 10 brief asks for a **seven-minute** demonstration covering assignment items 1 to 3. This script covers model performance, what-if and the weekly list, but not the two KPIs as KPIs (item 1), the predictor-importance panel or the per-prediction contribution panel (item 3a/3b), or the automatic scenario summary (item 3d). Roughly four minutes of new material is needed. The beats below remain correct and can open the longer recording.

How to record: open the published app (link in the README), set the browser window to 1280 × 720, and record the screen with narration. A silent, captioned walkthrough that follows this script second for second is included (`Week10_Demo_Screen_Capture.mp4`). You can narrate over it, or use it as a pacing guide while you record live.

| Time | Who | On screen | Say |
|---|---|---|---|
| 0:00–0:18 | M | **Model performance** tab, top. Rest the cursor on the big 55% tile. | "Each Monday our purchasing and receiving manager can review only a handful of vendors, as few as four in peak season and up to twelve off-season. Our tool forecasts which vendors are most likely to fail next week, in dollars, and says how sure it is." |
| 0:18–0:43 | D | Scroll to *Does it find the costly failures?* and hover **This model** (tooltip), then **Current practice**. Scroll to the drift chart and hover the point marked W22. | "We trained on 2023 to 2025 and tested once on 2026. The weekly list captured 55 percent of failure cost, against 31 percent for today's on-time and fill rules. We are upfront about limits: it does no better than ranking by delivery volume, and 2026 ran 26 percent above forecast, which the drift monitor flagged in week 22." |
| 0:43–1:20 | M | Click **What-if forecast**. Produce 002, week 26 is preselected: 19.4%, interval 15.5% to 24.3%. Click **Rejections +3 pts**, then **Deliveries +25%**. Read the cards and the red note. Scroll to the chart and hover the dashed section. | "On the what-if screen we pick Produce 002 in a peak week: a 19 percent chance of failure, and we are 80 percent sure it lies between about 16 and 24. Now raise recent rejections three points and deliveries by a quarter. The chance rises to about 24 percent, the interval moves to 18 to 30, and the four-week chance is 66 percent. It stays a review candidate even at the low end, and the tool warns that nine deliveries a week is beyond what the model has seen." |
| 1:20–1:48 | D | Click **Weekly review list**. Pick **W14**: the fourth tile reads 4 of 6, $10,579 of $11,989. Scroll to the table and point at an interval bar and the *In list* column. Switch to **W26**: 0 of 1. | "The weekly list ranks every vendor with its interval and how often it makes the cut. In week 14 the list of eleven caught four of six failures, about ten and a half thousand of twelve thousand dollars. In peak week 26 it caught none, so the hindsight check keeps us honest." |
| 1:48–2:00 | M | Back to **Model performance**, scroll to the *What this does not show* box. | "Under the hood it is a rate-based model with partial pooling. The data rejected the usual delivery-offset assumption. And since the data is synthetic, this validates our method, not a real resort." |

## What the video must show (assignment checklist)

- Relevant model outputs so the decision-maker can judge predictive performance: the 55% capture tile, the capture bars against today's rules, the reliability chart, the weekly forecast-against-actual chart, the drift monitor. *(0:00–0:43)*
- What-if analysis: change predictors, the app re-predicts. Rejections, deliveries, failure-rate shift, cost of a failure. *(0:43–1:20)*
- Uncertainty on the prediction: interval on the headline number, on the 4-week and lead-time cards, on the expected cost, and on both sensitivity charts, plus the 50/80/95% selector. *(0:43–1:20)*
- A decision the screens support: the weekly list with rank stability and a hindsight check. *(1:20–1:48)*

## Numbers to have ready for questions (all from the 2026 holdout, model frozen on 2023–2025)

| Question | Answer |
|---|---|
| How much failure cost does the list capture? | 55% [95% interval 43–66%] of addressable next-week failure cost. Today's rules 31% [21–42]. Ranking by recent rejections 29% [20–39]. Random 21%. |
| Is it better than just ranking by delivery volume? | Volume alone captures 50% [39–62]. The difference (+4 points, interval −2 to +12) cannot be told apart from zero. |
| How good is the ranking? | AUC 0.75 [0.72–0.79]. Category averages alone score 0.74. |
| Is it calibrated? | 2026 failures ran 5.6% against 4.4% forecast, so ×1.26. Calibration slope 0.76. |
| Do the intervals hold up? | Weekly count of failing vendors fell inside the 80% interval in 85% of weeks. Weekly dollars: 71%. |
| Why not the usual exposure offset? | The offset says failures scale in proportion to deliveries. Estimated elasticity is 0.30 [0.01–0.59]. Proportional (1.0) is rejected, z = −4.7. |
| Why not a more flexible model? | A gradient-boosted benchmark did not beat it (2026 AUC 0.742 against 0.749; list captured 41% against 55%) and gives no coefficients or intervals. |
| What about MRO? | No MRO failure in three years of data. The tool shows an exact 95% upper limit of about 0.5% a week instead of a made-up interval. |
| Biggest limit? | The data is synthetic. The results validate the method and its checks, not real-world performance. |
