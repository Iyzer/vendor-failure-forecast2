const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await page.goto(APP + '#whatif'); await page.waitForTimeout(400);
  const ans = () => page.$eval('#wi-answer .big', e => e.textContent);
  console.log('hash opens what-if:', await page.$eval('#view-whatif', e => !e.hidden));
  console.log('start', await ans());
  const setRange = async (sel, val) => page.$eval(sel, (e, v) => { e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); }, val);
  await setRange('#s-expo', 12); console.log('deliveries 12', await ans());
  await setRange('#s-expo', 3); console.log('deliveries 3', await ans());
  await page.click('button[data-q="calm"]'); console.log('clean record', await ans());
  await page.click('button[data-q="rej+3"]'); console.log('rej +3', await ans());
  await setRange('#s-rej4', 0.28); console.log('rej4 28% notes:', (await page.$$eval('#wi-notes .note', n => n.map(x => x.textContent.slice(0, 90)))).join(' | '));
  await page.click('#q-drift'); console.log('drift +26', await ans());
  await page.click('#seg-level button[data-level="95"]'); console.log('95%', await ans());
  await page.click('button[data-q="reset"]'); console.log('reset', await ans());
  // unscored vendor
  await page.selectOption('#wi-vendor', '0'); console.log('V001 W26 ->', (await page.$eval('#wi-answer', e => e.textContent)).slice(0, 120));
  // week change, MRO vendor
  const mro = await page.evaluate(() => window.__vr.D.vendors.findIndex(v => v.cat === 6));
  await page.selectOption('#wi-week', '10'); await page.selectOption('#wi-vendor', String(mro)); console.log('MRO', await ans(), (await page.$$eval('#wi-notes .note', n => n.map(x => x.textContent.slice(0, 60)))).join(' | '));
  // weekly
  await page.click('#tab-weekly'); await page.selectOption('#wk-week', '52'); console.log('W53 tile4:', await page.$eval('#wk-tiles .tile:nth-child(4)', e => e.textContent));
  await page.selectOption('#wk-week', '13'); console.log('W14 tile4:', await page.$eval('#wk-tiles .tile:nth-child(4)', e => e.textContent));
  await page.click('#wk-more'); console.log('rows all:', await page.$$eval('#wk-table tbody tr:not(.capline)', r => r.length));
  await page.uncheck('#wk-reveal'); console.log('hidden tile4:', await page.$eval('#wk-tiles .tile:nth-child(4)', e => e.textContent));
  await page.click('#wk-next'); await page.click('#wk-prev');
  // tooltip on perf
  await page.click('#tab-performance'); await page.waitForTimeout(200);
  const box = await page.$eval('#ch-week svg .hit', e => { const r = e.getBoundingClientRect(); return [r.x + r.width * 0.5, r.y + r.height * 0.5]; });
  await page.mouse.move(box[0], box[1]); await page.waitForTimeout(100);
  console.log('tooltip:', await page.$eval('.tip', e => e.hidden ? 'HIDDEN' : e.textContent.slice(0, 100)));
  console.log('errors:', JSON.stringify(errs));
  await browser.close();
})();
