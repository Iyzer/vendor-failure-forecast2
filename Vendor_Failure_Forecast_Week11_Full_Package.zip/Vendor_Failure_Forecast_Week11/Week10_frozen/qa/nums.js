const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 720 } })).newPage();
  await page.goto(APP + '#whatif'); await page.waitForTimeout(400);
  const t = sel => page.$eval(sel, e => e.textContent.replace(/\s+/g, ' ').trim());
  console.log('base      ', await t('#wi-answer .big'));
  await page.click('button[data-q="expo+25"]');
  console.log('+25% del  ', await t('#wi-answer .big'), '|', await t('#wi-answer .delta'), '|', await t('#wi-notes'));
  await page.click('button[data-q="rej+3"]');
  console.log('+3pts rej ', await t('#wi-answer .big'), '|', await t('#wi-answer .delta'), '|', await t('#wi-notes').then(x => x.slice(0, 200)));
  console.log('cards     ', await t('#wi-cards'));
  await page.click('#q-drift'); console.log('+26% drift', await t('#wi-answer .big'));
  await page.click('button[data-q="reset"]');
  await page.click('#tab-weekly');
  for (const wi of [13, 25]) {
    await page.selectOption('#wk-week', String(wi));
    console.log('weekly', wi, await t('#wk-title'), '|', (await page.$$eval('#wk-tiles .tile', ts => ts.map(x => x.textContent.replace(/\s+/g, ' ').trim()))).join(' || '));
  }
  await browser.close();
})();
