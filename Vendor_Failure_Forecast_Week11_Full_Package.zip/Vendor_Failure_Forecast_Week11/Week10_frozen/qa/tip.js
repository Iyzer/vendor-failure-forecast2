const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  await page.goto(APP); await page.waitForTimeout(300);
  for (const [sel, name] of [['#ch-week svg .hit', 'week'], ['#ch-drift svg .hit', 'drift']]) {
    await page.$eval(sel, e => e.scrollIntoView({ block: 'center' })); await page.waitForTimeout(250);
    const box = await page.$eval(sel, e => { const r = e.getBoundingClientRect(); return [r.x + r.width * 0.55, r.y + r.height * 0.5]; });
    await page.mouse.move(box[0], box[1]); await page.waitForTimeout(100);
    console.log(name, await page.$eval('.tip', e => e.hidden ? 'HIDDEN' : e.textContent.slice(0, 140)));
    if (name === 'week') await page.screenshot({ path: 'tip_week.png' });
  }
  await page.$eval('#ch-capture .brow', e => e.scrollIntoView({ block: 'center' }));
  const b2 = await page.$eval('#ch-capture .brow', e => { const r = e.getBoundingClientRect(); return [r.x + r.width * 0.5, r.y + r.height * 0.5]; });
  await page.mouse.move(b2[0], b2[1]); await page.waitForTimeout(100);
  console.log('capture', await page.$eval('.tip', e => e.hidden ? 'HIDDEN' : e.textContent.slice(0, 140)));
  await browser.close();
})();
