const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.goto(APP + '#whatif'); await page.waitForTimeout(400);
  const card = () => page.$eval('#wi-cards .card:nth-child(3)', e => e.textContent);
  console.log('base', await card());
  await page.$eval('#s-cost', e => { e.value = 50; e.dispatchEvent(new Event('input', { bubbles: true })); });
  console.log('+50%', await card(), await page.$eval('#v-cost', e => e.textContent));
  await page.click('button[data-q="reset"]'); console.log('reset', await card(), await page.$eval('#v-cost', e => e.textContent));
  console.log('errors', errs);
  await browser.close();
})();
