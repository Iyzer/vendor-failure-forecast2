const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const cfgs = [['desk', 1280, 900, 'light'], ['phone', 390, 844, 'light'], ['dark', 1280, 900, 'dark']];
  for (const [name, w, h, scheme] of cfgs) {
    const ctx = await browser.newContext({ viewport: { width: w, height: h }, colorScheme: scheme, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto(APP); await page.waitForTimeout(500);
    for (const v of ['performance', 'whatif', 'weekly']) {
      await page.evaluate(v => window.__vr.showView(v), v); await page.waitForTimeout(250);
      const ov = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
      console.log(name, v, 'overflow', JSON.stringify(ov), errs.length ? errs : '');
      await page.screenshot({ path: `${name}_${v}.png`, fullPage: true });
    }
    await ctx.close();
  }
  await browser.close();
})();
