const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await (await browser.newContext()).newPage();
  await page.goto(APP); await page.waitForTimeout(300);
  console.log(JSON.stringify(await page.evaluate(() => { const { D, forecast } = window.__vr; return D.parity.map(c => { const f = forecast(c.vendor, c.expo, c.rej4, c.rej13, 0, 1.2816); return { cat: D.cats[D.vendors[c.vendor].cat], dHi: +(f.hi - c.hi80).toFixed(5), hiJS: +f.hi.toFixed(5), hiPy: +c.hi80.toFixed(5), p: +c.p.toFixed(5) }; }).filter(x => Math.abs(x.dHi) > 1e-5 || x.cat === 'mro'); })));
  console.log(await page.evaluate(() => JSON.stringify(window.__vr.D.model.zero_cap)));
  await browser.close();
})();
