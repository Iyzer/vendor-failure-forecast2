const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const errs = [];
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, colorScheme: 'light' });
  const page = await ctx.newPage();
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await page.goto(APP);
  await page.waitForTimeout(800);
  const parity = await page.evaluate(() => window.__vr && window.__vr.parityReport());
  console.log('parity', JSON.stringify(parity));
  console.log('errors', JSON.stringify(errs, null, 1));
  await browser.close();
})();
