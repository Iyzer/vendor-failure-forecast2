const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  await page.goto(APP); await page.waitForTimeout(400);
  const res = await page.evaluate(() => {
    const { D, weekSimulation } = window.__vr, V = D.vendors.length, R = D.rows, out = [];
    for (let wi = 0; wi < D.weeks.length - 1; wi++) {
      const sim = weekSimulation(wi), k = D.weeks[wi].k;
      const elig = sim.vis.filter(vi => sim.scores[vi].cap === 0).sort((a, b) => sim.scores[b].p - sim.scores[a].p);
      const list = new Set(elig.slice(0, k));
      let nf = 0, caught = 0, cost = 0, ccost = 0;
      elig.forEach(vi => { const i = wi * V + vi; if (R.y[i] === 1) { nf++; cost += R.cost[i] || 0; if (list.has(vi)) { caught++; ccost += R.cost[i] || 0; } } });
      out.push({ w: D.weeks[wi].id, season: D.weeks[wi].season, k, nf, caught, cost: Math.round(cost), ccost: Math.round(ccost), exp: +sim.expCount.toFixed(1) });
    }
    return out;
  });
  const tot = res.reduce((a, r) => ({ nf: a.nf + r.nf, caught: a.caught + r.caught, cost: a.cost + r.cost, ccost: a.ccost + r.ccost }), { nf: 0, caught: 0, cost: 0, ccost: 0 });
  console.log(JSON.stringify(tot), (tot.ccost / tot.cost).toFixed(3));
  res.filter(r => r.nf >= 2 && r.caught >= 2).forEach(r => console.log(JSON.stringify(r)));
  await browser.close();
})();
