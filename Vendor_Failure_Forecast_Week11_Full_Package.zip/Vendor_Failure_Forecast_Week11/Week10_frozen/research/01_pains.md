# Research 01 — Real-world pain points in hotel/resort procurement and vendor reliability

Compiled 2026-10-20 for the Week 10 build. Scope: what practitioners (purchasing/receiving managers, chefs, F&B directors, controllers, GMs, procurement staff) say publicly about vendor reliability, and what they use and distrust.

## How to read this file (method and limits)

- **Quotes.** Every quote below was returned by the WebFetch tool, which reads the page through a small summarizing model. Quotes are labelled "verbatim" only where the tool reported them as verbatim; I could not re-diff them against raw page text, so treat each as high-but-not-certain fidelity. Anything else is marked PARAPHRASE.
- **Reddit was not reachable.** WebFetch returned `SITE_BLOCKED` for reddit.com; WebSearch with a `reddit.com` domain filter was rejected (HTTP 400); unfiltered searches never surfaced a Reddit URL. **There is zero Reddit evidence in this file** (r/KitchenConfidential, r/hotels, r/hospitality, r/procurement, r/supplychain, r/restaurateur, r/foodservice were all unavailable). I did not try any workaround.
- **Only forum evidence is ChefTalk** (undated threads; one useful, one thin).
- **Confidence labels:** High = first-hand and specific, or independent survey with stated sample. Medium = trade press with named operators, or survey with weak method. Low = vendor marketing, consultant opinion with no data, or undated/unsourced numbers.
- **Counts:** 47 distinct sources were fetched and read (register at the bottom). 15 contain first-hand practitioner voices (marked ★ in the register); several of those are mixed with vendor or consultant voices, so the ★ flag marks the practitioner quotes, not the whole page.
- **Era warning.** Most hard shortage numbers come from the 2020–2022 pandemic period. 2025–2026 evidence is mostly about cost/tariffs, consolidation and staffing, not fill rates.

---

## 1. Top recurring problems (ranked by how many independent sources raised them)

### 1.1 Short fills, stockouts and forced substitution — recurring, but numbers are pandemic-era
Evidence:
- Restaurant Business / FoodService Director panel (Jan 2022), operators from Burton's Grill, Cheesecake Factory, Juice It Up!: moderator Vince Purves: "Product fill rates by broadliners are typically at least 98%, but currently, they're around 80%." (moderator's claim, no source; Low–Medium). Denise Herrera: "We get delivery reports every day and are proactive about what to substitute if the distributor is out of something," and, per FSD, "Recently, I couldn't get gluten-free panko, so I crushed Rice Chex cereal and used that instead." Brenda Serrano: "There are few substitutes for some of the ingredients on our menu." [S3]
- The Caterer, UK CGA / Prestige Purchasing survey (1 Dec 2020, sample size not stated): "Over 90%" of hospitality operators had supply difficulties since reopening; 95% reported deliveries missing products; 63% said most supplies arrived on time. [S16]
- Myrtle Beach local news (undated, ~Apr 2022 inferred): GM Bryan Compher: "The supply is way less than the demand is, so getting chicken wings was very tough." PARAPHRASE: he never knew how much product the trucks would bring. Manager Sasha McRaven: "We couldn't get any of our supplies because of the COVID outbreak in their company." [S47]
- LODGING (AHLA magazine, 29 Oct 2025): Ted Peters (Remington Hospitality): "delivery times can sometimes be longer than expected." Ashley King (Resolute Road Hospitality): "Vendors are also keeping leaner inventories, which means hotels need to plan more carefully to avoid disruptions." [S43]
- US Foods governance story (undated, ~May of an unstated year): activist investor letter says customers mainly value "receiving everything they ordered, on time, and at a reasonable price" and links weaker margins to "unreliable fill rates and on-time deliveries" (PARAPHRASE of the article). Investor, not operator. [S35]
- Confidence: High that the problem is recurring; Low–Medium on magnitude today.

### 1.2 Price volatility and cost-of-goods pressure (tariffs, fuel, delivery fees)
- NRA (25 Mar 2026): 82% of operators reported higher food costs than the prior year; 68% said tariffs contributed; 63% of full-service operators "sought alternative suppliers." Sample/method not stated in the article. [S13]
- AHLA Front Desk Feedback survey, 246 hoteliers, fielded late Feb 2026: cost of goods and supplies was the most-cited financial pressure at 71% (labor 65%). [S26]
- Myrtle Beach: Madalyn Blevins: "Since September it's increased 22 percent," and "We had to change our prices for our wings like five times in the past two months." [S47]
- ChefTalk: a poster wants multiple vendors to "avoid the crazy price fluctuations that the broadliners love to shove down throats"; another: "I refuse to pay fuel surcharge." [S11] (undated, forum, Medium)
- Resort Trades (May 2022), written by the president of Meyer Jabara Hotels, a hotel management company: "Hoteliers are getting clobbered with delivery fees" and "What used to cost operators $1,100 six months ago for four pallets of product now costs $3,900." Self-promotional, unverified. [S34] (Low–Medium)
- Hotel Dive (11 Jun 2025): NRA CEO Michelle Korsmo: "The biggest concerns for restaurant operators are that tariffs will hike food and packaging costs." [S22]

### 1.3 Delivery logistics for remote/seasonal properties (cost, timing, reliability of the route itself)
See Section 4. Mackinac Island (ferry), a remote Oregon lodge, an island resort in the Maldives and UK holiday parks all describe the route as part of the reliability problem. [S2, S10, S14, S23, S24]

### 1.4 Supplier concentration and consolidation: fewer fallbacks
- Sysco's proposed ~$29.1B purchase of Jetro Restaurant Depot (announced March 30, 2026; SeafoodSource 2 Oct 2026 says Sysco expects close in early 2027). Independent Restaurant Coalition calls Restaurant Depot "the one meaningful wholesale alternative in many regions"; chef-owner Dan Jacobs (Milwaukee): "Restaurant Depot gives independent kitchens like mine a real price benchmark"; IRC's Erika Polmar: "Most of you check prices across both every single week." [S36] Forbes contributor Phil Lempert (opinion): "Small independents once used Jetro Restaurant Depot to keep the prices of the Syscos of the world honest." [S37] Consultancy Santiago & Co (has a commercial interest, many figures flagged as estimates): "the number of meaningful procurement alternatives available to independent operators is shrinking." [S38]
- IFDA survey of 500 restaurant operators (summer 2025; restaurants only; IFDA is the distributor trade body): operators buy from an average of 3.1 distributors, up from 2.8 pre-pandemic, citing "product availability and specialty items." [S5]
- Hotel Management (Oct 2026): Legacy Management president Tony Lunzman: "in the case that doesn't solve the problem, maintain multiple vendors so guest experience isn't impacted." [S41]

### 1.5 Supplier quality/safety events (recalls) as a vendor-risk trigger
- Newsweek (Aug 2026): Joe Gera, executive chef-owner of Keystone 'Cue, on Taylor Farms recalls: "They can't be trusted." and "I'd rather take it off the menu than risk dealing with them." He dropped one product line, continued another until "repeated recalls led to discarded inventory" (PARAPHRASE), estimated losses at about $21,200, and said the supplier had not offered a refund (PARAPHRASE). [S15] (High as a first-hand account; single case)

### 1.6 Silent drift: nobody sees a vendor getting worse until it hurts
- No practitioner said "we track on-time/fill rate in a spreadsheet and it fails us." The closest first-hand evidence is indirect: a ChefTalk poster picks a vendor by rep and "the sketchiness/greediness of their current sales rep" [S11]; the Hospitality Net consultant warns about "a vendor whose delivery times or defect rates are quietly drifting in the wrong direction" [S1] (consultant opinion, Low).
- Fast Casual blog (2013, no author): "Many scorecards focus on the supplier; it is often difficult for restaurant operators to see their own performance." and "Sometimes the supplier is right." [S39] (old; Low–Medium)
- Verma & Pullman (Cornell eCommons, 1995 data, **manufacturing firms**, n=58): managers "say that quality is the most important attribute for a supplier" but "they actually choose suppliers based largely on cost and delivery performance." [S25] (Medium; wrong industry, but a useful design warning: dashboards should show cost and on-time delivery prominently.)

### 1.7 Thin purchasing staff and peak-season labor strain
- AHLA (Mar 2026): more than half of respondents say their properties are somewhat or severely understaffed; 42% cite workforce shortages as a financial pressure. [S26]
- The Hotel Blueprint (30 Sep 2026, unsigned how-to site): a 40-to-80-room limited-service hotel "often doesn't have a dedicated Purchasing Manager at all"; the GM or Director of Finance commonly "handles vendor relationships and PO issuance directly." [S48] (Low–Medium: generic guidance, not research.) **This bears directly on project assumption C14.**
- Serrano (Cheesecake Factory, a large chain): "We have 18 supply chain team members and we cannot handle everything." [S3] (Even large teams are capacity-limited.)
- Resort Trades: "With reduced teams in the kitchen, no one has the time or the manpower to cut produce or proteins themselves." [S34]
- Hotel Management Network (undated, ~early 2026): "Many hotels, particularly in high-tourism regions or more remote locations, have struggled to recruit domestic workers," "leading to operational pressures during peak periods." [S46]
- **Not found:** any direct statement of how many vendors a purchasing manager can actively review per week, at peak or off-peak. No published support for or against project assumption A3 (k ≈ 4 peak / ≈ 12 off-peak).

---

## 2. What solutions and tools practitioners say they prefer, and why

Practitioner-voiced (higher weight):
- **Order further out and pre-allocate with the broadliner; keep specialty vendors as backup** — Herrera: "I work with my broadliner to pre-allocate products, especially proteins, and order further out," and "if the broadliner is out of something, I'll go to specialty vendors, particularly for dairy, produce and seafood." [S3]
- **Contingency plans and tested substitutes** — PARAPHRASE: Juice It Up! builds A/B/C supplier plans and uses an in-house scientist to test substitutes; Cheesecake Factory uses skip-day ordering plus a (unnamed) supply-chain technology partner. [S3]
- **Plan B vendors and "drop off the list" accountability** — ChefTalk: "its good to have a plan B when plan A hits the dumper." and "if I need something they best go the extra mile to help or they drop off the list." [S11] This is the closest real-world statement of an escalation rule: it is relational and event-driven, not metric-driven.
- **Share your forecast with suppliers** — Amey Fairbrother, Parkdean Resorts (Procurement Magazine, 4 Sep 2026): "We share, down to forecasting, what our arrivals are, so they've got a real clear understanding of how we're operating." Also: "We build the strategies based on business criticality of items." [S10] (Medium–High; first-hand but a large UK operator.)
- **Consolidate deliveries and be an attractive customer** — "By consolidating purchases into one weekly delivery vs. seven daily visits saves fuel and therefore lowers costs." [S34] (management company, self-promotional)
- **Know critical items and substitutes up front** — Lunzman: contingency planning starts with knowing critical products, brand standards and substitutes and "having alternate vendors identified in advance" (PARAPHRASE); evaluates suppliers on "reliability, product availability, service capability, and consistent performance, not just price" (PARAPHRASE). [S41]
- **Get a single, shared set of numbers** — Inn-Flow's Kelsey Higginbotham: "Property leaders need to work together from the same set of numbers," (vendor exec, Medium–Low). [S7]
- **Real-time spend vs budget** — La Quinta Resort & Club F&B director Maurice Constantin: "I like that our system shows me the spend to-date per outlet and where it stands against budget," [S6] (operator, but about spend, not vendor risk).
- **Tech helps pass information to the distributor** — Serrano: "Tech can help get information to the distributor and organize orders and deliveries." [S3]

Vendor/consultant-voiced (lower weight, flagged):
- Predictive analytics will "reduce waste and prevent out-of-stock issues" — Valerie Layman, BirchStreet CPO. [S7] Vendor claim.
- "Digital dashboards provide a transparent view of supplier performance relative to contracts." and "Timely warnings of potential issues permit prompt intervention." — FutureLog CFO. [S30] Vendor claim.
- AI forecasting "give[s] procurement teams earlier visibility into risks" — Ashley King, an operator-side procurement director, in LODGING. [S43] Operator-voiced but forward-looking and unmeasured.

---

## 3. Skepticism and adoption barriers voiced about analytics/AI

(Most evidence is general hospitality or procurement, not vendor-risk-specific. Domain gap noted.)
- **Trust ceiling:** NYU Tisch Center / RateGain / HEDNA State of Distribution 2026 (Sep 2026; distribution/marketing, not procurement; 270+ brands): "Hotels increasingly trust AI for assistance, but not autonomy." [S19] RateGain's founder: "Buying AI is easy. Getting value from it is not". Medium.
- **Implementation, not technology:** Actabl State of Hotel AI benchmark (Hotel Management, 2 Oct 2026; vendor-run): "Implementation barriers were the number one thing holding back results from AI," with "Only 8 percent" citing limits of the technology itself. PARAPHRASE: only 42% were confident in their organization's AI data readiness; one in four reported payback. [S20] Vendor-run, Medium–Low.
- **Managers override tools they have not learned to trust** — consultant Are Morch: "Not necessarily because the system is wrong, but because the team has not yet built trust in the process." and "In other words, faster broken processes are still broken processes." [S17] Opinion, no data, Low.
- **Operators using AI cautiously:** Nightfood Holdings' Ried Floco: "we don't currently rely heavily on independent AI for analytics." [S7]
- **Chains' barriers (vendor-sponsored polls):** h2c survey of 171 chains: lack of expertise 62%, unclear strategy 51%, integration 45%, budget 39%, data quality/access 26%; trust scored 6.6/10 but reliance 4.7/10. Independents' (TakeUp, 200 respondents, publisher interest) results were positive but no barrier list was reported. [S18] Low–Medium.
- **Data-quality complaints from actual software users** (Capterra, Apicbase reviews, 2019–2024): "Complicated to setup, bugs and connection problems within suppliers and POS"; "making sometimes whole lines of reports being useless due to corrupted data."; "Apicbase requires a knowledgeable and committed restaurant team to manage it correctly and set up". [S33] TrustRadius, BirchStreet reviewer (Interstate Hospitality AGM, Jul 2019): "Sometimes invoices will appear twice in the system even though it's supposed to detect and delete duplicates." [S21] First-hand but small and older, Medium.
- **Adoption timeline:** Consultant Nasir Zahir: "Technology only delivers value when people use it effectively." and "Many hotels implement technology but never verify whether promised benefits materialized." [S27] Opinion; many numbers unsourced, Low.
- **Procurement-wide "black box" distrust (vendor content):** Zycus: "No transparency = no trust." [S31]; Fairmarkit lists "Lack of insight into the system's internal decision-making process" as a driver of mistrust [S32]. Both are vendor marketing with unsourced stats; use only as framing.
- **Unmet-need signal:** Morch: "Many hoteliers simply do not receive a clear explanation of the operational value". [S17] Consistent with a tool that must explain itself.
- **Time cost today:** a ChefTalk original poster says two relatives "both spend about 6-8 hours a week doing price comparisons". [S12] Thin, second-hand, Low.

---

## 4. Independent and seasonal resort specifics

- **Parkdean Resorts (65 UK holiday parks):** cost base normally rises in summer; shares forecast arrivals with suppliers; segments suppliers by criticality. [S10]
- **Mackinac Island (Grand Hotel / Mission Point, Sep 2021):** Liz Ware: "before you can set your table here on Mackinac Island, you have to get the food to the ferry." Executive chef Michael Cerrie: "In some cases, we have to bring in something from somewhere else." PARAPHRASE: in peak season freight ferries arrive six days a week in the early morning. [S23] University of Michigan master's thesis (2019, abstract only): food arrives by ferry "from a few large national distributors." [S24]
- **Remote Oregon lodge (Tu Tu' Tun, Aug 2026):** Derek Piva: "Dry goods were the real headache." and "The quality we wanted just isn't out here"; he got the wholesaler to start driving down ("eventually I got them to commit to driving down here themselves"); sources about 90% of summer-to-fall produce from the farmers market (PARAPHRASE). [S14]
- **Maldives island resort (Dec 2021):** purchasing manager Kabirdoss Iniyan values a supplier who "delivers on time"; peak-period wine supply was the hard part ("since consumption shoots up during that period"). [S2] Thin, but a first-hand purchasing voice at a seasonal-peak resort.
- **Staffing in tourist/remote regions:** see 1.7 [S46, S26].
- **Independents' reliance on one wholesale alternative:** see 1.4 [S36–S38].
- **Small-property purchasing role:** see 1.7 [S48].
- **Not found:** any first-hand account from an independent beach-resort or Outer Banks / Dare County operator about distributor reliability; any account of a 150–200 room independent resort's purchasing workflow. The calibration geography (Dare County) has no practitioner evidence in this file.

---

## 5. Gaps / not-found list

1. All Reddit sources (blocked/unreachable, see top).
2. First-hand statements that practitioners track vendors in spreadsheets and the tracking fails. Only vendor assertions (e.g., FutureLog: "Spreadsheets initially help organise data, but as data volumes grow, they become cumbersome." [S8]) and a generic how-to site ("simple spreadsheets or the purchasing feature built into their accounting software" [S48]) were found.
3. Current (2025–2026) broadline fill-rate or on-time benchmarks for hotels. Fill-rate numbers found are 2020–2022 and restaurant-oriented.
4. Any published figure for manager review capacity per week (project assumption A3), or proof that a dedicated purchasing role exists at 150–200-room independents (C14).
5. Operator-voiced preference for probabilistic predictions or confidence/prediction intervals. Not found in any hospitality-procurement source; only generic "explainability / trust" arguments, mostly vendor content.
6. Hotel Tech Report's verified reviews were not reproduced on the fetched page. G2/Capterra: only a handful of reviews usable; "Verified" label appeared on one.
7. Pages that failed to load: ChefTalk "Sysco does it again" (two attempts), ChefTalk "Comparing suppliers' prices", ResearchGate papers on hotel purchasing (two), Marriott purchasing posting, Alterra posting (redirected off-site), Reeco benchmarking page (only marketing metadata).
8. Undated sources: ChefTalk threads, Myrtle Beach story (~Apr 2022 inferred), Hotel Management Network H-2B piece, the US Foods governance article, Restaurant Business original of S3 (dated via the FSD copy).
9. Checked and found irrelevant: Park City resort chefs article (Dec 2025; nothing on suppliers).

---

## Implications for the project (short; for the parent session to use or discard)

- The failure modes in 1.1–1.5 match the dataset's categories well (produce/protein/dairy dominate real complaints; MRO and amenities barely appear). That is consistent with the generator's pattern of zero MRO failures.
- Real escalation behavior is relational/event-driven (S11, S41). A tool that shows trailing metrics plus a clear "why" fits; a black-box score would run into the trust issues in Section 3.
- Operators want cost and on-time prominently (S25) and cheap contingency options (S3, S41); the what-if screen can map to "what if I add a backup vendor / order further out."
- Fill-rate figures in the dataset cannot be benchmarked against real hotel data from this research; any comparison should be labelled as illustrative.

---

## Source register

★ = first-hand practitioner voice. Type: P=practitioner interview/forum/user review, T=trade press, S=survey, V=vendor marketing/sponsored, A=academic, G=government/industry association, C=consultant opinion.

| ID | Source (URL) | Type | Date | Author / role | Confidence |
|---|---|---|---|---|---|
| S1 | https://www.hospitalitynet.org/opinion/4133737/procurement-and-supply-chain-challenges-unique-to-hotels-and-hospitality-operators | C | 2026-08-06 | Francisca Fasua, procurement consultant (Nigeria) | Low |
| S2 ★ | https://hoteliermaldives.com/purchasing-power-kabirdoss-iniyan-purchasing-manager-hideaway-beach-resort-spa/ | P | 2021-12-15 | Kabirdoss Iniyan, Purchasing Manager, Hideaway Beach Resort & Spa | Medium (thin) |
| S3 ★ | https://www.restaurantbusinessonline.com/operations/supply-chain-execs-share-solutions-managing-todays-challenges ; same panel: https://foodservicedirector.com/operations/supply-chain-execs-share-solutions-todays-procurement-challenges | T/P | 2022-01-05 (FSD byline) | Operators Herrera, Serrano, Taylor; moderator Purves | Medium (conference, publisher-affiliated) |
| S4 | https://www.futurelog.com/en/service-support/resource/common-procurement-challenges-in-hospitality-procurement | V | 2025-03-13 | FutureLog (P2P vendor) | Low |
| S5 | https://ifdaonline.org/research/aligning-distributor-strategies-with-operator-needs/ | S/G | 2025-09-30 | IFDA (distributor trade body); 500 restaurant operators | Medium |
| S6 ★ | https://www.hotelmanagement.net/food-beverage/procurement-strategies-boost-your-fb-profits | T | 2024-06-01 | Elyse Glickman; quotes Constantin (La Quinta), Coulter, Mulet, Smith | Medium |
| S7 ★ | https://www.hotelmanagement.net/food-beverage/better-fb-cost-management-through-technology | T/V | 2026-01-01 | Elyse Glickman; mostly vendor execs, a few operators (Beck, McElligott, Floco) | Low–Medium |
| S8 | https://www.hotel-online.com/news/the-top-7-pain-points-in-hospitality-procurement-and-how-to-overcome-them/ | V | 2024-07-24 | Johannes Vocke, CFO FutureLog | Low |
| S9 | https://hotelbusiness.com/creative-cost-control-how-smart-fb-management-can-turn-inflation-into-innovation/ | V (sponsored) | 2025-08-13 | Paul Bennie, Reeco | Low |
| S10 ★ | https://procurementmag.com/articles/amey-fairbrother-navigating-purchasing-procurement | P/T | 2026-09-04 | Amey Fairbrother, procurement leader, Parkdean Resorts (UK) | Medium–High |
| S11 ★ | https://www.cheftalk.com/threads/how-many-vendors-are-you-using.78250/ | P (forum) | undated | Various chefs/owners (usernames partly shown) | Medium |
| S12 | https://www.cheftalk.com/threads/how-do-you-order-supplies.116110/ | P (forum) | undated | OP only, second-hand | Low |
| S13 | https://restaurant.org/education-and-resources/resource-library/rising-food-costs-tight-supplies-more-challenges-for-industry/ | S/G | 2026-03-25 | National Restaurant Association | Medium (method not stated) |
| S14 ★ | https://www.theprep.co/p/this-chef-turned-a-supply-chain-problem-into-a-community-win | P/T | 2026-08-13 | Derek Piva, exec chef, Tu Tu' Tun Lodge (OR) | Medium–High |
| S15 ★ | https://www.newsweek.com/taylor-farms-cyclospora-salmonella-outbreak-lettuce-jalapenos-recall-chef-menu-12319931 | T/P | 2026-08-13 | Joe Gera, exec chef-owner, Keystone 'Cue (PA) | High (single case) |
| S16 | https://thecaterer.com/news/nine-ten-operators-covid-supply-disruption-cga-prestige-survey | S | 2020-12-01 | CGA / Prestige Purchasing (UK); n not stated | Medium |
| S17 | https://www.hospitalitynet.org/opinion/4131316/hospitality-doesnt-have-an-ai-problem-it-has-an-operations-problem-pretending-to-be-an-ai-problem | C | 2026-03-10 | Are Morch, consultant | Low |
| S18 | https://www.phocuswire.com/ai-adoption-hotels-independents-large-groups ; https://www.hotelinvestmenttoday.com/Asset-Management/Chains-struggle-with-AI-strategy-independents-see-fast-ROI | S/V | 2025-10-03 / 2025-10-17 | h2c (171 chains); TakeUp (200 independents, publisher interest) | Low–Medium |
| S19 | https://www.hospitalitynet.org/news/4134384/more-than-50-percent-of-hotels-use-ai-but-under-10-percent-see-real-impact-finds-state-of-distribution-2026-report | S | 2026-09-15 | NYU Tisch Center / RateGain / HEDNA (distribution domain) | Medium |
| S20 | https://www.hotelmanagement.net/tech/hm-location-hotel-ai-adoption-shifts-experimentation-execution | S/V | 2026-10-02 | Josiah Mackenzie, Actabl VP marketing | Low–Medium |
| S21 ★ | https://trustradius.com/reviews/birchstreet-eprocurement-2019-07-09-21-17-42 | P (user review) | 2019-07-10 | Assistant GM, Interstate Hospitality | Medium (old, one user) |
| S22 | https://www.hoteldive.com/news/hotel-food-beverage-tariffs/750414/ | T | 2025-06-11 | Jenna Graber; quotes NRA CEO Korsmo | Medium |
| S23 ★ | https://mynorth.com/towns/mackinac-island-farm-to-ferry-thrives-at-grand-hotel-mission-point/ | T/P | 2021-09-01 | Chefs Cerrie & Cox; owner Liz Ware | Medium |
| S24 | https://deepblue.lib.umich.edu/handle/2027.42/148832?show=full | A | 2019-04 | Ari Weill, U Michigan master's thesis (abstract only) | Medium |
| S25 | https://ecommons.cornell.edu/bitstream/1813/72004/1/Verma68_An_Analysis_of_the_Supplier_Selection_Process.pdf | A | 1995 data | Verma & Pullman; manufacturing, n=58 | Medium (wrong industry) |
| S26 | https://www.hotelmanagement.net/data-trends/ahla-survey-hotels-face-rising-costs-and-staffing-strains ; secondary: https://www.marketscale.com/industries/hospitality/more-than-half-of-hotels-are-still-short-staffed-despite-70-raising-pay | S/G | 2026-03-19 / 2026-09-14 | AHLA, 246 hoteliers | Medium (method not described) |
| S27 | https://www.hospitalitynet.org/opinion/4131305/how-hotel-cost-controls-will-change-in-2026 | C | 2026-04-20 | Nasir Zahir, consultant | Low |
| S28 | https://www.hotelmanagement.net/operate/assess-your-purchasing-processes-to-stir-up-incremental-savings | V | 2018-04-30 | Cory Dellinger, Avendra | Low |
| S29 | https://www.hospitalitynet.org/opinion/4132979/smart-savings-in-hotel-procurement-a-guide-for-f-b-and-housekeeping | C | 2026-06-15 | Nasir Zahir | Low |
| S30 | https://www.hospitalitynet.org/opinion/4125601.html | V | 2025-01-30 | Johannes Vocke, FutureLog | Low |
| S31 | https://www.zycus.com/blog/ai-agents/ai-trust-gap-in-procurement | V | 2025-07-03 | Zycus | Low |
| S32 | https://fairmarkit.com/blog/5-reasons-for-ai-resistance-in-procurement | V | 2024-10-24 | Fairmarkit | Low |
| S33 ★ | https://capterra.com/p/171584/Apicbase-Restaurant-Management/reviews/ | P (user reviews) | 2019–2024 | Restaurant/hospitality users (roles shown on page) | Medium |
| S34 ★ | https://resorttrades.com/how-to-better-manage-hotel-fb-amidst-todays-labor-supply-chain-shortages/ | V/P | 2022-05-03 | Justin Jabara, president Meyer Jabara Hotels; Guy Reinbold, corp. F&B director | Low–Medium (self-promotional) |
| S35 | https://www.restaurantbusinessonline.com/operations/what-us-foods-big-changes-could-mean-customers | T | undated | Quotes activist investor Sachem Head | Low–Medium |
| S36 | https://www.seafoodsource.com/news/us-legislators-independent-restaurants-step-up-opposition-to-proposed-sysco-restaurant-depot-merger | T | 2026-10-02 | Christine Blank; IRC, Chef Dan Jacobs, senators | Medium |
| S37 | https://www.forbes.com/sites/phillempert/2026/03/31/syscos-29-billion-power-grab-what-the-jetro-restaurant-depot-deal-means-for-main-street-menus/ | C | 2026-03-31 | Phil Lempert, Forbes contributor | Low–Medium |
| S38 | https://www.santiagocompany.com/insights/why-foodservice-consolidation-now-threatens-independent-restaurant-economics | C (commercial interest) | 2026-04-03 | Josh Santiago, Santiago & Company | Low |
| S39 | https://www.fastcasual.com/blogs/know-your-operations-purchasing-score/ | T | 2013-09-23 | unnamed | Low |
| S40 | https://setupmyhotel.com/job-description-for-hotels/back-office-and-other-job-description/hotel-purchase-manager-materials-manager-job-description/ | template | undated | Template site: "Monitor vendors for quality, service and price through standard purchasing specifications." Reports to Financial Controller / GM | Low |
| S41 ★ | https://hotelmanagement.mydigitalpublication.com/publication/?i=871541&article_id=5222510&view=articleBrowser | T | 2026-10-07 | Christine Blank; Daniel Lesser (LW Hospitality Advisors), Tony Lunzman (Legacy Management) | Medium |
| S42 | https://www.hoteliermagazine.com/purchasing-success-at-hotels-is-built-on-strong-relationships-not-price/ | T | 2015-03-10 | Rebecca Harris; half supplier voices | Low (old) |
| S43 ★ | https://lodgingmagazine.com/collaboration-in-action-smarter-sourcing-and-procurement-partnerships-deliver-value-for-hotels/ | T | 2025-10-29 | Robin McLaughlin; Peters (Remington), King (Resolute Road), LaBarge (Raines), Schultz (Foodbuy GPO) | Medium |
| S44 | https://hoteltechreport.com/operations/procurement-software | V (marketplace) | 2026-05-28 | Hotel Tech Report; no review quotes on page | Low |
| S45 | https://news.yahoo.com/chicken-shortages-hurt-myrtle-beach-090000705.html | see S47 | | | |
| S46 | https://www.yahoo.com/news/articles/us-hotels-react-trump-releases-094735737.html | T | undated (~early 2026) | Hotel Management Network | Low–Medium |
| S47 ★ | https://news.yahoo.com/chicken-shortages-hurt-myrtle-beach-090000705.html | T/P | undated (~Apr 2022) | Local news; GM Bryan Compher, managers Blevins and McRaven | Medium |
| S48 | https://thehotelblueprint.com/hotel-operations/management/hotel-purchase-request-purchase-order-system/ | T (how-to) | 2026-09-30 | unsigned | Low–Medium |

(S45 duplicates S47; kept only to preserve ID numbering used in the text above. Net distinct sources fetched and read: 47, plus 1 checked-and-irrelevant: https://mountainparkcity.com/park-city-resort-chefs-reveal-food-forecast-2026/ dated 2025-12-15.)
