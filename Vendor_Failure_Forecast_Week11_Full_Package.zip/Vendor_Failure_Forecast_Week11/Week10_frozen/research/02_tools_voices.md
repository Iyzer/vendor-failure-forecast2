# Research angle 2 — How real users talk about supplier-performance / supplier-risk / predictive tools, and how they would likely react to our product

Prepared for: Week 10 (predictive model + what-if + uncertainty). Compiled 2026-10-20.

## How to read this file

- **Evidence labels.** `[VERBATIM]` = text returned by the page-fetch tool inside quotation marks. The fetch tool runs a small summarising model over each page, so a quote is "as returned by the tool", not re-checked against the raw HTML. `[PARAPHRASE]` = my summary of what a page said. `[VENDOR]` = vendor marketing. `[INFERENCE]` = my reasoning, not found in any source.
- **Confidence.** H = primary text seen, clear provenance. M = primary text seen but partial, undated, or the fetcher flagged inconsistencies. L = thin, snippet-level, or secondary.
- **Gaps up front.** Reddit (all subreddits) is blocked in this environment, so no Reddit threads were read. The review-site pages (Gartner, Capterra, G2, Hotel Tech Report) returned only partial review text. **I found no first-hand hotel purchasing manager discussing supplier-failure prediction or ranking tools.** The closest first-hand voices are hotel/restaurant accountants and finance staff reviewing procurement and inventory software (section 3) and hotel operators quoted in LODGING. Nothing below should be read as "hotel purchasing managers said X about predictive vendor-risk tools."

---

## 1. User pain, likes and dislikes (with evidence)

### 1a. Scorecards are backward-looking and do not change behaviour

| # | Finding | Source / type / date | Evidence | Conf. |
|---|---|---|---|---|
| 1 | Scorecards "rarely improve performance" because they measure after the fact | [Logistics Viewpoints, Jim Frazer, 22 Apr 2026](http://logisticsviewpoints.com/2026/04/22/why-supplier-scorecards-rarely-improve-performance/) — trade-press opinion | [VERBATIM] "It usually does not change behavior, correct root causes, or tighten execution on its own." [VERBATIM] "transparency alone does not improve supplier performance." Recommends fewer, more meaningful metrics, faster visibility into emerging issues, regular operating reviews with clear ownership. | M-H |
| 2 | Scorecards called "lagging indicators rather than proactive tools"; siloed teams rate the same supplier differently | [HICX blog, Daniel Aston](https://www.hicx.com/?p=13941) — **[VENDOR]** supplier-management software, undated | [VERBATIM] "Scorecards serve as lagging indicators rather than proactive tools." [VERBATIM] "Data silos within the organization prevent a holistic view of supplier performance" (the article's claim, not a customer's). The Orkla case-study I was looking for was not on the page. | M |
| 3 | A restaurant-focused scorecard guide says scorecards stall when data and score live in different places, and that a scorecard should yield "a short list of the calls to make" | [Supy blog](https://supy.io/blog/learn-supplier-performance-scorecard-restaurant) — **[VENDOR]**, undated | [VERBATIM] "The scorecard stalls because the data sits in a different place from the score." [VERBATIM] "If you stay manual, keep the scorecard to two metrics so the habit survives a busy month." Also lists failure modes: orders closed without a goods-received note make "that supplier's delivery record disappear"; short deliveries are "hidden as cost" via emergency top-up orders. Figures in the page are illustrative and unsourced. | M |

**Relevance.** These all support our framing (ranking forward-looking risk into a short list under a capacity cap) and warn that a ranked list alone does not "do" anything unless an action and owner are attached. Our queue already ends in a recommended action (corrective action / qualify alternate), which is the right shape.

### 1b. Users of risk-monitoring platforms: alert noise, tailoring, integration cost, thin small-vendor data

All from Gartner Peer Insights unless noted. The fetcher returned partial text; several snippets are unattributed.

| # | Reviewer (role / industry / size / date as shown) | What they said | Evidence | Conf. |
|---|---|---|---|---|
| 4 | Manager of IT Services, IT Services, 1B–10B USD, 23 Apr 2026, 4.0 — [Gartner: Resilinc](https://www.gartner.com/reviews/product/resilinc-112976184) | Likes real-time assessment and surfacing single points of failure; con: alerting is comprehensive but "must be precisely tailored to the user's specific needs" | [PARAPHRASE] of cons; the quoted fragment is from the fetch summary | M |
| 5 | Unattributed reviewer, same page | Product "is not evolving as fast as expected" | [VERBATIM] "Resilinc is not evolving as fast as expected as a product." Said they had not benefited from new capabilities in two years. | L-M |
| 6 | Reviewer on [Gartner: Prewave](https://www.gartner.com/reviews/market/supplier-risk-management-solutions/vendor/prewave), 13 Aug 2026, 4.0 | Review title only; body not retrievable | [VERBATIM] title: "Real-time monitoring transforms supplier risk management, though alert noise persists." Fetcher also reported conflicting rating counts. | L |
| 7 | Solution Architect, Banking, 3.0, 11 Aug 2026 — [Gartner: Moody's Supplier Risk Mgmt](https://www.gartner.com/reviews/product/moodys-supplier-risk-management) | Praises financial-data depth; cons: steep learning curve, high cost, rigid interface, limited connectivity and customization | [PARAPHRASE] | M |
| 8 | Unattributed text, same page | Interface "does not suit non-risk specialists", customising rules/dashboards is complex; integration needs "considerable technical effort" | [PARAPHRASE] of unattributed snippet | L |
| 9 | Procurement Associate, Real Estate, 4.0, Oct 2026 — [Gartner: D&B Supplier Intelligence](https://www.gartner.com/reviews/product/dandb-risk-analytics-supplier-intelligence) | Likes automatic vendor-health tracking; con on small vendors | [VERBATIM] "However, finding deep background details on small vendors is often difficult." | M |
| 10 | Director of Supplier Risk Management, Manufacturing, 3.0, 17 Jan 2025, same page | Review title questions reliance on the algorithm | [VERBATIM] title: "D&B's Dominance Questioned: Is Reliance on Algorithm Flawed?" Body was placeholder text — **content unknown**. | L |
| 11 | Tom C., GSOC Analyst, 4.0, 20 Aug 2020 (incentivised review) — [Capterra listing](https://www.capterra.com/p/189655/Resilinc/) | Pro for our purposes: easy data export for scenario work. Note: the review sits on a page for a different product category despite the URL; treat as weak. | [VERBATIM] "The ability to export data. Easy to do when running what if scenarios." | L |

Gartner pages for Everstream vs Resilinc returned star ratings only (no review text); noted for completeness, not used as evidence.

### 1c. Hotel and restaurant finance/ops staff on purchasing and inventory software

These are the closest first-hand hospitality voices available.

| # | Reviewer / date | Comment | Evidence | Conf. |
|---|---|---|---|---|
| 12 | Controller, 500+ room branded hotel, San Jose (≈9 yrs ago) — [Hotel Tech Report: Birchstreet](https://hoteltechreport.com/operations/procurement-software/birchstreet) | Managers under-trained, many orders happen outside the system; ongoing training cost-prohibitive | [VERBATIM] "I wish that the managers were better trained on the capability the program has." | H |
| 13 | Hospitality Accountant, 200–499 room boutique, Chicago (≈4 yrs ago), 1.5/5 | "Outdated UX"; cluttered, PO status unclear | [PARAPHRASE] (title "Outdated UX" is verbatim) | H |
| 14 | Staff Accountant, 200–499 room branded hotel, Coral Gables (≈3 yrs ago), 5/5 | Likes one consolidated view of POs with receiving status | [PARAPHRASE] | H |
| 15 | Cailin H., Financial Analyst, Restaurants, 2.0, 29 Mar 2019 — [Capterra: Restaurant365](https://capterra.com/p/139768/Restaurant365/reviews/) | Stock-count pricing changed unexpectedly, wrong unit-of-measure conversions, unreliable invoice-approval workflow | [VERBATIM] "I feel like I'm using an unfinished product." | M |
| 16 | Richard P., President, Wine and Spirits, 2.0, 23 Apr 2019, same page | Inventory features (PAR levels) not working, wrong dashboard data | [VERBATIM] "many inventory features like PAR's do not work" | M |
| 17 | Vincent C., Beverage Director, Restaurants (51–200), 2 Feb 2026, same page | Ease of use for non-computer-oriented managers | [VERBATIM] "Super easy to use & very straightforward: most of our managers do not frequently work on computers." | M |
| 18 | Michael N., Finance Manager, Restaurants, 1 Apr 2019, same page | Hard to learn without finance background; wants better training | [VERBATIM] "The system runs slow at times" (the other points are [PARAPHRASE]) | M |
| 19 | Brian B., Purchasing Manager, G2 reviews mirrored on [SaaSworthy](https://www.saasworthy.com/product/restaurant365/reviews), 30 Nov 2023 | Reporting helps growth but "potentially way too many reports" | [VERBATIM] "Potentially way too many reports but we just were signed up so other things may come up." | M |
| 20 | Debora M., role not stated, same page, 30 Nov 2023 | Terminology a barrier for non-accountants | [VERBATIM] "For non accounting professionals, language can be an issue." | M |
| 21 | Dana, Food & Beverages, 2.0, 11 Aug 2023 — [Capterra: MarginEdge](https://www.capterra.ca/reviews/187718/marginedge) | Slow vendor payments, hard credit tracking (the one significant negative of five reviews fetched) | [PARAPHRASE] | M |
| 22 | Heather M., Beverage Director — [GetApp: MarginEdge](https://www.getapp.com/retail-consumer-services-software/a/marginedge/reviews/) | Had used Bevspot and Xtrachef; prefers MarginEdge for breadth | [VERBATIM] "comprehensive coverage of invoicing, transfers, inventory, ordering, bill pay, and costing" | M |

**Pattern.** Praise goes to *consolidated visibility* and *time saved*; complaints cluster on *learning curve, jargon, clutter, slow support, wrong data/units*, and *staff not using the system* (so the data is incomplete). None of these reviewers discuss forecasts or probabilities.

### 1d. Hotel operators on procurement risk (context, not tool feedback)

| # | Voice | Evidence | Conf. |
|---|---|---|---|
| 23 | Ted Peters (Remington Hospitality), Jason LaBarge (Raines), Ashley King (Resolute Road Hospitality) in [LODGING, R. McLaughlin, 29 Oct 2025](https://lodgingmagazine.com/collaboration-in-action-smarter-sourcing-and-procurement-partnerships-deliver-value-for-hotels/) | [VERBATIM] Peters: procurement "is no longer just about the cheapest price" and is about "making sure things are reliable, consistent, and flexible across all hotels." [VERBATIM] King: "Vendors are also keeping leaner inventories." [VERBATIM] LaBarge: "Tariffs are certainly the most concerning trend." The piece quotes a GPO (Foodbuy) heavily; no sponsorship tag shown in the text. It does not address small or independent hotels. | M |
| 24 | National Restaurant Association CEO Michelle Korsmo, via [Hotel Dive/Restaurant Dive, J. Graber, 23 Jun 2025](https://www.restaurantdive.com/news/hotel-food-beverage-tariffs/750430/) | [VERBATIM] "tariffs will hike food and packaging costs and add uncertainty to managing availability." No hotel operator is quoted in the article. | M-H |
| 25 | Avendra (GPO) [2026 outlook](https://avendra.com/en/us/resources/the-avendra-edge/2026-hospitality-procurement-outlook) — **[VENDOR]** | [VERBATIM] "Turkey supply will remain constrained due to bird health issues." Premium linen lead times 90–180 days in Q2. Contains no supplier-performance data. | M |

---

## 2. Adoption barriers

| # | Barrier | Evidence | Source / type | Conf. |
|---|---|---|---|---|
| 26 | **Small hotels: budget, lean staff, integration, complexity** | [PARAPHRASE] "Nearly half" of surveyed independents say affordability and value drive technology decisions; one in four cite complexity as the biggest adoption challenge; one in three prioritise ease of use; integration with existing systems and lack of vendor support also cited. Survey of 1,200+ hoteliers, July 2019. | [Skift/SkiftX, 11 Nov 2019](https://skift.com/2019/11/11/how-small-independent-hotels-are-using-tech-to-be-more-competitive/) — **sponsored content by Expedia Group**, no author | M (old, sponsored) |
| 27 | **Pricing opacity at hotel-procurement vendors** | [PARAPHRASE] Birchstreet publishes no general pricing; quotes tiered by room count (1–9 up to 500+). No reviewer is a small or independent property; the HTR page's "boutique/limited-service recommendation rate" of 30% rests on one reviewer each. | [HTR Birchstreet](https://hoteltechreport.com/operations/procurement-software/birchstreet), [HTR compare](https://hoteltechreport.com/compare/birchstreet-vs-innflow-procurement) | H |
| 28 | **Restaurant tools' listed price points** | [PARAPHRASE] "From $330/location/month" for MarginEdge; reviewer is affiliate-linked. | [CFO Club review](https://thecfoclub.com/tools/marginedge-review/) — affiliate | L-M |
| 29 | **Trust and explainability** | [VERBATIM] "No transparency = no trust." [VERBATIM] "Allow procurement teams to override AI decisions". Zycus cites a 40.2/100 AI-readiness score and 35% with AI governance but gives no methodology. | [Zycus, 3 Jul 2025](https://www.zycus.com/blog/ai-agents/ai-trust-gap-in-procurement) — **[VENDOR]** | L-M |
| 30 | **"Black box" is a stated concern; human-in-the-loop is expected** | [PARAPHRASE] Ardent Partners/Ivalua survey (reported 23 Jul 2026): 96% rate black-box AI risk as high or moderate; 63% say human-in-the-loop approval for critical decisions is non-negotiable; 59% cite data quality/availability as the top obstacle; only 11% have a unified procurement data model; 34% have no formal AI governance. Sample size and industries not reported in the article. | [The Supply Chain Xchange](https://www.thescxchange.com/finance-strategy/procure/procurement-leaders-pursue-ai-but-their-it-systems-lag) — trade press reporting a vendor-sponsored survey | M |
| 31 | **Usage lags understanding; tool sprawl** | [PARAPHRASE] ORO Labs 2025 report: 85% piloting/using AI but only 49% clearly understand agentic AI; 39% provide formal training; two-thirds use >10 procurement tools, only 8% think most deliver expected returns. Sample: 200+ executives at firms >$500M revenue (so not small hotels). [VERBATIM] "AI is widely in use but unevenly understood." | [Digital Commerce 360, 10 Sep 2025](https://www.digitalcommerce360.com/2025/09/10/procurement-faces-rising-pressure-ai-adoption-outpaces-readiness/) — trade press on vendor-sponsored survey | M |
| 32 | **Generic resistance narratives** | [VERBATIM] black-box problem: "the lack of insight into the system's internal decision-making process." Cites a "94% technology anxiety" figure without a source. | [Fairmarkit blog](https://fairmarkit.com/blog/5-reasons-for-ai-resistance-in-procurement) — **[VENDOR]** | L |
| 33 | **Hypothesis only: interpretability affects manager adoption** | The Wharton Mack Institute page is a 2019 *funded research proposal* (K. Hosanagar), not a result; it states the hypothesis that opacity "hurts the adoption of predicted analytics by managers who don't trust a system." | [Mack Institute](https://mackinstitute.wharton.upenn.edu/?p=18170) | H that it is only a hypothesis |

**Cross-cutting point.** Sources 12, 19–20 (users) and 30–31 (surveys) agree that the binding constraint is usually *people and data capture*, not model quality. In particular, orders placed outside the system (source 12) and closed orders without receiving records (source 3) are exactly the missing-data conditions our `snap_vendor_week` rules (W19 missing ≠ zero; W21 latency) are designed to survive.

---

## 3. Comparable existing products and what users say

| Product | Category | What users say | Evidence | Conf. |
|---|---|---|---|---|
| Birchstreet | Hotel procurement/AP (enterprise-skewed) | 3-way match and PO/receiving visibility valued; UX dated in one review; training burden; pricing by quote | Sources 12–14, 27 | H (only 3 reviews) |
| Restaurant365 | Restaurant accounting + inventory + purchasing | Consolidation praised; complaints on bugs, slow support, jargon, unfinished features | Sources 15–20 | M |
| MarginEdge | Restaurant invoice/cost control | Breadth and ease praised; payments/credit-tracking complaint; price per location | Sources 21–22, 28 | M |
| Resilinc, Prewave, Moody's, D&B, Everstream | Enterprise supplier-risk monitoring (mostly manufacturing / large-company) | Real-time monitoring valued; alert tailoring, noise, cost, integration effort, thin small-vendor data | Sources 4–11 | M-L |
| Supy (restaurant supplier scorecard) | Restaurant ops software | Marketing guidance; delivery accuracy, price accuracy, credit rate; manual scorecards decay | Source 3 | L (vendor) |

**What none of these appear to offer (inference from the pages read, not a market survey):** a *capacity-aware* queue (top-k by season-weighted expected cost) paired with a lead-time-aware action recommendation for one property. Enterprise risk platforms monitor external signals (news, financials); restaurant tools track price and cost. The Supy guide does name "delivery accuracy" and "short deliveries" as the signals that matter, which matches our `trailing_*_rejection_rate`/`fill_rate`.

---

## 4. Critiques we should pre-empt

### 4a. Trained on synthetic data (the critique a data scientist or professor will raise first)

- Jan Bosch, Bits&Chips, 13 Apr 2026 ([source](https://bits-chips.com/article/who-needs-data-when-you-can-create-it/)), opinion by a professor/consultant: [VERBATIM] "The central challenge is one of fidelity: How do we know that the generated data truly reflects the real world?" He describes models that "perform well in simulation but fail in practice" (the "sim-to-real gap"), says generation "encodes assumptions about what matters", and that synthetic data "must be continually checked and calibrated against real observations." **Conf. M-H** (single opinion piece).
- Schaeffer et al., "Position: Model Collapse Does Not Mean What You Think," arXiv 2503.03150 ([source](https://arxiv.org/html/2503.03150v2)): about model collapse in generative models trained on their own outputs, *not* about tabular risk models trained on simulator output. Useful only for the narrower point that "Population risk provides a holistic view of performance, but may mask specific failure modes" and tail risk can degrade while average metrics look fine. **Conf. M; relevance indirect.**
- Yaw Etse, HackerNoon, 20 Aug 2024 ([source](https://hackernoon.com/data-quality-is-all-you-need-why-synthetic-data-is-not-a-replacement-for-high-quality-data)), VP Engineering at a bank, opinion piece. Cites model collapse; recommends synthetic data for "testing and scenario simulation." **Conf. L-M; mostly about LLMs.**
- **[INFERENCE] Why it matters here.** Our "2026 holdout" is generated by the same code with shifted parameters (generation rules G2, G34). Any accuracy we report measures recovery of our own generator, not real-world performance. The defensible claim is about *method* (leakage-safe snapshots, offset model, calibrated intervals, ranking under capacity), and the report should say so plainly.

### 4b. Uncertainty displays can confuse as easily as help

- Experiment reported in *European Journal of Operational Research* 205(1), 2010 (authors not shown on the page I fetched; paper title "Do forecasts expressed as prediction intervals improve production planning decisions?") ([source](https://ftp.iaorifors.com/paper/66660)): production-planning participants received point forecasts, 50% or 95% prediction intervals. [VERBATIM] "The prediction intervals did not improve the quality of the decisions." They also "reduced the propensity of the decision makers to respond appropriately to the asymmetry in the loss function." A simple heuristic applied to 85% intervals gave "nearly optimal decisions." **Conf. M (abstract-level; one lab study, 2010).**
- Teigen, Andersen, Alnes, Hesselberg, *IJMPB* 13(2), 2020 ([source](https://www.emerald.com/insight/content/doi/10.1108/IJMPB-06-2018-0114/full/html)): construction-company staff, students and judges misread a probabilistic cost estimate (additivity neglect, a "cliff" effect above an arbitrary maximum, verbal labels like "entirely possible" applied to unlikely tail values). Full text paywalled; summary from abstract. **Conf. M.**
- Base-rate neglect: with a rare condition "There are far more false positives than true positives" (Jason Collins, 12 Apr 2022; [source](https://blog.jcx.au/posts/explaining-base-rate-neglect)); a 90%-sensitive test at 1% prevalence and 9% false-positive rate gives about 9% post-test probability. **Conf. H for the arithmetic; the example is medical, not procurement.** The project's material-failure rate is about 4–6% of vendor-weeks, so the same logic applies: even a good model's "top-5" will contain misses and false alarms.
- Naive count intervals undercover: Menssen et al., arXiv 2404.05282 ([source](https://arxiv.org/pdf/2404.05282)): Poisson-based limits assume mean = variance; with overdispersion their simulated coverage fell as low as "58%" against a nominal 95%; they build quasi-Poisson / negative-binomial prediction intervals with exposure as an **offset**, calibrated by bootstrap. **Conf. M-H (preprint, but directly on point).**

### 4c. Users override or ignore ranked alerts

- Poly et al., *JMIR Med Inform* 2020;8(7):e15653, a systematic review of 23 studies ([source](https://medinform.jmir.org/2020/7/e15653/PDF)): [VERBATIM] "The range of average override alerts was 46.2%-96.2%." Between 29.4% and 100% of overrides were judged appropriate. Different domain (clinical alerts), but the clearest quantified evidence on what high alert volume does. **Conf. H for the numbers; transfer to purchasing is [INFERENCE].**
- Our design choice (a fixed k-sized list, not an alert stream) is the structural answer, but the report should say so.

### 4d. People use an imperfect model more when they can adjust it

- Dietvorst, Simmons, Massey, 2016 ([source](https://repository.upenn.edu/marketing_papers/389)), incentivised forecasting studies: participants were "considerably more likely to choose to use an imperfect algorithm when they could modify its forecasts"; "one can reduce algorithm aversion by giving people some control—even a slight amount—over an imperfect algorithm's forecast." **Conf. H.** This supports the what-if screen and an explicit override log.
- Gathani et al., arXiv 2212.13643 (22 business professionals in marketing, sales, product, operations): users already do what-if analysis in "rudimentary tools"; techniques "improved decision-making efficiency and confidence"; needs include data prep, risk assessment and integrating domain knowledge ([source](https://arxiv.org/abs/2212.13643v4)). **Conf. M-H.**

### 4e. Goodhart / feedback loops (analogy, not direct evidence)

- Reynaert & Sallee, NBER WP 22911, 2016 (cars, EU CO2 tests) ([source](https://www.nber.org/papers/w22911.pdf)): "stronger policy incentives lead to more gaming." It is about emissions testing, not risk scores. **[INFERENCE]** if suppliers learn their on-time/rejection rates drive scrutiny, they may manage the *measured* signal (e.g., re-timing deliveries, disputing rejections). More important internally: a flagged vendor gets a corrective action, which then *lowers* its failure rate, so naive back-testing on historical labels can punish good predictions. The project's oracle table (untreated counterfactual) exists to handle exactly this and should be named in the report.

### 4f. Scorecard ranking can look like theatre

See 1a: "transparency alone does not improve supplier performance." Pre-empt by tying each ranked row to an action with lead time and owner.

---

## 5. INFERENCE — what each persona would probably think of our product

*Everything in this section is my reasoning from the evidence above plus the project docs. None of it is a quote or a finding from a source. No person in the sources was asked about our product.*

### Purchasing & Receiving Manager (the decision-maker)

- **Would like:** a short, ranked list sized to their real capacity (k shrinks at peak); a plain-language "why this vendor" line; the concrete lead-time warning ("8 weeks to qualify, peak starts in 5"); the ability to see the recent receiving history behind a score.
- **Would worry about:** extra data-entry (evidence 12, 19–20: managers skip the system); jargon ("offset", "prediction interval"); being blamed if the tool misses a failure; another login. Receiving data quality is their data.
- **Will want:** override + reason log; "show me last 8 deliveries"; a printable weekly list; mobile/tablet view at the receiving dock.

### Controller / General Manager (approves volume shifts, owns budget)

- **Would like:** dollar framing (expected cost, not a risk index) tied to departments, and the approval-lead-time (1–2 weeks) shown in the timeline.
- **Would worry about:** "what does this replace, and what does it cost?" — small-hotel buyers prioritise affordability and ease of use (evidence 26); an unvalidated model driving terminations; synthetic-only validation.
- **Will want:** a conservative default (recommend corrective action before switching vendors), a stated confidence level in dollars, and a simple payback story: how much failure cost the top-k review would have avoided versus current practice.

### Procurement director (multi-property or GPO-style buyer)

- **Would like:** the capacity-constrained prioritisation and the baseline comparison against trailing-rate ranking.
- **Would worry about:** vendor consolidation and tariff-driven switching changing risk faster than a model trained on 2023–2025 can follow; integration with Birchstreet/Avendra/GPO contracts (evidence 23–25, 27); governance: 63% say human-in-the-loop approval is non-negotiable (evidence 30).
- **Will want:** category-level views, contract/price data alongside reliability, an audit trail.

### Data scientist (skeptical reviewer)

- **Would attack first:** the synthetic data (4a) — "you've modelled your generator"; the rare-event base rate and class imbalance (4b); whether the interval has proper coverage under overdispersion (4b, Menssen); look-ahead leakage and the manager's own past actions in the features (our docs already address both: S6, S7, W18, W20); multiple comparisons across 50 vendors × 156 weeks; temporal vs random split; calibration, not just AUC.
- **Would like:** an offset-based count/rate model that cannot confuse volume with risk; temporal holdout; calibration curve; interval coverage reported on the holdout; a clear baseline (current practice).
- **Will want:** a reliability/calibration plot, coverage of the stated interval (e.g., "the 80% interval covered X% of 2026 vendor-weeks"), and a sensitivity run to the generator assumptions A1–A4.

### Professor (grader)

- **Would like:** a modelling choice justified by the decision structure (risk × exposure × cost; offset), honest disclosure of the synthetic-data limit, uncertainty shown on what-if outputs, and a one-page report that ties model performance to a decision.
- **Would worry about:** a polished UI over an unvalidated model; claims that outrun the evidence (e.g., calling holdout performance "real-world").
- **Will want:** performance on a time-based holdout, intervals with stated coverage, a baseline, what-if that visibly changes with inputs, and limits stated in the video.

### Concrete objections to pre-empt (ranked by likely severity)

1. "This is synthetic — how do you know it works on real vendors?" → Say the claim is about method; show sensitivity to generator parameters; name what real data would be needed.
2. "Does the interval actually cover?" → Report empirical coverage on the 2026 holdout; use an overdispersion-aware interval (not a naive Poisson one).
3. "With ~5% base rate, won't the top 5 be mostly false alarms?" → Show expected true catches in the top-k versus the trailing-rate baseline in natural frequencies ("out of 100 weeks like this…").
4. "Will managers over-trust or ignore it?" → Keep a fixed k, show the reasoning, allow overrides, log them.
5. "Corrective actions change outcomes, so how do you evaluate fairly?" → Point to the oracle/untreated counterfactual and exclude the manager's historical action from features.
6. "Why would a small hotel adopt this?" → Offer a no-integration CSV mode and a one-page weekly output (evidence 26–28).

### Features these audiences would likely want (not all appropriate for Week 10)

- Reliability/calibration plot and holdout coverage next to every interval.
- Sensible what-if sliders: occupancy/season, vendor trailing rates, deliveries per week, open-CAP flag — with the interval widening visibly when inputs go outside the training range.
- "Why this rank" panel: top three contributing factors in plain words.
- Baseline comparison: tool vs trailing-rate vs spend-ranked, in dollars.
- Data-health banner (missing receiving records, latency window) so users know when the score is unreliable.
- Override log and weekly export.

---

## 6. Not-found list

- **Reddit** (r/procurement, r/supplychain, r/analytics, r/datascience, hospitality/restaurant subs): fetch blocked; domain-filtered searches rejected. No Reddit evidence at all.
- **First-hand hotel purchasing/receiving managers** discussing vendor reliability or predictive tools: none found.
- **Small/independent hotel procurement tool reviews:** none; HTR Birchstreet has no small-property reviewers.
- **Full review text** on most Gartner/G2/Capterra pages (only titles/snippets/partials retrieved). G2's Restaurant365 page showed aggregates only (4.6/5 from 324 reviews, 4-month implementation, 15-month ROI — [PARAPHRASE]).
- **Orkla case study** (HICX) — not on the fetched page.
- **arXiv 2609.02465** (risk-based alerting, alert fatigue) and **arXiv 2608.27996** (testing synthetic datasets with minimal real data): PDFs had no extractable text; not used.
- **Hacker News:** one useful thread (id 21410708, black-box vs interpretable) with unattributed comments; id 21953293 failed to load; id 18650646 yielded one short comment ("Nobody will care what math/methods you use if you can add value."), username not shown.
- **Hotel F&B specific predictive-risk literature:** not found in this pass.
- **Sources I would not rely on:** Zycus, Fairmarkit, Supy, HICX, Avendra (vendors); Skift piece (sponsored; 2019).

## Source count

37 distinct URLs read with usable content (≈12 vendor/sponsored, ≈10 review-site pages with first-hand reviewer text, ≈8 research papers/proceedings/abstracts, remainder trade press/opinion). First-hand user voices with role or name shown: 20+ across sources 4–22 (Gartner, HTR, Capterra, G2/SaaSworthy, GetApp) plus LODGING-quoted hotel operators (source 23).
