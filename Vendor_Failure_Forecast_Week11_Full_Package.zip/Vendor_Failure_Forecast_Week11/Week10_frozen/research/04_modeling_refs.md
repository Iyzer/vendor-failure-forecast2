# Research angle 4 — modeling & uncertainty references for Week 10

Scope: citable support (and honest limits) for our planned approach: next-week vendor material-failure model, binomial GLM with cloglog link and log(expected deliveries) offset, partial pooling of vendor effects, temporal holdout (train 2023–25, test 2026), calibration, GBM benchmark, top-k cost-capture evaluation, and what-if predictions with intervals.

**How "verified" is used here.** A reference is VERIFIED only if I fetched a page (publisher, repository, RePEc/IDEAS, arXiv, PubMed/PMC mirror, author site) that shows the title, authors, venue, and an abstract or substantive description. The fetch tool relays pages through a summarizer, so anything in quotation marks below is text the tool returned as a quote. Re-check each quote against the original before putting it in quotation marks in the submitted report. Paraphrases are marked "Says:". Items I could only see in a search-result list, or only partly fetched, are in Section 3 (UNVERIFIED / PARTIAL).

---

## 1. Verified references by topic

### 1.1 Supplier delivery-failure / disruption prediction (thin literature — see Section 4)

**R1. Brintrup, Pak, Ratiney, Pearce, Wichmann, Woodall, McFarlane (2020).** "Supply chain data analytics for predicting supplier disruptions: a case study in complex asset manufacturing." *International Journal of Production Research* 58(11): 3330–3341. https://ideas.repec.org/a/taf/tprsxx/v58y2020i11p3330-3341.html
- Says: uses an OEM's historical data to predict first-tier supplier disruptions. Three phases (feature engineering, a purpose-built performance metric, an algorithm/parameter experiment). An engineered "agility" feature gave the best results. The final model predicts "late orders" with 80% accuracy. Domain knowledge matters for feature engineering.
- Use: "Supplier-disruption prediction from historical order data is feasible but, in the one verified applied study, was evaluated by accuracy on late orders, not by decision value under a capacity limit." (contrast sentence that motivates our top-k metric)

**R2. Baryannis, Validi, Dani, Antoniou (2019).** "Supply chain risk management and artificial intelligence: state of the art and future research directions." *International Journal of Production Research* 57(7): 2179–2202. DOI 10.1080/00207543.2018.1530476. https://ideas.repec.org/a/taf/tprsxx/v57y2019i7p2179-2202.html
- Says: literature review mapping AI methods (mathematical programming to ML) against risk identification/assessment/response tasks; identifies gaps and future directions.
- Use: "Reviews of AI in supply-chain risk management treat risk assessment and response as separate tasks; our tool links them through a weekly capacity-constrained review decision."  (My framing of the review's task taxonomy; the review does not say this.)

**R3. Tomlin, B. (2006).** "On the Value of Mitigation and Contingency Strategies for Managing Supply Chain Disruption Risks." *Management Science* 52(5): 639–657. https://ideas.repec.org/a/inm/ormnsc/v52y2006i5p639-657.html
- Says: two-supplier model (unreliable cheap, reliable expensive). The best strategy depends on supplier uptime and on whether disruptions are frequent-and-short or rare-and-long. Contingent rerouting to a reliable supplier lowers cost when that supplier can ramp up, but simple mitigation often beats contingent rerouting when disruptions are rare.
- Use: "Whether it pays to qualify an alternate depends on disruption frequency and duration, so the tool reports both the failure rate and the lead time to act." (supports lead-time/horizon framing, not the model form)

### 1.2 Rare events, cloglog, offsets for exposure

**R4. King, G. & Zeng, L. (2001).** "Logistic Regression in Rare Events Data." *Political Analysis* 9(2): 137–163. https://ideas.repec.org/a/cup/polals/v9y2001i02p137-163_00.html (also https://gking.harvard.edu/publication/logistic-regression-in-rare-events-data/)
- Says (abstract): standard logistic regression can substantially underestimate rare-event probabilities; proposes corrections; shows that sampling all events and a fraction of non-events supports valid inference. Direct quote relayed from Harvard page: "popular statistical procedures, such as logistic regression, can sharply underestimate the probability of rare events."
- Citation caution: the Harvard page relayed "Journal of Statistical Software, vol. 8", which conflicts with RePEc (Political Analysis 9(2):137–163). Use the RePEc/Political Analysis citation.
- Use: "Because failures are rare, we assess calibration directly instead of trusting default logistic output."

**R5. Allison, P. (2012; page modified 2024).** "Logistic Regression for Rare Events." Statistical Horizons blog. https://statisticalhorizons.com/logistic-regression-for-rare-events/ (practitioner post — see Section 2)
- Says: the concern is "the possibility of a small number of cases on the rarer of the two outcomes," not rarity itself (examples: 20 events in 1,000 rows is a problem; 2,000 events in 100,000 rows is fine). King–Zeng's alternative is very similar to Firth penalized likelihood; Allison argues "a case could be made for *always* using penalized likelihood."
- Use: "With 323 development-year failures, the rare-event bias problem is small, and we add a ridge penalty that also stabilizes sparse vendors."  (323 is from the parent's data check, not this source.)

**R6. Charpentier, A. (2015).** "Modelling Occurence of Events, with some Exposure." Freakonometrics (via R-bloggers, 28 Jul 2015). https://www.r-bloggers.com/2015/07/modelling-occurence-of-events-with-some-exposure/
- Says: for binary outcomes observed over different exposure, a logit with offset(log exposure) was "unjustified" and gave predictions far from the target; a log-link binomial failed to converge; the **cloglog link with log(exposure) as an offset works** and matches Poisson-process logic. Quote relayed: "the logarithm of the exposure should be taken as an offset variable."
- Math behind it (standard, my derivation): if failures arrive as a Poisson process with rate λ per delivery and E deliveries are expected, P(at least one failure) = 1 − exp(−λE), so cloglog(p) = log λ + log E. That is exactly a cloglog GLM with offset log E.
- Use: "We model next-week failure with a complementary log-log link and log(expected deliveries) as an offset, so a vendor's risk per delivery is separated from how often it delivers."

**R7. Charpentier, A. (c. 2013).** "Exposure with binomial responses." Freakonometrics (via R-bloggers). https://r-bloggers.com/?p=64948
- Says: P(Y=0)=P(N=0)^E under a Poisson process; log-binomial with exposure failed to converge; Taylor approximation P(Y>0)≈E·P(N>0). The post does NOT mention cloglog. Date is inferred from image paths, not stated.
- Use: background only; cite R6 for cloglog.

**R8. Parry, S. (Cornell Statistical Consulting Unit; 2018, updated 2022).** "To Offset or Not: Using Offsets in Count Models." https://cscu.cornell.edu/wp-content/uploads/offsets.pdf
- Says: an offset is log(exposure) with coefficient fixed at 1; it assumes the count scales proportionally with exposure; adding exposure as an ordinary covariate estimates its own coefficient and lets non-proportional scaling appear; a likelihood-ratio test can compare the two. Also says binary-outcome trials should use a binomial model, not a count model with trials as the offset.
- Use: "We test the proportional-exposure assumption by adding log(deliveries) as a free covariate and comparing with the offset model by likelihood ratio." (This is a check we can run and report in one line.)

**R9. Tsubota, Y. & Beppu, K. (arXiv 2506.00889; date not shown on fetched page).** "Improved Risk Ratio Approximation by Complementary Log-Log Models: A Comparison with Logistic Models." https://arxiv.org/html/2506.00889v1
- Says: odds ratios approximate risk ratios only for rare outcomes (deviation noticeable around 10% prevalence); the complementary-log ratio approximates the risk ratio better than the odds ratio across their bias measure, supported by simulation; cloglog models are standard GLMs (`binomial(link="cloglog")`). Preprint, not peer reviewed as far as I could tell.
- Use: "Under a cloglog link, a coefficient reads as a multiplicative change in the failure rate, which matches how a manager thinks about 'twice as risky'."  (cite as preprint; weaker than R6 for exact form)

**R10. Statalist thread (Dec 2023 – Mar 2024).** "Poisson regression: an offset variable with values of zero." https://www.statalist.org/forums/forum/general-stata-discussion/general/1738521-poisson-regression-an-offset-variable-with-values-of-zero
- Says: Leonardo Guizzetti replied that exposure "must be a value greater than 0" because the log of non-positive values is undefined, and that exposure is best thought of as the denominator of a risk or rate. (Paraphrase; quote text as returned by fetch tool.)
- Use (design implication, not report text): vendor-weeks with zero expected deliveries cannot take an offset. This matches our "missing, not zero" rule. Drop or flag them rather than adding a small constant silently.

### 1.3 Calibration and goodness of fit

**R11. Van Calster, McLernon, van Smeden, Wynants, Steyerberg & STRATOS Topic Group 6 (2019).** "Calibration: the Achilles heel of predictive analytics." *BMC Medicine* 17(1): 230. DOI 10.1186/s12916-019-1466-7. https://pubmed.ncbi.nlm.nih.gov/31842878/ (authors confirmed at https://cris.maastrichtuniversity.nl/en/publications/calibration-the-achilles-heel-of-predictive-analytics)
- Says (abstract): calibration of risk models, regression or ML, gets too little attention; poorly calibrated models can mislead decisions; balance model complexity against sample size; assess calibration in validation; update models when needed. Quote relayed: "poorly calibrated algorithms can be misleading and potentially harmful for clinical decision-making."
- Use: "We judge the model on calibration, not just ranking, because a manager who sees '8%' must be able to trust it."

**R12. Hosmer, Hosmer, le Cessie, Lemeshow (1997).** "A comparison of goodness-of-fit tests for the logistic regression model." *Statistics in Medicine* 16: 965–980. https://community.jmp.com/kvoqx44227/attachments/kvoqx44227/discussions/58739/1/Hosmer%20et%20al%20A%20Comparison%20of%20GoF%20Tests%20for%20the%20Logistic%20Regression%20model%20StatInMed1997.pdf (reached through a JMP community attachment; I could not locate a publisher page)
- Says: grouped chi-square tests can give conflicting answers depending on how groups are formed; for a wrong link function, power was poor at n=100; authors recommend Pearson chi-square and/or unweighted sum of squares, supplemented by the Hosmer–Lemeshow decile test and Stukel's test.
- Use: do not rely on one Hosmer–Lemeshow p-value; show a calibration plot with intervals plus a calibration slope/intercept. (Note: these tests were studied for logit models; applying them to a cloglog fit is our extension.)

**R13. Gneiting, T. & Raftery, A. E. (2007).** "Strictly proper scoring rules, prediction, and estimation." *Journal of the American Statistical Association* 102: 359–378. DOI 10.1198/016214506000001437. https://academicnewsletter.sufe.edu.cn/info/445563 (volume not stated by that page; abstract at https://apps.dtic.mil/sti/html/tr/ADA459827/index.html)
- Says: a scoring rule is strictly proper if the forecaster maximizes expected score by reporting the true distribution; proper rules encourage honest forecasts. The abstract excerpt does not mention calibration or sharpness.
- Use: "We score probabilities with the Brier score and log loss, which reward honest probabilities, instead of accuracy at a cut-off."

**R14. Harrell, F. (2017).** "Damage Caused by Classification Accuracy and Other Discontinuous Improper Accuracy Scoring Rules." fharrell.com, 1 Mar 2017. https://www.fharrell.com/post/class-damage/ (practitioner post)
- Says: "Estimating tendencies is usually a more appropriate goal than classification." Accuracy is discontinuous and improper; Brier and log scores preferred.
- Use: supports R13 in plain language.

**R15. Kuhn, M. (2023).** "The post-modeling model to fix the model." Talk, New York R Conference, 14 Jul 2023 (posted 4 Aug 2023). https://opensource.posit.co/resources/videos/2023-08-04_max-kuhn-the-post-modeling-model-to-fix-the-model/ (practitioner talk; description page only, I did not see the video)
- Says (description): a model can do well numerically while its predicted probabilities do not match the data; "Model calibration is a tool that can fix this."
- Use: if the GBM benchmark is miscalibrated we recalibrate it before comparing.

### 1.4 Prediction vs confidence vs credible intervals; conformal

**R16. Hyndman, R. J. & Athanasopoulos, G. *Forecasting: Principles and Practice* (3rd ed.), §5.5 "Prediction intervals." https://otexts.com/fpp3/prediction-intervals.html** (authors are from my knowledge; the fetched chapter text does not print them)
- Says: "A prediction interval gives an interval within which we expect y_t to lie with a specified probability." The standard formula assumes a normal forecast distribution and, for multi-step intervals, uncorrelated residuals. The chapter does not discuss parameter-estimation uncertainty explicitly (as relayed).
- Use: "A confidence interval says how sure we are of the failure rate; a prediction interval says where next period's actual count or dollar loss may land. We show both."

**R17. Morey, Hoekstra, Rouder, Lee, Wagenmakers (2016).** "The fallacy of placing confidence in confidence intervals." *Psychonomic Bulletin & Review* 23(1): 103–123. https://dare.uva.nl/id/31dd8441-fb9e-412d-814d-54cb52752158
- Says: CIs are often read as measures of precision, plausible values, or the probability the true value is inside; the paper shows they need not have those properties and recommends other interval theories.
- Use: wording guidance. Call ours "credible intervals from the model's posterior" and say in plain words "most likely range"; do not tell the manager there is a 95% chance the true value is inside a classical CI. (Our posterior-draw intervals are Bayesian-style, so the plain reading is closer to correct, provided priors and model are reasonable.)

**R18. Angelopoulos, A. N. & Bates, S. (2021; v6 Dec 2022).** "A Gentle Introduction to Conformal Prediction and Distribution-Free Uncertainty Quantification." arXiv:2107.07511. https://arxiv.org/abs/2107.07511v6
- Says: conformal prediction builds statistically rigorous uncertainty sets around black-box predictions; sets are distribution-free with non-asymptotic guarantees; covers distribution shift and time series extensions; includes code.
- Use: optional cross-check: "As a model-free check, we compare our interval coverage on 2026 with split-conformal intervals."

**R19. Vovk, Gammerman, Shafer (2022, 2nd ed.).** *Algorithmic Learning in a Random World.* Springer. DOI 10.1007/978-3-031-06649-8. https://link.springer.com/978-3-031-06648-1
- Says: conformal predictors are provably valid under randomness (exchangeability); second edition adds conformal predictive distributions and tests to protect against distribution change.
- Use: foundational citation for R18's method.

**R20. Gibbs, I. & Candès, E. (2021).** "Adaptive Conformal Inference Under Distribution Shift." NeurIPS 2021; arXiv:2106.00170. https://arxiv.org/abs/2106.00170v3
- Says: wrapper that keeps target coverage when the data distribution shifts over time in unknown ways, by treating the shift as a one-parameter learning problem. Tested on two real datasets.
- Use: relevant because our 2026 holdout has a declared parameter shift, so standard exchangeability-based coverage guarantees may not hold.

### 1.5 Partial pooling / hierarchical shrinkage

**R21. Efron, B. & Morris, C. (1977).** "Stein's Paradox in Statistics." Document at https://www.gwern.net/doc/statistics/bayes/1977-efron.pdf (pp. 119–127; the fetched text did not itself print the journal or year; *Scientific American*, 1977 is my identification from the byline and layout).
- Says: with three or more unrelated quantities, shrinking each toward the grand average beats each raw average in total squared error; the baseball example used 18 players' averages after 45 at-bats; total squared error was about 3.5× smaller after shrinking; the gain is biggest when true values cluster, the method can do worse for an atypical individual, and mixing unrelated data (their imported-car example) makes it absurd.
- Use: "Vendor effects are shrunk toward their category's typical rate, so vendors with few events are not over-read." Design implication from their caveat: shrink toward the category mean, not the global mean, and expect an atypically bad vendor to be pulled toward the middle.

**R22. Davis, Lasko, Chen, Matheny (2017/2018).** "Calibration Drift Among Regression and Machine Learning Models for Hospital Mortality." *AMIA Annual Symposium Proceedings* 2017 (online April 2018). https://pmc.ncbi.nlm.nih.gov/articles/PMC5977580
- Says: seven models trained on 2006 VA admissions and tested on 2007–2013. Discrimination was stable; calibration drifted for most models. Quote relayed: "Calibration was stable for the neural network model and declined for all other models." L2-penalized logistic regression and random forest drifted less than other regression models; drift tracked changes in case mix. Authors conclude updating protocols should be tailored to the model type.
- Note: this is the correct title. My first search guess ("Calibration drift in regression and machine learning models for acute kidney injury", JAMIA) is a different paper that I did not verify.
- Use: supports ridge-penalized fit and monitoring calibration, not only AUC, over time.

*(Books on multilevel models are in Section 3: existence confirmed only.)*

### 1.6 Decision-focused / top-k / cost-weighted evaluation

**R23. Hand, D. J. (2009).** "Measuring classifier performance: a coherent alternative to the area under the ROC curve." *Machine Learning* 77(1): 103–123. DOI 10.1007/s10994-009-5119-5. https://spiral.imperial.ac.uk/entities/publication/e6fe8369-8e9d-47fd-8981-f7b41ba849e6 (citation details); summary via https://mlanthology.org/mlj/2009/hand2009mlj-measuring
- Says: AUC can mislead when ROC curves cross, and is "fundamentally incoherent in terms of misclassification costs": it implicitly uses a different cost distribution for each classifier. Proposes an alternative (the H-measure).
- Use: "AUC alone does not tell a manager how many dollars of failure the review set captures, so we report the share of realized failure cost captured by the top-k."

**R24. Elkan, C. (2001).** "The Foundations of Cost-Sensitive Learning." IJCAI 2001, pp. 973–978. https://mlanthology.org/ijcai/2001/elkan2001ijcai-foundations
- Says: with different error costs, he recommends training on the data as given and then applying the cost matrix explicitly to the probability estimates when deciding (rebalancing has little effect on standard Bayesian and tree methods).
- Use: "We estimate probabilities first, then combine them with season-specific cost and the week's review capacity k to rank."

**R25. Vickers, A. J. & Elkin, E. B. (2006).** "Decision curve analysis: a novel method for evaluating prediction models." *Medical Decision Making* 26(6): 565–574. DOI 10.1177/0272989X06295361. https://ideas.repec.org/a/sae/medema/v26y2006i6p565-574.html
- Says: net benefit across threshold probabilities, using only the test dataset, to show where each model is useful.
- Use: optional. Our decision is "top k of 50", not a probability threshold, so top-k capture (R23–R24, R26) is the better fit. Mention net benefit only if the report has space.

**R26. Lakkaraju et al. (KDD 2015)** "A Machine Learning Framework to Identify Students at Risk of Adverse Academic Outcomes." Seen only through a secondary summary: Colyer, A. (2015-08-24), *the morning paper*. https://blog.acolyer.org/2015/08/24/a-machine-learning-framework-to-identify-students-at-risk-of-adverse-academic-outcomes/
- Says (per Colyer): districts have limited intervention resources that vary over time, so officials pick the top-k% at any time; the authors report precision- and recall-at-top-K curves with k variable; Random Forest was best in both districts.
- Not fully verified: I did not open the paper or its publisher page. The author list, venue and the model comparison above come from the blog's description. Cite the blog as the secondary source, or locate the paper before citing it directly.
- Use: precedent for precision-at-top-k with resource limits that change with time (like our varying k).

**R27. Kleinberg, Lakkaraju, Leskovec, Ludwig, Mullainathan (2018).** "Human Decisions and Machine Predictions." *Quarterly Journal of Economics* 133(1): 237–293. https://ideas.repec.org/a/oup/qjecon/v133y2018i1p237-293..html
- Says: bail decisions as a test case; a policy simulation shows large possible gains (crime down up to 24.7% at the same jailing rate); the authors face a missing-outcomes problem (outcomes seen only for released defendants) and address it with econometric strategies.
- Use: design precedent for replaying a policy under a fixed decision budget. Our simulated data avoids their missing-outcome problem because the oracle table holds counterfactuals, but the oracle must not be used in training (schema S6).

**R28. Elmachtoub, A. N. & Grigas, P. (2022).** "Smart 'Predict, then Optimize'." *Management Science* 68(1): 9–26. DOI 10.1287/mnsc.2020.3922. https://ideas.repec.org/a/inm/ormnsc/v68y2022i1p9-26.html
- Says: prediction models trained for prediction error can ignore downstream decision error; proposes a decision-aware loss; in experiments linear models trained this way often outperform random forests even when the true relationship is highly nonlinear.
- Use: "We evaluate on the decision (top-k cost capture), not on prediction error alone." Optional stretch: tune the ridge penalty on top-k capture.

**R29. Obermeyer, Powers, Vogeli, Mullainathan (2019).** "Dissecting racial bias in an algorithm used to manage the health of populations." *Science* 366(6464). Summary via https://thelivinglib.org/dissecting-racial-bias-in-an-algorithm-used-to-manage-the-health-of-populations/ (the page showed volume/issue but not the year; 2019 is consistent with volume 366)
- Says: the algorithm used cost as a proxy for health need; because less is spent on Black patients with the same need, it underestimated their need.
- Use (caution, not a claim about our data): the label you train on is a decision. We train on failure occurrence (not cost) and apply cost afterwards, per R24; we should say why.

### 1.7 Uncertainty communication and trust in algorithmic aids

**R30. Spiegelhalter, D. (2017).** "Risk and uncertainty communication." *Annual Review of Statistics and Its Application* 4. https://www.repository.cam.ac.uk/handle/1810/260626
- Says: reviews research on presenting numbers, verbal descriptions, graphics and deeper uncertainty across health, weather, industrial reliability and other domains; tentative conclusion: seek expert input, define goals precisely, and work closely with the intended audience.
- Use: "The uncertainty display was chosen for a purchasing manager's decision, not for a statistician."

**R31. Gigerenzer, G. & Hoffrage, U. (1995).** "How to improve Bayesian reasoning without instruction: Frequency formats." *Psychological Review* 102(4): 684–704. https://pages.ucsd.edu/~scoulson/203/GG_How_1995.pdf
- Says: frequency formats make Bayesian algorithms computationally simpler; statistically naive participants reached up to 50% Bayesian-consistent inferences with frequencies.
- Use: "Probabilities are also shown as natural frequencies, e.g. 'about 8 in 100 weeks like this'." (Their task is Bayesian updating; applying frequency format to displaying risk is a design extension.)

**R32. Joslyn, S. & LeClerc, J. (2013).** "Decisions With Uncertainty: The Glass Half Full." *Current Directions in Psychological Science* 22(4). DOI 10.1177/0963721413481473. https://www.psychologicalscience.org/journals/current-directions/0963721413481473/
- Says: in weather decisions, numeric uncertainty estimates increased trust, helped people grasp the range of outcomes, and improved precautionary decisions; the quote relayed: "the advantage for uncertainty estimates depends critically on how they are expressed."
- Use: supports showing intervals, with a caveat about format.

**R33. Goodwin, Önkal, Thomson (2010).** "Do forecasts expressed as prediction intervals improve production planning decisions?" *European Journal of Operational Research* 205(1): 195–201. https://researchportal.bath.ac.uk/en/publications/do-forecasts-expressed-as-prediction-intervals-improve-production/
- Says: in an experiment, point forecast vs 50% vs 95% prediction intervals; **the intervals did not improve decision quality** and made people less likely to adjust properly for asymmetric costs; a simple heuristic applied to 85% intervals gave near-optimal decisions.
- Use: an honest limit for the report: intervals are included because they show how much to trust a number, and we pair them with a plain "what to do" line, because interval displays alone did not improve decisions in this experiment. (Order-quantity setting, not vendor review; evidence is indirect.)

**R34. Hullman, Qiao, Correll, Kale, Kay (2018/2019).** "In Pursuit of Error: A Survey of Uncertainty Visualization Evaluation." *IEEE TVCG* (InfoVis proceedings). https://mucollective.northwestern.edu/project/uncertainty-eval-survey
- Says: reviews 86 user studies; people often struggle to interpret uncertainty; evaluations often measure performance and satisfaction in ways that assume more predictable statistical judgment than decision research supports. (Year is 2018 on the project page; IEEE publication year may differ.)
- Use: "We test the display with the manager's actual question ('which two vendors do I review?') instead of asking whether the chart looks clear."

**R35. Gilliland, M. (2021).** "The Forecaster's Predicament: Communicating Uncertainty Effectively." *Journal of Business Forecasting*, Fall 2021 (summary only; full text paywalled). https://ibf.org/knowledge/jbf-articles/the-forecasters-predicament-communicating-uncertainty-effectively-1342
- Says (summary): present a range with its likelihood instead of a single number; show probability visually; mind how colleagues receive ranges; balance accuracy against informativeness.
- Use: practitioner-journal support for ranges in business forecasts.

**R36. Dietvorst, Simmons, Massey (2015).** "Algorithm Aversion: People Erroneously Avoid Algorithms after Seeing Them Err." *Journal of Experimental Psychology: General* (2015). https://repository.upenn.edu/fnce_papers/58 (volume/pages not shown on the fetched page)
- Says: people lose confidence in algorithms faster than in human forecasters after seeing the same mistake. Quote relayed: "people more quickly lose confidence in algorithmic than human forecasters after seeing them make the same mistake."

**R37. Dietvorst, Simmons, Massey (2018).** "Overcoming Algorithm Aversion: People Will Use Imperfect Algorithms If They Can (Even Slightly) Modify Them." *Management Science* 64(3): 1155–1170. DOI 10.1287/mnsc.2016.2643. https://ideas.repec.org/a/inm/ormnsc/v64y2018i3p1155-1170.html
- Says: three incentivized studies; participants were much more likely to use an imperfect algorithm when they could modify its forecasts, even slightly; control raised satisfaction and later use.
- Use: "The what-if panel lets the manager change inputs and override the recommendation, which supports adoption of an imperfect model."  (The what-if panel modifies inputs, not forecasts; the study modified forecasts. Close, not identical.)

**R38. Rudin, C. (2019).** "Stop explaining black box machine learning models for high stakes decisions and use interpretable models instead." *Nature Machine Intelligence* 1(5): 206–215. DOI 10.1038/s42256-019-0048-x. https://scholars.duke.edu/individual/pub1454259 (arXiv:1811.10154)
- Says: explaining opaque models can entrench bad practice; build interpretable models when stakes are high.
- Use: supports a GLM as the primary model. "High stakes" in the paper means healthcare and criminal justice; our setting is lower stakes, so state it as support for preferring interpretable models, not as a mandate.

### 1.8 Model choice: simple vs GBM

**R39. Christodoulou, Ma, Collins, Steyerberg, Verbakel, Van Calster (2019).** "A systematic review shows no performance benefit of machine learning over logistic regression for clinical prediction models." *Journal of Clinical Epidemiology* 110: 12–22. DOI 10.1016/j.jclinepi.2019.02.004. https://ora.ox.ac.uk/objects/uuid:4167c905-5171-4fc7-b157-ff36d56a73db
- Says: 71 studies, 282 LR-vs-ML comparisons; among low-risk-of-bias studies (145 comparisons) the difference in logit(AUC) was 0.00 (95% CI −0.18 to 0.18); high-risk-of-bias studies showed ML ahead by 0.34; 79% of studies did not address calibration. Quote relayed: "We found no evidence of superior performance of ML over LR for clinical prediction modeling."
- Use: "A gradient-boosted model is reported as a benchmark; in comparable prediction literature it has not reliably beaten a well-specified regression." (Clinical, not supply chain.)

**R40. Grinsztajn, Oyallon, Varoquaux (2022).** "Why do tree-based models still outperform deep learning on typical tabular data?" NeurIPS 2022 Datasets & Benchmarks; arXiv:2207.08815. https://arxiv.org/abs/2207.08815v1
- Says: on 45 tabular datasets, tree-based models (XGBoost, random forest) remain strongest on medium-sized data (~10,000 samples) over deep learning. It compares trees with neural networks, **not with regression**.
- Use: "If the GBM wins, we say so": do not cite this as evidence against GLMs.

**R41. Harrell, F. (2018).** "Road Map for Choosing Between Statistical Modeling and Machine Learning." fharrell.com, 30 Apr 2018. https://fharrell.com/post/stat-ml (practitioner post)
- Says (relayed): favors a statistical model when uncertainty is inherent and signal:noise is not large, when uncertainty in predictions matters, when additivity dominates, when sample size is not huge, and when the whole model must be interpretable. Favors ML when signal:noise is large, interactions are strong, sample is huge, or black-box is acceptable.
- Use: our case (low base rate, ~7–9k scored rows, intervals required, manager needs reasons) lands on the statistical-model side of his list.

### 1.9 Monitoring and drift

**R42. Gama, Žliobaitė, Bifet, Pechenizkiy, Bouchachia (2014).** "A Survey on Concept Drift Adaptation." *ACM Computing Surveys* 46(4), Article 44. DOI 10.1145/2523813. https://eprints.bournemouth.ac.uk/22491/
- Says: surveys adaptive-learning strategies for concept drift (the input–target link changing over time), how to evaluate adaptive methods, and applications.
- Use: "We re-check calibration each month and recalibrate when it slips." Which trigger to use is our choice, not from this survey.

### 1.10 Synthetic data

**R43. Jordon, Szpruch, Houssiau, Bottarelli, Cherubin, Maple, Cohen, Weller (2022).** "Synthetic Data — what, why and how?" arXiv:2205.03257 (Royal Society explainer). https://arxiv.org/abs/2205.03257v1
- Says: explainer for a non-technical audience, privacy-focused; warns of "nuances that can easily be overlooked" when deploying synthetic data. The abstract lists no specific limitations.
- Use: weak; cite for the statement that synthetic data has subtleties, not for specific pitfalls.

**R44. Chen, Lu, Chen, Williamson, Mahmood (2021).** "Synthetic data in machine learning for medicine and healthcare." *Nature Biomedical Engineering* 5(6): 493–497 (a Comment). https://pmc.ncbi.nlm.nih.gov/articles/PMC9353344
- Says: synthetic data can help with rare conditions and data sharing, but practice is not ready for routine use; fidelity and validation metrics are weak; generative models reflect biased training data; stress-test against domain shift.
- Use: "Our data are simulated from stated rules, so findings describe how the tool behaves when those rules hold, not real hotel performance."  (Their concerns are about generative models trained on real patient data; ours is a rule-based simulator. Apply only the 'stress-test under shift' and 'validation is hard' points.)

**R45. Rankin, Black, Bond, Wallace, Mulvenna, Epelde (2020).** "Reliability of Supervised Machine Learning Using Synthetic Data in Health Care: Model to Preserve Privacy for Data Sharing." *JMIR Medical Informatics* 8(7): e18910. https://medinform.jmir.org/2020/7/e18910/
- Says: models trained on synthetic data and tested on real data lost only a little accuracy; tree-based classifiers were more sensitive to synthetic training data; robustness needs more evaluation.
- Use: weak; one more reason to treat a GBM benchmark with caution on simulated data. (Their synthetic data were generated from real health data, unlike ours.)

---

## 2. Practitioner discussions (authentic, named, dated where possible)

Retrieval note: I could not retrieve any Cross Validated (stats.stackexchange) or Reddit threads. Site-filtered searches returned no links or a proxy rejection, and Reddit/Stack Exchange pages did not surface in unfiltered searches. I am therefore NOT claiming any Reddit or Cross Validated posts. What follows are named practitioners, consulting-unit notes, and forum threads that I did open.

| # | Source | Who / when | Topic | What it says (verified at fetch) |
|---|---|---|---|---|
| P1 | Freakonometrics, "Modelling Occurence of Events, with some Exposure" (R6) | Arthur Charpentier, 2015 | offset vs feature for exposure; cloglog | cloglog + log(exposure) offset matches Poisson logic; logit + offset does not |
| P2 | Freakonometrics, "Exposure with binomial responses" (R7) | Arthur Charpentier, c. 2013 | binary outcome with exposure | log-binomial fails to converge when P(Y=0) is near 1; Taylor approximation gives a multiplicative exposure |
| P3 | Statistical Horizons, "Logistic Regression for Rare Events" (R5) | Paul Allison, 13 Feb 2012 (modified 2024) | rare events | the number of rare-class cases matters, not the ratio; consider penalized likelihood always |
| P4 | Cornell Statistical Consulting Unit, "To Offset or Not" (R8) | Stephen Parry, 2018, updated 2022 | offset vs covariate | offset = coefficient fixed at 1; test against a free coefficient by likelihood ratio |
| P5 | Statalist thread 1738521 (R10) | Joe Cai (asker, 30 Dec 2023); Leonardo Guizzetti (answers, Dec 2023 and Mar 2024) | zero exposure in offset | exposure must be > 0; treat as a denominator; non-linear size effects go in as ordinary predictors |
| P6 | Posit talk, "Understanding, generating, and evaluating prediction intervals" | Bryan Shalloway, posted 31 Oct 2024 (likely posit::conf 2024 per slides repo label) | whether to show intervals | "For many problems concerning prediction, providing intervals is more useful than just offering point estimates." Separates noise from model uncertainty; compares parametric and conformal intervals |
| P7 | fharrell.com, "Road Map for Choosing Between Statistical Modeling and Machine Learning" (R41) | Frank Harrell, 30 Apr 2018 | simple models vs GBM | list of conditions favoring regression vs ML |
| P8 | fharrell.com, "Damage Caused by Classification Accuracy…" (R14) | Frank Harrell, 1 Mar 2017 | calibration / proper scores | prefer probabilities and proper scores over classification accuracy |
| P9 | Posit talk, "The post-modeling model to fix the model" (R15) | Max Kuhn, 14 Jul 2023 | calibration | numerically good models can have miscalibrated probabilities; calibrate as a post-processing step |
| P10 | Journal of Business Forecasting, "The Forecaster's Predicament" (R35) | Michael Gilliland, Fall 2021 | showing intervals to business users | present ranges with likelihood; mind how colleagues receive them (summary only) |

Honest read of what practitioners say: the exposure/offset and rare-event posts (P1–P5) support our model form. The interval-communication sources are split: advocates for intervals (P6, P10, R32) versus an experiment where intervals did not improve a planning decision (R33). No practitioner source I found speaks directly to hotel vendor-review tools.

---

## 3. UNVERIFIED / PARTIAL (do not recommend as citations without further checking)

- **Gelman, A. & Hill, J., *Data Analysis Using Regression and Multilevel/Hierarchical Models* (Cambridge University Press).** A bookseller listing confirmed title, author, publisher and a 2006 listing year (copyright files elsewhere suggest 2007); no synopsis seen. The title implies multilevel coverage but I verified no sentence. Check the publisher page before citing; use R21 and R22 for shrinkage claims meanwhile.
- **McElreath, R., *Statistical Rethinking*, 2nd ed. (Chapman & Hall/CRC, 2020).** Existence and table of contents seen on O'Reilly's page (Ch. 13 "Models With Memory" includes "Multilevel tadpoles" and "Varying effects and the underfitting/overfitting trade-off"). The phrase "partial pooling" did not appear on that page. Cite the chapter, not the phrase.
- **Steyerberg, E. W., *Clinical Prediction Models* (Springer, 2009).** Existence and scope seen only through a 2009 *Kybernetes* book review (C.J.H. Mann). Fine as a book citation for validation/updating practice; I did not read it.
- **Lakkaraju et al. KDD 2015** (see R26): seen only through Colyer's blog summary.
- **Agresti, *Categorical Data Analysis*** (cloglog / grouped binary data): I did not locate a page for it. Do not cite.
- **A late-supplier-delivery ML paper (low-volume-high-variety products, German machinery industry; Elsevier, 2023)** and **"An analytical review of predictive methods for delivery delays in supply chains" (Elsevier, 2025)**: titles seen in search results; Elsevier pages blocked fetching (robots disallowed). Not usable.
- **Sculley et al. (2015), "Hidden Technical Debt in Machine Learning Systems," NIPS 2015, pp. 2503–2511:** metadata (authors, venue, pages) seen on Google Research page; no abstract text retrieved. Fine for a one-line citation on pipeline/monitoring debt; I verified no claim from it.
- **Hyndman & Athanasopoulos authors/edition:** chapter text verified; the author names come from my own knowledge.
- **Dietvorst et al. 2015 volume/pages:** not shown on the fetched page.
- **Gneiting & Raftery volume number:** 102 comes from my own knowledge; the fetched page gave pages and DOI.
- **DataRobot community thread on confidence intervals of predictions:** URL redirected to a generic help page; thread not reachable.
- **Medium post (J. Dancker, 24 Nov 2024) "Confidence Interval vs Prediction Interval":** only the intro was retrieved; I verified no explanation. Do not cite.
- **Vickers & Elkin PMC copy and Spiegelhalter full text:** only abstracts/records seen.

---

## 4. Recommendations

### Best supported
1. **Cloglog + log(expected deliveries) offset.** Derivable from the Poisson-process argument (R6) and shown to work in a worked example by a named practitioner. The offset assumption (rate scales proportionally with deliveries) is testable with one likelihood-ratio test against a free log(deliveries) coefficient (R8). Report that test. Caveat: the peer-reviewed supplier-risk literature I verified (R1, R2) has no cloglog/offset precedent, so the support is statistical, not domain-specific.
2. **Calibration first, with proper scores.** Calibration plot with intervals plus calibration slope and intercept (R11, R12), Brier and log loss (R13, R14). Do not report accuracy at a cut-off.
3. **Decision-focused evaluation.** Top-k cost capture against baselines (R23, R24, R26, R27, R28), with the oracle table used only for scoring (schema S6). Use estimated probabilities then apply cost explicitly (R24).
4. **Ridge / partial pooling, with the right center.** R21 supports shrinkage; its own caveat says to shrink toward a sensible group mean. Shrink vendor effects toward their category's rate. R22 gives an applied reason to prefer L2-penalized logistic regression when calibration over time matters.

### Weaker support, say so in the report
5. **Intervals will not automatically improve decisions.** R33 found no benefit from prediction intervals in a planning experiment; R32 found benefits depending on how uncertainty is expressed; R30 advises designing with the audience. Pair every interval with a plain-language reading, use frequency wording (R31), and do not hard-code 95%: R33's heuristic used 85% intervals, so offer 80% by default with a selector. Treat these defaults as our design choice.
6. **Conformal cross-check is optional.** For a binary next-week outcome, conformal sets add little; they fit the dollar-loss and count intervals better. Exchangeability is doubtful across a declared 2026 shift (R20). Empirical coverage of our intervals on 2026 is the more convincing evidence: report "nominal 80%, observed X%".
7. **GBM benchmark.** R39 and R41 favor a regression as the primary model for this kind of problem; R40 says trees do well on tabular data of ~10,000 rows but does not compare with regression; R45 hints tree models may be touchy on simulated data. Report the GBM honestly whichever way it comes out, recalibrated first (R15).
8. **Synthetic-data limits.** Sources are weak and from health. The defensible framing is our own: the model can only learn mechanisms the generator encodes, so results show the tool's behavior under stated rules. Test under the declared 2026 shift and report calibration-in-the-large (average predicted vs observed rate) separately from slope.

### Design implications from the sources (checks to add)
- Vendor-weeks with zero expected deliveries cannot take log exposure (R10); keep them out of the fit and mark them "insufficient data" in the what-if screen.
- Test offset vs free coefficient (R8) and report the result in one sentence.
- Check for separation or near-empty groups. MRO has zero failures in the data the parent examined (not from these sources), so an unpenalized fit would send its effect to −∞; ridge/Firth-type penalties address this (R4, R5).
- Cost and label: keep failure occurrence as the training target and apply cost afterwards (R24, R29).
- Monitoring plan (R22, R42): recompute calibration slope and Brier score on the most recent window each month. Any numeric recalibration trigger is our choice, not sourced.

### Alternatives found
- Firth/penalized likelihood instead of ridge (R5): similar goal, different penalty; ridge is easier to justify as partial pooling.
- Poisson count model with log(deliveries) offset, if a vendor can fail more than once per week: cloglog is exactly right for "at least one failure." Check how often a vendor has more than one failure in a week before choosing.
- Quantile or conformal intervals for dollar loss (R18, R20): distribution-free, but guarantees weaken under drift.

### Single most important caution
The strongest-supported parts of the plan are statistical and generic. The domain-specific literature on supplier-failure prediction I could verify is thin (R1–R3). Do not write that the approach is "standard in supplier risk modeling"; write that it applies standard rare-event and exposure methods to a supplier setting, citing R4–R8.
