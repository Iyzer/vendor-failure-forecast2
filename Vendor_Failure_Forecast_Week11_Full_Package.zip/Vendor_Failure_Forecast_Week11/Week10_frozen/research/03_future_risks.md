# Research Angle 3 — Horizon scan: risks to U.S. hotel/resort procurement, 2026–2030

Prepared 2026-10-20 for the Vendor Risk and Corrective-Action Prioritization Tool (Week 10).
Scope: independent seasonal resort; categories produce, protein, dairy/bakery, non-alcoholic beverage, linen/laundry, guest amenities, MRO.

## How to read this file

- **Evidence labels.** `[F]` = page was fetched and read in this session. `[S]` = seen only as a search-result title (not read; not relied on). Every finding below is `[F]` unless stated.
- **Quotes.** The fetch tool returns short extracts produced by a summarizer. Text in quotation marks is what that extract returned as verbatim; the tool caps quotes at about 125 characters. Re-open the page before putting any quote on a slide or in the report. Anything not in quotation marks is PARAPHRASE.
- **Confidence.** H = government/regulator, primary filing, or direct statement on a primary page. M = reputable trade/news/academic, one source. L = vendor marketing, consultancy blog, unsourced statistics, or internally inconsistent page.
- **Marketing flag.** `MKT` = the publisher sells something related to the claim.
- **Today's date** is 2026-10-20. Items dated after the training cutoff were checked only against the pages cited.
- **Internal evidence.** Rows labelled `OUR DATA` come from `snap_vendor_week.csv`, `fact_failure_event.csv`, `dim_calendar_week.csv` (computed this session), not from the web.

## Our-data facts used to anchor the "detectability" column

Computed on scored vendor-weeks (trailing 13-week delivery count > 0, target not missing). OUR DATA.

| Year | Scored vendor-weeks | Next-week material failures | Base rate | Avg cost per failure | Share of failures flagged commodity shock |
|---|---|---|---|---|---|
| 2023 | 2,132 | 99 | 4.64% | $1,542 | 6.1% |
| 2024 | 2,432 | 117 | 4.81% | $1,397 | 2.8% |
| 2025 | 2,414 | 104 | 4.31% | $1,577 | 0.0% |
| 2026 | 2,441 | 136 | 5.57% | $1,701 | 14.2% |

Per-category base rate, 2025 → 2026 (OUR DATA): protein 6.0% → 9.4%; produce 10.5% → 13.7%; linen/laundry 1.6% → 2.9%; dairy/bakery 6.3% → 4.8%; MRO 0% in every year (zero failures, so any model has nothing to learn from for MRO). 2026 produce shock-flagged failures: 24 of 2026's 169 failures; protein 0. Note: the generator's declared 2026 parameter shift is the likely cause, so these numbers show what a shift looks like in our schema; they are not independent evidence about the real world.

---

## 1. Risk register

Columns: risk | evidence (what is happening, date, URL, confidence) | likelihood and magnitude | how it would show up in our data | detectability in vendor-week data | proposed tool-level mitigation.

### R1. Beef and protein supply tightness (herd at multi-decade low, screwworm)

- **Evidence.**
  - USDA ERS (updated 2026-09-25): 2026 beef and veal retail forecast +9.4% (interval 7.4 to 11.6); wholesale beef PPI +8.5% (3.0 to 15.0); "Beef production is expected to remain below year ago levels through the end of 2026." [F, H] https://www-tx.ers.usda.gov/data-products/food-price-outlook/summary-findings
  - farmdoc daily (Univ. of Illinois, 2026-10-05): beef cows 28.5M on 2026-07-01, down 1%; 2026 calf crop projected 32.5M, down 2%; "Rebuilding the cattle herd takes time." [F, M] https://farmdocdaily.illinois.edu/2026/10/food-inflation-and-the-outlook-for-beef-prices.html
  - Inquirer/AP (2026-08-26): U.S. closed the border to Mexican cattle in May 2025; Douglas, AZ crossing reopened 2026-08-24; first Texas screwworm case since 1966 reported 2026-06-03, "more than 40 cases" since; ground beef $6.89/lb July 2026 (peak $6.90 in May); herd 86.2M head on 2026-01-01, "the lowest in 75 years." Derrell Peel (Oklahoma State): "I don't expect to see any measurable impact on cattle prices or beef prices soon." [F, M] https://www.inquirer.com/business/cattle-beef-mexico-import-screwworm-prices-20260826.html
  - US Foods CFO Dirk Locascio (Q2 2026 call, via Benzinga transcript): "proteins continued to have strong levels of inflation." [F, M] https://www.benzinga.com/node/62212417
- **Likelihood / magnitude.** Price pressure is already in the data (high likelihood). Herd rebuild is multi-year per the sources above, so persistence through 2027–2028 is plausible. Whether it raises failure *rates* (as opposed to prices) is not established by any source; the sources speak to price and supply, not to delivery failure.
- **In our data.** Higher `emergency_premium` (retail-vs-contract gap) and `lost_contribution_margin` per protein failure; possibly higher short/substitution rates if distributors allocate scarce product. OUR DATA already shows protein base rate rising 6.0% → 9.4% in 2026.
- **Detectability.** Category-level: simultaneous rise in trailing rejection/fill shortfalls across all protein vendors. Cost-side: rising cost per failure within a category. Vendor-specific decline would be one vendor moving while its peers stay flat.
- **Mitigation.** (1) What-if input "category cost multiplier" so the manager can stress cost per failure. (2) Category-level monitor: flag when the category median trailing rejection rate moves more than a set threshold versus its own 13-week history. (3) Report the model's category-level calibration separately for protein.

### R2. Produce supply: weather extremes, farm-labor loss, and food-safety outbreaks

- **Evidence.**
  - FreshPlaza (2026-09-21, citing USDA ERS): U.S. retail fresh vegetable prices +6.3% in July 2026 versus a year earlier; tomatoes +12.8%; lettuce +7.5%. [F, M] https://www.freshplaza.com/north-america/article/9874850/fresh-vegetable-prices-rise-6-3-in-the-u-s-as-farm-labor-concerns-continue/
  - ERS 2026: farm-level vegetables PPI +16.0% (7.7 to 26.8); retail fresh vegetables +5.7%. [F, H] (ERS URL above)
  - FreshFruitPortal (2026-04-24): abnormal California heat; cherry orchards had about 400 chill hours versus up to 850 needed; one desert vegetable farm reported losses of about 2,500 tons (lettuce, broccoli, celery); berry growers discarding sunburned fruit. [F, M] https://www.freshfruitportal.com/news/2026/04/24/california-heat-2026/ (the page contains one geographic error noted by the fetch tool — "Kent County" in a California citrus passage — so treat details with care).
  - WGBH (2026-05-18, Massachusetts farms): "We typically would have about 15 seasonal immigrant workers here in our peak season. This past year, we were only able to fill about 10 of those slots." (unnamed Western MA farmer); Karina Laurenitis, Starview Gardens: "Everything went up about 30% since last year." [F, M] https://www.wgbh.org/news/local/2026-05-18/we-could-not-farm-without-them-small-mass-farms-face-immigration-and-labor-pressures
  - U.S. Dept. of Labor Federal Register filing as reported by Farm Policy News (2025-10-16): "The Department concludes that qualified and eligible U.S. workers will not make themselves available in sufficient numbers." [F, M] https://farmpolicynews.illinois.edu/2025/10/immigration-crackdown-hurting-ag-labor-dept-concedes/
  - FreshPlaza, same article: an MSU/California Farm Bureau survey of 500+ growers found "fewer than 1% reported losing workers directly to enforcement actions," about 15% lost workers because of fear and anxiety, about 14% reduced cultivation. This cuts against any claim that enforcement alone explains shortages. [F, M]
  - WISN (Hearst, 2026): a cyclosporiasis outbreak infecting more than 28,000 people was linked to iceberg lettuce from Taylor Fresh Foods, with a recall issued in mid-July. [F, M] https://www.wisn.com/article/us-food-recalls-trend-analysis/73415731
- **Likelihood / magnitude.** High likelihood that produce price and availability stay volatile; the 2-day coverage (OUR DATA, `dim_category.coverage_days`) makes produce the category where any lapse becomes an operational problem fastest. Magnitude of labor effect on *delivery failure rates* is not quantified by any source found.
- **In our data.** Category-wide jump in short/late/rejected lines for produce vendors in the same weeks (the generator's `commodity_shock_flag`); higher cost per failure; produce has the highest base rate in our data (12.3% of scored vendor-weeks over the full history; 13.7% in 2026). OUR DATA.
- **Detectability.** Strong: a shock hits many produce vendors at once, which separates it from single-vendor decline. Harder: slow labor-driven degradation looks like gradual vendor deterioration.
- **Mitigation.** Separate "category shock" feature (fraction of category vendors with a failure in the last 1–2 weeks) from vendor features so the model does not blame one vendor for a category event; produce-specific recalibration trigger (see R13); what-if "shock weeks" input.

### R3. Eggs and dairy: avian influenza and milk-price swings

- **Evidence.**
  - ERS 2026: eggs retail −29.4% (−32.9 to −25.2); farm-level eggs −79.2%; "U.S. egg production is recovering"; dairy retail +0.1%; farm-level milk −9.4%. [F, H]
  - ThePoultrySite/AVMA (2026-05-11): cumulative losses above 206 million birds since early 2022; 1,000th commercial flock depopulation on 2026-03-31; table-egg layers about three-quarters of losses; USDA: "Detections are higher in the fall and spring, because we continue to see wild birds spreading virus." [F, M] https://www.thepoultrysite.com/news/2026/05/bird-flu-surges-in-us-poultry-as-wild-migration-spreads-virus-avma
- **Likelihood / magnitude.** The seasonal pattern (fall and spring detections) implies recurring risk; the 2026 egg price *fall* shows the swing runs both ways. No source found gives a delivery-failure effect.
- **In our data.** Dairy/bakery base rate 6.3% over history (OUR DATA) — second-highest after produce; a price spike appears as higher `emergency_premium`.
- **Detectability.** Price-side only, unless a distributor shorts eggs; watch fill rate (not rejection) for dairy/bakery.
- **Mitigation.** Cost multiplier in what-if; treat dairy/bakery fill rate as a separate monitored feature.

### R4. Tariff and trade-policy churn

- **Evidence.**
  - Flexport (summary of Supreme Court ruling of 2026-02-20): IEEPA tariffs struck down 6–3; replaced by a 10% global Section 122 tariff effective 2026-02-24 with certain agricultural goods excluded; refund system (CBP "CAPE") launched 2026-04-20; about 8.3M entries liquidated without IEEPA duties by 2026-05-11. Flexport itself notes this is "a Flexport blog summary, not an official government source." [F, M, MKT] https://www.flexport.com/blog/the-supreme-courts-ieepa-tariff-ruling-next-steps-potential-refunds-and/
  - Wiley law-firm alert (2026-02-25): Section 122 limited by statute to 150 days and up to 15%; excludes "certain agricultural goods" and USMCA-compliant goods; USTR previewed Section 301 investigations "on an accelerated timeframe." [F, M] https://www.wiley.law/alert-Trump-Imposes-Section-122-Tariffs-After-Halting-IEEPA-Tariffs-Previews-New-Section-301-Investigations
  - tariffstool.com: the Section 122 tariff "lapsed by operation of law at 12:01 a.m. ET July 24, 2026" and was followed by a Section 301 action with a two-tier structure; rate tiers and exemptions are unclear and the page carries internal inconsistencies and affiliate links. [F, L, MKT] https://www.tariffstool.com/guides/section-301-replacing-section-122 — **do not cite rates from this page; verify with USTR/CBP.**
  - Hotel Management (Oct 2026): Daniel Lesser (LW Hospitality Advisors) on "long-range, singlesource global shipping increasingly risky" (page wording). [F, M] https://hotelmanagement.mydigitalpublication.com/publication/?i=871541&article_id=5222510&view=articleBrowser
- **Likelihood / magnitude.** Policy is changing on a months-long cadence (ruling, 150-day replacement, expiry, new action), so a model trained on one tariff regime should expect another. Which of our seven categories are import-exposed is not established by any source fetched (the IFPA fact sheet gave no import shares).
- **In our data.** Price-level changes appear in cost per failure and possibly lead times for imported linen, amenities, MRO; unlikely to appear in rejection rates directly.
- **Detectability.** Weak in vendor-week delivery data; visible in invoice/unit-price data (not in the Week 10 feature set).
- **Mitigation.** Keep tariffs out of the fitted model; expose them only as a user-set cost multiplier in what-if with a visible note that it is a scenario, not a forecast.

### R5. Distributor concentration and cyber/ransomware disruption

- **Evidence.**
  - SupermarketNews: UNFI detected the cyberattack on 2025-06-05 and shut its network on 2025-06-06; ordering restored 2025-06-16; core systems 2025-06-26; fill rates, on-time delivery and units shipped near pre-incident levels by 2025-07-16; total cost up to $425M (sales loss $300–400M); CEO Sandy Douglas: "broadly returned to more normal operating capacity." [F, M] https://www.supermarketnews.com/grocery-technology/unfi-lost-425m-in-cyberattack-but-increased-its-net-sales-outlook-for-the-year
  - SupermarketNews, same incident: Whole Foods, UNFI's largest customer, "could see its shelves affected in the coming days"; one independent retailer reverted to phone orders. [F, M] https://www.supermarketnews.com/grocery-technology/unfi-cyberattack-shuts-down-network-and-leaves-whole-foods-and-others-in-limbo
  - FreightWaves (2026-09-18), IFDA 2026 Solutions Conference panel: a hacked carrier email arranged a fraudulent pickup — a truck took a load of blueberries (Frank Smith, Palmer Family of Cos.: "There goes a load of blueberries. Gone."); James Cusack (Van Eerden): "If it's that critical of a system, we should have fallback to go back to a manual process."; panel suggested planning for fallbacks beyond 48 hours. [F, M] https://www.freightwaves.com/news/food-distributors-warn-cyberattacks-can-quickly-become-supply-chain-disruptions
  - Hotel Management (Oct 2026): "Driver shortages causing missed broadline distributor deliveries, which can disrupt F&B service" (page's paraphrase of practitioner commentary); Lesser warns that consolidating with one vendor brings serious vulnerabilities. [F, M] (Hotel Management supply-chain URL above)
  - Sysco Q4 FY2026 call, Kevin Hourican: "we increased on-time delivery performance versus customer promise windows by 10 full points in the quarter." [F, M] https://www.fool.com/earnings/call-transcripts/2026/08/11/sysco-syy-q4-2026-earnings-call-transcript/ (this shows distributor service is actively changing in both directions).
  - Not found: any evidence of a 2026 attack on Sysco, US Foods or PFG that disrupted delivery (a search surfaced an unverified Qilin ransomware *claim* against Sysco; not fetched or verified).
- **Likelihood / magnitude.** One verified large event (UNFI 2025, roughly three weeks to core restoration). Probability of recurrence in any given year is not quantified in any source fetched.
- **In our data.** Several vendors that buy through the same upstream distributor failing in the same weeks, across categories. This breaks the independence assumption in a per-vendor model. We have no `upstream_distributor` field in the schema.
- **Detectability.** Cross-category failure clusters within one or two weeks, unlike R2's single-category cluster.
- **Mitigation.** Add a "shared upstream" tag to the vendor master (a schema change, flag as an open decision for the team); stress-test what-if with a multi-vendor outage scenario of 2–3 weeks; document a manual fallback review list.

### R6. Recalls and food-safety regulation

- **Evidence.**
  - FSMA 204 (Food Traceability Rule): enforcement date moved from 2026-01-20 to **2028-07-20**. FDA page: "extend the compliance date for the rule by 30 months to July 20, 2028" and "directed FDA not to enforce the Food Traceability Rule prior to that same date." Barley Snyder (law firm) dates Congress's directive to a November 2025 appropriations act. [F, H for FDA; M for law-firm detail] https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods ; https://www.barley.com/update-food-traceability-rule-enforcement-deadline-extended/
  - FDA page also says the rule "includes a full exemption for small RFEs and restaurants," and a **draft** enforcement-discretion policy would cover other smaller ones; the page is internally inconsistent (its "Getting Started" section still shows the old date). Whether a 150–200 room resort with 2–3 outlets counts as "small" is **not answered by anything fetched**. [F, H]
  - Recall Bench (unaffiliated aggregator, data refreshed 2026-10-19): 387 FDA food enforcement events year-to-date in 2026 (146 Class I, 205 Class II, 34 Class III; 2 unaccounted). Page gives no prior-year comparison. [F, M-L] https://recallbench.com/statistics/2026/
  - WISN (2026): 162 food recalls (FDA+USDA) so far in 2026 versus 320 in all of 2025; the article says the count alone does not show whether food safety is getting worse. Teresa Murray (U.S. PIRG): "Does it mean that there's more enforcement, or that there's more hazardous food?" [F, M] (WISN URL above). **Counts differ between sources because of different definitions (enforcement events vs recalls); do not compare them.**
- **Likelihood / magnitude.** Recalls are rare, high-severity, and category-wide when they occur; the project already treats them that way (context C33).
- **In our data.** A recall appears as a burst of severe failures in one category (a `commodity_shock_flag`-style event); our dataset flagged zero shock-failures in 2025 and 24 in produce in 2026 (OUR DATA).
- **Detectability.** Immediate and category-wide, but only after it has happened — no vendor-week feature predicts it.
- **Mitigation.** Do not claim to predict recalls; keep a "category alert" status that the manager can set manually and that suppresses vendor-level inference for that category for N weeks.

### R7. Foodservice demand softness and distributor behavior

- **Evidence.**
  - Sysco Q4 FY2026: Hourican: "Foot traffic to restaurants remains down year-over-year." Sysco grew independent customers faster than the industry, with growth from "health care, travel and hospitality and foodservice management businesses." [F, M] (Fool URL above)
  - US Foods Q2 2026: Flitman: "independent restaurant case growth of 5.1% was the strongest since the fourth quarter of 2023"; "the strength in hospitality has been a contributor"; Ops Quality Composite ("ability to deliver accurate, error free orders") improved 13% year over year. [F, M] (Benzinga URL above)
  - PFG Q4 FY2026 (MarketBeat summary; paraphrase, no direct quotes): independent restaurant case volume +5.8% in Q4; restaurant foot traffic negative in every month of fiscal 2026; FY2027 foodservice inflation assumption about 2%. [F, M] https://www.marketbeat.com/instant-alerts/performance-food-group-q4-earnings-call-highlights-2026-08-12/
- **Reading.** Distributors say their own service metrics are improving while end-demand is soft. These are executive self-reports and should be read as favorable framing; they do not measure what a resort actually receives.
- **In our data.** Fewer deliveries per vendor-week, so more vendor-weeks with sparse trailing windows (our `trailing_13wk_delivery_count = 0` rows are already 654 of 10,120).
- **Detectability.** Direct, from delivery counts.
- **Mitigation.** Keep the "insufficient data" state (W19); widen intervals as delivery count falls.

### R8. Hotel and resort labor shortages affecting receiving and data quality

- **Evidence.**
  - AHLA survey (fielded late Feb 2026; 246 hoteliers; announced 2026-03-17): over half say properties are somewhat or severely understaffed; cost of goods and supplies is a financial pain point for 71%, labor costs 65%, workforce shortages 42%; Rosanna Maietta, AHLA CEO: "Hoteliers are resilient, but the cost pressures they’re facing are very real." [F, M] https://www.ahla.com/news/rising-cost-staffing-challenges-persist-hotels-travel-demand-expected-hold-steady (corroborated by Business Travel News: https://www.businesstravelnews.com/Lodging/Survey-Costs-Staffing-Shortages-Plague-Hoteliers-in-2026 [F, M]).
  - No source fetched gives a purchasing- or receiving-specific staffing figure. **Not found.**
- **Likelihood / magnitude.** Moderate to high that receiving inspections are recorded less consistently when staff are stretched; the project already assumes this for peak weeks (W22).
- **In our data.** Rejection counts under-recorded at peak, making vendor performance look better exactly when it matters (the assumption is built into the generator; no source fetched measures it in real hotels).
- **Detectability.** Indirect: unusually low rejection rates at peak across all vendors together.
- **Mitigation.** Show a "recording reliability" note on peak-week predictions; do not treat "no rejections" as safety in peak weeks.

### R9. Hotel demand volatility

- **Evidence.**
  - Hotel Dive (2026-06-02): CoStar and Tourism Economics forecast 2026 RevPAR +2.8%, occupancy 62.8% (62.3% in 2025), ADR +2%; international inbound +3.4% forecast; headwinds included inflation, a softening labor market and "weakening international sentiment." No 2027 forecast in the article. [F, M] https://www.hoteldive.com/news/costar-tourism-economics-hotel-revpar-forecast-2026/821683/
  - Hotel News Resource (2026-10-18, NTTO data): international air arrivals −6.1% year over year in April–June 2026 (overseas −8.0%, Canada −0.9%, Mexico −0.5%); World Cup visitors "did not offset weakness in other international travel segments." [F, M] https://www.hotelnewsresource.com/article143374.html
  - Travelweek (2026-10-02): U.S. Travel Association's Geoff Freeman: U.S. on track for 2 million fewer international visitors in 2026; monthly international visitation down 2% in June, 7% in July, 11% in August; "We're the only major country in the world losing visitation. It's mind-boggling." The article's comparison with 2025 ("smaller than 2025's decline of about 11 million") is unclear and I could not reconcile it. [F, M] https://www.travelweek.ca/news/destinations/u-s-looking-at-2-million-fewer-intl-visitors-in-2026-says-ustas-freeman/
  - **Source conflict.** The June forecast (+3.4% inbound) and the NTTO/USTA data (−6.1% in Q2, deepening to −11% in August) disagree; the forecast predates the data. Treat 2026–2027 inbound demand as uncertain in both directions.
- **In our data.** `occupancy_rate`, `fb_covers`, `banquet_covers` shift; cost per failure scales with them (G22); `review_capacity_k` rises when occupancy falls.
- **Detectability.** Direct and fast — demand is an input, not a latent.
- **Mitigation.** Keep occupancy as a what-if predictor; warn when a user-entered occupancy lies outside the training range.

### R10. Interest rates

- **Evidence.** Federal Reserve statement of 2026-09-16: raised the target range a quarter point to 3-3/4 to 4 percent, vote 12–0; "Inflation remains elevated." [F, H] https://www.federalreserve.gov/monetarypolicy/files/monetary20260916a1.pdf (CNBC and several aggregator titles in search results report the same hike; the CNBC page itself could not be fetched).
- **Likelihood / magnitude.** The direction is now up. The effect on a single independent resort's vendor failures is indirect (financing cost, willingness to hold buffer stock and defer equipment purchases). No source fetched quantifies it.
- **In our data.** None directly.
- **Mitigation.** Out of model scope; mention as a limitation.

### R11. Linen and laundry capacity

- **Evidence.**
  - Hotel Management (Oct 2026, laundry operations): Gabriel Mandujano (Wash Cycle Laundry): "Within laundry, labor is the No. 1 cost, utilities are the No. 2 and chemistry is No. 3."; Nick Fertig (Rosen Hotels): "Keeping up on maintenance is a full-time job,"; Lacey King (The Maxwell Hotel): "Having adequate linen par levels is probably the most important piece." The article does not discuss equipment lead times. [F, M] https://hotelmanagement.mydigitalpublication.com/publication/?i=871541&article_id=5222504&view=articleBrowser
  - Hotel Management (Oct 2026, supply chain): Lesser advises three to four "pars" of laundry supplies and pre-vetted secondary and tertiary local laundry vendors under reciprocal emergency agreements. [F, M]
  - Laundry & Cleaning News (published 2021-09-06; **UK, 2021 analog only**): linen supply strained by labor shortage; wages up 10–25%, container freight up 300%; IHG limited linen changes. [F, M, dated analog] https://www.laundryandcleaningnews.com/news/ft-report-hotels-and-laundries-suffering-with-linen-supply-amid-labour-shortages-and-rising-costs-9057972/
  - RHF News (2026-10-19): "Hotel linen buyers shift from price to supply reliability" — a Chinese manufacturer's PR distribution that cites no independent data. [F, L, MKT] https://rhfnews.com/article/hotel-linen-buyers-shift-from-price-to-supply-reliability
  - **Not found:** any 2026 U.S. figure for commercial-laundry capacity, closures, or lead times.
- **Likelihood / magnitude.** Unquantified for the U.S. in 2026. Our data show linen/laundry at 1.8% base rate over history, 2.9% in 2026.
- **Mitigation.** Treat linen as lower-signal; fall back to category-level priors when vendor history is thin; keep par-level buffer as a manager decision outside the model.

### R12. AI adoption and AI regulation for small hospitality operators

- **Evidence.**
  - h2c AI Opportunity Study 2026 (via Hospitality Net, 2026-10-01; 122 responses from 113 **hotel chains**): 91% already use AI; only 28% have a company-wide strategy; 13% report measurable ROI; leading barrier is skills (56%), then integration (38%). Independent hotels are not in the sample. [F, M] https://www.hospitalitynet.org/news/4134680/new-h2c-study-ai-adoption-is-widespread-among-hotel-chains-but-enterprise-readiness-remains-limited
  - Otelier 2026 Hotel Operations Index (Hospitality Net, 2026-01-26): only 15% "very confident" in operational data accuracy and timeliness; 91% rely on manual reporting to some degree; respondents ranked predictive demand modeling above guest chatbots. Sample size not stated; **MKT** (Otelier sells data/automation). [F, L-M] https://www.hospitalitynet.org/report/4130590/the-2026-hotel-operations-index-progress-pressure-and-the-path-forward
  - Restaurant365 mid-year report 2026 (>420 operators; **MKT**): 38.9% not using AI and not planning to; barriers: data privacy 37%, output accuracy 34%, cost 29%. [F, L-M] https://www.restaurant365.com/guides/2026-state-of-the-restaurant-industry-mid-year-report/
  - Regulation (Wittliff Cutter, Sep 2026): Colorado's original AI Act was blocked in court in April 2026 and replaced by SB 26-189, effective 2027-01-01, a narrower notice-based law; Texas TRAIGA effective 2026-01-01; a December 2025 federal executive order seeking to preempt state AI laws "has not taken effect." Listed consequential-decision areas are education, employment, finance, healthcare, housing and insurance — **vendor-risk scoring is not on those lists**, but the same article says coverage depends on how a tool is used. [F, M] https://www.wittliffcutter.com/news-insights/ai-regulation-texas-colorado-federal-2026
- **Likelihood / magnitude.** Adoption is rising; regulation of vendor-ranking tools specifically is not indicated by anything fetched. If the same model were ever used to score *people* (e.g., staff performance), the regulatory picture would change.
- **Mitigation.** Keep a documented decision log, show reasons for each ranking, and keep a human accountable for every action (already in the design).

### R13. Data drift and regime change (a model trained 2023–2025, scored in 2026)

- **Evidence.**
  - Gama, Žliobaitė, Bifet, Pechenizkiy, Bouchachia, "A survey on concept drift adaptation," *ACM Computing Surveys* 46(4), article 44, 2014, DOI 10.1145/2523813: concept drift is a change over time in the relationship between inputs and the target. [F, H] https://research.tue.nl/en/publications/a-survey-on-concept-drift-adaptation/
  - OUR DATA: 2026 base rate 5.57% versus 4.31–4.81% in 2023–2025; protein 6.0% → 9.4%; cost per failure $1,701 versus $1,397–1,577; 14.2% of 2026 failures flagged as shock versus 0% in 2025.
- **Likelihood / magnitude.** In our data it has already happened by construction; the real world gives the same signs (R1–R4 show multiple simultaneous regime changes in 2026).
- **Mitigation (tool level).**
  1. Report performance on the 2026 holdout *and* on a rolling-origin backtest inside 2023–2025, so drift is visible rather than hidden in a single number.
  2. Monitor calibration monthly: compare predicted failure counts for the last 13 weeks with observed counts and show whether the observed count lies inside the model's prediction interval.
  3. Recalibration trigger: when observed failures fall outside the interval for N consecutive weeks (N set by the team), the dashboard turns its banner amber and says the model needs refitting.
  4. Fall back to category-level priors when a vendor's history is too short.
  5. Never extrapolate silently: what-if inputs outside the training range get a visible warning.

---

## 2. Cross-cutting design implications for Week 10

1. **Show uncertainty explicitly.** A University of Washington dissertation (Burgeno 2022, advisor Susan Joslyn) found that reliable explicit uncertainty estimates amplified decision-making benefits in forecasts that vary between updates (four experiments, school-closure decisions; only the abstract was read). [F, M-L] https://digital.lib.washington.edu/researchworks/items/2606e30e-b9a8-4669-9a3f-57914fff773c/full — generalizing from snow forecasts to vendor risk is an inference, not a finding.
2. **Separate category events from vendor events** (R2, R5, R6): the tool should say "this looks like a category-wide event" instead of ranking every vendor in the category as failing.
3. **Keep scenario knobs for things that cannot be forecast** (tariffs, beef prices, outages) rather than fitting them.
4. **Plan for sparse and zero-failure categories** (MRO has zero failures in the dataset; R7, R11).
5. **Log data reliability** (R8) and show it next to peak-week predictions.

---

## 3. Practitioner commentary and what operators say they prefer

This section is built only from pages actually read. Operators' own voices were scarce; most commentary is from executives, consultants and vendors.

### Operators and practitioners (higher weight)

- **Greg Presnol** (EVP operations, Palette Hotels), on AI use, per Hotel Management (Jun/Jul 2026): uses it to flag off-contract purchases, draft RFPs and vendor scorecards, and to ease invoice coding and GL mapping; the article reports no savings figures. [F, M] https://hotelmanagement.mydigitalpublication.com/publication/?i=865365&article_id=5160313&view=articleBrowser
- **Tony Lunzman** (president, Legacy Management, 30+ properties), per Hotel Management (Oct 2026): "Expanding our vendor relationships provides greater flexibility in pricing, service and product availability."; Legacy judges suppliers on "reliability, product availability, service capability, and consistent performance, not just price" (PARAPHRASE). [F, M]
- **Daniel Lesser** (LW Hospitality Advisors, consultant), same article: buffer of three to four pars for laundry; pre-vetted backup laundry vendors; link property-management and inventory systems; use reservation and occupancy forecasts to tighten pars. [F, M]
- **Nick Fertig** (Rosen Hotels, in-house laundry): "Keeping up on maintenance is a full-time job,". [F, M]
- **Kevin O'Bold** (VP Finance, Aspen Creek Grill, restaurant): "The remainder of 2026 will be a fight for market share as economic pressures persist." [F, L-M, quoted in vendor report]
- **Distributor-side IT leaders** at IFDA 2026 (Shaffer, Smith, Cusack, Perry): resilience over prevention; tested manual fallbacks; "Disaster recovery is an action and resilience is an outcome." (Brett Perry, Dot Foods). [F, M]

### Vendors and consultants (lower weight; self-interested)

- **Christine Carillo** (Amazon Business): "But the goal should never be to automate your buying decisions." **Eleanor Waddell** (Avendra): "AI can flag the issue early and recommend compliant substitutions." Both work for companies that sell procurement services. [F, M-L, MKT]
- **Access Point Group** (consultancy): "The issue is usually fragmentation, not lack of information." and "technology does not correct a weak purchasing process on its own." No statistics or named sources; reads as marketing. [F, L, MKT] https://www.accesspointgroup.com/hospitality-procurement-trends/
- **Graphite Connect** (supplier-data software vendor): 47% of procurement leaders say they do not trust their supplier data (about 70 organizations, May 2026; vendor-published). [F, L, MKT] https://www.graphiteconnect.com/press-article/nearly-half-of-procurement-leaders-dont-trust-their-supplier-data-study-finds
- **Nasir Zahir** (consultant, Hospitality Net opinion, 2026-04-20): claims large AI cost savings; every statistic is unsourced. [F, L, MKT] https://www.hospitalitynet.org/opinion/4131305/how-hotel-cost-controls-will-change-in-2026

### What the sources say operators prefer (synthesis; PARAPHRASE)

- Multiple sources, backup and near-by vendors, pre-agreed in advance (Lunzman, Lesser, Access Point Group — though the last cautions "Dual sourcing is one response, but it is not always the right answer.").
- Buffer stock expressed as pars, set from occupancy forecasts (Lesser, King).
- Human control retained: Carillo's quote above; Presnol's examples are all assistive.
- Fallback to manual processes when systems fail (Cusack).
- Integrated systems and trustworthy data before more AI (h2c: "connected systems, accessible and well-governed data" — Christin Haensel; Otelier: only 15% very confident in data).

### How practitioners would likely react to our tool (INFERENCE, not sourced)

I found no practitioner commentary about a per-vendor predictive risk ranking for an independent resort. The following is inference from the sources above and should be presented as such:

- Likely to value: a short ranked list sized to the manager's real review capacity; plain-language reasons; dollar framing; separation of category events from vendor events; a visible human override.
- Likely objections: "Do I trust the data?" (R8, Otelier 15% figure); "What happens when the system or my staff can't feed it?" (Cusack's fallback point); "Is this one more tool to maintain?" (h2c: skills barrier at 56%).
- Open question for the team: who at a 150–200 room property actually owns this task (context C14 already flags this as an unverified assumption).

---

## 4. Not found / limitations

- **Reddit and forum threads.** Not found. WebSearch rejected a domain-filtered query (HTTP 400) and an unfiltered query surfaced no forum threads; a direct fetch of Reddit was blocked by the fetch tool. No claim in this file relies on forum content.
- **Direct practitioner feedback on predictive vendor-risk tools in hospitality.** Not found; see inference above.
- **U.S. hotel purchasing or receiving staffing data.** Not found (only general hotel understaffing).
- **U.S. 2026 commercial-laundry capacity or lead-time data.** Not found; the one dated analog is UK 2021.
- **Import share by produce item, and which tariffs apply to hotel-relevant categories.** Not found (IFPA fact sheet had no import shares or association position).
- **Current Section 301 rates and exemptions.** Not verified; only a low-quality source was read.
- **Whether a 150–200 room resort with 2–3 outlets is covered by FSMA 204.** Not answered; FDA says small restaurants and retail food establishments are fully exempt and a draft policy would cover others.
- **Recall trend.** Two sources give different counts under different definitions; neither establishes a trend. openFDA itself was not queried this session.
- **2027+ hotel forecasts.** The Hotel Dive article has no 2027 forecast; a search result titled "Hotel Industry Forecast 2027" (Majestic Hospitality) was not read.
- **Pages seen only in search results, not read:** CNN pieces on screwworm (robots-blocked), US News on the 2026-09-24 cattle ban easing (fetch error), IBM and DZone model-drift explainers, CBO/CRS HPAI reports, the NewsNation recall article (fetch error), the CNBC Fed article (fetch error), USDA APHIS pages, Cintas filings.
- **Quote reliability.** All quotes come through a summarizing fetch tool; re-check before reuse.
- **Dates.** Several pages carry inconsistent dates (tariffstool.com; the FDA FSMA page; Travelweek's 2025 comparison). These are flagged where they occur.

---

## 5. Source list (distinct pages read)

1. USDA ERS Food Price Outlook — https://www-tx.ers.usda.gov/data-products/food-price-outlook/summary-findings (2026-09-25; H)
2. farmdoc daily, Mashange — https://farmdocdaily.illinois.edu/2026/10/food-inflation-and-the-outlook-for-beef-prices.html (2026-10-05; M)
3. Inquirer on screwworm/cattle — https://www.inquirer.com/business/cattle-beef-mexico-import-screwworm-prices-20260826.html (2026-08-26; M)
4. SupermarketNews, UNFI loss — https://www.supermarketnews.com/grocery-technology/unfi-lost-425m-in-cyberattack-but-increased-its-net-sales-outlook-for-the-year (2025; M)
5. SupermarketNews, UNFI shutdown — https://www.supermarketnews.com/grocery-technology/unfi-cyberattack-shuts-down-network-and-leaves-whole-foods-and-others-in-limbo (2025-06; M)
6. FreightWaves, IFDA cyber panel — https://www.freightwaves.com/news/food-distributors-warn-cyberattacks-can-quickly-become-supply-chain-disruptions (2026-09-18; M)
7. FDA FSMA 204 page — https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods (H)
8. Barley Snyder FSMA update — https://www.barley.com/update-food-traceability-rule-enforcement-deadline-extended/ (M)
9. Recall Bench 2026 — https://recallbench.com/statistics/2026/ (2026-10-19; M-L)
10. WISN recall analysis — https://www.wisn.com/article/us-food-recalls-trend-analysis/73415731 (2026; M)
11. ThePoultrySite/AVMA HPAI — https://www.thepoultrysite.com/news/2026/05/bird-flu-surges-in-us-poultry-as-wild-migration-spreads-virus-avma (2026-05-11; M)
12. FreshPlaza vegetable prices — https://www.freshplaza.com/north-america/article/9874850/fresh-vegetable-prices-rise-6-3-in-the-u-s-as-farm-labor-concerns-continue/ (2026-09-21; M)
13. FreshFruitPortal California heat — https://www.freshfruitportal.com/news/2026/04/24/california-heat-2026/ (2026-04-24; M)
14. WGBH Massachusetts farms — https://www.wgbh.org/news/local/2026-05-18/we-could-not-farm-without-them-small-mass-farms-face-immigration-and-labor-pressures (2026-05-18; M)
15. Farm Policy News on DOL filing — https://farmpolicynews.illinois.edu/2025/10/immigration-crackdown-hurting-ag-labor-dept-concedes/ (2025-10-16; M)
16. Flexport on IEEPA ruling — https://www.flexport.com/blog/the-supreme-courts-ieepa-tariff-ruling-next-steps-potential-refunds-and/ (M, MKT)
17. Wiley Section 122 alert — https://www.wiley.law/alert-Trump-Imposes-Section-122-Tariffs-After-Halting-IEEPA-Tariffs-Previews-New-Section-301-Investigations (2026-02-25; M)
18. tariffstool.com Section 301 — https://www.tariffstool.com/guides/section-301-replacing-section-122 (L, MKT)
19. IFPA tariff fact sheet — https://www.freshproduce.com/siteassets/files/advocacy/tariff-fact-sheet-feb-2026.pdf (2026-02; M; no import data)
20. Federal Reserve statement 2026-09-16 — https://www.federalreserve.gov/monetarypolicy/files/monetary20260916a1.pdf (H)
21. Hotel Dive, CoStar/Tourism Economics — https://www.hoteldive.com/news/costar-tourism-economics-hotel-revpar-forecast-2026/821683/ (2026-06-02; M)
22. Hotel News Resource, NTTO arrivals — https://www.hotelnewsresource.com/article143374.html (2026-10-18; M)
23. Travelweek, USTA — https://www.travelweek.ca/news/destinations/u-s-looking-at-2-million-fewer-intl-visitors-in-2026-says-ustas-freeman/ (2026-10-02; M)
24. AHLA survey — https://www.ahla.com/news/rising-cost-staffing-challenges-persist-hotels-travel-demand-expected-hold-steady (2026-03-17; M)
25. Business Travel News survey coverage — https://www.businesstravelnews.com/Lodging/Survey-Costs-Staffing-Shortages-Plague-Hoteliers-in-2026 (2026-03-17; M)
26. Sysco Q4 FY2026 transcript (Motley Fool) — https://www.fool.com/earnings/call-transcripts/2026/08/11/sysco-syy-q4-2026-earnings-call-transcript/ (2026-08-11; M)
27. US Foods Q2 2026 transcript (Benzinga) — https://www.benzinga.com/node/62212417 (2026; M)
28. PFG Q4 FY2026 call summary (MarketBeat) — https://www.marketbeat.com/instant-alerts/performance-food-group-q4-earnings-call-highlights-2026-08-12/ (2026-08-12; M)
29. Hotel Management, supply chain — https://hotelmanagement.mydigitalpublication.com/publication/?i=871541&article_id=5222510&view=articleBrowser (Oct 2026; M)
30. Hotel Management, laundry — https://hotelmanagement.mydigitalpublication.com/publication/?i=871541&article_id=5222504&view=articleBrowser (Oct 2026; M)
31. Hotel Management, procurement AI — https://hotelmanagement.mydigitalpublication.com/publication/?i=865365&article_id=5160313&view=articleBrowser (Jun/Jul 2026; M-L)
32. ILHA, supply chain webinar — https://ilha.org/articles/luxury-hotels-supply-chain-volatility-2026 (2026-06-25; M)
33. Access Point Group — https://www.accesspointgroup.com/hospitality-procurement-trends/ (L, MKT)
34. Hospitality Net opinion (Zahir) — https://www.hospitalitynet.org/opinion/4131305/how-hotel-cost-controls-will-change-in-2026 (2026-04-20; L, MKT)
35. Hospitality Net / Otelier Operations Index — https://www.hospitalitynet.org/report/4130590/the-2026-hotel-operations-index-progress-pressure-and-the-path-forward (2026-01-26; L-M, MKT)
36. Hospitality Net / h2c AI study — https://www.hospitalitynet.org/news/4134680/new-h2c-study-ai-adoption-is-widespread-among-hotel-chains-but-enterprise-readiness-remains-limited (2026-10-01; M)
37. Restaurant365 mid-year report — https://www.restaurant365.com/guides/2026-state-of-the-restaurant-industry-mid-year-report/ (2026; L-M, MKT)
38. Wittliff Cutter AI regulation — https://www.wittliffcutter.com/news-insights/ai-regulation-texas-colorado-federal-2026 (Sep 2026; M)
39. Graphite Connect press release — https://www.graphiteconnect.com/press-article/nearly-half-of-procurement-leaders-dont-trust-their-supplier-data-study-finds (2026-05-20; L, MKT)
40. RHF News linen — https://rhfnews.com/article/hotel-linen-buyers-shift-from-price-to-supply-reliability (2026-10-19; L, MKT)
41. Laundry & Cleaning News (UK, 2021 analog) — https://www.laundryandcleaningnews.com/news/ft-report-hotels-and-laundries-suffering-with-linen-supply-amid-labour-shortages-and-rising-costs-9057972/ (2021-09-06; M, dated)
42. Gama et al. 2014, concept drift survey — https://research.tue.nl/en/publications/a-survey-on-concept-drift-adaptation/ (H)
43. Burgeno 2022 dissertation, Univ. of Washington — https://digital.lib.washington.edu/researchworks/items/2606e30e-b9a8-4669-9a3f-57914fff773c/full (M-L; abstract only)
