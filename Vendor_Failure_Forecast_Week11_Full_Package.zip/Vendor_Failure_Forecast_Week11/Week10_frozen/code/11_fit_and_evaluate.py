"""
Week 10 step 2 -- fit, select, and evaluate the predictive model.

Design (justified in the one-page report):
  * Target: >= 1 material failure at the vendor in the NEXT week (W31).
  * Model:  binomial GLM, complementary log-log link  (P = 1 - exp(-hazard), the Poisson-process form,
            observed as "any failure this week"), with hazard = exp(category + vendor + g*log(deliveries/wk) + b*rejection rates).
            The textbook assumption g = 1 (failures proportional to deliveries, i.e. an offset) is TESTED and rejected by
            the data, so g (an exposure elasticity) is estimated instead.
            Category fixed effects + vendor random intercepts (ridge = partial pooling).
            Gaussian priors -> Laplace-approximate posterior -> credible intervals.
  * Selection uses ONLY the 2023-2025 development data (rolling-origin CV: train 2023 -> test 2024,
    train 2023-24 -> test 2025). The 2026 holdout is touched once, after the configuration is frozen.
  * Benchmarks: category prior, trailing-rate baselines (W35-W37), gradient-boosted trees.
  * Decision metric: share of next-week failure cost that falls inside the weekly top-k review set (W33).
  * Manager-action field (open corrective action) is NOT a predictor (W20/G29/S7); reported as an ablation only.

Outputs: data/model_params.json, data/model_eval.json, docs/model_report_wk10.txt
"""
import json
import os
import sys
import warnings

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glm_cloglog as G
from modeling_common import *

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "..", "data")
rng = np.random.default_rng(SEED)
LOG = []


def say(s=""):
    LOG.append(s)
    print(s)


# ------------------------------------------------------------------ data
d = pd.read_csv(os.path.join(D, "model_table.csv"))
d["banquet_flag"] = d.banquet_flag.astype(int)
src = lambda n: pd.read_csv(os.path.join(D, "source", n))
fail = src("fact_failure_event.csv")
cal = src("dim_calendar_week.csv").sort_values("week_start_monday").reset_index(drop=True)
cal["t"] = np.arange(len(cal))
dem = src("fact_demand_week.csv").merge(cal[["week_id", "t"]], on="week_id")
fail = fail.merge(cal[["week_id", "t", "data_split"]], on="week_id").merge(src("dim_vendor.csv")[["vendor_id", "category_id"]], on="vendor_id")
fail["total_cost"] = fail[["emergency_premium", "lost_contribution_margin", "guest_compensation", "firefighting_labor"]].sum(axis=1)
vendors = vendor_list(d)
dev = d[d.data_split == "dev"].reset_index(drop=True)
val = d[d.data_split == "validation_2026"].reset_index(drop=True)
folds = [("train 2023 -> test 2024", dev[dev.iso_year == 2023], dev[dev.iso_year == 2024]),
         ("train 2023-24 -> test 2025", dev[dev.iso_year <= 2024], dev[dev.iso_year == 2025])]


def cv_score(feats, lam_cat=0.1, lam_v=8.0, lam_b=1.0, **kw):
    out = []
    for _, tr, te in folds:
        m = fit_glm(tr, feats, vendors, lam_cat, lam_v, lam_b, **kw)
        out.append(metrics(te.y.values, predict(m, te)))
    return {k: float(np.mean([o[k] for o in out])) for k in out[0]}


say("WEEK 10 MODEL FIT & EVALUATION LOG")
say("=" * 78)
say(f"development rows={len(dev)} (positives {int(dev.y.sum())}), holdout 2026 rows={len(val)} (positives {int(val.y.sum())})")

# ------------------------------------------------------------------ 1) structure screen (dev CV only)
say("\n1) MODEL STRUCTURE (rolling-origin CV on 2023-2025; lower log-loss / higher AUC,AP is better)")
struct = {}
for name, kw in [("category rates only (no vendor, no exposure)", dict(feats=[], use_vendor=False)),
                 ("+ vendor partial pooling", dict(feats=[])),
                 ("+ Poisson-process offset (failures proportional to deliveries, g=1)", dict(feats=[], use_offset=True)),
                 ("+ estimated exposure elasticity g (chosen)", dict(feats=["log_exposure"]))]:
    struct[name] = cv_score(**kw)
    say(f"  {name:70s} " + "  ".join(f"{k}={v:.4f}" for k, v in struct[name].items()))

m_free = fit_glm(dev, ["log_exposure"], vendors, 0.1, 8.0, 1.0)
j = m_free["names"].index("log_exposure")
sd_le = m_free["scaler"]["log_exposure"][1]
g_hat, g_se = m_free["beta"][j] / sd_le, np.sqrt(m_free["cov"][j, j]) / sd_le
say(f"\n  Exposure elasticity g (hazard ~ deliveries^g): {g_hat:.2f} (SE {g_se:.2f}); 95% CI {g_hat - 1.96 * g_se:.2f} .. {g_hat + 1.96 * g_se:.2f}")
say(f"  H0 'failures proportional to deliveries' (g=1): z = {(g_hat - 1) / g_se:+.2f}  -> REJECTED; H0 'no exposure effect' (g=0): z = {g_hat / g_se:+.2f}")
offset_check = dict(g=float(g_hat), se=float(g_se), z_vs_1=float((g_hat - 1) / g_se), z_vs_0=float(g_hat / g_se))

# ------------------------------------------------------------------ 2) predictor screen (dev CV only)
say("\n2) PREDICTOR SCREEN: add ONE candidate to the base model (category + vendor + exposure elasticity). Delta vs base:")
base = cv_score(["log_exposure"])
cands = [("rej_4wk", "Rejection rate, last 4 wks"), ("rej_13wk", "Rejection rate, last 13 wks"),
         ("late_4wk", "Late-delivery rate, last 4 wks"), ("late_13wk", "Late-delivery rate, last 13 wks"),
         ("short_4wk", "Short-fill rate, last 4 wks"), ("short_13wk", "Short-fill rate, last 13 wks"),
         ("fail_13wk", "Material failures, last 13 wks"), ("fail_52wk", "Material failures, last 52 wks"),
         ("wks_since_fail", "Weeks since last failure"), ("occupancy_rate", "Occupancy rate"),
         ("banquet_flag", "Banquet this week"), ("no_delivery_4wk", "No deliveries in last 4 wks")]
screen = []
for f, label in cands:
    r = cv_score(["log_exposure", f], lam_b=25.0)
    screen.append(dict(feature=f, label=label, d_logloss=r["logloss"] - base["logloss"], d_ap=r["ap"] - base["ap"], d_auc=r["auc"] - base["auc"]))
    say(f"  {label:34s} dLogLoss={screen[-1]['d_logloss']:+.4f}  dAP={screen[-1]['d_ap']:+.4f}  dAUC={screen[-1]['d_auc']:+.4f}")
r = cv_score(FEATS)
say(f"  --> chosen set (exposure + rej_4wk + rej_13wk)         dLogLoss={r['logloss'] - base['logloss']:+.4f}  dAP={r['ap'] - base['ap']:+.4f}  dAUC={r['auc'] - base['auc']:+.4f}")
r_cap = cv_score(["log_exposure", "open_cap"], lam_b=25.0)
say(f"  [ablation, EXCLUDED by rule S7/G29] open corrective action: dLogLoss={r_cap['logloss'] - base['logloss']:+.4f} dAP={r_cap['ap'] - base['ap']:+.4f}")
screen.append(dict(feature="open_cap", label="Open corrective action (manager action; excluded by rule S7)", d_logloss=r_cap["logloss"] - base["logloss"],
                   d_ap=r_cap["ap"] - base["ap"], d_auc=r_cap["auc"] - base["auc"], excluded=True))

# ------------------------------------------------------------------ 3) penalty selection (dev CV only)
say("\n3) PARTIAL-POOLING STRENGTH (grid, dev CV log-loss; vendor prior sd = 1/sqrt(lam_v))")
best = None
grid = []
for lv in (2, 4, 8, 16, 40):
    for lc in (0.01, 0.1, 1.0):
        s = cv_score(FEATS, lam_cat=lc, lam_v=lv)
        grid.append(dict(lam_v=lv, lam_cat=lc, **s))
        if best is None or s["logloss"] < best[0]:
            best = (s["logloss"], lv, lc)
LAM_V, LAM_CAT = best[1], best[2]
say(f"  selected lam_v={LAM_V} (vendor effect sd ~ {1 / np.sqrt(LAM_V):.2f} on the log-hazard scale), lam_cat={LAM_CAT}; CV log-loss={best[0]:.4f}")

# ------------------------------------------------------------------ 4) final fit on ALL development data
final = fit_glm(dev, FEATS, vendors, LAM_CAT, LAM_V, 1.0)
say(f"\n4) FINAL FIT on {len(dev)} development rows  (converged={final['info']['converged']}, max |grad|={final['info']['maxgrad']:.2e})")
se = np.sqrt(np.diag(final["cov"]))
coefs = []
for n, b, s in zip(final["names"], final["beta"], se):
    if n.startswith("v:"):
        continue
    coefs.append(dict(name=n, beta=float(b), se=float(s)))
    say(f"  {n:22s} {b:+8.3f}  (SE {s:.3f})   hazard ratio {np.exp(b):8.3f}" if not n.startswith("cat:") and n != "intercept"
        else f"  {n:22s} {b:+8.3f}  (SE {s:.3f})")
veff = np.array([b for n, b in zip(final["names"], final["beta"]) if n.startswith("v:")])
say(f"  vendor random effects: sd={veff.std():.3f}, range [{veff.min():+.2f}, {veff.max():+.2f}]  (log-hazard scale)")

# Categories with ZERO observed failures (MRO): the Gaussian (Laplace) posterior is symmetric on the log-hazard scale, so it puts
# real mass on failure rates the data have already ruled out. Exact likelihood for zero events is exp(-lambda) with lambda the
# expected number of events in that category's development rows; lambda > -ln(0.05) = 3.0 has 5% likelihood or less. Posterior draws of
# that category's effect are therefore clipped at the value where lambda reaches 3.0 (a one-sided exact 95% Poisson limit).
ZERO_EVENT_UPPER = float(-np.log(0.05))
_pd, _eta, _ = predict(final, dev, return_eta=True)
zero_cap = {}
for c in CATS:
    m_ = (dev.category_id == c).values
    if dev.y.values[m_].sum() == 0:
        lam_hat = float(np.exp(_eta[m_]).sum())
        zero_cap[c] = dict(delta=float(np.log(ZERO_EVENT_UPPER / lam_hat)), lambda_hat=lam_hat, n=int(m_.sum()))
        say(f"  zero-failure category {c}: expected events at the mode {lam_hat:.3f} in {int(m_.sum())} rows -> posterior draws of its effect "
            f"clipped at mode + {zero_cap[c]['delta']:.2f} (weekly chance cannot exceed about {1 - np.exp(-np.exp(_eta[m_].mean() + zero_cap[c]['delta'])):.2%})")

# cross-check: independent optimiser reproduces the mode (unpenalised check on a small design)
from scipy.optimize import minimize
Xc, nm = build_design(dev, FEATS, final["scaler"], vendors)
lam = final["lam"]
off = np.zeros(len(dev))
f2 = lambda b: G.neg_log_post(b, Xc, dev.y.values, off, lam)
res = minimize(f2, np.zeros(Xc.shape[1]), method="Powell", options=dict(maxiter=60000, xtol=1e-6, ftol=1e-12))
say(f"  cross-check: Powell optimum NLL={res.fun:.4f} vs Newton NLL={final['info']['nll']:.4f} (should match to ~1e-3)")
# gradient check
b0 = final["beta"] + 0.01 * rng.standard_normal(len(final["beta"]))
num = np.array([(f2(b0 + 1e-6 * e) - f2(b0 - 1e-6 * e)) / 2e-6 for e in np.eye(len(b0))[:12]])
ana = G.grad(b0, Xc, dev.y.values, off, lam)[:12]
say(f"  analytic vs numeric gradient (12 coords): max abs diff = {np.max(np.abs(num - ana)):.2e}")

# ------------------------------------------------------------------ 5) failure-cost model (dev failure vendor-weeks only)
# The prediction target is ">= 1 failure in the week"; a failing vendor-week can contain several events (see below),
# so the cost model is per FAILING VENDOR-WEEK = the summed cost of all events that vendor had that week.
vw = fail.groupby(["vendor_id", "t", "week_id", "data_split"], as_index=False).agg(total_cost=("total_cost", "sum"), n_events=("total_cost", "size"))
fc = vw.merge(dem[["t", "occupancy_rate", "banquet_flag"]], on="t", how="left")
fc_dev, fc_val = fc[fc.data_split == "dev"], fc[fc.data_split == "validation_2026"]
mean_events = float(fc_dev.n_events.mean())
cm = fit_cost_model(fc_dev)
cse = np.sqrt(np.diag(cm["cov"]))
say("\n5) FAILURE-COST MODEL: mean cost per failing vendor-week = OLS on the demand context of that week (robust SEs)")
say(f"  {len(fc_dev)} failing vendor-weeks in 2023-25 hold {int(fc_dev.n_events.sum())} events (mean {mean_events:.2f} events per failing vendor-week; "
    f"{(fc_dev.n_events > 1).mean():.0%} have 2+)")
for n, b, s_ in zip(cm["names"], cm["beta"], cse):
    say(f"  {n:12s} {b:+9.1f}  (SE {s_:.1f})")
mu_v = np.array([expected_cost(cm, o, q) for o, q in zip(fc_val.occupancy_rate, fc_val.banquet_flag)])
q10, q90 = cm["ratio_q"][10], cm["ratio_q"][90]
cov80 = float(((fc_val.total_cost.values >= mu_v * q10) & (fc_val.total_cost.values <= mu_v * q90)).mean())
by_season = fc_val.assign(pred=mu_v).merge(cal[["week_id", "season_label"]], on="week_id").groupby("season_label").agg(n=("total_cost", "size"), actual=("total_cost", "mean"), pred=("pred", "mean"))
say(f"  2026 check (failure-week demand given): mean actual ${fc_val.total_cost.mean():,.0f} vs mean predicted ${mu_v.mean():,.0f}; "
    f"80% interval for one failing vendor-week (x{q10:.2f} .. x{q90:.2f} of the mean) covers {cov80:.1%} of {len(fc_val)} 2026 failing vendor-weeks")
for sl, r_ in by_season.iterrows():
    say(f"    {sl:9s} n={int(r_.n):3d}  actual ${r_.actual:,.0f}  predicted ${r_.pred:,.0f}")
cost_eval = dict(n_dev=int(len(fc_dev)), mean_events_per_failing_week=mean_events, mean_actual_2026=float(fc_val.total_cost.mean()),
                 mean_pred_2026=float(mu_v.mean()), coverage80_2026=cov80,
                 by_season={k: dict(n=int(v.n), actual=float(v.actual), pred=float(v.pred)) for k, v in by_season.iterrows()})

# ------------------------------------------------------------------ 6) 2026 holdout (frozen model, touched once)
say("\n6) 2026 HOLDOUT (model frozen on 2023-2025; no 2026 information used anywhere above)")
val = val.copy()
val["p"], val["eta"], Xv = predict(final, val, return_eta=True)
M = metrics(val.y.values, val.p.values)
cat_prior = dev.groupby("category_id").y.mean()
val["p_cat"] = val.category_id.map(cat_prior)
M0 = metrics(val.y.values, val.p_cat.values)
say(f"  GLM (frozen)        " + "  ".join(f"{k}={v:.4f}" for k, v in M.items()))
say(f"  category base rate  " + "  ".join(f"{k}={v:.4f}" for k, v in M0.items()))

# bootstrap CIs by week
weeks_arr = val.week_id.values
boot = {"auc": [], "ap": [], "brier": [], "d_brier": []}
for idx in week_bootstrap_idx(weeks_arr, 500, rng):
    yy, pp, p0 = val.y.values[idx], val.p.values[idx], val.p_cat.values[idx]
    if yy.sum() == 0:
        continue
    mm = metrics(yy, pp)
    boot["auc"].append(mm["auc"]); boot["ap"].append(mm["ap"]); boot["brier"].append(mm["brier"])
    boot["d_brier"].append(metrics(yy, p0)["brier"] - mm["brier"])
ci = {k: [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))] for k, v in boot.items()}
say(f"  95% week-bootstrap CI: AUC {ci['auc'][0]:.3f}-{ci['auc'][1]:.3f}, AP {ci['ap'][0]:.3f}-{ci['ap'][1]:.3f}, "
    f"Brier improvement over category prior {np.mean(boot['d_brier']):+.5f} (CI {ci['d_brier'][0]:+.5f} .. {ci['d_brier'][1]:+.5f})")

# calibration: intercept and slope on the cloglog scale
cl = np.log(-np.log1p(-np.clip(val.p.values, 1e-9, 1 - 1e-9)))          # cloglog(p) = log(mu)
Xcal = np.column_stack([np.ones(len(val)), cl - cl.mean()])
bcal, covcal, _ = G.fit(Xcal, val.y.values, np.zeros(len(val)), np.array([1e-9, 1e-9]))
# intercept-only recalibration offset: shift needed in log-hazard so mean prediction matches observed
bshift, covshift, _ = G.fit(np.ones((len(val), 1)), val.y.values, cl, np.array([1e-9]))
say(f"  calibration slope (cloglog scale) = {bcal[1]:.3f} (SE {np.sqrt(covcal[1, 1]):.3f}) [ideal 1]")
say(f"  calibration-in-the-large: observed {val.y.mean():.4f} vs predicted mean {val.p.mean():.4f} "
    f"-> log-hazard shift needed {bshift[0]:+.3f} (SE {np.sqrt(covshift[0, 0]):.3f}), i.e. x{np.exp(bshift[0]):.2f}")
calib = dict(slope=float(bcal[1]), slope_se=float(np.sqrt(covcal[1, 1])), shift=float(bshift[0]), shift_se=float(np.sqrt(covshift[0, 0])),
             obs_rate=float(val.y.mean()), pred_mean=float(val.p.mean()))

# reliability table (deciles of predicted risk) with Wilson CI
val["bin"] = pd.qcut(val.p.rank(method="first"), 10, labels=False)
rel = []
for b, g in val.groupby("bin"):
    k, n = int(g.y.sum()), len(g)
    lo_, hi_ = wilson(k, n)
    rel.append(dict(bin=int(b) + 1, n=n, pred=float(g.p.mean()), obs=float(k / n), lo=float(lo_), hi=float(hi_)))
say("  reliability (decile: predicted -> observed [95% CI]):")
for r_ in rel:
    say(f"    D{r_['bin']:>2}  {r_['pred']:.3f} -> {r_['obs']:.3f} [{r_['lo']:.3f}, {r_['hi']:.3f}]  n={r_['n']}")

# ------------------------------------------------------------------ 7) benchmarks on the same holdout
say("\n7) BENCHMARKS on the 2026 holdout (ranking quality; higher AUC/AP better)")
# GBM
gcols = ["exposure_wk", "rej_4wk", "rej_13wk", "late_4wk", "late_13wk", "short_4wk", "short_13wk", "fail_13wk", "fail_52wk", "wks_since_fail", "occupancy_rate", "banquet_flag"]


def gbm_frame(df):
    X = df[gcols].copy()
    X["cat"] = df.category_id.map({c: i for i, c in enumerate(CATS)})
    return X


gbm = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=150, l2_regularization=5.0, min_samples_leaf=60,
                                     categorical_features=[len(gcols)], random_state=SEED)
gbm.fit(gbm_frame(dev), dev.y.values)
val["p_gbm"] = gbm.predict_proba(gbm_frame(val))[:, 1]
# dev-CV for the GBM too (same folds), so the comparison is not only on the holdout
gcv = []
for _, tr, te in folds:
    g_ = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=150, l2_regularization=5.0, min_samples_leaf=60,
                                        categorical_features=[len(gcols)], random_state=SEED).fit(gbm_frame(tr), tr.y.values)
    gcv.append(metrics(te.y.values, g_.predict_proba(gbm_frame(te))[:, 1]))
gcv = {k: float(np.mean([o[k] for o in gcv])) for k in gcv[0]}
Mg = metrics(val.y.values, val.p_gbm.values)
# ablation with open corrective action
abl = fit_glm(dev, FEATS + ["open_cap"], vendors, LAM_CAT, LAM_V, 1.0)
val["p_abl"] = predict(abl, val)
Ma = metrics(val.y.values, val.p_abl.values)
# trailing-rate baselines (scores, not probabilities -> ranking metrics only)
from sklearn.metrics import roc_auc_score, average_precision_score
jit = rng.random(len(val)) * 1e-9


def rk(sc):
    return dict(auc=float(roc_auc_score(val.y, sc + jit)), ap=float(average_precision_score(val.y, sc + jit)))


bench = {
    "GLM (this model)": dict(auc=M["auc"], ap=M["ap"], brier=M["brier"], logloss=M["logloss"]),
    "Gradient-boosted trees": dict(auc=Mg["auc"], ap=Mg["ap"], brier=Mg["brier"], logloss=Mg["logloss"]),
    "GLM + open-CAP flag (excluded by S7)": dict(auc=Ma["auc"], ap=Ma["ap"], brier=Ma["brier"], logloss=Ma["logloss"]),
    "Category base rate": dict(auc=M0["auc"], ap=M0["ap"], brier=M0["brier"], logloss=M0["logloss"]),
    "Trailing 13-wk rejection rate": rk(val.rej_13wk.values),
    "Trailing 4-wk rejection rate": rk(val.rej_4wk.values),
    "Trailing on-time + fill (current practice score)": rk((val.late_13wk + val.short_13wk).values),
    "Delivery volume (spend proxy)": rk(val.exposure_wk.values),
}
for k, v in bench.items():
    say(f"  {k:50s} " + "  ".join(f"{a}={b:.4f}" for a, b in v.items()))
say(f"  GBM dev-CV (same folds as GLM): " + "  ".join(f"{a}={b:.4f}" for a, b in gcv.items()) + f"   vs GLM dev-CV: " +
    "  ".join(f"{a}={b:.4f}" for a, b in cv_score(FEATS, LAM_CAT, LAM_V).items()))

# ------------------------------------------------------------------ 8) decision metric: cost captured in top-k review set
say("\n8) DECISION METRIC: share of ADDRESSABLE next-week failure cost inside the weekly top-k review set (k = that week's review capacity)")
realized = fail.groupby(["vendor_id", "t"]).total_cost.sum()
val["t_target"] = val.t + 1
val["real_cost"] = [realized.get((v, tt), 0.0) for v, tt in zip(val.vendor_id, val.t_target)]
val["fail_n"] = val.y
val["e_cost"] = [expected_cost(cm, o, b) for o, b in zip(val.occupancy_rate, val.banquet_flag)]
val["score_model"] = val.p * val.e_cost
val["score_model_p"] = val.p
val["score_gbm"] = val.p_gbm * val.e_cost
val["score_b1"] = np.where(val.wks_since_fail <= 2, 100.0, 0.0) + val.late_13wk + val.short_13wk        # loud recent failure jumps the queue
val["score_b2"] = val.rej_13wk + 0.001 * val.rej_4wk
val["score_b3"] = val.exposure_wk
open_mask = val.open_cap.values == 0
val["addressable"] = open_mask
wk_ids = sorted(val.t.unique())
policies = {"Model: expected cost (this tool)": "score_model", "Model: failure probability only": "score_model_p",
            "Gradient-boosted trees x cost": "score_gbm",
            "Current practice (on-time/fill + loud-failure override)": "score_b1",
            "Trailing rejection rate": "score_b2", "Spend proxy (delivery volume)": "score_b3", "Random": None}
JIT_REPS = 40
per_week = {}
for name, col in policies.items():
    cap_c, tot_c, cap_n, tot_n = [], [], [], []
    for w in wk_ids:
        g = val[(val.t == w) & val.addressable]
        k = int(val[val.t == w].review_capacity_k.iloc[0])
        tc, tn = g.real_cost.sum(), g.fail_n.sum()
        if col is None:
            cc = np.mean([g.real_cost.values[rng.permutation(len(g))[:k]].sum() for _ in range(200)])
            cn = np.mean([g.fail_n.values[rng.permutation(len(g))[:k]].sum() for _ in range(200)])
        else:
            cs, ns = [], []
            sc = g[col].values
            for _ in range(JIT_REPS if col in ("score_b1", "score_b2", "score_b3") else 1):
                j_ = np.argsort(-(sc + rng.random(len(sc)) * (1e-9 if col not in ("score_b1", "score_b2", "score_b3") else 1e-4)))[:k]
                cs.append(g.real_cost.values[j_].sum()); ns.append(g.fail_n.values[j_].sum())
            cc, cn = np.mean(cs), np.mean(ns)
        cap_c.append(cc); tot_c.append(tc); cap_n.append(cn); tot_n.append(tn)
    per_week[name] = dict(cap_c=np.array(cap_c), tot_c=np.array(tot_c), cap_n=np.array(cap_n), tot_n=np.array(tot_n))
# oracle ceiling
orc_c, orc_n = [], []
for w in wk_ids:
    g = val[(val.t == w) & val.addressable]
    k = int(val[val.t == w].review_capacity_k.iloc[0])
    orc_c.append(np.sort(g.real_cost.values)[::-1][:k].sum()); orc_n.append(np.sort(g.fail_n.values)[::-1][:k].sum())
per_week["Oracle ceiling (hindsight)"] = dict(cap_c=np.array(orc_c), tot_c=per_week["Random"]["tot_c"], cap_n=np.array(orc_n), tot_n=per_week["Random"]["tot_n"])

nW = len(wk_ids)
boots = [rng.integers(0, nW, nW) for _ in range(2000)]
capture = {}
base_pw = per_week["Model: expected cost (this tool)"]
for name, pw in per_week.items():
    est_c = pw["cap_c"].sum() / pw["tot_c"].sum()
    est_n = pw["cap_n"].sum() / pw["tot_n"].sum()
    bc = [pw["cap_c"][i].sum() / pw["tot_c"][i].sum() for i in boots]
    bn = [pw["cap_n"][i].sum() / pw["tot_n"][i].sum() for i in boots]
    dc = [(base_pw["cap_c"][i].sum() / base_pw["tot_c"][i].sum()) - (pw["cap_c"][i].sum() / pw["tot_c"][i].sum()) for i in boots]
    capture[name] = dict(cost=float(est_c), cost_ci=[float(np.percentile(bc, 2.5)), float(np.percentile(bc, 97.5))],
                         count=float(est_n), count_ci=[float(np.percentile(bn, 2.5)), float(np.percentile(bn, 97.5))],
                         model_minus_this_cost=float(np.mean(dc)), model_minus_this_ci=[float(np.percentile(dc, 2.5)), float(np.percentile(dc, 97.5))])
    say(f"  {name:56s} cost captured {est_c:6.1%} [{np.percentile(bc, 2.5):.1%}, {np.percentile(bc, 97.5):.1%}]   failures captured {est_n:6.1%}   "
        f"(model minus this: {np.mean(dc):+.1%} [{np.percentile(dc, 2.5):+.1%}, {np.percentile(dc, 97.5):+.1%}])")
tot_all = val[val.t.isin(wk_ids)].real_cost.sum()
say(f"  addressable failure cost = ${per_week['Random']['tot_c'].sum():,.0f} of ${tot_all:,.0f} total 2026 next-week failure cost "
    f"({per_week['Random']['tot_c'].sum() / tot_all:.1%}); the rest sits at vendors already under an open corrective action")
say(f"  mean weekly capacity k = {val.groupby('t').review_capacity_k.first().mean():.1f}; mean eligible vendors/week = {val[val.addressable].groupby('t').size().mean():.1f}")

# ------------------------------------------------------------------ 9) uncertainty honesty: portfolio count intervals + drift monitor
say("\n9) UNCERTAINTY CHECK: does the model's 80% interval for the weekly NUMBER of failing vendors hold up in 2026?")
Z = G.draws(final["beta"], final["cov"], 600, rng)
for c_, zc_ in zero_cap.items():
    j_ = final["names"].index("cat:" + c_)
    Z[:, j_] = np.minimum(Z[:, j_], final["beta"][j_] + zc_["delta"])
Pm = G._mu_p(Z @ Xv.T)[1]            # 600 x n_rows
tw = val.t.values
cov_hits, rows_w = [], []
for w in wk_ids:
    ix = np.where(tw == w)[0]
    counts = (rng.random(Pm[:, ix].shape) < Pm[:, ix]).sum(axis=1)
    lo_, hi_ = np.percentile(counts, 10), np.percentile(counts, 90)
    act = int(val.y.values[ix].sum())
    cov_hits.append(lo_ <= act <= hi_)
    rows_w.append(dict(t=int(w), week=val.week_id.values[ix[0]], expected=float(val.p.values[ix].sum()), lo=float(lo_), hi=float(hi_), actual=act))
cov_w = float(np.mean(cov_hits))
# dollars: weekly expected / predictive interval for TOTAL next-week failure cost across the scored portfolio
dem_t = dem.set_index("t")
Zc = rng.multivariate_normal(cm["beta"], cm["cov"], size=600)
cost_hits, exp_costs = [], []
for r_ in rows_w:
    w = r_["t"]
    ix = np.where(tw == w)[0]
    d_ = dem_t.loc[w + 1]
    m_draw = Zc @ np.array([1.0, d_.occupancy_rate, float(d_.banquet_flag)])               # 600 mean-cost draws
    fails_ = rng.random(Pm[:, ix].shape) < Pm[:, ix]
    ratio_draw = rng.choice(cm["ratio"], size=fails_.shape)
    tot = (fails_ * ratio_draw).sum(axis=1) * np.maximum(m_draw, 0)
    lo_, hi_ = np.percentile(tot, 10), np.percentile(tot, 90)
    act = float(val.real_cost.values[ix].sum())
    exp_ = float(val.p.values[ix].sum() * expected_cost(cm, d_.occupancy_rate, d_.banquet_flag))
    r_.update(exp_cost=exp_, cost_lo=float(lo_), cost_hi=float(hi_), actual_cost=act)
    cost_hits.append(lo_ <= act <= hi_)
cov_cost = float(np.mean(cost_hits))
tot_exp = sum(r_["exp_cost"] for r_ in rows_w); tot_act = sum(r_["actual_cost"] for r_ in rows_w)
say(f"  weekly total failure cost: 80% predictive interval contained the actual in {cov_cost:.1%} of {len(wk_ids)} weeks; "
    f"2026 total expected ${tot_exp:,.0f} vs actual ${tot_act:,.0f} (ratio {tot_act / tot_exp:.2f})")
say(f"  weekly failing-vendor count: 80% predictive interval contained the actual count in {cov_w:.1%} of {len(wk_ids)} weeks (nominal 80%)")
say(f"  total expected failures {val.p.sum():.1f} vs actual {int(val.y.sum())}  (ratio actual/expected = {val.y.sum() / val.p.sum():.2f})")
# rolling observed/expected monitor (uses only information available at each date: labels up to t-1)
oe = []
allv = pd.concat([dev, val]).sort_values("t")
allv["p_frozen"] = predict(final, allv)
for w in wk_ids:
    past = allv[(allv.t <= w - 1) & (allv.t >= w - 26)]                       # labels of rows <= w-2 are known; use w-1 conservatively
    past = allv[(allv.t <= w - 2) & (allv.t >= w - 27)]
    oe.append(dict(t=int(w), week=val[val.t == w].week_id.iloc[0], oe=float(past.y.sum() / max(past.p_frozen.sum(), 1e-9)), n=int(past.y.sum())))
trig = [o for o in oe if o["oe"] > 1.25 or o["oe"] < 0.8]
say(f"  rolling 26-week observed/expected: first week outside [0.80, 1.25]: {trig[0]['week'] if trig else 'never'}; "
    f"final value {oe[-1]['oe']:.2f}")
# per-category drift
catdrift = []
for c in CATS:
    g_dev, g_val = dev[dev.category_id == c], val[val.category_id == c]
    catdrift.append(dict(category=c, dev_rate=float(g_dev.y.mean()), val_rate=float(g_val.y.mean()), val_pred=float(g_val.p.mean()),
                         val_fail=int(g_val.y.sum()), val_n=len(g_val)))
    say(f"  {c:16s} dev rate {g_dev.y.mean():.3f}  2026 rate {g_val.y.mean():.3f}  2026 predicted {g_val.p.mean():.3f}  (failures: {int(g_val.y.sum())})")

# ------------------------------------------------------------------ 10) sensitivity: quarterly refit (walk-forward) on 2026
say("\n10) SENSITIVITY: refit the same model at each quarter start of 2026 (labels known by then only) and score the quarter")
allv = pd.concat([dev, val]).sort_values("t").reset_index(drop=True)
t0 = int(val.t.min())
q_starts = [t0, t0 + 13, t0 + 26, t0 + 39, int(val.t.max()) + 1]
preds_wf = pd.Series(np.nan, index=val.index)
for a, b in zip(q_starts[:-1], q_starts[1:]):
    tr = allv[allv.t <= a - 2]
    m_ = fit_glm(tr, FEATS, vendors, LAM_CAT, LAM_V, 1.0)
    ix = val.index[(val.t >= a) & (val.t < b)]
    preds_wf.loc[ix] = predict(m_, val.loc[ix])
Mwf = metrics(val.y.values, preds_wf.values)
say(f"  frozen: brier={M['brier']:.4f} logloss={M['logloss']:.4f} auc={M['auc']:.3f} | quarterly refit: brier={Mwf['brier']:.4f} logloss={Mwf['logloss']:.4f} auc={Mwf['auc']:.3f}; "
    f"mean predicted {preds_wf.mean():.4f} vs observed {val.y.mean():.4f}")
refit = dict(frozen=M, quarterly=Mwf, pred_mean_quarterly=float(preds_wf.mean()))

# ------------------------------------------------------------------ 11) persist
params = dict(
    seed=SEED, feats=FEATS, lam_cat=LAM_CAT, lam_v=LAM_V, cats=CATS, vendors=vendors,
    names=final["names"], beta=final["beta"].tolist(), cov=final["cov"].tolist(),
    scaler={k: list(v) for k, v in final["scaler"].items()},
    cost_model=dict(names=cm["names"], beta=cm["beta"].tolist(), cov=cm["cov"].tolist(), ratio_q=[round(float(x), 4) for x in cm["ratio_q"]]),
    vendor_prior_sd=float(1 / np.sqrt(LAM_V)), zero_event_cap=zero_cap)
json.dump(params, open(os.path.join(D, "model_params.json"), "w"))
evalj = dict(
    n_dev=len(dev), n_val=len(val), pos_dev=int(dev.y.sum()), pos_val=int(val.y.sum()),
    structure=struct, offset_check=offset_check, screen=screen, base_cv=base, grid=grid, chosen=dict(lam_v=LAM_V, lam_cat=LAM_CAT),
    coefs=coefs, vendor_effect_sd=float(veff.std()), cost_eval=cost_eval,
    holdout=dict(glm=M, cat=M0, ci=ci, calib=calib, reliability=rel), bench=bench, gbm_cv=gcv,
    capture=capture, addressable_share=float(per_week["Random"]["tot_c"].sum() / tot_all),
    weekly_counts=rows_w, weekly_count_cov80=cov_w, weekly_cost_cov80=cov_cost, cost_total_expected=float(tot_exp), cost_total_actual=float(tot_act), oe=oe, catdrift=catdrift, refit=refit,
    mean_k=float(val.groupby("t").review_capacity_k.first().mean()))
json.dump(evalj, open(os.path.join(D, "model_eval.json"), "w"))
val.drop(columns=["bin"]).to_csv(os.path.join(D, "holdout_predictions_2026.csv"), index=False)
say("\nwrote data/model_params.json, data/model_eval.json, data/holdout_predictions_2026.csv")
open(os.path.join(HERE, "..", "docs", "model_report_wk10.txt"), "w").write("\n".join(LOG) + "\n")
