"""
Penalized complementary-log-log GLM with an exposure offset (Poisson-process hazard model).

    P(at least one material failure next week) = 1 - exp(-mu),   mu = exp(offset + X @ beta)

where offset = log(expected deliveries next week). Equivalent to a Poisson-process model in
which failures arrive at a per-delivery hazard exp(X @ beta) and we only observe whether
>= 1 failure happened in the week (so the model is a binary-outcome model with exact
exposure scaling -- a vendor that delivers twice as often has twice the hazard, by construction).

Priors: independent Gaussian N(0, 1/lam_j) on each coefficient (lam_j = 0 -> flat). With the
Gaussian prior this is a Laplace-approximation Bayesian model: the posterior is approximately
N(beta_hat, H^-1) where H = observed information + diag(lam). Vendor/category effects get a
ridge prior, which is the standard partial-pooling approximation to random intercepts.

No external dependencies beyond numpy/scipy (statsmodels is not installed in this environment;
the unpenalised case is cross-checked against an independent numeric optimiser in
10_fit_model.py).
"""
import numpy as np
from scipy.optimize import minimize


def _mu_p(eta):
    eta = np.clip(eta, -30, 8)
    mu = np.exp(eta)
    p = -np.expm1(-mu)                 # 1 - exp(-mu), stable for small mu
    return mu, p


def neg_log_post(beta, X, y, offset, lam):
    eta = offset + X @ beta
    mu, p = _mu_p(eta)
    p = np.clip(p, 1e-12, 1.0)
    ll = np.sum(np.where(y == 1, np.log(p), -mu))
    return -(ll) + 0.5 * np.sum(lam * beta * beta)


def grad(beta, X, y, offset, lam):
    eta = offset + X @ beta
    mu, p = _mu_p(eta)
    p = np.clip(p, 1e-12, 1.0)
    g1 = mu * np.exp(-mu) / p          # d log p / d eta
    g = np.where(y == 1, g1, -mu)
    return -(X.T @ g) + lam * beta


def observed_information(beta, X, y, offset, lam):
    eta = offset + X @ beta
    mu, p = _mu_p(eta)
    em = np.expm1(mu)                  # e^mu - 1
    em = np.maximum(em, 1e-12)
    g2_pos = mu * (em - mu * np.exp(mu)) / em ** 2   # d2 log p / d eta2 (y = 1)
    g2 = np.where(y == 1, g2_pos, -mu)
    W = -g2                            # observed information weights (>= 0 for this link)
    H = (X * W[:, None]).T @ X + np.diag(lam)
    return H


def fit(X, y, offset, lam, beta0=None):
    """Return (beta_hat, cov, info) with cov = H^-1 at the mode."""
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    offset = np.asarray(offset, float)
    lam = np.asarray(lam, float)
    if beta0 is None:
        beta0 = np.zeros(X.shape[1])
    res = minimize(neg_log_post, beta0, args=(X, y, offset, lam), jac=grad, method="L-BFGS-B",
                   options=dict(maxiter=5000, ftol=1e-13, gtol=1e-9))
    beta = res.x
    # polish with a few Newton steps for an accurate mode (needed for a faithful Hessian)
    for _ in range(25):
        H = observed_information(beta, X, y, offset, lam)
        g = grad(beta, X, y, offset, lam)
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        beta = beta - step
        if np.max(np.abs(step)) < 1e-10:
            break
    H = observed_information(beta, X, y, offset, lam)
    cov = np.linalg.inv(H)
    return beta, cov, dict(converged=bool(res.success), nll=float(neg_log_post(beta, X, y, offset, lam)),
                           maxgrad=float(np.max(np.abs(grad(beta, X, y, offset, lam)))))


def predict_p(beta, X, offset):
    eta = np.asarray(offset) + np.asarray(X) @ beta
    return _mu_p(eta)[1]


def draws(beta, cov, n, rng):
    L = np.linalg.cholesky(cov + 1e-12 * np.eye(len(beta)))
    return beta[None, :] + rng.standard_normal((n, len(beta))) @ L.T
