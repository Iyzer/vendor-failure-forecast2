"""
Week 10 step 3 -- export the fitted model and the 2026 scoring rows as one compact JSON for the app.

The app recomputes every prediction in the browser from the exported coefficients and posterior covariance
(eta = x'beta, Var(eta) = x'Sigma x), so a what-if edit re-scores instantly and the numbers can be checked against
Python. This script also writes parity cases (inputs -> Python outputs) that the QA step replays in the browser.

Output: data/app_data.json
"""
import json
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glm_cloglog as G
from modeling_common import *

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "..", "data")
P = json.load(open(os.path.join(D, "model_params.json")))
E = json.load(open(os.path.join(D, "model_eval.json")))
src = lambda n: pd.read_csv(os.path.join(D, "source", n))

CAT_LABEL = {"produce": "Produce", "protein": "Protein", "dairy_bakery": "Dairy & bakery", "nonalc_beverage": "Non-alcoholic beverage",
             "linen_laundry": "Linen & laundry", "guest_amenities": "Guest amenities", "mro": "MRO supplies"}
beta = np.array(P["beta"])
cov = np.array(P["cov"])
names = P["names"]
vendors = P["vendors"]
feats = P["feats"]
scaler = P["scaler"]
zcap = {c: v["delta"] for c, v in P.get("zero_event_cap", {}).items()}      # categories with no observed failures: upper tail clipped

dim_v = src("dim_vendor.csv").set_index("vendor_id")
sc = pd.read_csv(os.path.join(D, "scoring_table_2026.csv"))
cal = src("dim_calendar_week.csv").sort_values("week_start_monday").reset_index(drop=True)
cal["t"] = np.arange(len(cal))
fail = src("fact_failure_event.csv").merge(cal[["week_id", "t"]], on="week_id")
fail["total_cost"] = fail[["emergency_premium", "lost_contribution_margin", "guest_compensation", "firefighting_labor"]].sum(axis=1)
realized = fail.groupby(["vendor_id", "t"]).total_cost.sum()
dev = pd.read_csv(os.path.join(D, "model_table.csv"))
dev = dev[dev.data_split == "dev"]

weeks = sc.drop_duplicates("week_id").sort_values("t")
week_ids = weeks.week_id.tolist()
W = len(week_ids)
V = len(vendors)
assert len(sc) == W * V

sc["wi"] = sc.week_id.map({w: i for i, w in enumerate(week_ids)})
sc["vi"] = sc.vendor_id.map({v: i for i, v in enumerate(vendors)})
sc = sc.sort_values(["wi", "vi"]).reset_index(drop=True)
sc["next_cost"] = [realized.get((v, t + 1), 0.0) for v, t in zip(sc.vendor_id, sc.t)]
last_t = int(sc.t.max())


def arr(col, nd=4, null_if=None):
    out = []
    for v, ok in zip(sc[col], sc.scored_flag):
        if null_if == "unscored" and not ok:
            out.append(None)
        elif pd.isna(v):
            out.append(None)
        else:
            out.append(round(float(v), nd))
    return out


out = dict(
    meta=dict(title="Vendor Failure Forecast", seed=P["seed"], dev_period="2023-W01 to 2025-W52", holdout_period="2026-W01 to 2026-W53",
              n_dev=E["n_dev"], n_val=E["n_val"], pos_dev=E["pos_dev"], pos_val=E["pos_val"],
              note="All data is synthetic (generator with declared 2026 parameter shift). Results describe the method, not real hotel performance."),
    cats=CATS, cat_labels=[CAT_LABEL[c] for c in CATS],
    lead=[int(src("dim_category.csv").set_index("category_id").loc[c, "qualification_lead_time_weeks"]) for c in CATS],
    model=dict(names=names, beta=[round(b, 6) for b in beta], cov=[[round(x, 7) for x in row] for row in cov],
               scaler=scaler, feats=feats, vendor_prior_sd=P["vendor_prior_sd"], zero_cap={c: round(d, 6) for c, d in zcap.items()}),
    cost=dict(beta=[round(x, 3) for x in P["cost_model"]["beta"]], cov=[[round(x, 3) for x in r] for r in P["cost_model"]["cov"]],
              ratio_q=P["cost_model"]["ratio_q"], mean_events=E["cost_eval"]["mean_events_per_failing_week"]),
    vendors=[dict(id=v, name=dim_v.loc[v, "vendor_name"].replace(" Vendor", ""), cat=CATS.index(dim_v.loc[v, "category_id"]),
                  size=dim_v.loc[v, "size_band"], local=bool(dim_v.loc[v, "local_flag"])) for v in vendors],
    weeks=[dict(id=r.week_id, t=int(r.t), season=r.season_label, occ=round(float(r.occupancy_rate), 4), banq=int(bool(r.banquet_flag)),
                k=int(r.review_capacity_k), start=str(src("dim_calendar_week.csv").set_index("week_id").loc[r.week_id, "week_start_monday"]),
                w53=bool(src("dim_calendar_week.csv").set_index("week_id").loc[r.week_id, "is_week_53"])) for r in weeks.itertuples()],
    rows=dict(scored=[int(x) for x in sc.scored_flag], expo=arr("exposure_wk", 5, "unscored"), rej4=arr("rej_4wk", 4, "unscored"),
              rej13=arr("rej_13wk", 4, "unscored"), cap=[int(x) for x in sc.open_cap],
              y=[None if (pd.isna(y) or t == last_t) else int(y) for y, t in zip(sc.y, sc.t)],
              cost=[None if t == last_t else round(float(c), 0) for c, t in zip(sc.next_cost, sc.t)]),
    ranges={},
)
for c in CATS:
    g = dev[dev.category_id == c]
    out["ranges"][c] = dict(expo=[round(float(g.exposure_wk.quantile(.01)), 2), round(float(g.exposure_wk.quantile(.99)), 2)],
                            rej4=[0.0, round(float(g.rej_4wk.quantile(.99)), 3)], rej13=[0.0, round(float(g.rej_13wk.quantile(.99)), 3)],
                            expo_med=round(float(g.exposure_wk.median()), 2), n=int(len(g)))

# ----------------------------------------------------------------- a typical-vendor table by category (CI via x'Sigma x)
sd_idx = {n: i for i, n in enumerate(names)}


def xvec(cat, vendor, log_exp, rej4, rej13):
    x = np.zeros(len(names))
    x[0] = 1
    x[sd_idx["cat:" + cat]] = 1
    if vendor is not None:
        x[sd_idx["v:" + vendor]] = 1
    for f, val in (("log_exposure", log_exp), ("rej_4wk", rej4), ("rej_13wk", rej13)):
        x[sd_idx[f]] = (val - scaler[f][0]) / scaler[f][1]
    return x


typ = []
for c in CATS:
    g = dev[dev.category_id == c]
    x = xvec(c, None, float(np.log(g.exposure_wk.median())), float(g.rej_4wk.mean()), float(g.rej_13wk.mean()))
    eta, se = float(x @ beta), float(np.sqrt(x @ cov @ x))
    f = lambda e: float(-np.expm1(-np.exp(e)))
    eta_hi = min(eta + 1.96 * se, eta + zcap[c]) if c in zcap else eta + 1.96 * se
    typ.append(dict(cat=c, label=CAT_LABEL[c], p=f(eta), lo=f(eta - 1.96 * se), hi=f(eta_hi), obs=float(g.y.mean()),
                    n=int(len(g)), fails=int(g.y.sum()), expo=float(g.exposure_wk.median())))
# effects per interpretable unit
effects = []
j = sd_idx["log_exposure"]
sd = scaler["log_exposure"][1]
effects.append(dict(key="elasticity", label="Deliveries per week: +10%", est=float(np.exp(beta[j] / sd * np.log(1.10))),
                    lo=float(np.exp((beta[j] - 1.96 * np.sqrt(cov[j, j])) / sd * np.log(1.10))),
                    hi=float(np.exp((beta[j] + 1.96 * np.sqrt(cov[j, j])) / sd * np.log(1.10))), kind="hazard ratio",
                    note="If failures were proportional to deliveries this would be 1.10."))
for key, lab, unit in (("rej_4wk", "Rejection rate, last 4 weeks: +5 points", 0.05), ("rej_13wk", "Rejection rate, last 13 weeks: +5 points", 0.05)):
    j = sd_idx[key]
    sd = scaler[key][1]
    se_ = np.sqrt(cov[j, j])
    effects.append(dict(key=key, label=lab, est=float(np.exp(beta[j] / sd * unit)), lo=float(np.exp((beta[j] - 1.96 * se_) / sd * unit)),
                        hi=float(np.exp((beta[j] + 1.96 * se_) / sd * unit)), kind="hazard ratio", note=""))
out["typical"] = typ
out["effects"] = effects

# ----------------------------------------------------------------- slim evaluation payload
keep_eval = ["n_dev", "n_val", "pos_dev", "pos_val", "structure", "offset_check", "screen", "base_cv", "chosen", "vendor_effect_sd", "cost_eval",
             "holdout", "bench", "gbm_cv", "capture", "addressable_share", "weekly_counts", "weekly_count_cov80", "weekly_cost_cov80",
             "cost_total_expected", "cost_total_actual", "oe", "catdrift", "refit", "mean_k"]
out["eval"] = {k: E[k] for k in keep_eval}
out["eval"]["grid"] = E["grid"]

# ----------------------------------------------------------------- parity cases (Python truth for the browser to reproduce)
rng = np.random.default_rng(7)
cases = []
for _ in range(16):
    wi = int(rng.integers(0, W - 1))
    idx = np.where((sc.wi == wi) & (sc.scored_flag == 1) & ((sc.category_id == "mro") if _ < 2 else True))[0]     # first two cases exercise the zero-failure clip
    r = sc.iloc[int(rng.choice(idx))]
    vi = int(r.vi)
    cat = r.category_id
    expo = float(r.exposure_wk) * float(rng.choice([0.5, 1.0, 1.5, 2.0]))
    rej4 = float(np.clip(r.rej_4wk + rng.choice([0, 0.03, 0.08, -0.5]), 0, 0.5))
    rej13 = float(np.clip(r.rej_13wk + rng.choice([0, 0.02, 0.05]), 0, 0.3))
    x = xvec(cat, r.vendor_id, float(np.log(expo)), rej4, rej13)
    eta, se = float(x @ beta), float(np.sqrt(x @ cov @ x))
    p = float(-np.expm1(-np.exp(eta)))
    z = 1.2816
    eta_hi = min(eta + z * se, eta + zcap[cat]) if cat in zcap else eta + z * se
    cases.append(dict(week=wi, vendor=vi, expo=expo, rej4=rej4, rej13=rej13, eta=eta, se=se, p=p,
                      lo80=float(-np.expm1(-np.exp(eta - z * se))), hi80=float(-np.expm1(-np.exp(eta_hi)))))
out["parity"] = cases
# frozen-model predictions on the unmodified 2026 rows (JS must reproduce these)
hp = pd.read_csv(os.path.join(D, "holdout_predictions_2026.csv"))[["vendor_id", "week_id", "p"]]
out["parity_rows"] = [dict(v=r.vendor_id, w=r.week_id, p=round(float(r.p), 6)) for r in hp.sample(30, random_state=3).itertuples()]

json.dump(out, open(os.path.join(D, "app_data.json"), "w"), separators=(",", ":"))
print(f"wrote data/app_data.json  {os.path.getsize(os.path.join(D, 'app_data.json')) / 1024:.0f} KB; {W} weeks x {V} vendors; {len(cases)} parity cases")
