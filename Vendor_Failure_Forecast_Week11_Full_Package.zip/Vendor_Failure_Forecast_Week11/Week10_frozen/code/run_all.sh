#!/usr/bin/env bash
# Rebuild everything from the source tables in data/source (about 45 seconds).
# Order matters: each step reads the previous step's output.
set -euo pipefail
cd "$(dirname "$0")"
# scikit-learn's HistGradientBoostingClassifier splits work across OpenMP threads, and the
# binning/split-finding is not thread-count stable: the benchmark's AUC moved in the third
# decimal between runs on the same seed. Pinning to one thread makes the whole pipeline
# reproducible. The main model was already exact to 16 significant figures without it.
export OMP_NUM_THREADS=1
python3 10_build_model_table.py      # as-of-Monday model table + data validation  -> data/model_table.csv, docs/data_validation_wk10.txt
python3 11_fit_and_evaluate.py       # fit on 2023-2025, evaluate once on 2026       -> data/model_params.json, model_eval.json, holdout_predictions_2026.csv, docs/model_report_wk10.txt
python3 12_export_app_data.py        # compact JSON for the app + parity cases      -> data/app_data.json
python3 14_add_explanations.py      # per-prediction explanation baseline (exact Shapley) -> adds "explain" to data/app_data.json
python3 13_build_app.py              # assemble the single-file app                  -> app/index.html
echo "done"
