"""
Week 10 step 1 -- build and VALIDATE the model-ready table from the validated Weeks 7-8 tables.

Input  : data/source/*.csv  (copies of the validated Weeks 7-8 dataset; nothing regenerated)
Output : data/model_table.csv  (one row per scored vendor-week, as-of features + realised target)
         docs/data_validation_wk10.txt  (every check below, with PASS/FAIL and the numbers)

Rules enforced (project docs): W18/G26 as-of cutoff, W19/G27 missing-not-zero, W20/G29/S7 no
manager-action fields as predictors, S6/S20 oracle table never touched, W26 target definition
not broadened, W29 week-53 explicitly handled (no target exists for it).
"""
import os
import sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "data", "source")
OUT = os.path.join(HERE, "..", "data", "model_table.csv")
LOG = os.path.join(HERE, "..", "docs", "data_validation_wk10.txt")

lines = []
fails = []


def check(name, ok, detail=""):
    lines.append(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  -- {detail}" if detail else ""))
    if not ok:
        fails.append(name)


def info(msg):
    lines.append(msg)


rd = lambda n: pd.read_csv(os.path.join(SRC, n))
snap, cal, vend, cat = rd("snap_vendor_week.csv"), rd("dim_calendar_week.csv"), rd("dim_vendor.csv"), rd("dim_category.csv")
fail, dem = rd("fact_failure_event.csv"), rd("fact_demand_week.csv")

info("WEEK 10 DATA VALIDATION LOG")
info("=" * 78)
check("oracle_vendor_week is not among the inputs (S6/S20)",
      not any("oracle" in f for f in os.listdir(SRC)), f"inputs: {sorted(os.listdir(SRC))}")

# ---------------------------------------------------------------- week index (single source of truth: dim_calendar_week, S8)
cal = cal.sort_values("week_start_monday").reset_index(drop=True)
cal["t"] = np.arange(len(cal))
check("calendar weeks are consecutive Mondays", (pd.to_datetime(cal.week_start_monday).diff().dropna().dt.days == 7).all(),
      f"{len(cal)} weeks, {cal.week_id.iloc[0]} .. {cal.week_id.iloc[-1]}")
check("exactly one week-53 row, in 2026", cal.is_week_53.sum() == 1 and cal[cal.is_week_53].iso_year.iloc[0] == 2026)
tmap = cal.set_index("week_id").t

snap = snap.merge(cal[["week_id", "t", "iso_year", "week_start_monday", "season_label", "data_split", "is_week_53"]], on="week_id")
snap = snap.merge(vend[["vendor_id", "size_band", "local_flag"]], on="vendor_id")
check("snap_vendor_week has one row per vendor-week", not snap.duplicated(["vendor_id", "week_id"]).any(),
      f"{len(snap)} rows = {snap.vendor_id.nunique()} vendors x {snap.week_id.nunique()} weeks")
check("as_of_cutoff equals the Monday of the row's week (W18)",
      (pd.to_datetime(snap.as_of_cutoff) == pd.to_datetime(snap.week_start_monday)).all())

# ---------------------------------------------------------------- target alignment (empirical: target week = t + 1)
fail["t"] = fail.week_id.map(tmap)
fe = set(zip(fail.vendor_id, fail.t))
lab = snap.dropna(subset=["material_failure_next_week"])
hit = np.array([(v, t + 1) in fe for v, t in zip(lab.vendor_id, lab.t)])
check("target == 'a material failure event exists for this vendor in week t+1' (all labelled rows)",
      (hit == lab.material_failure_next_week.astype(bool).values).all(), f"{len(lab)} labelled rows")
check("week-53 rows have no target (no t+1 exists) and are excluded from fit/eval (W29)",
      snap[snap.is_week_53].material_failure_next_week.isna().all() and snap[~snap.is_week_53].material_failure_next_week.notna().all())
snap["y"] = snap.material_failure_next_week.astype(float)

# ---------------------------------------------------------------- as-of failure-history features: only weeks <= t-1 (before Monday t)
fcount = fail.groupby(["vendor_id", "t"]).size().rename("n").reset_index()
T = len(cal)
idx = {v: i for i, v in enumerate(sorted(snap.vendor_id.unique()))}
M = np.zeros((len(idx), T + 1), float)
for v, t, n in fcount.itertuples(index=False):
    M[idx[v], t] += n
cs = np.concatenate([np.zeros((len(idx), 1)), np.cumsum(M, axis=1)], axis=1)   # cs[:, k] = sum of weeks < k


def window(v, t, w):                                   # failures in weeks [t-w, t-1]
    r = idx[v]
    return cs[r, t] - cs[r, max(t - w, 0)]


snap["fail_13wk"] = [window(v, t, 13) for v, t in zip(snap.vendor_id, snap.t)]
snap["fail_52wk"] = [window(v, t, 52) for v, t in zip(snap.vendor_id, snap.t)]
snap = snap.sort_values(["vendor_id", "t"]).reset_index(drop=True)
fts = fail.groupby("vendor_id").t.apply(lambda s: np.sort(s.unique())).to_dict()
since = []
for v, t in zip(snap.vendor_id, snap.t):
    a = fts.get(v, np.array([], int))
    prior = a[a <= t - 1]
    since.append(min(t - prior[-1], 104) if len(prior) else 104)
snap["wks_since_fail"] = since

# leakage proof: shifting the cutoff must change the counts only through events strictly before week t
probe = snap.sample(400, random_state=1)
ok = True
for v, t, c13 in zip(probe.vendor_id, probe.t, probe.fail_13wk):
    direct = ((fail.vendor_id == v) & (fail.t >= t - 13) & (fail.t <= t - 1)).sum()
    ok &= (direct == c13)
check("fail_13wk recomputed independently for 400 random rows (events from weeks t-13..t-1 only; none from week t or later)", ok)
# a second, stricter probe: the feature must be unchanged if every event at week >= t is deleted
ok2 = True
for v, t, c52 in zip(probe.vendor_id, probe.t, probe.fail_52wk):
    past = fail[(fail.vendor_id == v) & (fail.t <= t - 1)]
    ok2 &= (((past.t >= t - 52)).sum() == c52)
check("fail_52wk unchanged when all events at week >= t are removed (as-of rule W18/G26)", ok2)

# ---------------------------------------------------------------- missing-vs-zero (W19/G27) and exposure
snap["exposure_wk"] = snap.trailing_13wk_delivery_count / 13.0
snap["log_exposure"] = np.log(snap.exposure_wk.where(snap.exposure_wk > 0))
no_hist = snap.trailing_13wk_delivery_count == 0
check("rows with zero 13-week deliveries have null trailing rates, never zeros (W19)",
      snap.loc[no_hist, ["trailing_13wk_on_time_rate", "trailing_13wk_fill_rate", "trailing_13wk_rejection_rate"]].isna().all().all(),
      f"{int(no_hist.sum())} unscorable vendor-weeks")
check("rows with deliveries have non-null 13-week rates",
      snap.loc[~no_hist, ["trailing_13wk_on_time_rate", "trailing_13wk_fill_rate", "trailing_13wk_rejection_rate"]].notna().all().all())
for c in ["trailing_4wk_rejection_rate", "trailing_13wk_rejection_rate", "trailing_4wk_on_time_rate", "trailing_13wk_fill_rate"]:
    v = snap[c].dropna()
    check(f"{c} within [0,1]", v.between(0, 1).all(), f"min={v.min():.3f} max={v.max():.3f}")
check("trailing delivery counts are non-negative integers", (snap.trailing_13wk_delivery_count >= 0).all())

# demand context
snap = snap.merge(dem[["week_id", "fb_covers", "banquet_covers"]], on="week_id", how="left")
check("every vendor-week joins to exactly one demand row", snap.fb_covers.notna().all())

# fill/impute rules (deterministic, documented): short windows fall back to the 13-week value, plus a flag
for w, base in [("4wk", "13wk")]:
    for m in ["rejection_rate", "on_time_rate", "fill_rate"]:
        snap[f"miss_{w}_{m}"] = snap[f"trailing_{w}_{m}"].isna()
snap["rej_4wk"] = snap.trailing_4wk_rejection_rate.fillna(snap.trailing_13wk_rejection_rate)
snap["rej_13wk"] = snap.trailing_13wk_rejection_rate
snap["late_13wk"] = 1 - snap.trailing_13wk_on_time_rate
snap["short_13wk"] = 1 - snap.trailing_13wk_fill_rate
snap["late_4wk"] = (1 - snap.trailing_4wk_on_time_rate).fillna(snap.late_13wk)
snap["short_4wk"] = (1 - snap.trailing_4wk_fill_rate).fillna(snap.short_13wk)
snap["no_delivery_4wk"] = (snap.trailing_4wk_delivery_count == 0).astype(int)

# manager-action field is carried ONLY for the stated ablation, never as a default predictor (W20/G29/S7)
snap["open_cap"] = snap.open_corrective_action_flag.astype(int)

scored = snap[(snap.trailing_13wk_delivery_count > 0) & snap.y.notna()].copy()
info("")
info(f"Scored vendor-weeks (>=1 delivery in 13 wks AND a label exists): {len(scored)}")
info(f"Excluded: {int(no_hist.sum())} with no 13-week deliveries (flagged 'insufficient data', never scored as 0 or 1), "
     f"{int(snap.y.isna().sum())} week-53 rows without a target (some overlap)")
for sp, g in scored.groupby("data_split"):
    info(f"  {sp:16s} rows={len(g):5d}  positives={int(g.y.sum()):4d}  base rate={g.y.mean():.4f}")
base = scored.groupby("data_split").y.mean()
check("base rate in the roughly 4-6% range the project's W26 rule expects (not broadened to manufacture positives)",
      all(0.03 <= v <= 0.07 for v in base), f"dev={base['dev']:.4f} 2026={base['validation_2026']:.4f}")
check("temporal split: every dev week precedes every 2026 week",
      cal[cal.data_split == "dev"].t.max() < cal[cal.data_split == "validation_2026"].t.min())
check("MRO has zero observed failures (so its rate cannot be learned from failures; handled by shrinkage)",
      scored[scored.category_id == "mro"].y.sum() == 0, f"{int((scored.category_id == 'mro').sum())} MRO vendor-weeks")
check("fact_failure_event cost components are non-negative", (fail[["emergency_premium", "lost_contribution_margin", "guest_compensation", "firefighting_labor"]] >= 0).all().all())

keep = ["vendor_id", "week_id", "t", "iso_year", "data_split", "season_label", "category_id", "department_id", "size_band", "local_flag",
        "occupancy_rate", "banquet_flag", "review_capacity_k", "exposure_wk", "log_exposure", "trailing_13wk_delivery_count", "trailing_4wk_delivery_count",
        "rej_4wk", "rej_13wk", "late_4wk", "late_13wk", "short_4wk", "short_13wk", "no_delivery_4wk",
        "fail_13wk", "fail_52wk", "wks_since_fail", "open_cap", "y"]
scored[keep].to_csv(OUT, index=False)
# every 2026 vendor-week (incl. week 53 and rows that cannot be scored) for the app's what-if / queue screens
snap["scored_flag"] = (snap.trailing_13wk_delivery_count > 0).astype(int)
snap[snap.data_split == "validation_2026"][keep + ["scored_flag"]].to_csv(OUT.replace("model_table", "scoring_table_2026"), index=False)
info("")
info(f"wrote data/model_table.csv  ({len(scored)} rows, {len(keep)} columns)")
info("")
info("RESULT: " + ("ALL CHECKS PASSED" if not fails else f"{len(fails)} FAILED: {fails}"))
os.makedirs(os.path.dirname(LOG), exist_ok=True)
open(LOG, "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
sys.exit(1 if fails else 0)
