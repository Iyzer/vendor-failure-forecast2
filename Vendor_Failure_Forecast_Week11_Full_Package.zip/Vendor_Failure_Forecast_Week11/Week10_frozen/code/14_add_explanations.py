"""
Week 10 step 5 -- per-prediction explanation baseline.

Adds to data/app_data.json the constants the app needs to decompose a single
vendor-week forecast into per-predictor contributions.

WHY AN EXACT DECOMPOSITION RATHER THAN SAMPLED SHAP
---------------------------------------------------
The forecast is a complementary log-log GLM, so it is LINEAR in the link
(log-hazard) scale:

    eta = b0 + b_cat + b_vendor + b_expo*z_expo + b_rej4*z_rej4 + b_rej13*z_rej13

For a model linear in its link, the Shapley value of feature j against a
background distribution is exactly

    phi_j = b_j * (x_j - E[x_j])

-- no sampling, no kernel approximation, no background-set choice to defend.
11_fit_and_evaluate.py standardises each continuous feature on the DEVELOPMENT
mean and sd, so E[z_j] = 0 over the training data and phi_j is simply b_j * z_j.
This script verifies that (it is a property of how the scaler was fitted, not an
assumption) and computes the two remaining pieces:

  * the frequency-weighted mean category effect over the development rows
  * the frequency-weighted mean vendor effect over the same rows

The baseline is then "an average vendor-week in the training data":

    eta_base = b0 + mean_cat_effect + mean_vendor_effect      (continuous at z = 0)

and the contributions are

    category        b_cat(this)     - mean_cat_effect
    vendor identity b_vendor(this)  - mean_vendor_effect
    deliveries      b_expo  * z_expo
    rejections 4wk  b_rej4  * z_rej4
    rejections 13wk b_rej13 * z_rej13

which sum EXACTLY to eta - eta_base. The script asserts that over every scored
row rather than trusting the algebra.

Contributions are additive on the log-hazard scale only. The app converts them to
probabilities as a cumulative walk from the baseline, states the order it used,
and never presents the probability steps as if they were additive.

Inputs : data/app_data.json, data/model_params.json, data/model_table.csv
Output : data/app_data.json  (adds an "explain" block; nothing else is changed)
"""
import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")

app = json.load(open(os.path.join(DATA, "app_data.json")))
par = json.load(open(os.path.join(DATA, "model_params.json")))
tab = pd.read_csv(os.path.join(DATA, "model_table.csv"))

names = par["names"]
beta = np.asarray(par["beta"], dtype=float)
idx = {n: i for i, n in enumerate(names)}
scaler = par["scaler"]

dev = tab[tab["data_split"] == "dev"].copy()
dev = dev[dev["exposure_wk"].notna()]

# ---- 1. confirm the standardisation really is centred on the development mean
dev["log_exposure"] = np.log(np.maximum(dev["exposure_wk"], 1e-3))
for feat, col in [("log_exposure", "log_exposure"), ("rej_4wk", "rej_4wk"), ("rej_13wk", "rej_13wk")]:
    centre, scale = scaler[feat]
    assert abs(centre - dev[col].mean()) < 1e-9, (
        f"{feat}: scaler centre {centre} is not the development mean {dev[col].mean()}; "
        "b_j * z_j would then NOT be the exact Shapley value and this script's claim would be wrong"
    )

# ---- 2. frequency-weighted mean category and vendor effects over development rows
cat_of = {v["id"]: app["cats"][v["cat"]] for v in app["vendors"]}
dev_cat = dev["vendor_id"].map(cat_of)
cat_share = dev_cat.value_counts(normalize=True)
mean_cat = float(sum(share * beta[idx["cat:" + c]] for c, share in cat_share.items()))

ven_share = dev["vendor_id"].value_counts(normalize=True)
mean_ven = float(sum(
    share * (beta[idx["v:" + v]] if ("v:" + v) in idx else 0.0)
    for v, share in ven_share.items()
))

eta_base = float(beta[idx["intercept"]] + mean_cat + mean_ven)

# ---- 3. assert the decomposition is exact on every scored development row
zf = lambda f, v: (v - scaler[f][0]) / scaler[f][1]
worst = 0.0
for _, r in dev.iterrows():
    vid = r["vendor_id"]
    c = cat_of[vid]
    eta = (beta[idx["intercept"]]
           + beta[idx["cat:" + c]]
           + (beta[idx["v:" + vid]] if ("v:" + vid) in idx else 0.0)
           + beta[idx["log_exposure"]] * zf("log_exposure", r["log_exposure"])
           + beta[idx["rej_4wk"]] * zf("rej_4wk", r["rej_4wk"])
           + beta[idx["rej_13wk"]] * zf("rej_13wk", r["rej_13wk"]))
    contrib = (
        (beta[idx["cat:" + c]] - mean_cat)
        + ((beta[idx["v:" + vid]] if ("v:" + vid) in idx else 0.0) - mean_ven)
        + beta[idx["log_exposure"]] * zf("log_exposure", r["log_exposure"])
        + beta[idx["rej_4wk"]] * zf("rej_4wk", r["rej_4wk"])
        + beta[idx["rej_13wk"]] * zf("rej_13wk", r["rej_13wk"])
    )
    worst = max(worst, abs((eta_base + contrib) - eta))
assert worst < 1e-10, f"decomposition does not close: worst residual {worst}"

# ---- 4. overall importance, for the panel that sits BESIDE the per-prediction one.
# Mean absolute contribution over the development rows: the standard global
# summary of a per-prediction attribution, and deliberately a DIFFERENT quantity
# from the effect-size panel the app already shows (which is the effect of a
# typical CHANGE in each input, not how much each input moves real forecasts).
imp = {}
for feat, col in [("log_exposure", "log_exposure"), ("rej_4wk", "rej_4wk"), ("rej_13wk", "rej_13wk")]:
    imp[feat] = float(np.mean(np.abs(beta[idx[feat]] * zf(feat, dev[col].values))))
imp["category"] = float(np.mean(np.abs(
    np.array([beta[idx["cat:" + c]] for c in dev_cat]) - mean_cat)))
imp["vendor"] = float(np.mean(np.abs(
    np.array([(beta[idx["v:" + v]] if ("v:" + v) in idx else 0.0) for v in dev["vendor_id"]]) - mean_ven)))

app["explain"] = dict(
    eta_base=eta_base,
    mean_cat=mean_cat,
    mean_ven=mean_ven,
    importance=imp,
    n_dev_rows=int(len(dev)),
    note=("Contributions are exact Shapley values on the log-hazard scale: the model is "
          "linear in its link, so phi_j = beta_j * (x_j - mean_j) with no approximation. "
          "The baseline is an average development-period vendor-week."),
)

json.dump(app, open(os.path.join(DATA, "app_data.json"), "w"), separators=(",", ":"))

print(f"baseline log-hazard {eta_base:.4f}  ->  baseline chance {(-np.expm1(-np.exp(eta_base))) * 100:.2f}%")
print(f"decomposition closes on all {len(dev)} development rows (worst residual {worst:.2e})")
print("mean |contribution| on the log-hazard scale:")
for k, v in sorted(imp.items(), key=lambda kv: -kv[1]):
    print(f"   {k:14s} {v:.4f}")
