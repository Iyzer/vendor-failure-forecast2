"""
Week 10 step 4 -- assemble the single-file app.

Inputs : app/src/style.css, body.html, 01_core.js .. 05_main.js, data/app_data.json
Outputs: app/index.html          standalone page (open in any browser, works offline except the web font)
         app/artifact_page.html  the same page without doctype/html/head/body, for publishing as a hosted artifact
Everything (data, model, charts) is inline: the page needs no server and makes no network calls except the optional font.
"""
import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "app", "src")
OUT = os.path.join(HERE, "..", "app")
rd = lambda p: open(p, encoding="utf-8").read()

css = rd(os.path.join(SRC, "style.css"))
body = rd(os.path.join(SRC, "body.html"))
js = "\n".join(rd(p) for p in sorted(glob.glob(os.path.join(SRC, "0*.js"))))
data = json.dumps(json.load(open(os.path.join(HERE, "..", "data", "app_data.json"))), separators=(",", ":")).replace("<", "\\u003c")

FONT = '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&display=swap">'
head = f'''<title>Vendor Failure Forecast</title>
<meta name="claude:viewport-fit-sides" content="cover">
{FONT}
<style>
{css}
</style>
'''
content = f'''{head}
{body}
<script type="application/json" id="app-data">{data}</script>
<script>
{js}
</script>
'''
open(os.path.join(OUT, "artifact_page.html"), "w", encoding="utf-8").write(content)
standalone = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
{head}</head>
<body>
{body}
<script type="application/json" id="app-data">{data}</script>
<script>
{js}
</script>
</body>
</html>
'''
open(os.path.join(OUT, "index.html"), "w", encoding="utf-8").write(standalone)
for n in ("index.html", "artifact_page.html"):
    print(f"{n}: {os.path.getsize(os.path.join(OUT, n)) / 1024:.0f} KB")
