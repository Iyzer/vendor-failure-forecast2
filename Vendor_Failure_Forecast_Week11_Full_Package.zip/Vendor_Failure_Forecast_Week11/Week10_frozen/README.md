# Week 10: Implementation — Vendor Failure Forecast

Vendor Risk and Corrective-Action Prioritization Tool for a synthetic independent seasonal resort's Purchasing & Receiving Manager.
Team: Mirza Ali and Debra Senteu. MS Analytics, Saint Louis University. Due Mon 26 Oct 2026, 11:59 pm.

## Open it

- **The app:** open `app/index.html` in any browser. It is one self-contained file (data, model and charts inline) and works offline; only the optional web font needs a network.
- **Hosted copy:** https://claude.ai/artifact/6d12QCujNoGf9ZGURscABB — private to its owner until shared from the page's Share menu, so teammates and the instructor cannot open it yet. `app/index.html` is the copy to use.
- **Shared repository / folder:** *(link to be added by the team before submission)*
- **Industry brief (future risks, practitioner voices, likely reactions):** https://claude.ai/code/artifact/d8e26ae7-f252-4aa7-9687-de37916f598a

## What is in the folder

| Path | What it is |
|---|---|
| `report/Week10_One_Page_Report.docx` and `.pdf` | Submission item 3: one page justifying the modelling approach and explaining how performance and what-if uncertainty support the decision |
| `video/Week10_Video_Script.md` | Submission item 4: timed two-minute script for the team to narrate, with a checklist and a numbers cheat sheet |
| `video/Week10_Demo_Screen_Capture.mp4` | Silent, captioned 120-second screen walkthrough that follows the script; use it as the recording or as a pacing guide |
| `app/index.html` | The three screens: Model performance, What-if forecast, Weekly review list (`app/src/` holds the editable source) |
| `code/` | Data processing, validation, model, evaluation, explanation baseline (`14_add_explanations.py`), app export and build (`run_all.sh` runs them in order) |
| `data/source/` | Submission item 2: the synthetic source tables (vendors, categories, calendar, demand, deliveries snapshot, failure events, corrective actions) |
| `data/` | Derived tables, fitted model (`model_params.json`), evaluation (`model_eval.json`), 2026 holdout predictions |
| `docs/Week10_KPIs_and_Progress.md` | Assignment items 1, 2(a), 3(a), 3(b) and 4: the two KPIs and their justification, predictors per KPI, predictor importance and per-prediction contributions, progress report and contributions |
| `docs/data_validation_wk10.txt` | Data validation log: all checks pass |
| `docs/model_report_wk10.txt` | Full model and evaluation log |
| `qa/` | Browser tests (JavaScript against Python parity, console errors, interactions) and screenshots at desktop, phone and dark theme |
| `research/` | Four research notes behind the report and the industry brief, with source registers and confidence labels |

## Rebuild

Needs Python 3.10+ with the packages in `requirements.txt` (versions this was tested with are in `requirements-tested.txt`). Run `bash code/run_all.sh` (about 40 seconds). Repeated runs from a clean copy on the same machine produce all derived files byte-identical, `app/index.html` included. `run_all.sh` pins `OMP_NUM_THREADS=1` so the threaded gradient-boosting benchmark cannot vary with core count. Across scikit-learn builds the benchmark's figures can still differ: 1.9.1 gives AUC 0.742 and 41.4% cost capture, an earlier 1.8.0 run gave 0.743 and 43.0%. The main model was unaffected in every build; its coefficients agree to 16 significant figures. The browser tests in `qa/` need Node with Playwright and Chromium and are optional.

## How it meets the assignment

| Requirement | Where |
|---|---|
| Decision-maker need a predictive model can address | Each Monday, which vendors to review next week and which to start qualifying alternates for, ranked by expected cost under a review capacity of about 4 (peak) to 12 (off-peak) vendors |
| Screen showing model outputs and predictive performance | Model performance tab: capture of failure cost against today's rules and four baselines, reliability chart, forecast against actual per week, drift monitor, effect sizes, benchmark table, limits |
| Predictor importance, overall | Model performance tab: mean absolute contribution of each input across the 6,978 training vendor-weeks |
| Predictor contributions, one prediction | What-if tab: the forecast on screen decomposed into per-input contributions, walked from an average training vendor-week to this one. Exact Shapley values — the model is linear in its link, so no sampling or kernel approximation is involved |
| Automatic scenario summary | What-if tab: regenerated on every input change, covering the scenario, the updated forecast, the change against the baseline, what it means for the review list, and the limits |
| What-if analysis | What-if tab: change deliveries per week, 4- and 13-week rejection rates, an all-vendor failure-rate shift and cost of a failure; the model re-predicts in the browser |
| Uncertainty of predictions | 50/80/95% intervals on the failure chance, the multi-week chance, expected cost and both sensitivity charts; out-of-range inputs are flagged; Weekly list shows rank stability over 600 draws and a hindsight check |
| Code, data, validation | `code/`, `data/source/`, `docs/data_validation_wk10.txt` |
| One-page report | `report/` |
| Two-minute video | `video/` (script and silent captioned capture; the team adds narration) |

## Model in one paragraph

Binomial regression with a complementary log-log link, category effects and vendor random intercepts with ridge shrinkage (partial pooling), fitted on 2023-2025 and scored once on the 2026 holdout. Inputs are as of Monday only: deliveries per week, 4-week rejection rate, 13-week rejection rate. The delivery-volume coefficient is estimated, not fixed: a proportional offset was tested and rejected (estimated elasticity 0.30, 95% interval 0.01 to 0.59). Intervals come from the Laplace posterior; categories with no recorded failures (MRO) get an exact Poisson upper limit instead of a Gaussian tail. The manager's own past actions and open corrective actions are excluded from predictors.

## Key results, 2026 holdout (model frozen on 2023-2025)

| Measure | Result |
|---|---|
| Share of addressable next-week failure cost inside the weekly list | Model 54.7% [95% interval 42.9, 65.7]; ranking by delivery volume 50.4%; gradient boosting 41.4%; today's on-time and fill rules 30.7%; trailing rejection rate 29.4%; random 21.3% |
| Model minus today's rules | +23.9 points [11.4, 36.6] |
| Model minus ranking by volume | +4.1 points [-2.3, +11.6], not distinguishable from zero |
| AUC | 0.749 [0.715, 0.786]; category averages alone 0.740 |
| Calibration | Observed 5.57% against 4.44% predicted per vendor-week (x1.26); slope 0.76 |
| Interval coverage, nominal 80% | Weekly failure counts 84.6%; weekly failure dollars 71.2% |

## Limits we state in the report and video

1. The data is synthetic, so results validate the method and its checks, not performance at a real resort. The 2026 shift is declared in the generator.
2. The model mostly learns category and delivery-volume structure: its Brier score ties a category-only forecast (0.0506 for both), and ranking by volume captures almost as much cost.
3. 2026 ran above forecast (failures x1.26, failure dollars x1.42); the drift monitor first left its band in week 22.
4. Weekly dollar intervals cover 71%, below the stated 80%.
5. Individual-vendor deterioration is a weak signal: about 83% of scored vendor-weeks have a perfect 13-week on-time record.

## Disclosures

- The app is a single HTML page. A Streamlit version was planned but could not be built or tested because package installation was unavailable in our build environment.
- The research notes contain no Reddit evidence (blocked) and no first-hand hotel purchasing manager discussing predictive vendor-risk tools; practitioner-reaction sections are labelled inference. Quotes passed through a summarising fetch tool and should be re-checked against the source page before reuse.
