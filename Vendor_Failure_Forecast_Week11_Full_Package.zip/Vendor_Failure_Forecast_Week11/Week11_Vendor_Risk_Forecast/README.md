# Week 11: Model Evaluation and Decision Support — Vendor Failure Forecast

Vendor Risk and Corrective-Action Prioritization Tool for a synthetic independent seasonal resort's Purchasing & Receiving Manager.
Team: Mirza Ali and Debra Senteu. MS Analytics, Saint Louis University. Week 11 is due Mon 2 Nov 2026, 11:59 pm; presentation Thu 5 Nov 2026.

**Where the Week 10 version is:** the folder `Week10_frozen/` next to this one is the Week 10 submission, unchanged. Everything in this folder is the Week 11 version.

## Open it

- **The app:** open `app/index.html` in any browser. One self-contained file (data, model and charts inline); it works offline and makes no network request: the Inter typeface (SIL Open Font License, `app/src/fonts/`) is embedded.
- **Streamlit copy:** `streamlit/` holds a small Streamlit wrapper that serves the same page (Week 11 by default; add `?version=week10` to the address to see the Week 10 page). See `streamlit/README_STREAMLIT.md`.
- **Hosted and shared copies:** *(links to be added by the team before submission: the deployed app, and the shared repository or folder with instructor access)*.

## What changed since Week 10

| Area | Change |
|---|---|
| Evaluation | New **Evaluation & limits** tab: test design, leakage table, KPI tables with baselines and verdicts, list-size chart, error analysis by segment, improvements tried, limits in plain words. |
| What-if | Inputs are whole-number counts with the recorded value beside each; every input is tagged *You can change / Fixed / Outside your control*; rules between related inputs; a clear "this scenario cannot happen" message with an "adjust to the nearest possible scenario" button; baseline-versus-scenario table with 80% intervals; a rewritten automatic summary (what changed, what the model says, trade-offs, what it does not tell you, "model-based, not proven cause"). |
| Cost estimate | The cost model is now fed next week's expected occupancy and banquet flag, matching how it was fitted (a correctness fix; accuracy is unchanged). |
| Model | **Unchanged.** Thirteen improvement candidates (two of them from Debra's screening script `code/15_select_improvements.py`) were tested on 2023–2025 only; none met the stated rules. |
| Evidence | Walk-forward evaluation (eight 13-week blocks), leakage controls, error analysis, improvement experiments: `code/20_*`, `21_*`, `22_*`, plus Debra's two-fold screen `code/15_*`; logs in `docs/`. |

## What is in the folder

| Path | What it is |
|---|---|
| `report/Week11_Evaluation_Report.docx` and `.pdf` | The evaluation report: test design, leakage check, KPIs and baselines, error analysis, improvements, limits, decision support, outside test, package |
| `video/Week11_Video_Script.md` | Seven-minute script for the team to narrate, with a checklist from the Week 9 feedback and a numbers cheat-sheet |
| `video/` (recordings) | The two silent screen recordings that follow the script are not stored in this repository because of their size; the finished narrated video is linked below |
| `usability_test/Week11_Usability_Test_Kit.docx` and `.pdf` | Protocol, task sheet, observation form, post-test questions, findings log, facilitator key. Completed forms and findings are added here after the session |
| `app/index.html` | The app (`app/src/` holds the editable source; `code/13_build_app.py` assembles it) |
| `code/` | Data processing, model, Debra's two-fold screen (15), evaluation (20), error analysis (21), improvements (22), app export and build; `run_all.sh` runs them in order |
| `data/source/` | The synthetic source tables (vendors, categories, calendar, demand, deliveries snapshot, failure events, corrective actions) |
| `data/` | Derived tables, the fitted model (`model_params.json`), Week 10 and Week 11 evaluation files (`wk11_*.json`, `wk11_dev_oof.csv`), 2026 holdout predictions |
| `docs/` | Logs written by the scripts, `CHANGELOG.md`, and the Week 10 documents |
| `qa/` | Browser tests (parity against the Python model, 32 what-if checks, console errors, app text against the result files), `wk11_docs_check.py` (README, report and video script against the result files) and a script (`wk11_visual.js`) that regenerates screenshots at desktop, phone and dark theme (the images are not stored here) |
| `research/` | Four research notes from Week 10 behind the industry brief |
| `CONTRIBUTIONS.md` | Contributions summary: a draft for the team to confirm |

## Setup and rebuild

Needs Python 3.10 or later with the packages in `requirements.txt` (the versions this was tested with are in `requirements-tested.txt`). Run `bash code/run_all.sh` (about three minutes). It rebuilds the model table, fits the model on 2023–2025, scores 2026 once, runs the Week 11 evaluation, error analysis and improvement experiments, exports the app data and assembles `app/index.html`. `run_all.sh` pins `OMP_NUM_THREADS=1` so the threaded gradient-boosting benchmark does not vary with core count. Repeated runs on the same machine give identical files.

Optional: the browser tests in `qa/` need Node with Playwright and Chromium (`node qa/check.js`, `node qa/wk11_whatif.js`, `node qa/wk11_smoke.js`, `node qa/wk11_text.js`); `python3 qa/wk11_docs_check.py` needs only Python and pandoc. The report and kit are built with `node report/build_report_w11.js` and `node usability_test/build_kit.js` (the `docx` npm package), the report figures with `python3 report/make_figures.py`.

## Key results

Decisions were made on 2023–2025 with rolling 13-week blocks. 2026 is a holdout the team had already seen in Week 10, so it is read as confirmation only.

| Measure | 2024–25 tests | 2026 (confirmation) |
|---|---|---|
| Share of next-week failure cost inside the weekly list | Model 58.3% [48.8, 67.7]; ranking by delivery volume 52.6%; today's on-time and fill rules 40.7%; random 21.7% | Model 54.7% [43.0, 66.2]; volume 50.4%; today's rules 30.6%; random 21.4% |
| Model minus today's rules | +17.6 points [+6.9, +28.6] | +24.1 points [+10.7, +36.2] |
| Model minus ranking by volume | +5.7 points [−3.0, +14.0] (not distinguishable from zero) | +4.3 points [−2.6, +12.1] |
| Failure chance: AUC and log loss | 0.789 and 0.1599 (category rate: 0.769 and 0.1623) | 0.749 and 0.1944 (category rate: 0.740 and 0.1944) |
| Calibration | Forecast 4.66% against 4.56% observed, slope 1.03 | Forecast 4.44% against 5.57% observed, slope 0.76 |
| Dollar cost of a failure, typical miss | $1,163 (plain average: $1,170) | $1,221 (plain average: $1,274) |

Verdicts against the rules set before running: the failure chance, the dollar cost and the list against the strongest simple list are **not** meaningful improvements over simple baselines; the list is a clear improvement over today's rules.

## Limits we state

1. The data is synthetic, so the results show how the method behaves, not how a real resort would perform.
2. 2026 was viewed in Week 10; it is not a clean final test. The "meaningful improvement" thresholds were written after those results were known.
3. The weekly list holds about half of next-week failure cost; reaching about 80% takes roughly two to two and a half times the usual capacity.
4. The model is not shown to beat ranking by delivery volume. Rejection rates add almost nothing.
5. Coverage is weakest for protein and dairy, in peak weeks, and for vendors under an open corrective action (held out of the list by design).
6. Dollar estimates are averages; the weekly dollar intervals covered 71% in 2026, below the stated 80%.
7. The outside test involved one person (see the report, section 8).

## How it meets the Week 11 requirements

| Requirement | Where |
|---|---|
| 1a Data split and why | Report section 1; Evaluation tab, test design |
| 1b Leakage check | Report section 1; Evaluation tab, leakage table; `code/20_wk11_evaluation.py` |
| 1c Metrics for the decision-maker | Report section 2; Evaluation tab, plain-language panel |
| 1d Baselines and verdict per KPI | Report section 3; Evaluation tab; `docs/wk11_evaluation_log.txt` |
| 1e Error analysis and implications | Report section 4; Evaluation tab; `docs/wk11_error_analysis.txt` |
| 2a–c Improvements, consistent comparison, keep or reject | Report section 5; Evaluation tab; `docs/wk11_improvements_log.txt` |
| 2d Remaining limitations | Report section 6; Evaluation tab, limits box |
| 3a Performance and limits in the manager's words | Report section 7; Evaluation tab |
| 3b Explaining one prediction | What-if tab, contributions panel |
| 3c Changeable, fixed and outside inputs | What-if tab, tags |
| 3d Input checks and invalid-scenario message | What-if tab; `qa/wk11_whatif.js` |
| 3e Baseline against scenario | What-if tab, comparison table |
| 3f Automatic summary | What-if tab, summary |
| 4 Structured test with someone outside the group | `usability_test/`; report section 8 |
| 5 Folder: app, data, setup, report, video, contributions, Week 10 copy, access | This folder, `Week10_frozen/`, `streamlit/`, `CONTRIBUTIONS.md` |

## Before submitting (checklist for the team)

- [ ] Run the outside test with the kit, copy `usability_test/results_template.json` to `usability_test/results.json`, fill it from the real session, make at least one app change that follows from it, and rebuild the report (`node report/build_report_w11.js`).
- [ ] Record the narration over the screen capture, check the loudness and that no face overlaps the screen, and add the finished video to `video/`.
- [ ] Confirm `CONTRIBUTIONS.md` (Mirza and Debra).
- [ ] Add the deployed-app and shared-repository links above, and give the instructor access.
