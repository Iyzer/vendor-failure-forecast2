# Contributions summary (draft for Mirza and Debra to confirm)

**Status: draft.** The first part is taken from records in the package (the changelog and the Week 10 progress notes). The Week 11 part is left for the team to write, because we do not know who did what outside this workspace. Please edit or delete anything that is wrong before submitting; nothing here should be submitted unless both of you agree with it.

## Week 10 (from `docs/CHANGELOG.md`)

| Member | What the record shows |
|---|---|
| Mirza Ali | First package (v1): data processing, model, evaluation, three-screen app, one-page report, video script. Third package (v3, after reviewing Debra's version): fixed the reference-vendor-week label, added the expected-cost line to the scenario summary, corrected the worked example, updated the report, README and tested requirements. |
| Debra Senteu | Second package (v2): pinned `OMP_NUM_THREADS=1`, added predictor importance, per-prediction contributions with an exactness check, automatic scenario summaries and `docs/Week10_KPIs_and_Progress.md`; rebuilt the first package and confirmed it reproduced. Week 9 video script and the question to the instructor about the volume baseline are recorded in the project notes. |

## Week 11 (to be completed by the team)

| Piece of work | Who | Notes |
|---|---|---|
| Choosing the KPIs and the evaluation design | *(team to fill in)* | |
| Evaluation, error analysis and improvement experiments (`code/20`–`22`) | *(team to fill in)* | |
| Screening script `code/15_select_improvements.py` (two-fold screen of two candidate changes) | Debra Senteu (shared with the team on 1 Nov 2026, as reported by Mirza; please confirm) | Included with one change, see `docs/CHANGELOG.md` |
| App changes: Evaluation tab, input checks, side-by-side table, summary | *(team to fill in)* | |
| Outside test: recruiting, running, writing up | *(team to fill in)* | Must be a real session; see `usability_test/` |
| Evaluation report | *(team to fill in)* | |
| Video: narration and recording | *(team to fill in)* | |
| Deployment, repository and access | *(team to fill in)* | |

## Tools

Claude (Anthropic's AI assistant) was used in this workspace to write and run code, draft the analysis and documents, and build the app and test materials. The team is responsible for checking the results and for what is submitted. *(Edit this line so it states how you actually worked, and follow your course's rules on disclosing AI assistance.)*
