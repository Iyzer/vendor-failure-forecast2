"""
Week 11 step 1 -- model evaluation for the two KPIs and the weekly decision they feed.

KPI 1  Probability that a vendor has a material failure next week.
KPI 2  Dollar cost of a failure if one happens (per failing vendor-week).
Decision  Expected cost = KPI 1 x KPI 2 ranks vendors; the manager reviews the top k each week (k = review capacity).

Evidence is produced two ways and kept apart:
  * DEVELOPMENT evidence  : rolling-origin walk-forward on 2023-2025 (eight 13-week blocks, 2024Q1..2025Q4). All design choices
                            in Week 11 are made on this evidence only.
  * 2026 confirmation     : the frozen Week 10 model scored once on 2026. 2026 was already looked at in Week 10, so it is a
                            previously viewed holdout, not a clean test (no fresh year was generated).
Outputs: data/wk11_evaluation.json, data/wk11_dev_oof.csv, docs/wk11_evaluation_log.txt
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from wk11_lib import *                     # noqa: F401,F403

OUT_JSON = os.path.join(D, "wk11_evaluation.json")
OUT_LOG = os.path.join(HERE, "..", "docs", "wk11_evaluation_log.txt")
LOG = []
rng = np.random.default_rng(SEED)
NB = 1000


def say(s=""):
    LOG.append(s)
    print(s)


L = load()
d, cal, vw, fail, dem = L["d"], L["cal"], L["vw"], L["fail"], L["dem"]
vendors = vendor_list(d)
dev = d[d.data_split == "dev"].reset_index(drop=True)
val = d[d.data_split == "validation_2026"].reset_index(drop=True)
R = {}

say("WEEK 11 MODEL EVALUATION LOG")
say("=" * 100)
say("""
DECISION RULES FOR 'MEANINGFUL IMPROVEMENT' (written before the Week 11 numbers were produced)
  Note: the Week 10 2026 results were already known to the team when these rules were written; they are therefore thresholds set
  for a fair reading, not a blind pre-registration. Every design choice is made on development data only.
  KPI 1 probability accuracy : the model beats the best simple baseline (category rate or vendor's own history) on log loss, the
                               paired 95% interval for the difference excludes zero, AND it is better in at least 6 of the 8 blocks.
  KPI 1 ranking ability      : AUC at least 0.03 above the best simple baseline with a 95% interval that excludes zero.
  KPI 2 cost estimate        : mean absolute error at least 5% lower than 'use the average past failure cost', interval excludes zero.
  Decision (top-k capture)   : at least 5 percentage points more of the next-week failure cost inside the review list than the
                               strongest simple baseline, with a paired 95% interval that excludes zero.
  2026 is read as confirmation only: same direction as development evidence = 'consistent'; otherwise 'not confirmed'.""")

# ============================================================================================ 1a. data split
say("\n" + "=" * 100 + "\n1a. DATA SPLIT")
n_dev_w, n_val_w = dev.t.nunique(), val.t.nunique()
R["split"] = dict(dev_rows=len(dev), dev_weeks=int(n_dev_w), dev_fail_rows=int(dev.y.sum()), dev_rate=float(dev.y.mean()),
                  val_rows=len(val), val_weeks=int(n_val_w), val_fail_rows=int(val.y.sum()), val_rate=float(val.y.mean()),
                  dev_events=int((fail.data_split == "dev").sum()), val_events=int((fail.data_split == "validation_2026").sum()),
                  dev_fail_vendor_weeks=int((vw.data_split == "dev").sum()), val_fail_vendor_weeks=int((vw.data_split == "validation_2026").sum()))
say(f"  Development 2023-2025 : {len(dev)} scored vendor-weeks, {n_dev_w} weeks, {int(dev.y.sum())} failure-rows ({dev.y.mean():.2%}), "
    f"{R['split']['dev_fail_vendor_weeks']} failing vendor-weeks")
say(f"  Holdout 2026          : {len(val)} scored vendor-weeks, {n_val_w} weeks, {int(val.y.sum())} failure-rows ({val.y.mean():.2%}), "
    f"{R['split']['val_fail_vendor_weeks']} failing vendor-weeks")
say("  Walk-forward blocks   : 2024Q1..2025Q4 (8 blocks of 13 weeks). Each block is predicted by a model fitted only on rows whose "
    "outcome was already known on the block's first Monday (t <= a-2).")
say("  Why this split: weeks are autocorrelated and the tool is used forward in time, so random row splits would leak the future. "
    "Walk-forward replays what the manager would have had, and yields eight separate tests instead of one.")

# ============================================================================================ 1b. leakage check
say("\n" + "=" * 100 + "\n1b. LEAKAGE CHECK  (is every predictor knowable on Monday, before the week being predicted?)")
snap = src("snap_vendor_week.csv").merge(cal[["week_id", "t", "week_start_monday"]], on="week_id")
asof_ok = bool((pd.to_datetime(snap.as_of_cutoff) == pd.to_datetime(snap.week_start_monday)).all())
say(f"  as_of_cutoff equals the Monday of the row's week for all {len(snap)} vendor-weeks: {asof_ok}")
sn = snap.sort_values(["vendor_id", "t"]).set_index(["vendor_id", "t"])
base = dev[["vendor_id", "t", "y"]].copy()


def snap_at(col, shift):
    s = sn[col]
    return np.array([s.get((v, t + shift), np.nan) for v, t in zip(base.vendor_id, base.t)])


leak = []
spec = [("Delivery volume (deliveries per week)", "trailing_13wk_delivery_count", +1),
        ("Rejection rate, last 4 weeks", "trailing_4wk_rejection_rate", +1),
        ("Rejection rate, last 13 weeks", "trailing_13wk_rejection_rate", +1)]
fcount = fail.groupby(["vendor_id", "t"]).size()
for name, col, sign in spec:
    now, late = snap_at(col, 0), snap_at(col, 2)
    ok = ~np.isnan(now) & ~np.isnan(late)
    a0 = roc_auc_score(base.y[ok], sign * now[ok])
    a2 = roc_auc_score(base.y[ok], sign * late[ok])
    leak.append(dict(name=name, auc_asof=float(a0), auc_if_measured_two_mondays_later=float(a2)))
b13 = base.copy()
b13["now"] = dev.fail_13wk.values
b13["late"] = [sum(fcount.get((v, tt), 0) for tt in range(t + 2 - 13, t + 2)) for v, t in zip(b13.vendor_id, b13.t)]
leak_extra = dict(name="(not used) Failures in last 13 weeks", auc_asof=float(roc_auc_score(b13.y, b13.now)),
                  auc_if_measured_two_mondays_later=float(roc_auc_score(b13.y, b13.late)))
say("  Negative control: if a predictor secretly contained next-week information, measuring it two Mondays later (window then covers "
    "the target week) would make it look far better. A clean predictor should look about the same either way only if the target week "
    "adds little; a large jump proves the as-of version is not peeking.")
say(f"  {'Predictor':45s} {'AUC as of Monday t':>20s} {'AUC if it included week t+1':>30s}")
for r_ in leak + [leak_extra]:
    say(f"  {r_['name']:45s} {r_['auc_asof']:20.3f} {r_['auc_if_measured_two_mondays_later']:30.3f}")
R["leakage_controls"] = leak + [leak_extra]

R["leakage_table"] = [
    dict(item="Delivery volume (log deliveries per week)", source="Trailing 13-week delivery count / 13, from the weekly vendor snapshot",
         known="Monday of the forecast week, counts deliveries through the previous Sunday", decision_time=True),
    dict(item="Rejection rate, last 4 weeks", source="Weekly vendor snapshot (trailing_4wk_rejection_rate); falls back to the 13-week rate when no deliveries in 4 weeks",
         known="Monday of the forecast week", decision_time=True),
    dict(item="Rejection rate, last 13 weeks", source="Weekly vendor snapshot (trailing_13wk_rejection_rate)", known="Monday of the forecast week", decision_time=True),
    dict(item="Vendor category", source="Vendor master table (fixed attribute)", known="Always", decision_time=True),
    dict(item="Vendor effect (reliability history)", source="Learned only from earlier rows (label known two Mondays after the row)", known="Monday of the forecast week", decision_time=True),
    dict(item="Cost model: occupancy and banquet flag", source="Demand table; used to size the cost of a failure, not to predict whether one happens",
         known="Occupancy forecast and booked banquets are known ahead; Week 11 tests using last week's values", decision_time=True),
    dict(item="Open corrective action", source="Corrective-action log", known="Excluded from the model (manager action, rule W20/G29/S7); used only as an eligibility filter for the review list", decision_time=True),
    dict(item="Oracle (true reliability) table", source="Generator internals", known="Never read (S6/S20)", decision_time=False)]

# structural checks on the training/test construction
ok_split = True
for a, b, tr, te in rolling_folds(dev):
    ok_split &= bool(tr.t.max() <= a - 2) and bool(te.t.min() >= a)
say(f"  Every walk-forward block trains only on rows with t <= a-2 (their label is known by Monday a): {ok_split}")
say("  The 2026 rows are never used for fitting, tuning, or choosing thresholds in the Week 11 pipeline: True (scripts 20-22 fit on `dev` only).")
R["leakage_checks"] = dict(asof_ok=asof_ok, walkforward_ok=bool(ok_split))

# ============================================================================================ rolling out-of-fold predictions
say("\n" + "=" * 100 + "\nBuilding rolling out-of-fold predictions (eight blocks) ...")
oof = oof_table(dev, vendors)
oof["real_cost"] = oof.real_cost.values
oof.to_csv(os.path.join(D, "wk11_dev_oof.csv"), index=False)
say(f"  {len(oof)} out-of-fold rows, {int(oof.y.sum())} failures")

# 2026 predictions from the frozen Week 10 configuration (refit on all development data)
pv, final = predict_all(dev, val, vendors)
for k, v in pv.items():
    val[k] = v
for k, v in rank_scores(val).items():
    val["s_" + k] = v
w10 = pd.read_csv(os.path.join(D, "holdout_predictions_2026.csv"))
parity = float(np.abs(w10.set_index(["vendor_id", "t"]).p.reindex(list(zip(val.vendor_id, val.t))).values - val.p.values).max())
say(f"  Parity with the Week 10 model's 2026 predictions: max |difference| = {parity:.2e}")
R["parity_w10_2026"] = parity

# boundary detail: the last development row (2025-W52, t = 155) predicts 2026-W01, so its label is a 2026 outcome. Measure what that one week does.
edge = dev[dev.t == dev.t.max()]
m_cut = fit_glm(dev[dev.t < dev.t.max()], FEATS, vendors, P10["lam_cat"], P10["lam_v"], 1.0)
p_cut = predict(m_cut, val)
R["boundary"] = dict(rows=int(len(edge)), failures=int(edge.y.sum()), dev_failures=int(dev.y.sum()), max_abs_dp=float(np.abs(p_cut - val.p.values).max()),
                     logloss_with=float(metrics(val.y.values, val.p.values)["logloss"]), logloss_without=float(metrics(val.y.values, p_cut)["logloss"]),
                     auc_with=float(metrics(val.y.values, val.p.values)["auc"]), auc_without=float(metrics(val.y.values, p_cut)["auc"]))
say(f"  Boundary: the last development week (t={int(dev.t.max())}) has {len(edge)} rows whose label is a 2026-W01 outcome ({int(edge.y.sum())} failures of {int(dev.y.sum())}). "
    f"Refitting without it changes 2026 log loss {R['boundary']['logloss_with']:.5f} -> {R['boundary']['logloss_without']:.5f}, AUC {R['boundary']['auc_with']:.4f} -> {R['boundary']['auc_without']:.4f}, "
    f"largest change in any 2026 probability {R['boundary']['max_abs_dp']:.4f}. Disclosed; the frozen Week 10 model is left as it was.")

# ============================================================================================ 1c/1d  KPI 1 metrics
say("\n" + "=" * 100 + "\n1c/1d. KPI 1 -- PROBABILITY OF A MATERIAL FAILURE NEXT WEEK: model vs baselines")
MODELS = [("Model (this tool)", "p"), ("Vendor's own history (smoothed)", "p_vend"), ("Category rate", "p_cat"),
          ("Same rate for every vendor", "p_const"), ("Gradient-boosted trees", "p_gbm"),
          ("Model without rejection rates (ablation)", "p_nobeh")]
RANKS = [("Delivery volume (spend proxy)", "s_volume"), ("Trailing 13-week rejection rate", "s_trailing_rej"),
         ("Current practice (on-time/fill + loud failure)", "s_practice")]


def loss_rows(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p)), (y - p) ** 2


def kpi1_table(df, label):
    y = df.y.values
    wk = df.t.values
    idx_list = list(week_bootstrap_idx(wk, NB, rng))
    rows = {}
    for name, col in MODELS:
        p = df[col].values
        ll, br = loss_rows(y, p)
        m = metrics(y, p)
        cs = cal_slope_shift(np.clip(p, 1e-6, 1 - 1e-6), y) if col in ("p", "p_gbm", "p_cat", "p_vend") else None
        rows[name] = dict(col=col, **m, cal=cs, obs_rate=float(y.mean()), mean_pred=float(p.mean()))
    for name, col in RANKS:
        s = df[col].values + rng.random(len(df)) * 1e-9
        rows[name] = dict(col=col, auc=float(roc_auc_score(y, s)), ap=float(average_precision_score(y, s)))
    # paired differences of the model vs each probability baseline
    diffs = {}
    for name, col in MODELS[1:]:
        llm, brm = loss_rows(y, df.p.values)
        llb, brb = loss_rows(y, df[col].values)
        d_ll, d_br = (llm - llb), (brm - brb)
        bs_ll, bs_br, bs_auc = [], [], []
        for ii in idx_list:
            bs_ll.append(d_ll[ii].mean())
            bs_br.append(d_br[ii].mean())
            bs_auc.append(roc_auc_score(y[ii], df.p.values[ii]) - roc_auc_score(y[ii], df[col].values[ii]))
        diffs[name] = dict(
            logloss=[float(d_ll.mean()), float(np.percentile(bs_ll, 2.5)), float(np.percentile(bs_ll, 97.5))],
            brier=[float(d_br.mean()), float(np.percentile(bs_br, 2.5)), float(np.percentile(bs_br, 97.5))],
            auc=[float(roc_auc_score(y, df.p.values) - roc_auc_score(y, df[col].values)), float(np.percentile(bs_auc, 2.5)), float(np.percentile(bs_auc, 97.5))])
    # AUC interval for each model (week-cluster bootstrap)
    for name, col in MODELS:
        b = [roc_auc_score(y[ii], df[col].values[ii]) for ii in idx_list[:500]]
        rows[name]["auc_ci"] = [float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))]
    say(f"\n  [{label}]  n={len(df)}  failures={int(y.sum())}  observed rate={y.mean():.2%}")
    say(f"  {'':48s}{'AUC':>7s}{'AP':>7s}{'Brier':>8s}{'LogLoss':>9s}{'Cal.slope':>10s}{'Mean pred':>10s}")
    for name, r_ in rows.items():
        if "brier" in r_:
            say(f"  {name:48s}{r_['auc']:7.3f}{r_['ap']:7.3f}{r_['brier']:8.4f}{r_['logloss']:9.4f}{r_['cal']['slope']:10.2f}{r_['mean_pred']:10.4f}"
                if r_["cal"] else f"  {name:48s}{r_['auc']:7.3f}{r_['ap']:7.3f}{r_['brier']:8.4f}{r_['logloss']:9.4f}{'':>10s}{r_['mean_pred']:10.4f}")
        else:
            say(f"  {name:48s}{r_['auc']:7.3f}{r_['ap']:7.3f}   (ranking only: not a probability)")
    say("  Model minus baseline, paired week-cluster bootstrap 95% interval  (negative log loss / Brier = model better; positive AUC = model better)")
    for name, v in diffs.items():
        say(f"    vs {name:34s} logloss {v['logloss'][0]:+.4f} [{v['logloss'][1]:+.4f},{v['logloss'][2]:+.4f}]   "
            f"Brier {v['brier'][0]:+.4f} [{v['brier'][1]:+.4f},{v['brier'][2]:+.4f}]   AUC {v['auc'][0]:+.3f} [{v['auc'][1]:+.3f},{v['auc'][2]:+.3f}]")
    return dict(rows=rows, diffs=diffs, n=len(df), fails=int(y.sum()))


K1_dev = kpi1_table(oof, "DEVELOPMENT rolling 2024-2025")
K1_val = kpi1_table(val, "2026 CONFIRMATION (previously viewed holdout)")

# per-block consistency (log loss and AUC, model vs category and vs vendor history)
blk = []
for bidx, g in oof.groupby("block"):
    ll_m, _ = loss_rows(g.y.values, g.p.values)
    ll_c, _ = loss_rows(g.y.values, g.p_cat.values)
    ll_v, _ = loss_rows(g.y.values, g.p_vend.values)
    a_m, a_c = roc_auc_score(g.y, g.p), roc_auc_score(g.y, g.p_cat + rng.random(len(g)) * 1e-9)
    blk.append(dict(block=int(bidx), label=f"{2024 + bidx // 4}Q{bidx % 4 + 1}", n=len(g), fails=int(g.y.sum()),
                    ll_model=float(ll_m.mean()), ll_cat=float(ll_c.mean()), ll_vend=float(ll_v.mean()), auc_model=float(a_m), auc_cat=float(a_c)))
bk = pd.DataFrame(blk)
say("\n  Block by block (development): does the model beat 'category rate' consistently?")
say(bk.round(4).to_string(index=False))
better_ll = int((bk.ll_model < np.minimum(bk.ll_cat, bk.ll_vend)).sum())
better_auc = int((bk.auc_model > bk.auc_cat).sum())
say(f"  Blocks where model log loss < best simple baseline: {better_ll}/8;  blocks where model AUC > category-rate AUC: {better_auc}/8")
R["kpi1_dev"], R["kpi1_val"], R["kpi1_blocks"] = K1_dev, K1_val, blk

# ============================================================================================ KPI 2 -- cost of a failure
say("\n" + "=" * 100 + "\n1c/1d. KPI 2 -- DOLLAR COST OF A FAILURE (per failing vendor-week), model vs baselines")
dem_i = dem.set_index("t")
vw = vw.copy()
vw["occ_prev"] = [dem_i.occupancy_rate.get(t - 1, np.nan) for t in vw.t]
vw["banq_prev"] = [float(dem_i.banquet_flag.get(t - 1, np.nan)) for t in vw.t]
vw = vw.dropna(subset=["occ_prev", "banq_prev"]).reset_index(drop=True)
vw["banquet_flag"] = vw.banquet_flag.astype(float)


def cost_fit(tr, kind):
    """Return a predict(df)->mean-cost function and the empirical cost/mean ratio distribution (heavy right tail kept)."""
    y = tr.total_cost.values
    if kind == "mean":
        mu = y.mean()
        f = lambda df: np.full(len(df), mu)
    elif kind == "category":
        cm = tr.groupby("category_id").total_cost.mean()
        f = lambda df: df.category_id.map(cm).fillna(y.mean()).values
    else:
        cols = {"failure_week": ["occupancy_rate", "banquet_flag"], "prev_week": ["occ_prev", "banq_prev"]}[kind]
        X = np.column_stack([np.ones(len(tr))] + [tr[c].astype(float).values for c in cols])
        b = np.linalg.lstsq(X, y, rcond=None)[0]
        f = lambda df: np.maximum(np.column_stack([np.ones(len(df))] + [df[c].astype(float).values for c in cols]) @ b, 1.0)
    ratio = np.sort(y / f(tr))
    return f, ratio


COST_MODELS = [("Week 10 cost model (occupancy + banquet of the failure week)", "failure_week"),
               ("Same inputs, but last week's occupancy + banquet (decision-time)", "prev_week"),
               ("Average cost by category", "category"), ("Average past failure cost", "mean")]


def cost_eval(pairs, label):
    """pairs: list of (train_df, test_df)."""
    preds = {n: [] for n, _ in COST_MODELS}
    act, wkk, lo_hi = [], [], {n: [] for n, _ in COST_MODELS}
    for tr, te in pairs:
        act.append(te.total_cost.values)
        wkk.append(te.t.values)
        for name, kind in COST_MODELS:
            f, ratio = cost_fit(tr, kind)
            mu = f(te)
            preds[name].append(mu)
            lo_hi[name].append(np.column_stack([mu * np.quantile(ratio, 0.10), mu * np.quantile(ratio, 0.90)]))
    y = np.concatenate(act)
    wk = np.concatenate(wkk)
    idx_list = list(week_bootstrap_idx(wk, NB, rng))
    out = {}
    say(f"\n  [{label}]  failing vendor-weeks n={len(y)}   mean actual cost ${y.mean():,.0f}   median ${np.median(y):,.0f}")
    say(f"  {'':72s}{'MAE':>9s}{'WAPE':>7s}{'Bias':>7s}{'80% cover':>10s}{'Corr':>7s}")
    ref = np.abs(y - np.concatenate(preds["Average past failure cost"]))
    for name, _ in COST_MODELS:
        p = np.concatenate(preds[name])
        lh = np.vstack(lo_hi[name])
        err = np.abs(y - p)
        cover = float(((y >= lh[:, 0]) & (y <= lh[:, 1])).mean())
        corr = float(np.corrcoef(y, p)[0, 1]) if p.std() > 0 else float("nan")
        diff_mae = err - ref
        bs = [diff_mae[ii].mean() for ii in idx_list]
        out[name] = dict(mae=float(err.mean()), wape=float(err.sum() / y.sum()), bias=float(y.sum() / p.sum()), cover80=cover, corr=corr,
                         mae_vs_mean=float(diff_mae.mean()), mae_vs_mean_ci=[float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))],
                         mae_vs_mean_pct=float(diff_mae.mean() / ref.mean()), n=len(y))
        say(f"  {name:72s}{err.mean():9,.0f}{err.sum() / y.sum():7.2f}{y.sum() / p.sum():7.2f}{cover:10.2f}{corr:7.2f}"
            f"   vs avg: {diff_mae.mean():+,.0f} [{np.percentile(bs, 2.5):+,.0f},{np.percentile(bs, 97.5):+,.0f}]")
    return out


pairs_dev = []
for a, b in blocks(FIRST_TEST_T, int(dev.t.max())):
    tr = vw[(vw.data_split == "dev") & (vw.t <= a - 1)]
    te = vw[(vw.data_split == "dev") & (vw.t >= a + 1) & (vw.t <= b)]
    pairs_dev.append((tr, te))
K2_dev = cost_eval(pairs_dev, "DEVELOPMENT rolling 2024-2025")
K2_val = cost_eval([(vw[vw.data_split == "dev"], vw[vw.data_split == "validation_2026"])], "2026 CONFIRMATION")
say("  Reading: 'MAE' is the typical dollar miss per failing vendor-week; 'Bias' = actual total / predicted total (1.00 = unbiased); "
    "'80% cover' = share of real costs inside the model's 80% range (target 0.80).")
R["kpi2_dev"], R["kpi2_val"] = K2_dev, K2_val
cs_ = {}
for nm, sel in (("dev", (vw.data_split == "dev") & (vw.t >= FIRST_TEST_T + 1)), ("val", vw.data_split == "validation_2026")):      # dev = the 2024-25 test period, as in the table above
    t_ = vw[sel].total_cost
    cs_[nm] = dict(n=int(len(t_)), mean=float(t_.mean()), median=float(t_.median()), p10=float(t_.quantile(.1)), p90=float(t_.quantile(.9)), max=float(t_.max()))
R["cost_summary"] = cs_
say(f"  Typical failing vendor-week cost (2024-25 test period): mean ${cs_['dev']['mean']:,.0f}, median ${cs_['dev']['median']:,.0f}, 10th-90th percentile ${cs_['dev']['p10']:,.0f} to ${cs_['dev']['p90']:,.0f}; "
    f"2026 mean ${cs_['val']['mean']:,.0f}, median ${cs_['val']['median']:,.0f}")

# ============================================================================================ decision-level capture
say("\n" + "=" * 100 + "\nDECISION LEVEL -- share of next-week failure cost (and failures) that falls inside the weekly review list (top k, k = review capacity)")
say("  Within one week every vendor shares the same cost multiplier, so ranking by probability x cost is the same ranking as probability alone;"
    " the tool's expected-cost ranking and the probability ranking give identical lists.")
POLICIES = [("Model (this tool)", "p"), ("Model without rejection rates (ablation)", "p_nobeh"), ("Gradient-boosted trees", "p_gbm"),
            ("Vendor's own history (smoothed)", "p_vend"), ("Category rate", "p_cat"), ("Delivery volume (spend proxy)", "s_volume"),
            ("Trailing 13-week rejection rate", "s_trailing_rej"), ("Current practice (on-time/fill + loud failure)", "s_practice"),
            ("Random list", None)]
COARSE = {"s_volume", "s_trailing_rej", "s_practice", "p_cat"}          # rule-based scores with many ties


def run_policy(df, col, r_):
    kw = dict(jitter=1e-4, jit_reps=40) if col in COARSE else {}
    return topk_by_week(df, col, rng=r_, **kw)


def capture_block(df, label, seed):
    r_ = np.random.default_rng(seed)
    pws = {n: run_policy(df, c, r_) for n, c in POLICIES}
    res = {n: capture_summary(pw, r_, 1000) for n, pw in pws.items()}
    say(f"\n  [{label}]  weeks={df.t.nunique()}  mean k={df.groupby('t').review_capacity_k.first().mean():.1f}  "
        f"addressable failures={int(df[df.addressable].y.sum())}  addressable failure cost=${df[df.addressable].real_cost.sum():,.0f}")
    say(f"  {'List built by':48s}{'Cost captured':>16s}{'95% interval':>18s}{'Failures caught':>17s}{'Model minus this (cost)':>34s}")
    cmp_ = {}
    for n, _ in POLICIES:
        r = res[n]
        if n != "Model (this tool)":
            dif, ci = paired_diff(pws["Model (this tool)"], pws[n], r_, 1000)
            dn, cin = paired_diff(pws["Model (this tool)"], pws[n], r_, 1000, col=("cap_n", "tot_n"))
            cmp_[n] = dict(cost=[dif, ci[0], ci[1]], fail=[dn, cin[0], cin[1]])
            ds = f"{dif * 100:+6.1f} pts [{ci[0] * 100:+5.1f},{ci[1] * 100:+5.1f}]"
        else:
            ds = ""
        say(f"  {n:48s}{r['cost'] * 100:15.1f}%{'[' + format(r['cost_ci'][0] * 100, '.1f') + ',' + format(r['cost_ci'][1] * 100, '.1f') + ']':>18s}{r['fail'] * 100:16.1f}%{ds:>34s}")
    return dict(res=res, cmp=cmp_, per_week={n: pw.to_dict("list") for n, pw in pws.items() if n in ("Model (this tool)", "Delivery volume (spend proxy)", "Current practice (on-time/fill + loud failure)")})


D_dev = capture_block(oof, "DEVELOPMENT rolling 2024-2025", 11)
D_val = capture_block(val, "2026 CONFIRMATION", 12)
R["decision_dev"], R["decision_val"] = D_dev, D_val

# how the list size changes coverage (the lever the manager actually controls)
say("\n" + "=" * 100 + "\nLIST SIZE VERSUS COVERAGE -- share of next-week failure cost caught if the weekly list were a multiple of the review capacity k")


def capture_vs_size(df, label, seed):
    rows = []
    for mult in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0]:
        d2 = df.copy()
        d2["k_x"] = np.ceil(d2.review_capacity_k * mult).astype(int)
        r_ = np.random.default_rng(seed)
        row = dict(mult=mult, mean_k=float(d2.groupby("t").k_x.first().mean()))
        for n, c in [("Model (this tool)", "p"), ("Delivery volume (spend proxy)", "s_volume"), ("Current practice (on-time/fill + loud failure)", "s_practice"), ("Random list", None)]:
            kw = dict(jitter=1e-4, jit_reps=40) if c in COARSE else {}
            pw = topk_by_week(d2, c, k_col="k_x", rng=r_, **kw)
            cs = capture_summary(pw, r_, 500)
            row[n] = dict(cost=cs["cost"], cost_ci=cs["cost_ci"], fail=cs["fail"])
        rows.append(row)
    say(f"\n  [{label}]  {'list size':>12s}  {'Model':>8s} {'95% interval':>14s}  {'Volume':>7s} {'Practice':>9s} {'Random':>7s}   failures caught by model")
    for r in rows:
        m_ = r["Model (this tool)"]
        say(f"  {'k x ' + format(r['mult'], '.1f') + ' = ' + format(r['mean_k'], '.1f') + '/wk':>22s}  {m_['cost'] * 100:7.1f}% [{m_['cost_ci'][0] * 100:4.1f},{m_['cost_ci'][1] * 100:4.1f}]  "
            f"{r['Delivery volume (spend proxy)']['cost'] * 100:6.1f}% {r['Current practice (on-time/fill + loud failure)']['cost'] * 100:8.1f}% {r['Random list']['cost'] * 100:6.1f}%   {m_['fail'] * 100:5.1f}%")
    return rows


R["list_size_dev"] = capture_vs_size(oof, "DEVELOPMENT rolling 2024-2025", 21)
R["list_size_val"] = capture_vs_size(val, "2026 CONFIRMATION", 22)
n_elig_dev = float(oof[oof.addressable].groupby("t").size().mean())
R["eligible_per_week"] = dict(dev=n_elig_dev, val=float(val[val.addressable].groupby("t").size().mean()))
say(f"  (mean eligible vendors per week: {R['eligible_per_week']['dev']:.1f} in development, {R['eligible_per_week']['val']:.1f} in 2026)")

# consistency by block: model vs strongest simple list
simple = ["Vendor's own history (smoothed)", "Category rate", "Delivery volume (spend proxy)", "Trailing 13-week rejection rate", "Current practice (on-time/fill + loud failure)"]
best_simple = max(simple, key=lambda n: D_dev["res"][n]["cost"])
say(f"\n  Strongest simple list in development: {best_simple} ({D_dev['res'][best_simple]['cost'] * 100:.1f}% of cost)")
bl = []
r_ = np.random.default_rng(5)
for bidx, g in oof.groupby("block"):
    pm = run_policy(g, "p", r_)
    ps = run_policy(g, dict(POLICIES)[best_simple], r_)
    bl.append(dict(block=f"{2024 + bidx // 4}Q{bidx % 4 + 1}", model=pm.cap_c.sum() / pm.tot_c.sum(), best_simple=ps.cap_c.sum() / ps.tot_c.sum()))
bl = pd.DataFrame(bl)
say(bl.round(3).to_string(index=False))
say(f"  Blocks where the model list captures more cost than {best_simple}: {int((bl.model > bl.best_simple).sum())}/8")
R["decision_blocks"] = bl.to_dict("records")
R["best_simple_dev"] = best_simple

# ============================================================================================ verdicts
say("\n" + "=" * 100 + "\nVERDICT AGAINST THE PRE-STATED RULES")
v = {}
dd = K1_dev["diffs"]
ll_ok = all(dd[n]["logloss"][2] < 0 for n in ["Vendor's own history (smoothed)", "Category rate"]) and better_ll >= 6
v["kpi1_probability"] = dict(rule="log loss beats best simple baseline, interval excludes 0, better in >=6/8 blocks", met=bool(ll_ok),
                             detail={n: dd[n]["logloss"] for n in ["Vendor's own history (smoothed)", "Category rate"]}, blocks_better=better_ll)
best_auc = max(["Vendor's own history (smoothed)", "Category rate"], key=lambda n: K1_dev["rows"][n]["auc"])
auc_d = dd[best_auc]["auc"]
v["kpi1_ranking"] = dict(rule="AUC >= +0.03 over best simple baseline with 95% interval excluding 0", met=bool(auc_d[0] >= 0.03 and auc_d[1] > 0),
                         baseline=best_auc, diff=auc_d)
kp = K2_dev["Week 10 cost model (occupancy + banquet of the failure week)"]
v["kpi2_cost"] = dict(rule="MAE >= 5% below 'average past failure cost' with 95% interval excluding 0", met=bool(kp["mae_vs_mean_pct"] <= -0.05 and kp["mae_vs_mean_ci"][1] < 0),
                      pct=kp["mae_vs_mean_pct"], ci=kp["mae_vs_mean_ci"])
cb = D_dev["cmp"][best_simple]["cost"]
v["decision_capture"] = dict(rule=">= +5 pts cost captured over strongest simple list, interval excluding 0", met=bool(cb[0] >= 0.05 and cb[1] > 0),
                             baseline=best_simple, diff=cb)
cv_ = D_val["cmp"].get(best_simple, {}).get("cost")
v["decision_capture_2026"] = dict(baseline=best_simple, diff=cv_, consistent=bool(cv_ and cv_[0] > 0))
v["decision_vs_practice"] = dict(dev=D_dev["cmp"]["Current practice (on-time/fill + loud failure)"]["cost"], val=D_val["cmp"]["Current practice (on-time/fill + loud failure)"]["cost"])
for k, x in v.items():
    say(f"  {k:24s} " + ("MET" if x.get("met") else ("NOT MET" if "met" in x else "")) + "  " + json.dumps({a: b for a, b in x.items() if a not in ("met",)}, default=float))
R["verdicts"] = v

R["config"] = dict(sklearn=__import__("sklearn").__version__, n_boot=NB, block=BLOCK, first_test_t=FIRST_TEST_T, vend_shrink=VEND_SHRINK, seed=SEED)
with open(OUT_JSON, "w") as f:
    json.dump(R, f, indent=1, default=float)
with open(OUT_LOG, "w") as f:
    f.write("\n".join(LOG))
say(f"\nWrote {OUT_JSON} and {OUT_LOG}")
