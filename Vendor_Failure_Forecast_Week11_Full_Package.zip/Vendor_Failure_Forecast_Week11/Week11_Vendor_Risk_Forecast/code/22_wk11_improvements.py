"""
Week 11 step 3 -- improvements suggested by the error analysis, tested on DEVELOPMENT data only (rolling 2024-2025 blocks).
The 2026 holdout is not read by this script.

Candidates (each links to a finding in docs/wk11_error_analysis.txt)
  A  Recency weighting            Drift: observed/expected failures ranged 0.80-1.12 by quarter; old weeks may mislead a later quarter.
  B  Smoothed rejection rates     Thin history: rows with few deliveries have rates built on 1-3 deliveries (one rejection = 33% or 100%).
  C  Recent-failure count         'Failed 5-13 weeks ago' is the best-caught segment (74%); is the failure history missing from the model?
  D  Fewer rejection predictors   Rejection rates add little to ranking (see ablation in script 20); is one of the two enough?
  E  Category-specific cost       Protein/dairy are 47% of failure cost but 11-33% caught: costs may differ by category and re-order the list.
  F  Trailing recalibration       Quarter-level drift: rescale all probabilities by the recent observed/expected ratio.
  G  Pooling strength             Does a different vendor-effect strength (lam_v) fit better now that there are eight test blocks?
  J  Fixed exposure offset        Raised by Debra Senteu's screening script (15_select_improvements.py, two yearly folds): exposure as an offset (g = 1)
                                  on an as-of exposure shrunk toward the category mean, as in the Week 9 model. Week 10 had tested a plain offset
                                  and rejected it (estimated elasticity 0.30); this is the shrunk variant.
  K  Category in the cost model   Raised by the same script: dollar model = occupancy + banquet + category intercepts (her "B"). Tested two ways:
                                  (1) accuracy of the dollar estimate on the eight blocks; (2) whether pricing by category re-orders the list.

Keep / reject rules. Candidates A-G were judged by rules written before they were run. J and K were added after Debra's two-fold screen was
shared; their rules below were written before J and K were run on the eight blocks, but not blind to her two-fold result (disclosed in the report).
  Model changes (A,B,C,D,G,J): keep if pooled log loss is lower by >= 0.001 AND lower in >= 6 of 8 blocks AND list cost capture is not
                              more than 1.0 point lower than the Week 10 configuration.
  Calibration rescaling (F): keep if pooled log loss is lower by >= 0.001 AND lower in >= 6 of 8 blocks (it cannot change the list).
  Cost ranking (E, and K as a ranking): keep if list cost capture is >= 1.0 point higher AND higher in >= 5 of 8 blocks.
  Dollar model (K, accuracy): keep if the typical miss (mean absolute error) is at least 1% lower than the Week 10 cost model AND lower in
                              >= 6 of 8 blocks AND the paired 95% interval over weeks excludes zero.
  Thirteen candidates are compared with one baseline, so a winner can still be luck; the block-consistency requirement is the guard.
Outputs: data/wk11_improvements.json, docs/wk11_improvements_log.txt
"""
import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from wk11_lib import *                       # noqa: F401,F403

LOG = []
rng = np.random.default_rng(SEED + 22)


def say(s=""):
    LOG.append(s)
    print(s)


L = load()
d, vw = L["d"], L["vw"]
vendors = vendor_list(d)
dev = d[d.data_split == "dev"].reset_index(drop=True)          # 2026 rows are deliberately not used
vwd = vw[vw.data_split == "dev"]


def ll_rows(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p))


# ------------------------------------------------------------------------------------------------ variant definitions
def v_base(tr, te, lam_v=None, feats=None, weights=None):
    m = fit_glm(tr, feats or FEATS, vendors, P10["lam_cat"], lam_v or P10["lam_v"], 1.0, weights=weights)
    return predict(m, te)


def v_recency(half_life):
    def f(tr, te):
        w = 0.5 ** ((tr.t.max() - tr.t.values) / half_life)
        return v_base(tr, te, weights=w * len(w) / w.sum())
    return f


def smooth_rates(tr, te, m):
    p0 = (tr.rej_13wk * tr.trailing_13wk_delivery_count).sum() / tr.trailing_13wk_delivery_count.sum()
    out = []
    for df in (tr, te):
        df = df.copy()
        n13 = df.trailing_13wk_delivery_count.values.astype(float)
        n4 = np.where(df.no_delivery_4wk.values == 1, 0.0, df.trailing_4wk_delivery_count.values.astype(float))
        r13 = (df.rej_13wk.values * n13 + m * p0) / (n13 + m)
        r4 = (df.rej_4wk.values * n4 + m * r13) / (n4 + m)
        df["rej_13wk"], df["rej_4wk"] = r13, r4
        out.append(df)
    return out


def v_smooth(m):
    def f(tr, te):
        a, b = smooth_rates(tr, te, m)
        return v_base(a, b)
    return f


EXPOSURE_SHRINK_WEEKS = 4.0      # pseudo-weeks pulling an as-of exposure toward its category mean (as in the Week 9 model and Debra's screen)


def v_offset(tr, te):
    """J: exposure as a fixed offset (g = 1) on an as-of exposure shrunk toward the training-block category mean; only the rejection rates stay as predictors."""
    cat_mean = tr.groupby("category_id").exposure_wk.mean()
    a, b = tr.copy(), te.copy()
    for df in (a, b):
        prior = df.category_id.map(cat_mean).values
        df["exposure_wk"] = (df.trailing_13wk_delivery_count.values + EXPOSURE_SHRINK_WEEKS * prior) / (13.0 + EXPOSURE_SHRINK_WEEKS)
    m = fit_glm(a, ["rej_4wk", "rej_13wk"], vendors, P10["lam_cat"], P10["lam_v"], 1.0, use_offset=True)
    return predict(m, b)


VARIANTS = [
    ("Week 10 configuration (baseline)", "base", lambda tr, te: v_base(tr, te)),
    ("A1 Recency weighting, half-life 52 weeks", "model", v_recency(52)),
    ("A2 Recency weighting, half-life 104 weeks", "model", v_recency(104)),
    ("B1 Smoothed rejection rates (prior = 5 deliveries)", "model", v_smooth(5)),
    ("B2 Smoothed rejection rates (prior = 15 deliveries)", "model", v_smooth(15)),
    ("C  Add failures in last 13 weeks", "model", lambda tr, te: v_base(tr, te, feats=FEATS + ["fail_13wk"])),
    ("D1 Drop 13-week rejection rate", "model", lambda tr, te: v_base(tr, te, feats=["log_exposure", "rej_4wk"])),
    ("D2 Drop 4-week rejection rate", "model", lambda tr, te: v_base(tr, te, feats=["log_exposure", "rej_13wk"])),
    ("G1 Weaker vendor effects (lam_v = 16)", "model", lambda tr, te: v_base(tr, te, lam_v=16.0)),
    ("G2 Stronger vendor effects (lam_v = 4)", "model", lambda tr, te: v_base(tr, te, lam_v=4.0)),
    ("J  Fixed exposure offset (g = 1) on shrunk exposure", "model", v_offset),
]

# ------------------------------------------------------------------------------------------------ run all variants on the eight blocks
dem_i = L["dem"].set_index("t")


def cost_design(df, occ, banq, with_cat):
    cols = [np.ones(len(df)), np.asarray(occ, float), np.asarray(banq, float)]
    if with_cat:
        cols += [(df.category_id == c).astype(float).values for c in CATS[1:]]           # produce is the reference category
    return np.column_stack(cols)


folds = list(rolling_folds(dev))
P = {n: [] for n, _, _ in VARIANTS}
frames = []
for a, b, tr, te in folds:
    te = te.copy()
    te["block"] = (a - FIRST_TEST_T) // BLOCK
    for n, _, fn in VARIANTS:
        P[n].append(np.asarray(fn(tr, te)))
    # category-specific cost multiplier (E): shrunk mean cost given failure by category, from failures known by Monday a
    trv = vwd[vwd.t <= a - 1]
    mu_all = trv.total_cost.mean()
    g = trv.groupby("category_id").total_cost.agg(["mean", "size"])
    shrunk = (g["mean"] * g["size"] + 20 * mu_all) / (g["size"] + 20)
    te["cost_mult"] = te.category_id.map(shrunk).fillna(mu_all).values / mu_all
    # K: occupancy + banquet + category dollar model fitted on failures known by Monday a, priced with next week's occupancy and banquet flag
    trk = trv[trv.t >= 1]                                                               # a failure in week 0 has no forecast row (same filter as script 20)
    bk = np.linalg.lstsq(cost_design(trk, trk.occupancy_rate.values, trk.banquet_flag.astype(float).values, True), trk.total_cost.values, rcond=None)[0]
    nxt = te.t.values + 1
    inside = nxt <= int(dev.t.max())                                                    # never read a 2026 week: the last dev week uses its own values
    occ_n = np.where(inside, dem_i.occupancy_rate.reindex(nxt).values, te.occupancy_rate.values)
    banq_n = np.where(inside, dem_i.banquet_flag.reindex(nxt).astype(float).values, te.banquet_flag.astype(float).values)
    te["cost_k"] = np.maximum(cost_design(te, occ_n, banq_n, True) @ bk, 1.0)
    frames.append(te)
oof = pd.concat(frames).reset_index(drop=True)
for n, _, _ in VARIANTS:
    oof["p::" + n] = np.concatenate(P[n])

# F: trailing recalibration of the baseline probabilities (needs earlier OOF rows only: label known by Monday t -> row weeks <= t-2)
base_p = oof["p::Week 10 configuration (baseline)"].values
tt = oof.t.values
fac = np.ones(len(oof))
C0 = 5.0
by_t = oof.assign(p0=base_p).groupby("t").agg(obs=("y", "sum"), exp=("p0", "sum"), n=("y", "size"))
for t in np.unique(tt):
    win = by_t.loc[(by_t.index >= t - 27) & (by_t.index <= t - 2)]
    if win.n.sum() >= 1000:
        fac[tt == t] = np.clip((win.obs.sum() + C0) / (win.exp.sum() + C0), 0.67, 1.5)
mu = -np.log1p(-np.clip(base_p, 1e-9, 1 - 1e-9))
oof["p::F  Trailing recalibration (26-week observed/expected)"] = 1 - np.exp(-mu * fac)
oof["fac"] = fac
VARIANTS_ALL = VARIANTS + [("F  Trailing recalibration (26-week observed/expected)", "recal", None)]

# ------------------------------------------------------------------------------------------------ compare
BASE = "Week 10 configuration (baseline)"
say("WEEK 11 IMPROVEMENT EXPERIMENTS (development only: rolling 2024-2025, eight blocks)")
say("=" * 130)
say("Rules: see the top of script 22 (written before the experiments were run).")

y = oof.y.values
base_ll_blk = oof.assign(l=ll_rows(y, oof["p::" + BASE].values)).groupby("block").l.mean()
res = []
pw_base = None
for n, kind, _ in VARIANTS_ALL:
    p = oof["p::" + n].values
    ll = ll_rows(y, p)
    llb = oof.assign(l=ll).groupby("block").l.mean()
    wins = int((llb < base_ll_blk - 1e-12).sum())
    m = metrics(y, p)
    df_ = oof.assign(score=p)
    pw = topk_by_week(df_, "score", rng=np.random.default_rng(3))
    if n == BASE:
        pw_base = pw
    res.append(dict(name=n, kind=kind, logloss=m["logloss"], brier=m["brier"], auc=m["auc"], blocks_better=wins, pw=pw))
for r in res:
    r["capture"] = r["pw"].cap_c.sum() / r["pw"].tot_c.sum()
    r["capture_fail"] = r["pw"].cap_n.sum() / r["pw"].tot_n.sum()
    dif, ci = paired_diff(r["pw"], pw_base, np.random.default_rng(4), 1000)
    r["cap_diff"], r["cap_ci"] = dif, ci
base_ll = [r for r in res if r["name"] == BASE][0]["logloss"]
say(f"\n{'Variant':58s}{'LogLoss':>9s}{'d LogLoss':>10s}{'Blocks better':>14s}{'Brier':>8s}{'AUC':>7s}{'Cost capture':>13s}{'d capture (95% CI)':>26s}")
for r in res:
    keep = None
    if r["name"] != BASE:
        d_ll = r["logloss"] - base_ll
        if r["kind"] == "model":
            keep = (d_ll <= -0.001) and (r["blocks_better"] >= 6) and (r["cap_diff"] >= -0.01)
        elif r["kind"] == "recal":
            keep = (d_ll <= -0.001) and (r["blocks_better"] >= 6)
    r["keep"] = keep
    say(f"{r['name']:58s}{r['logloss']:9.4f}{r['logloss'] - base_ll:+10.4f}{r['blocks_better']:>11d}/8{r['brier']:8.4f}{r['auc']:7.3f}{r['capture'] * 100:12.1f}%"
        f"{r['cap_diff'] * 100:+9.1f} pts [{r['cap_ci'][0] * 100:+5.1f},{r['cap_ci'][1] * 100:+5.1f}]   {'' if keep is None else ('KEEP' if keep else 'reject')}")

# E: category-specific cost ranking (dollars)
say("\nE  Category-specific cost multiplier (ranking by probability x category cost; probabilities unchanged)")
cat_cost = vwd.groupby("category_id").total_cost.agg(["size", "mean", "median"])
say(cat_cost.round(0).to_string())
oofE = oof.assign(scoreE=oof["p::" + BASE] * oof.cost_mult)
pwE = topk_by_week(oofE, "scoreE", rng=np.random.default_rng(3))
difE, ciE = paired_diff(pwE, pw_base, np.random.default_rng(4), 1000)
# block consistency
blkE = []
for b_, g in oofE.groupby("block"):
    a_ = topk_by_week(g, "scoreE", rng=np.random.default_rng(3))
    b2 = topk_by_week(g.assign(s0=g["p::" + BASE]), "s0", rng=np.random.default_rng(3))
    blkE.append(a_.cap_c.sum() / a_.tot_c.sum() - b2.cap_c.sum() / b2.tot_c.sum())
winsE = int((np.array(blkE) > 1e-9).sum())
keepE = (difE >= 0.01) and (winsE >= 5)
say(f"  cost captured: {pwE.cap_c.sum() / pwE.tot_c.sum():.1%} vs baseline {pw_base.cap_c.sum() / pw_base.tot_c.sum():.1%}  (diff {difE * 100:+.1f} pts [{ciE[0] * 100:+.1f},{ciE[1] * 100:+.1f}]); "
    f"higher in {winsE}/8 blocks -> {'KEEP' if keepE else 'reject'}")
say("  Block-by-block difference (pts): " + "  ".join(f"{x * 100:+.1f}" for x in blkE))
# category-level cost test: is the category effect on cost itself statistically supported (dev, all failing vendor-weeks)?
from scipy import stats as st
groups = [g.total_cost.values for _, g in vwd.groupby("category_id") if len(g) >= 8]
H, pH = st.kruskal(*groups)
say(f"  Kruskal-Wallis test, cost given failure differs by category: H={H:.2f}, p={pH:.3f}")
E_res = dict(capture=float(pwE.cap_c.sum() / pwE.tot_c.sum()), diff=float(difE), ci=ciE, blocks_higher=winsE, keep=bool(keepE), kruskal_p=float(pH),
             by_category=cat_cost.reset_index().to_dict("records"))

# K: category intercepts in the dollar model (Debra's "B"), judged on the eight blocks
say("\nK  Category intercepts in the cost model (occupancy + banquet + category); dollars first, then whether it re-orders the list")
yk, pw10, pkk, pmn, wkk, bkk = [], [], [], [], [], []
for i, (a_, b_) in enumerate(blocks(FIRST_TEST_T, int(dev.t.max()))):
    tr_, te_ = vwd[(vwd.t >= 1) & (vwd.t <= a_ - 1)], vwd[(vwd.t >= a_ + 1) & (vwd.t <= b_)]          # same pairs as the KPI 2 table in script 20
    fits = {}
    for nm, wc in (("w10", False), ("k", True)):
        bb = np.linalg.lstsq(cost_design(tr_, tr_.occupancy_rate.values, tr_.banquet_flag.astype(float).values, wc), tr_.total_cost.values, rcond=None)[0]
        fits[nm] = np.maximum(cost_design(te_, te_.occupancy_rate.values, te_.banquet_flag.astype(float).values, wc) @ bb, 1.0)
    yk.append(te_.total_cost.values); pw10.append(fits["w10"]); pkk.append(fits["k"]); pmn.append(np.full(len(te_), tr_.total_cost.mean()))
    wkk.append(te_.t.values); bkk.append(np.full(len(te_), i))
yk, pw10, pkk, pmn, wkk, bkk = (np.concatenate(v_) for v_ in (yk, pw10, pkk, pmn, wkk, bkk))
e10, ek, em = np.abs(yk - pw10), np.abs(yk - pkk), np.abs(yk - pmn)
dk = ek - e10
bs_k = [dk[ii].mean() for ii in week_bootstrap_idx(wkk, 1000, np.random.default_rng(5))]
ci_k = [float(np.percentile(bs_k, 2.5)), float(np.percentile(bs_k, 97.5))]
blk_wins_k = int(sum(ek[bkk == i].mean() < e10[bkk == i].mean() - 1e-9 for i in range(8)))
pct_k = float(dk.mean() / e10.mean())
keepK_acc = (pct_k <= -0.01) and (blk_wins_k >= 6) and (ci_k[1] < 0)
say(f"  Typical dollar miss over {len(yk)} failing vendor-weeks: Week 10 cost model ${e10.mean():,.0f}; plain average ${em.mean():,.0f}; with category ${ek.mean():,.0f}")
say(f"  Category minus Week 10: {dk.mean():+,.0f} dollars ({pct_k * 100:+.1f}%), 95% interval [{ci_k[0]:+,.0f}, {ci_k[1]:+,.0f}]; lower in {blk_wins_k}/8 blocks -> {'KEEP' if keepK_acc else 'reject'}")
say("  Block by block, typical miss (Week 10 / with category): " + "  ".join(f"${e10[bkk == i].mean():,.0f}/${ek[bkk == i].mean():,.0f}" for i in range(8)))
# does pricing by category re-order the list? score = chance x category-aware dollars (next week's occupancy and banquet)
oofK = oof.assign(scoreK=oof["p::" + BASE] * oof.cost_k)
pwK = topk_by_week(oofK, "scoreK", rng=np.random.default_rng(3))
difK, ciK = paired_diff(pwK, pw_base, np.random.default_rng(4), 1000)
blkK = []
for b_, g in oofK.groupby("block"):
    a_ = topk_by_week(g, "scoreK", rng=np.random.default_rng(3))
    b2 = topk_by_week(g.assign(s0=g["p::" + BASE]), "s0", rng=np.random.default_rng(3))
    blkK.append(a_.cap_c.sum() / a_.tot_c.sum() - b2.cap_c.sum() / b2.tot_c.sum())
winsK = int((np.array(blkK) > 1e-9).sum())
keepK_rank = (difK >= 0.01) and (winsK >= 5)
say(f"  As a ranking (chance x category-aware dollars): cost captured {pwK.cap_c.sum() / pwK.tot_c.sum():.1%} vs baseline {pw_base.cap_c.sum() / pw_base.tot_c.sum():.1%} "
    f"(diff {difK * 100:+.1f} pts [{ciK[0] * 100:+.1f},{ciK[1] * 100:+.1f}]); higher in {winsK}/8 blocks -> {'KEEP' if keepK_rank else 'reject'}")
say("  Block-by-block difference (pts): " + "  ".join(f"{x * 100:+.1f}" for x in blkK))
say("  Context: Debra's two-fold screen (train 2023 -> test 2024; 2023-24 -> 2025) found $1,174 for the Week 10 cost model and $1,161 with category ($13 or 1.1% lower) "
    "by the rule 'lower is better'; here the same comparison is made on eight blocks with a block-consistency rule and an interval.")
K_res = dict(mae_w10=float(e10.mean()), mae_k=float(ek.mean()), mae_mean=float(em.mean()), diff=float(dk.mean()), pct=pct_k, ci=ci_k, blocks_better=blk_wins_k, n=int(len(yk)),
             keep_accuracy=bool(keepK_acc), rank_capture=float(pwK.cap_c.sum() / pwK.tot_c.sum()), rank_diff=float(difK), rank_ci=ciK, rank_blocks_higher=winsK,
             keep_rank=bool(keepK_rank), keep=bool(keepK_acc or keepK_rank))

# cost-model input alignment (script 20 evidence): report only
say("\nH  Cost model inputs aligned to the week being priced (next week's expected occupancy and banquet flag)")
say("   See docs/wk11_evaluation_log.txt (KPI 2): MAE $1,163 with next week's own occupancy/banquet vs $1,172 with the strict alternative that uses only "
    "last week's values (nothing from the week being predicted); the difference is noise. This is a CORRECTNESS fix, not an accuracy gain: the Week 10 app "
    "priced next week's failure with the selected week's own occupancy/banquet while the cost model had been fitted on the failure week's values. "
    "Adopted so that training inputs equal scoring inputs. The figures come from bookings known ahead of Monday (assumption); they size the dollar cost "
    "only and never enter the probability or the ranking.")

# ------------------------------------------------------------------------------------------------ recalibration detail
say("\nF  Trailing recalibration factors applied (rows from 2024Q2 on):")
fb = oof.groupby("block").fac.agg(["mean", "min", "max"])
say(fb.round(2).to_string())

out = dict(variants=[{k: v for k, v in r.items() if k != "pw"} for r in res], category_cost=E_res, cost_model_k=K_res,
           rules=dict(model="log loss -0.001, >=6/8 blocks, capture not >1pt lower", recal="log loss -0.001, >=6/8 blocks", cost_rank="+1pt capture, >=5/8 blocks",
                      cost_model="typical miss >=1% lower, >=6/8 blocks, 95% interval excludes zero"))
with open(os.path.join(D, "wk11_improvements.json"), "w") as f:
    json.dump(out, f, indent=1, default=float)
with open(os.path.join(HERE, "..", "docs", "wk11_improvements_log.txt"), "w") as f:
    f.write("\n".join(LOG))
say("\nWrote data/wk11_improvements.json and docs/wk11_improvements_log.txt")
