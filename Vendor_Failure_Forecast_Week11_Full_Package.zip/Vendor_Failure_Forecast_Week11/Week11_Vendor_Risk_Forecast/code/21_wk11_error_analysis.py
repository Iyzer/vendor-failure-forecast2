"""
Week 11 step 2 -- error analysis: where does the model (and its weekly review list) do well or badly?

Segments: vendor category, season, vendor size, delivery volume, open corrective action, thin history, recent failure, recent rejections,
banquet week. Evidence base for every design decision = rolling out-of-fold predictions on 2023-2025 (data/wk11_dev_oof.csv).
The same table for 2026 is produced at the end, for the report's "do the patterns persist?" check only; nothing in script 22 reads it.

For each segment:
  obs / pred / O:E   observed failure rate, average predicted probability, and their ratio with a 95% Poisson interval
                     (1.00 = the model's probabilities are right on average for that segment)
  AUC                how well the model orders vendors inside the segment (shown when the segment has >= 8 failures)
  on list / catch    share of the segment's vendor-weeks that land on the weekly review list; share of its failures that were on the list
  cost share/captured share of next-week failure cost that comes from addressable vendors in the segment, and the share of it the list catches
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from wk11_lib import *                      # noqa: F401,F403

LOG = []


def say(s=""):
    LOG.append(s)
    print(s)


L = load()
d, cal = L["d"], L["cal"].set_index("t")
vendors = vendor_list(d)
oof = pd.read_csv(os.path.join(D, "wk11_dev_oof.csv"))
oof["addressable"] = oof.addressable.astype(bool)
dev = d[d.data_split == "dev"].reset_index(drop=True)
val = d[d.data_split == "validation_2026"].reset_index(drop=True)
final = fit_glm(dev, FEATS, vendors, P10["lam_cat"], P10["lam_v"], 1.0)
val["p"] = predict(final, val)


def add_segments(o):
    o = o.copy()
    o["season"] = o.t.map(cal.season_label)
    o["thin"] = pd.cut(o.trailing_13wk_delivery_count, [-1, 5, 12, 30, 10000], labels=["0-5 deliveries", "6-12", "13-30", "31+"])
    o["volume"] = pd.cut(o.exposure_wk, [0, 1.0, 2.5, 1e9], labels=["low (<1/wk)", "mid (1-2.5/wk)", "high (>2.5/wk)"])
    o["recent_failure"] = np.where(o.wks_since_fail <= 4, "failed within 4 wks", np.where(o.wks_since_fail <= 13, "failed 5-13 wks ago", "no failure in 13+ wks"))
    o["recent_rejections"] = np.where(o.rej_4wk > 0, "rejections in last 4 wks", "no rejections in last 4 wks")
    o["banquet"] = np.where(o.banquet_flag == 1, "banquet week", "no banquet")
    o["corrective_action"] = np.where(o.open_cap == 1, "open corrective action", "none open")
    return o


def mark_list(o):
    flag = np.zeros(len(o), bool)
    for t, g in o.groupby("t"):
        g = g[g.addressable]
        k = int(g.review_capacity_k.iloc[0]) if len(g) else 0
        flag[o.index.get_indexer(g.sort_values("p", ascending=False).index[:k])] = True
    o["on_list"] = flag
    return o


SEGS = [("category_id", "Vendor category"), ("season", "Season"), ("size_band", "Vendor size"), ("volume", "Delivery volume"),
        ("corrective_action", "Corrective action"), ("thin", "History length (deliveries in last 13 wks)"),
        ("recent_failure", "Recent failure"), ("recent_rejections", "Recent rejections"), ("banquet", "Banquet this week")]


def seg_table(o):
    rows = []
    tot_cost_addr = o[o.addressable].real_cost.sum()
    for col, title in SEGS:
        for lv, g in o.groupby(col, observed=True):
            n, f, e = len(g), int(g.y.sum()), g.p.sum()
            lo = stats.chi2.ppf(.025, 2 * f) / 2 / e if f > 0 else 0.0
            hi = stats.chi2.ppf(.975, 2 * f + 2) / 2 / e
            auc = roc_auc_score(g.y, g.p) if (f >= 8 and f < n) else np.nan
            ga = g[g.addressable]
            cost_seg = ga.real_cost.sum()
            cost_cap = ga[ga.on_list].real_cost.sum()
            f_list = int(g[g.on_list].y.sum())
            rows.append(dict(segment=title, level=str(lv), rows=n, share_rows=n / len(o), failures=f, obs=f / n, pred=float(g.p.mean()), oe=f / e, oe_lo=lo, oe_hi=hi,
                             auc=auc, on_list=float(g.on_list.mean()), fails_on_list=f_list, catch=(f_list / f if f else np.nan),
                             cost_share=cost_seg / tot_cost_addr if tot_cost_addr else np.nan, cost_captured=(cost_cap / cost_seg if cost_seg else np.nan),
                             cost_total=float(cost_seg)))
    return pd.DataFrame(rows)


oof = add_segments(oof)
oof = mark_list(oof)
T = seg_table(oof)
overall_catch = oof[oof.on_list].y.sum() / oof.y.sum()
overall_addr_catch = oof[oof.addressable & oof.on_list].y.sum() / oof[oof.addressable].y.sum()
say("WEEK 11 ERROR ANALYSIS (development, rolling out-of-fold 2024-2025)")
say("=" * 130)
say(f"Rows {len(oof)}, failures {int(oof.y.sum())}, overall observed {oof.y.mean():.2%}, predicted {oof.p.mean():.2%}; "
    f"{int(oof.on_list.sum())} rows on the weekly lists; failures on lists {overall_catch:.1%} of all failures "
    f"({overall_addr_catch:.1%} of failures at vendors that are eligible for review).")
pd.set_option("display.width", 250)
cols = ["level", "rows", "failures", "obs", "pred", "oe", "oe_lo", "oe_hi", "auc", "on_list", "catch", "cost_share", "cost_captured"]
fmt = {"obs": "{:.3f}", "pred": "{:.3f}", "oe": "{:.2f}", "oe_lo": "{:.2f}", "oe_hi": "{:.2f}", "auc": "{:.2f}", "on_list": "{:.2f}", "catch": "{:.2f}",
       "cost_share": "{:.2f}", "cost_captured": "{:.2f}"}
for title, g in T.groupby("segment", sort=False):
    say(f"\n{title}")
    say(g[cols].to_string(index=False, formatters={k: (lambda x, f=f: ("" if pd.isna(x) else f.format(x))) for k, f in fmt.items()}))

# ---- automatic flags -> implications
say("\n" + "=" * 130 + "\nFLAGS (development)")
flags = []
for _, r in T.iterrows():
    if r.failures >= 8 and (r.oe_lo > 1 or r.oe_hi < 1):
        flags.append(dict(kind="calibration", segment=r.segment, level=r.level, text=f"{r.level}: observed/predicted = {r.oe:.2f} (95% {r.oe_lo:.2f}-{r.oe_hi:.2f}), "
                          f"{'under' if r.oe > 1 else 'over'}-predicts"))
    if r.failures >= 15 and r.catch < overall_catch - 0.15 and r.on_list < 0.2:
        flags.append(dict(kind="coverage", segment=r.segment, level=r.level, text=f"{r.level}: list catches {r.catch:.0%} of its failures vs {overall_catch:.0%} overall "
                          f"({r.failures} failures)"))
    if r.failures >= 15 and r.catch > overall_catch + 0.15:
        flags.append(dict(kind="strength", segment=r.segment, level=r.level, text=f"{r.level}: list catches {r.catch:.0%} (vs {overall_catch:.0%}) of {r.failures} failures"))
for f in flags:
    say(f"  [{f['kind']:11s}] {f['segment']}: {f['text']}")

# ---- thin history & the zero-failure pattern
thin = T[T.segment.str.startswith("History")]
say("\nThin history: vendor-weeks with few recent deliveries have very few failures (nothing to fail on), so a high probability is rarely right there.")
# ---- is miscalibration in some segments just that mean-level drift? per-block observed/expected
blk = oof.groupby("block").agg(obs=("y", "sum"), exp=("p", "sum"))
blk["oe"] = blk.obs / blk.exp
say("\nObserved / expected failures by quarter:  " + "  ".join(f"{2024 + b // 4}Q{b % 4 + 1}={r.oe:.2f}" for b, r in blk.iterrows()))

# ---- week-level peak vs off-peak
oof["peak"] = np.where(oof.season == "peak", "peak weeks", "other weeks")
pk = {}
for lv, g in oof.groupby("peak"):
    pk[lv] = dict(rows=len(g), failures=int(g.y.sum()), obs=float(g.y.mean()), pred=float(g.p.mean()), catch=float(g[g.on_list].y.sum() / max(g.y.sum(), 1)),
                  k=float(g.groupby("t").review_capacity_k.first().mean()), elig=float(g[g.addressable].groupby("t").size().mean()))
say("\nPeak vs other weeks (list size k is smaller in peak weeks, when the team is busiest):")
for lv, r in pk.items():
    say(f"  {lv:12s} rows={r['rows']} failures={r['failures']} obs={r['obs']:.3f} pred={r['pred']:.3f} mean k={r['k']:.1f} of {r['elig']:.0f} eligible vendors, failures caught={r['catch']:.0%}")

# ---- 2026 for persistence only
val = add_segments(val)
val["addressable"] = val.open_cap.values == 0
val = mark_list(val)
real = L["d"].set_index(["vendor_id", "t"]).real_cost
val["real_cost"] = [real.get((v, t)) for v, t in zip(val.vendor_id, val.t)]
T26 = seg_table(val)
say("\n" + "=" * 130 + "\n2026 (frozen Week 10 model) -- persistence check only; no Week 11 decision reads this table")
for title, g in T26.groupby("segment", sort=False):
    say(f"\n{title}")
    say(g[cols].to_string(index=False, formatters={k: (lambda x, f=f: ("" if pd.isna(x) else f.format(x))) for k, f in fmt.items()}))

out = dict(dev=T.replace({np.nan: None}).to_dict("records"), val2026=T26.replace({np.nan: None}).to_dict("records"), flags=flags,
           overall=dict(rows=len(oof), failures=int(oof.y.sum()), obs=float(oof.y.mean()), pred=float(oof.p.mean()), catch_all=float(overall_catch),
                        catch_eligible=float(overall_addr_catch)),
           quarter_oe={f"{2024 + b // 4}Q{b % 4 + 1}": float(r.oe) for b, r in blk.iterrows()}, peak=pk)
with open(os.path.join(D, "wk11_error_analysis.json"), "w") as f:
    json.dump(out, f, indent=1, default=float)
with open(os.path.join(HERE, "..", "docs", "wk11_error_analysis.txt"), "w") as f:
    f.write("\n".join(LOG))
say("\nWrote data/wk11_error_analysis.json and docs/wk11_error_analysis.txt")
