"""
Week 10 step 4 -- assemble the single-file app.

Inputs : app/src/style.css, body.html, 01_core.js .. 05_main.js, data/app_data.json
Outputs: app/index.html          standalone page (open in any browser, works offline; fonts are embedded)
         app/artifact_page.html  the same page without doctype/html/head/body, for publishing as a hosted artifact
Everything (data, model, charts) is inline: the page needs no server and makes no network calls.
"""
import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "app", "src")
OUT = os.path.join(HERE, "..", "app")
rd = lambda p: open(p, encoding="utf-8").read()

css = rd(os.path.join(SRC, "style.css"))
body = rd(os.path.join(SRC, "body.html"))
js = "\n".join(rd(p) for p in sorted(glob.glob(os.path.join(SRC, "0*.js"))))
data = json.dumps(json.load(open(os.path.join(HERE, "..", "data", "app_data.json"))), separators=(",", ":")).replace("<", "\\u003c")

# Inter (SIL Open Font License, see app/src/fonts/LICENSE_Inter.txt) is embedded so the page needs no network request for fonts.
import base64
FONTS = [("Inter", 400, "Inter-Regular.woff"), ("Inter", 500, "Inter-Medium.woff"), ("Inter", 600, "Inter-SemiBold.woff"), ("Inter Display", 600, "InterDisplay-SemiBold.woff")]
font_css = "\n".join(
    "@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:swap;src:url(data:font/woff;base64,%s) format('woff')}"
    % (fam, wt, base64.b64encode(open(os.path.join(SRC, "fonts", fn), "rb").read()).decode())
    for fam, wt, fn in FONTS)
head = f'''<title>Vendor Failure Forecast</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>
{font_css}
{css}
</style>
'''
content = f'''{head}
{body}
<script type="application/json" id="app-data">{data}</script>
<script>
{js}
</script>
'''
open(os.path.join(OUT, "artifact_page.html"), "w", encoding="utf-8").write(content)
standalone = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
{head}</head>
<body>
{body}
<script type="application/json" id="app-data">{data}</script>
<script>
{js}
</script>
</body>
</html>
'''
open(os.path.join(OUT, "index.html"), "w", encoding="utf-8").write(standalone)
for n in ("index.html", "artifact_page.html"):
    print(f"{n}: {os.path.getsize(os.path.join(OUT, n)) / 1024:.0f} KB")
