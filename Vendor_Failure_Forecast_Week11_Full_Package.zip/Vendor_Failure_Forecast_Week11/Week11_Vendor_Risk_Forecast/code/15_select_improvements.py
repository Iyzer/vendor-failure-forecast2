"""
Week 11 step -- choose model improvements using DEVELOPMENT data only (2023-2025).

Screening script written by Debra Senteu and shared with the team on 1 Nov 2026 (kept here as she wrote it, with one change by Mirza noted below).

CHANGE BY MIRZA: LAM_CAT and LAM_V are now read from data/model_params.json. The original hard-coded LAM_CAT = 1.0 with the comment "Week 10's selected
pooling strength", but the fitted Week 10 model uses lam_cat = 0.01 (docs/model_report_wk10.txt, CV log loss 0.1603). With 1.0 the Week 10 baseline
log loss in this screen was 0.1607; with the fitted value it is 0.1603. The decisions (keep W10 for KPI 1; her B for KPI 2) are the same either way.
The Week 11 eight-block test of the same two ideas (candidates J and K in 22_wk11_improvements.py) reaches a different decision on B: see the report, section 5.

The 2026 holdout is never read here. Each candidate is compared with the Week 10 model
on the same rolling-origin folds used in Week 10 (train 2023 -> test 2024,
train 2023-24 -> test 2025). The selection rules were written before this ran:

KPI 1 (failure probability)
  W10  : category + vendor + estimated exposure elasticity g on log(trailing 13-wk deliveries/wk) + rej_4wk + rej_13wk
  A    : same predictors, but exposure enters as a fixed offset (g = 1) on an as-of
         exposure estimate shrunk toward the training-fold category mean
         (EXPOSURE_SHRINK_WEEKS pseudo-weeks, as in the Week 9 model)
  Rule : keep A only if it is no worse on mean CV log-loss AND better on mean CV
         addressable cost captured in the weekly top-k. Otherwise keep W10.

KPI 2 (cost of a failing vendor-week)
  C0   : constant (training-fold mean)                      -- the simple baseline
  W10  : occupancy + banquet of the failure week
  B    : W10 + category intercepts
  Rule : keep B only if it lowers mean CV mean absolute error versus W10.
         C0 is reported so the brief's baseline comparison is on record.

Output: docs/improvement_selection_wk11.txt
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from modeling_common import *  # noqa: F401,F403

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "..", "data")
EXPOSURE_SHRINK_WEEKS = 4.0
LOG = []


def say(s=""):
    LOG.append(s)
    print(s)


d = pd.read_csv(os.path.join(D, "model_table.csv"))
dev = d[d.data_split == "dev"].reset_index(drop=True)          # 2026 rows dropped before anything else
assert (dev.data_split == "dev").all()
src = lambda n: pd.read_csv(os.path.join(D, "source", n))
cal = src("dim_calendar_week.csv").sort_values("week_start_monday").reset_index(drop=True)
cal["t"] = np.arange(len(cal))
dem = src("fact_demand_week.csv").merge(cal[["week_id", "t", "data_split", "iso_year"]], on="week_id")
fail = src("fact_failure_event.csv").merge(cal[["week_id", "t", "data_split", "iso_year"]], on="week_id")
fail = fail[fail.data_split == "dev"]
fail["total_cost"] = fail[["emergency_premium", "lost_contribution_margin", "guest_compensation", "firefighting_labor"]].sum(axis=1)
realized = fail.groupby(["vendor_id", "t"]).total_cost.sum()
dev["real_cost"] = [realized.get((v, t + 1), 0.0) for v, t in zip(dev.vendor_id, dev.t)]
vendors = vendor_list(d)
folds = [("2023 -> 2024", dev[dev.iso_year == 2023], dev[dev.iso_year == 2024]),
         ("2023-24 -> 2025", dev[dev.iso_year <= 2024], dev[dev.iso_year == 2025])]
import json
_P10 = json.load(open(os.path.join(D, "model_params.json")))
LAM_CAT, LAM_V = _P10["lam_cat"], _P10["lam_v"]          # Week 10's fitted pooling strength (step 11): lam_cat 0.01, lam_v 8
rng = np.random.default_rng(SEED)


def shrunk_exposure(tr, te):
    cat_mean = tr.groupby("category_id").exposure_wk.mean()
    out = []
    for df in (tr, te):
        prior = df.category_id.map(cat_mean).values
        out.append((df.trailing_13wk_delivery_count.values + EXPOSURE_SHRINK_WEEKS * prior) / (13.0 + EXPOSURE_SHRINK_WEEKS))
    return out


def capture(te, p):
    cc = tc = 0.0
    g_all = te.assign(score=p)
    for t, g in g_all.groupby("t"):
        k = int(g.review_capacity_k.iloc[0])
        g = g[g.open_cap == 0]
        s = g.score.values + rng.random(len(g)) * 1e-9
        cc += g.real_cost.values[np.argsort(-s)[:k]].sum()
        tc += g.real_cost.sum()
    return cc / tc


say("WEEK 11 IMPROVEMENT SELECTION -- development data only (2026 holdout not read)")
say("=" * 78)
say("\nKPI 1  failure probability")
res = {"W10": [], "A": []}
for name, tr, te in folds:
    m = fit_glm(tr, FEATS, vendors, LAM_CAT, LAM_V, 1.0)
    p = predict(m, te)
    res["W10"].append(dict(metrics(te.y.values, p), capture=capture(te, p)))
    tr2, te2 = tr.copy(), te.copy()
    tr2["exposure_wk"], te2["exposure_wk"] = shrunk_exposure(tr, te)
    m = fit_glm(tr2, ["rej_4wk", "rej_13wk"], vendors, LAM_CAT, LAM_V, 1.0, use_offset=True)
    p = predict(m, te2)
    res["A"].append(dict(metrics(te.y.values, p), capture=capture(te, p)))
summ = {}
for k, rows in res.items():
    summ[k] = {m_: float(np.mean([r[m_] for r in rows])) for m_ in rows[0]}
    say(f"  {k:4s} " + "  ".join(f"{m_}={v:.4f}" for m_, v in summ[k].items())
        + "   per fold capture: " + ", ".join(f"{r['capture']:.1%}" for r in rows))
keepA = summ["A"]["logloss"] <= summ["W10"]["logloss"] and summ["A"]["capture"] > summ["W10"]["capture"]
say(f"  DECISION: {'adopt A (fixed offset on shrunk exposure)' if keepA else 'keep W10 (estimated elasticity)'}")

say("\nKPI 2  cost of a failing vendor-week")
vw = fail.groupby(["vendor_id", "t"], as_index=False).total_cost.sum()
vw = vw.merge(dem[["t", "occupancy_rate", "banquet_flag", "iso_year"]], on="t").merge(src("dim_vendor.csv")[["vendor_id", "category_id"]], on="vendor_id")


def design(df, with_cat):
    cols = [np.ones(len(df)), df.occupancy_rate.values, df.banquet_flag.astype(float).values]
    if with_cat:
        cols += [(df.category_id == c).astype(float).values for c in CATS[1:]]    # produce = reference
    return np.column_stack(cols)


err = {"C0": [], "W10": [], "B": []}
for name, yrs_tr, yr_te in [("2023 -> 2024", [2023], 2024), ("2023-24 -> 2025", [2023, 2024], 2025)]:
    tr, te = vw[vw.iso_year.isin(yrs_tr)], vw[vw.iso_year == yr_te]
    err["C0"].append(np.mean(np.abs(te.total_cost - tr.total_cost.mean())))
    for k, wc in (("W10", False), ("B", True)):
        b = np.linalg.lstsq(design(tr, wc), tr.total_cost.values, rcond=None)[0]
        err[k].append(np.mean(np.abs(te.total_cost.values - design(te, wc) @ b)))
for k, v in err.items():
    say(f"  {k:4s} mean CV MAE ${np.mean(v):,.0f}   per fold: " + ", ".join(f"${x:,.0f}" for x in v))
keepB = np.mean(err["B"]) < np.mean(err["W10"])
say(f"  DECISION: {'adopt B (add category)' if keepB else 'keep W10 (occupancy + banquet)'}")
say(f"  note: within a week, cost under W10 is identical for every vendor, so W10's cost term cannot change the review ranking; under B it can.")

say("\n  NOTE (added by Mirza): this is a two-fold screen with the rule 'lower is better'. The same two ideas were then run on the eight 13-week blocks with a")
say("  stated keep rule (candidates J and K in 22_wk11_improvements.py, docs/wk11_improvements_log.txt). There the category cost model is not adopted: its")
say("  advantage is too small and inconsistent across blocks, and pricing the list by category lowers the cost held in the list. The Week 10 model is unchanged.")

os.makedirs(os.path.join(HERE, "..", "docs"), exist_ok=True)
open(os.path.join(HERE, "..", "docs", "improvement_selection_wk11.txt"), "w").write("\n".join(LOG) + "\n")
