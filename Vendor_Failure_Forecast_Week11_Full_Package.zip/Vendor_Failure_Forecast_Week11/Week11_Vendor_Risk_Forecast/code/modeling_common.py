"""Shared helpers for the Week 10 pipeline: design matrices, feature config, metrics, cost model."""
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, log_loss, brier_score_loss, average_precision_score

import glm_cloglog as G

CATS = ["produce", "protein", "dairy_bakery", "nonalc_beverage", "linen_laundry", "guest_amenities", "mro"]
FEATS = ["log_exposure", "rej_4wk", "rej_13wk"]       # exposure elasticity + the behavioural predictors that earned a place
LAM_INT = 1e-6
SEED = 20261026


def vendor_list(df_all):
    return sorted(df_all.vendor_id.unique())


def build_design(df, feats, scaler, vendors, use_vendor=True, use_cat=True):
    cols, names = [np.ones(len(df))], ["intercept"]
    if use_cat:
        for c in CATS:
            cols.append((df.category_id == c).astype(float).values)
            names.append("cat:" + c)
    if use_vendor:
        for v in vendors:
            cols.append((df.vendor_id == v).astype(float).values)
            names.append("v:" + v)
    for f in feats:
        cols.append((df[f].astype(float).values - scaler[f][0]) / scaler[f][1])
        names.append(f)
    return np.column_stack(cols), names


def make_scaler(df, feats):
    return {f: (float(df[f].astype(float).mean()), float(df[f].astype(float).std() or 1.0)) for f in feats}


def lam_vector(names, lam_cat, lam_v, lam_b):
    out = []
    for n in names:
        if n == "intercept":
            out.append(LAM_INT)
        elif n.startswith("cat:"):
            out.append(lam_cat)
        elif n.startswith("v:"):
            out.append(lam_v)
        else:
            out.append(lam_b)
    return np.array(out)


def fit_glm(tr, feats, vendors, lam_cat, lam_v, lam_b=1.0, use_vendor=True, use_cat=True, use_offset=False, weights=None):
    scaler = make_scaler(tr, feats)
    X, names = build_design(tr, feats, scaler, vendors, use_vendor, use_cat)
    off = np.log(tr.exposure_wk.values) if use_offset else np.zeros(len(tr))
    lam = lam_vector(names, lam_cat, lam_v, lam_b)
    beta, cov, info = G.fit(X, tr.y.values, off, lam, w=weights)
    return dict(beta=beta, cov=cov, names=names, scaler=scaler, feats=feats, vendors=vendors, lam=lam, info=info,
                use_vendor=use_vendor, use_cat=use_cat, use_offset=use_offset)


def predict(model, df, return_eta=False):
    X, _ = build_design(df, model["feats"], model["scaler"], model["vendors"], model["use_vendor"], model["use_cat"])
    off = np.log(df.exposure_wk.values) if model["use_offset"] else np.zeros(len(df))
    eta = off + X @ model["beta"]
    p = G._mu_p(eta)[1]
    return (p, eta, X) if return_eta else p


def metrics(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return dict(logloss=float(log_loss(y, p)), brier=float(brier_score_loss(y, p)),
                auc=float(roc_auc_score(y, p)), ap=float(average_precision_score(y, p)))


def week_bootstrap_idx(weeks, n_boot, rng):
    """Cluster bootstrap: resample whole weeks (rows within a week share shocks)."""
    uw = np.unique(weeks)
    groups = {w: np.where(weeks == w)[0] for w in uw}
    for _ in range(n_boot):
        pick = rng.choice(uw, size=len(uw), replace=True)
        yield np.concatenate([groups[w] for w in pick])


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    ph = k / n
    den = 1 + z * z / n
    c = (ph + z * z / (2 * n)) / den
    h = z * np.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
    return (c - h, c + h)


# ------------------------------------------------------------------ failure-cost model
# Mean cost per material failure = OLS of total cost (the 4 components of C19 summed) on the demand context of the
# week in which the failure happens (G22: costs are computed from that week's demand row). Heteroskedasticity-robust
# covariance. Individual-failure uncertainty uses the empirical distribution of cost / fitted-mean from the
# development failures (heavy right tail preserved; no normality assumption).
def fit_cost_model(fails):
    X = np.column_stack([np.ones(len(fails)), fails.occupancy_rate.values, fails.banquet_flag.astype(float).values])
    y = fails.total_cost.values
    XtXi = np.linalg.inv(X.T @ X)
    beta = XtXi @ X.T @ y
    r = y - X @ beta
    meat = (X * (r ** 2)[:, None]).T @ X
    cov = XtXi @ meat @ XtXi * len(y) / (len(y) - X.shape[1])          # HC1
    ratio = np.sort(y / (X @ beta))
    qs = np.percentile(ratio, np.arange(0, 101, 1))
    return dict(names=["intercept", "occupancy", "banquet"], beta=beta, cov=cov, n=len(y), ratio_q=qs, ratio=ratio)


def expected_cost(cm, occupancy, banquet):
    return float(cm["beta"] @ np.array([1.0, occupancy, float(banquet)]))
