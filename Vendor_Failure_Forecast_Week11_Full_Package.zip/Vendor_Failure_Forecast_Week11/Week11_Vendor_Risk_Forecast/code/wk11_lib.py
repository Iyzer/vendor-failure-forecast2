"""
Week 11 shared tools: data loading, rolling-origin folds on the 2023-2025 development data, per-week top-k capture,
cost-model helpers and bootstrap intervals.

Why rolling-origin on quarters
------------------------------
Week 10 selected its configuration with two yearly folds (train 2023 -> test 2024, train 2023-24 -> test 2025). Week 11 asks for
error analysis and improvement choices that never touch the 2026 holdout, so everything here uses only 2023-2025 and a finer
walk-forward scheme: eight 13-week test blocks (2024 Q1 .. 2025 Q4). Each block is predicted by a model trained only on rows whose
label was already known on the block's first Monday. A row for week t has its label (a failure in week t+1) known from Monday of
week t+2, so the training set for a block starting at week a is {rows with t <= a-2}. That is exactly what a manager using the tool
in real time would have had.
"""
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from modeling_common import *          # noqa: F401,F403  (CATS, FEATS, fit_glm, predict, metrics, fit_cost_model, expected_cost, ...)

D = os.path.join(HERE, "..", "data")
FIRST_TEST_T = 52                      # 2024-W01; dev weeks are t = 0..155
BLOCK = 13


def src(name):
    return pd.read_csv(os.path.join(D, "source", name))


def load():
    d = pd.read_csv(os.path.join(D, "model_table.csv"))
    d["banquet_flag"] = d.banquet_flag.astype(int)
    cal = src("dim_calendar_week.csv").sort_values("week_start_monday").reset_index(drop=True)
    cal["t"] = np.arange(len(cal))
    dem = src("fact_demand_week.csv").merge(cal[["week_id", "t"]], on="week_id")
    vend = src("dim_vendor.csv")
    fail = src("fact_failure_event.csv").merge(cal[["week_id", "t", "data_split"]], on="week_id").merge(
        vend[["vendor_id", "category_id", "size_band"]], on="vendor_id")
    fail["total_cost"] = fail[["emergency_premium", "lost_contribution_margin", "guest_compensation", "firefighting_labor"]].sum(axis=1)
    realized = fail.groupby(["vendor_id", "t"]).total_cost.sum()
    d["real_cost"] = [realized.get((v, t + 1), 0.0) for v, t in zip(d.vendor_id, d.t)]
    d["addressable"] = d.open_cap.values == 0
    # failing vendor-weeks (the unit of the cost model): summed cost of all events that vendor had that week
    vw = fail.groupby(["vendor_id", "t", "week_id", "data_split", "category_id", "size_band"], as_index=False).agg(
        total_cost=("total_cost", "sum"), n_events=("total_cost", "size"))
    vw = vw.merge(dem[["t", "occupancy_rate", "banquet_flag"]], on="t", how="left")
    return dict(d=d, cal=cal, dem=dem, vend=vend, fail=fail, vw=vw)


def blocks(t_min, t_max, block=BLOCK):
    """Test blocks [a, b) covering weeks t_min .. t_max."""
    a = t_min
    while a <= t_max:
        yield a, min(a + block, t_max + 1)
        a += block


def rolling_folds(dev):
    """Yield (a, b, train_rows, test_rows) for the eight 2024-2025 quarterly blocks. Train = labels known by Monday a (t <= a-2)."""
    for a, b in blocks(FIRST_TEST_T, int(dev.t.max())):
        yield a, b, dev[dev.t <= a - 2], dev[(dev.t >= a) & (dev.t < b)]


def topk_by_week(df, score, k_col="review_capacity_k", rng=None, jitter=1e-9, jit_reps=1, only_addressable=True):
    """
    For every week: take the k highest-scoring addressable vendors (k = that week's review capacity), sum the realised next-week
    failure cost and failure count inside the list. `score` is a column name, a callable(df_week) -> array, or None for a random list
    (exact expectation: each eligible vendor is on the list with probability k / n_eligible). Ties are broken at random; for coarse
    rule-based scores (jitter=1e-4, jit_reps=40) the list is averaged over 40 tie-break draws, as in Week 10.
    Returns one row per week: t, k, n_elig, cap_c, tot_c, cap_n, tot_n.
    """
    rng = rng or np.random.default_rng(1)
    out = []
    for t, g_all in df.groupby("t"):
        g = g_all[g_all.addressable] if only_addressable else g_all
        k = int(g_all[k_col].iloc[0])
        tc, tn = g.real_cost.sum(), g.y.sum()
        if score is None:
            share = min(1.0, k / max(len(g), 1))
            cc, cn = share * tc, share * tn
        else:
            sc = (score(g) if callable(score) else g[score].values).astype(float)
            cs, ns = [], []
            for _ in range(jit_reps):
                j = np.argsort(-(sc + rng.random(len(sc)) * jitter))[:k]
                cs.append(g.real_cost.values[j].sum())
                ns.append(g.y.values[j].sum())
            cc, cn = float(np.mean(cs)), float(np.mean(ns))
        out.append(dict(t=int(t), k=k, n_elig=len(g), cap_c=float(cc), tot_c=float(tc), cap_n=float(cn), tot_n=float(tn)))
    return pd.DataFrame(out)


def capture_summary(pw, rng, n_boot=2000):
    """Pooled capture share of cost / failures with a week-level bootstrap 95% interval."""
    est_c = pw.cap_c.sum() / pw.tot_c.sum()
    est_n = pw.cap_n.sum() / pw.tot_n.sum()
    n = len(pw)
    bc, bn = [], []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        bc.append(pw.cap_c.values[i].sum() / max(pw.tot_c.values[i].sum(), 1e-9))
        bn.append(pw.cap_n.values[i].sum() / max(pw.tot_n.values[i].sum(), 1e-9))
    return dict(cost=float(est_c), cost_ci=[float(np.percentile(bc, 2.5)), float(np.percentile(bc, 97.5))],
                fail=float(est_n), fail_ci=[float(np.percentile(bn, 2.5)), float(np.percentile(bn, 97.5))])


def paired_diff(pw_a, pw_b, rng, n_boot=2000, col=("cap_c", "tot_c")):
    """Difference in pooled capture (a - b) with a paired week-level bootstrap interval."""
    n = len(pw_a)
    f = lambda pw, i: pw[col[0]].values[i].sum() / max(pw[col[1]].values[i].sum(), 1e-9)
    full = np.arange(n)
    est = f(pw_a, full) - f(pw_b, full)
    bs = []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        bs.append(f(pw_a, i) - f(pw_b, i))
    return float(est), [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def cal_slope_shift(p, y):
    """Calibration slope and calibration-in-the-large on the cloglog scale (as in Week 10)."""
    import glm_cloglog as G
    cl = np.log(-np.log1p(-np.clip(p, 1e-9, 1 - 1e-9)))
    X = np.column_stack([np.ones(len(p)), cl - cl.mean()])
    b, cov, _ = G.fit(X, y, np.zeros(len(p)), np.array([1e-9, 1e-9]))
    bs, cs, _ = G.fit(np.ones((len(p), 1)), y, cl, np.array([1e-9]))
    return dict(slope=float(b[1]), slope_se=float(np.sqrt(cov[1, 1])), shift=float(bs[0]), shift_se=float(np.sqrt(cs[0, 0])))


def season_of(t, cal):
    return cal.set_index("t").loc[t, "season_label"]


# ====================================================================== model + baseline predictions used by Week 11 scripts
import json
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, average_precision_score

P10 = json.load(open(os.path.join(D, "model_params.json")))          # frozen Week 10 hyper-parameters (lam_v=8, lam_cat=0.01)
GCOLS = ["exposure_wk", "rej_4wk", "rej_13wk", "late_4wk", "late_13wk", "short_4wk", "short_13wk", "fail_13wk", "fail_52wk",
         "wks_since_fail", "occupancy_rate", "banquet_flag"]
VEND_SHRINK = 26.0               # vendor-history baseline: own failure rate, pulled to its category rate with a 26-week prior


def gbm_frame(df):
    X = df[GCOLS].copy()
    X["cat"] = df.category_id.map({c: i for i, c in enumerate(CATS)})
    return X


def fit_gbm(tr):
    return HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=150, l2_regularization=5.0, min_samples_leaf=60,
                                          categorical_features=[len(GCOLS)], random_state=SEED).fit(gbm_frame(tr), tr.y.values)


def simple_baselines(tr, te):
    """Probability baselines that use no model: constant rate, category rate, vendor's own (smoothed) history."""
    p0 = float(tr.y.mean())
    cr = tr.groupby("category_id").y.mean()
    p_cat = te.category_id.map(cr).fillna(p0).values
    g = tr.groupby("vendor_id").y.agg(["sum", "size"])
    vc = tr.groupby("vendor_id").category_id.first().map(cr)
    pv = ((g["sum"] + VEND_SHRINK * vc) / (g["size"] + VEND_SHRINK))
    p_vend = te.vendor_id.map(pv).fillna(pd.Series(te.category_id.map(cr).values, index=te.index)).values
    return dict(p_const=np.full(len(te), p0), p_cat=p_cat, p_vend=p_vend)


def predict_all(tr, te, vendors, with_gbm=True):
    """GLM (Week 10 configuration) + simple baselines + GBM, trained on `tr`, scored on `te`."""
    m = fit_glm(tr, FEATS, vendors, P10["lam_cat"], P10["lam_v"], 1.0)
    m0 = fit_glm(tr, ["log_exposure"], vendors, P10["lam_cat"], P10["lam_v"], 1.0)           # ablation: no rejection rates
    out = dict(p=predict(m, te), p_nobeh=predict(m0, te), **simple_baselines(tr, te))
    if with_gbm:
        out["p_gbm"] = fit_gbm(tr).predict_proba(gbm_frame(te))[:, 1]
    return out, m


def rank_scores(df):
    """Ranking-only scores (not probabilities): what a manager would do without the model."""
    return dict(
        practice=np.where(df.wks_since_fail <= 2, 100.0, 0.0) + df.late_13wk.values + df.short_13wk.values,   # loud failure jumps the queue
        trailing_rej=df.rej_13wk.values + 0.001 * df.rej_4wk.values,
        volume=df.exposure_wk.values)


def oof_table(dev, vendors, with_gbm=True):
    """Rolling-origin out-of-fold predictions for 2024-2025 (eight 13-week blocks)."""
    parts = []
    for a, b, tr, te in rolling_folds(dev):
        o, _ = predict_all(tr, te, vendors, with_gbm)
        te = te.copy()
        te["block"] = (a - FIRST_TEST_T) // BLOCK
        for k, v in o.items():
            te[k] = v
        for k, v in rank_scores(te).items():
            te["s_" + k] = v
        parts.append(te)
    return pd.concat(parts).reset_index(drop=True)
