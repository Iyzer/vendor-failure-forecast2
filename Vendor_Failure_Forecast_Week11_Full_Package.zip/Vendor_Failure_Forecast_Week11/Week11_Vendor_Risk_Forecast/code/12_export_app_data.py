"""
Week 10 step 3 -- export the fitted model and the 2026 scoring rows as one compact JSON for the app.

The app recomputes every prediction in the browser from the exported coefficients and posterior covariance
(eta = x'beta, Var(eta) = x'Sigma x), so a what-if edit re-scores instantly and the numbers can be checked against
Python. This script also writes parity cases (inputs -> Python outputs) that the QA step replays in the browser.

Output: data/app_data.json
"""
import json
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glm_cloglog as G
from modeling_common import *

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "..", "data")
P = json.load(open(os.path.join(D, "model_params.json")))
E = json.load(open(os.path.join(D, "model_eval.json")))
src = lambda n: pd.read_csv(os.path.join(D, "source", n))

CAT_LABEL = {"produce": "Produce", "protein": "Protein", "dairy_bakery": "Dairy & bakery", "nonalc_beverage": "Non-alcoholic beverage",
             "linen_laundry": "Linen & laundry", "guest_amenities": "Guest amenities", "mro": "MRO supplies"}
beta = np.array(P["beta"])
cov = np.array(P["cov"])
names = P["names"]
vendors = P["vendors"]
feats = P["feats"]
scaler = P["scaler"]
zcap = {c: v["delta"] for c, v in P.get("zero_event_cap", {}).items()}      # categories with no observed failures: upper tail clipped

dim_v = src("dim_vendor.csv").set_index("vendor_id")
sc = pd.read_csv(os.path.join(D, "scoring_table_2026.csv"))
cal = src("dim_calendar_week.csv").sort_values("week_start_monday").reset_index(drop=True)
cal["t"] = np.arange(len(cal))
fail = src("fact_failure_event.csv").merge(cal[["week_id", "t"]], on="week_id")
fail["total_cost"] = fail[["emergency_premium", "lost_contribution_margin", "guest_compensation", "firefighting_labor"]].sum(axis=1)
realized = fail.groupby(["vendor_id", "t"]).total_cost.sum()
dev = pd.read_csv(os.path.join(D, "model_table.csv"))
dev = dev[dev.data_split == "dev"]

weeks = sc.drop_duplicates("week_id").sort_values("t")
week_ids = weeks.week_id.tolist()
W = len(week_ids)
V = len(vendors)
assert len(sc) == W * V

sc["wi"] = sc.week_id.map({w: i for i, w in enumerate(week_ids)})
sc["vi"] = sc.vendor_id.map({v: i for i, v in enumerate(vendors)})
sc = sc.sort_values(["wi", "vi"]).reset_index(drop=True)
sc["next_cost"] = [realized.get((v, t + 1), 0.0) for v, t in zip(sc.vendor_id, sc.t)]
last_t = int(sc.t.max())
dem_all = src("fact_demand_week.csv").merge(cal[["week_id", "t"]], on="week_id").set_index("t")
# exact counts behind the rates (Week 11: the what-if inputs are whole numbers; rates are derived from them)
sc["n13"] = sc.trailing_13wk_delivery_count.astype(int)
sc["n4"] = np.where(sc.no_delivery_4wk == 1, 0, sc.trailing_4wk_delivery_count).astype(int)
sc["r13"] = np.rint(sc.rej_13wk.fillna(0) * sc.n13).astype(int)
sc["r4"] = np.where(sc.n4 > 0, np.rint(sc.rej_4wk.fillna(0) * sc.n4), 0).astype(int)
_ok = sc.scored_flag == 1
# the source snapshot stores rates rounded to 4 decimals; the app derives rates from counts and rounds the same way, so the model sees identical inputs
assert (np.abs((sc.r13[_ok] / sc.n13[_ok]).round(4) - sc.rej_13wk[_ok]) < 1e-9).all(), "13-week rejection counts do not reproduce the stored rates"
assert (np.abs((sc.r4[_ok] / sc.n4[_ok].clip(lower=1)).round(4).where(sc.n4[_ok] > 0, sc.rej_13wk[_ok]) - sc.rej_4wk[_ok]) < 1e-9).all(), "4-week rejection counts do not reproduce the stored rates"
assert ((sc.r4 <= sc.r13) & (sc.n4 <= sc.n13) & (sc.r13 <= sc.n13) & (sc.r4 <= sc.n4) & ((sc.r13 - sc.r4) <= (sc.n13 - sc.n4)))[_ok].all(), "recorded counts violate the nesting rules"


def arr(col, nd=4, null_if=None):
    out = []
    for v, ok in zip(sc[col], sc.scored_flag):
        if null_if == "unscored" and not ok:
            out.append(None)
        elif pd.isna(v):
            out.append(None)
        else:
            out.append(round(float(v), nd))
    return out


out = dict(
    meta=dict(title="Vendor Failure Forecast", seed=P["seed"], dev_period="2023-W01 to 2025-W52", holdout_period="2026-W01 to 2026-W53",
              n_dev=E["n_dev"], n_val=E["n_val"], pos_dev=E["pos_dev"], pos_val=E["pos_val"],
              note="All data is synthetic (generator with declared 2026 parameter shift). Results describe the method, not real hotel performance."),
    cats=CATS, cat_labels=[CAT_LABEL[c] for c in CATS],
    lead=[int(src("dim_category.csv").set_index("category_id").loc[c, "qualification_lead_time_weeks"]) for c in CATS],
    model=dict(names=names, beta=[round(b, 6) for b in beta], cov=[[round(x, 7) for x in row] for row in cov],
               scaler=scaler, feats=feats, vendor_prior_sd=P["vendor_prior_sd"], zero_cap={c: round(d, 6) for c, d in zcap.items()}),
    cost=dict(beta=[round(x, 3) for x in P["cost_model"]["beta"]], cov=[[round(x, 3) for x in r] for r in P["cost_model"]["cov"]],
              ratio_q=P["cost_model"]["ratio_q"], mean_events=E["cost_eval"]["mean_events_per_failing_week"]),
    vendors=[dict(id=v, name=dim_v.loc[v, "vendor_name"].replace(" Vendor", ""), cat=CATS.index(dim_v.loc[v, "category_id"]),
                  size=dim_v.loc[v, "size_band"], local=bool(dim_v.loc[v, "local_flag"])) for v in vendors],
    weeks=[dict(id=r.week_id, t=int(r.t), season=r.season_label, occ=round(float(r.occupancy_rate), 4), banq=int(bool(r.banquet_flag)),
                occ_n=round(float(dem_all.loc[int(r.t) + 1].occupancy_rate if int(r.t) + 1 in dem_all.index else r.occupancy_rate), 4),
                banq_n=int(bool(dem_all.loc[int(r.t) + 1].banquet_flag if int(r.t) + 1 in dem_all.index else r.banquet_flag)),
                k=int(r.review_capacity_k), start=str(src("dim_calendar_week.csv").set_index("week_id").loc[r.week_id, "week_start_monday"]),
                w53=bool(src("dim_calendar_week.csv").set_index("week_id").loc[r.week_id, "is_week_53"])) for r in weeks.itertuples()],
    rows=dict(scored=[int(x) for x in sc.scored_flag], n13=[int(a) if ok else None for a, ok in zip(sc.n13, sc.scored_flag)],
              n4=[int(a) if ok else None for a, ok in zip(sc.n4, sc.scored_flag)], r13=[int(a) if ok else None for a, ok in zip(sc.r13, sc.scored_flag)],
              r4=[int(a) if ok else None for a, ok in zip(sc.r4, sc.scored_flag)], cap=[int(x) for x in sc.open_cap],
              y=[None if (pd.isna(y) or t == last_t) else int(y) for y, t in zip(sc.y, sc.t)],
              cost=[None if t == last_t else round(float(c), 0) for c, t in zip(sc.next_cost, sc.t)]),
    ranges={},
)
for c in CATS:
    g = dev[dev.category_id == c]
    out["ranges"][c] = dict(expo=[round(float(g.exposure_wk.quantile(.01)), 2), round(float(g.exposure_wk.quantile(.99)), 2)],
                            rej4=[0.0, round(float(g.rej_4wk.quantile(.99)), 3)], rej13=[0.0, round(float(g.rej_13wk.quantile(.99)), 3)],
                            expo_med=round(float(g.exposure_wk.median()), 2), n=int(len(g)),
                            n13=[int(g.trailing_13wk_delivery_count.quantile(.01)), int(g.trailing_13wk_delivery_count.quantile(.99))])

# ----------------------------------------------------------------- a typical-vendor table by category (CI via x'Sigma x)
sd_idx = {n: i for i, n in enumerate(names)}


def xvec(cat, vendor, log_exp, rej4, rej13):
    x = np.zeros(len(names))
    x[0] = 1
    x[sd_idx["cat:" + cat]] = 1
    if vendor is not None:
        x[sd_idx["v:" + vendor]] = 1
    for f, val in (("log_exposure", log_exp), ("rej_4wk", rej4), ("rej_13wk", rej13)):
        x[sd_idx[f]] = (val - scaler[f][0]) / scaler[f][1]
    return x


typ = []
for c in CATS:
    g = dev[dev.category_id == c]
    x = xvec(c, None, float(np.log(g.exposure_wk.median())), float(g.rej_4wk.mean()), float(g.rej_13wk.mean()))
    eta, se = float(x @ beta), float(np.sqrt(x @ cov @ x))
    f = lambda e: float(-np.expm1(-np.exp(e)))
    eta_hi = min(eta + 1.96 * se, eta + zcap[c]) if c in zcap else eta + 1.96 * se
    typ.append(dict(cat=c, label=CAT_LABEL[c], p=f(eta), lo=f(eta - 1.96 * se), hi=f(eta_hi), obs=float(g.y.mean()),
                    n=int(len(g)), fails=int(g.y.sum()), expo=float(g.exposure_wk.median())))
# effects per interpretable unit
effects = []
j = sd_idx["log_exposure"]
sd = scaler["log_exposure"][1]
effects.append(dict(key="elasticity", label="Deliveries per week: +10%", est=float(np.exp(beta[j] / sd * np.log(1.10))),
                    lo=float(np.exp((beta[j] - 1.96 * np.sqrt(cov[j, j])) / sd * np.log(1.10))),
                    hi=float(np.exp((beta[j] + 1.96 * np.sqrt(cov[j, j])) / sd * np.log(1.10))), kind="hazard ratio",
                    note="If failures were proportional to deliveries this would be 1.10."))
for key, lab, unit in (("rej_4wk", "Rejection rate, last 4 weeks: +5 points", 0.05), ("rej_13wk", "Rejection rate, last 13 weeks: +5 points", 0.05)):
    j = sd_idx[key]
    sd = scaler[key][1]
    se_ = np.sqrt(cov[j, j])
    effects.append(dict(key=key, label=lab, est=float(np.exp(beta[j] / sd * unit)), lo=float(np.exp((beta[j] - 1.96 * se_) / sd * unit)),
                        hi=float(np.exp((beta[j] + 1.96 * se_) / sd * unit)), kind="hazard ratio", note=""))
out["typical"] = typ
out["effects"] = effects

# ----------------------------------------------------------------- slim evaluation payload
keep_eval = ["n_dev", "n_val", "pos_dev", "pos_val", "structure", "offset_check", "screen", "base_cv", "chosen", "vendor_effect_sd", "cost_eval",
             "holdout", "bench", "gbm_cv", "capture", "addressable_share", "weekly_counts", "weekly_count_cov80", "weekly_cost_cov80",
             "cost_total_expected", "cost_total_actual", "oe", "catdrift", "refit", "mean_k"]
out["eval"] = {k: E[k] for k in keep_eval}
out["eval"]["grid"] = E["grid"]

# ----------------------------------------------------------------- Week 11 evaluation payload (all numbers produced by scripts 20-22)
W11 = json.load(open(os.path.join(D, "wk11_evaluation.json")))
ERR = json.load(open(os.path.join(D, "wk11_error_analysis.json")))
IMP = json.load(open(os.path.join(D, "wk11_improvements.json")))
# Make the Performance tab and the Evaluation tab quote the SAME top-k numbers (Week 11 shared evaluation code; Week 10 values differ by <= 1 point
# because tie-breaks are now sampled the same way for every method and the random list is an exact expectation, not a 200-draw simulation).
CAPMAP = {"Model: expected cost (this tool)": "Model (this tool)", "Spend proxy (delivery volume)": "Delivery volume (spend proxy)",
          "Gradient-boosted trees x cost": "Gradient-boosted trees", "Current practice (on-time/fill + loud-failure override)": "Current practice (on-time/fill + loud failure)",
          "Trailing rejection rate": "Trailing 13-week rejection rate", "Random": "Random list"}
DV = W11["decision_val"]
newcap = {}
for k10, k11 in CAPMAP.items():
    r_ = DV["res"][k11]
    c_ = DV["cmp"].get(k11, {})
    newcap[k10] = dict(cost=r_["cost"], cost_ci=r_["cost_ci"], count=r_["fail"], count_ci=r_["fail_ci"],
                       model_minus_this_cost=c_["cost"][0] if c_ else 0.0, model_minus_this_ci=c_["cost"][1:] if c_ else [0.0, 0.0])
out["eval"]["capture"] = newcap


def _k1(block):
    rows = []
    for n_, r_ in block["rows"].items():
        rows.append(dict(name=n_, auc=r_["auc"], ap=r_["ap"], brier=r_.get("brier"), logloss=r_.get("logloss"), auc_ci=r_.get("auc_ci"),
                         slope=(r_["cal"]["slope"] if r_.get("cal") else None), mean_pred=r_.get("mean_pred")))
    return dict(rows=rows, diffs=block["diffs"], n=block["n"], fails=block["fails"])


def _dec(block):
    rows = []
    for n_, r_ in block["res"].items():
        c_ = block["cmp"].get(n_)
        rows.append(dict(name=n_, cost=r_["cost"], cost_ci=r_["cost_ci"], fail=r_["fail"], fail_ci=r_["fail_ci"],
                         diff=(c_["cost"] if c_ else None), diff_fail=(c_["fail"] if c_ else None)))
    return rows


SEG_KEEP = ["segment", "level", "rows", "failures", "obs", "pred", "oe", "oe_lo", "oe_hi", "auc", "on_list", "catch", "cost_share", "cost_captured"]
out["wk11"] = dict(
    split=W11["split"], boundary=W11["boundary"], leakage_table=W11["leakage_table"], leakage_controls=W11["leakage_controls"], leakage_checks=W11["leakage_checks"],
    kpi1=dict(dev=_k1(W11["kpi1_dev"]), val=_k1(W11["kpi1_val"]), blocks=W11["kpi1_blocks"]),
    kpi2=dict(dev=W11["kpi2_dev"], val=W11["kpi2_val"], cost_summary=W11["cost_summary"]),
    decision=dict(dev=_dec(W11["decision_dev"]), val=_dec(W11["decision_val"]), blocks=W11["decision_blocks"], best_simple=W11["best_simple_dev"]),
    list_size=dict(dev=W11["list_size_dev"], val=W11["list_size_val"], eligible=W11["eligible_per_week"]),
    verdicts=W11["verdicts"],
    segments=dict(dev=[{k: r_[k] for k in SEG_KEEP} for r_ in ERR["dev"]], val=[{k: r_[k] for k in SEG_KEEP} for r_ in ERR["val2026"]],
                  overall=ERR["overall"], peak=ERR["peak"], quarter_oe=ERR["quarter_oe"]),
    improvements=dict(variants=[{k: v_ for k, v_ in r_.items()} for r_ in IMP["variants"]], category_cost=IMP["category_cost"], cost_model_k=IMP["cost_model_k"]),
    config=W11["config"])

# ----------------------------------------------------------------- parity cases (Python truth for the browser to reproduce)
rng = np.random.default_rng(7)
cases = []
for _ in range(16):
    wi = int(rng.integers(0, W - 1))
    idx = np.where((sc.wi == wi) & (sc.scored_flag == 1) & ((sc.category_id == "mro") if _ < 2 else True))[0]     # first two cases exercise the zero-failure clip
    r = sc.iloc[int(rng.choice(idx))]
    vi = int(r.vi)
    cat = r.category_id
    expo = float(r.exposure_wk) * float(rng.choice([0.5, 1.0, 1.5, 2.0]))
    rej4 = float(np.clip(r.rej_4wk + rng.choice([0, 0.03, 0.08, -0.5]), 0, 0.5))
    rej13 = float(np.clip(r.rej_13wk + rng.choice([0, 0.02, 0.05]), 0, 0.3))
    x = xvec(cat, r.vendor_id, float(np.log(expo)), rej4, rej13)
    eta, se = float(x @ beta), float(np.sqrt(x @ cov @ x))
    p = float(-np.expm1(-np.exp(eta)))
    z = 1.2816
    eta_hi = min(eta + z * se, eta + zcap[cat]) if cat in zcap else eta + z * se
    cases.append(dict(week=wi, vendor=vi, expo=expo, rej4=rej4, rej13=rej13, eta=eta, se=se, p=p,
                      lo80=float(-np.expm1(-np.exp(eta - z * se))), hi80=float(-np.expm1(-np.exp(eta_hi)))))
out["parity"] = cases
# frozen-model predictions on the unmodified 2026 rows (JS must reproduce these)
hp = pd.read_csv(os.path.join(D, "holdout_predictions_2026.csv"))[["vendor_id", "week_id", "p"]]
out["parity_rows"] = [dict(v=r.vendor_id, w=r.week_id, p=round(float(r.p), 6)) for r in hp.sample(30, random_state=3).itertuples()]

json.dump(out, open(os.path.join(D, "app_data.json"), "w"), separators=(",", ":"))
print(f"wrote data/app_data.json  {os.path.getsize(os.path.join(D, 'app_data.json')) / 1024:.0f} KB; {W} weeks x {V} vendors; {len(cases)} parity cases")
