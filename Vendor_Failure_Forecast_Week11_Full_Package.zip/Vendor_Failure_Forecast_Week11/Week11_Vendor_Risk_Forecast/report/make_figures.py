"""Figures for the Week 11 evaluation report. Reads only data/wk11_evaluation.json and data/wk11_error_analysis.json."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "..", "data")
OUT = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)
E = json.load(open(os.path.join(D, "wk11_evaluation.json")))
A = json.load(open(os.path.join(D, "wk11_error_analysis.json")))

BLUE, ORANGE, INK, INK2, GRID = "#2a78d6", "#d95926", "#1b1b1a", "#5d5b55", "#e1e0d9"
GREY_D, GREY_M, GREY_L = "#6f6d67", "#9b998f", "#c9c7bd"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK2, "xtick.color": INK2,
                     "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 100, "savefig.dpi": 200})

MODEL, VOL, PRAC, RAND = "Model (this tool)", "Delivery volume (spend proxy)", "Current practice (on-time/fill + loud failure)", "Random list"
STYLE = {MODEL: (BLUE, 2.4, "-"), VOL: (GREY_D, 1.6, "-"), PRAC: (ORANGE, 1.6, "-"), RAND: (GREY_L, 1.4, "--")}
SHORT = {MODEL: "This model", VOL: "Rank by delivery volume", PRAC: "Today's on-time / fill rules", RAND: "Random list"}


# ------------------------------------------------------------------ Figure 1: capture against list size
def fig1():
    fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.9), sharey=True)
    for ax, key, title in [(axs[0], "list_size_dev", "Development: rolling tests 2024-2025 (decisions made here)"),
                           (axs[1], "list_size_val", "2026 (previously viewed; confirmation only)")]:
        rows = E[key]
        x = [r["mean_k"] for r in rows]
        for m in (RAND, PRAC, VOL, MODEL):
            c, lw, ls = STYLE[m]
            y = [r[m]["cost"] * 100 for r in rows]
            ax.plot(x, y, color=c, lw=lw, ls=ls, marker="o", ms=3.6 if m == MODEL else 3, zorder=3 if m == MODEL else 2)
            if m == MODEL:
                ax.fill_between(x, [r[m]["cost_ci"][0] * 100 for r in rows], [r[m]["cost_ci"][1] * 100 for r in rows], color=BLUE, alpha=0.13, lw=0)
            dy = {MODEL: 3.2, VOL: -4.5, PRAC: -3.0, RAND: -3.5}[m]
            if key == "list_size_dev" or m != VOL:
                pass
            ax.text(x[-1] + 0.5, y[-1] + (dy if m != RAND else -2), SHORT[m], color=c if m != RAND else GREY_M, fontsize=8.2, va="center", ha="left", fontweight="bold" if m == MODEL else "normal")
        k1 = rows[1]["mean_k"]
        ax.axvline(k1, color=INK2, lw=0.8, ls=":")
        ax.text(k1 + 0.3, 3, f"usual capacity\n({k1:.1f} a week)", fontsize=7.6, color=INK2, va="bottom")
        ax.set_xlim(3, 41)
        ax.set_ylim(0, 100)
        ax.set_xticks([round(v, 1) for v in x])
        ax.set_xticklabels([f"{v:.0f}" for v in x])
        ax.set_xlabel("Vendors reviewed per week (average)")
        ax.set_title(title, loc="left", fontsize=9, color=INK, pad=8)
        ax.grid(axis="y", color=GRID, lw=0.7)
        ax.set_axisbelow(True)
        ax.yaxis.set_major_formatter(lambda v, _: f"{v:.0f}%")
    axs[0].set_ylabel("Share of next-week failure cost inside the list")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig1_list_size.png"))
    plt.close(fig)


# ------------------------------------------------------------------ Figure 2: capture by method, both periods
def fig2():
    dev, val = E["decision_dev"]["res"], E["decision_val"]["res"]
    order = sorted(dev, key=lambda k: dev[k]["cost"])
    lab = {MODEL: "This model", "Model without rejection rates (ablation)": "Model without rejection rates", "Gradient-boosted trees": "Gradient-boosted trees",
           "Vendor's own history (smoothed)": "Vendor's own history", "Category rate": "Category failure rate", VOL: "Delivery volume",
           "Trailing 13-week rejection rate": "13-week rejection rate", PRAC: "Today's on-time / fill rules", RAND: "Random list"}
    col = {MODEL: BLUE, PRAC: ORANGE, RAND: GREY_L, VOL: GREY_D}
    fig, ax = plt.subplots(figsize=(8.4, 3.9))
    for i, k in enumerate(order):
        c = col.get(k, GREY_M)
        d = dev[k]
        ax.plot([d["cost_ci"][0] * 100, d["cost_ci"][1] * 100], [i, i], color=c, lw=2.2, solid_capstyle="round", alpha=0.55)
        ax.plot(d["cost"] * 100, i, "o", color=c, ms=7.5, zorder=3)
        ax.plot(val[k]["cost"] * 100, i + 0.0, "D", mfc="white", mec=c, mew=1.5, ms=6, zorder=4)
        ax.text(d["cost_ci"][1] * 100 + 1.6, i, f"{d['cost'] * 100:.0f}%", va="center", fontsize=8.2, color=INK)
    ax.set_yticks(range(len(order)))
    ax.set_yticklabels([lab[k] for k in order])
    for t, k in zip(ax.get_yticklabels(), order):
        if k == MODEL:
            t.set_fontweight("bold"); t.set_color(BLUE)
    ax.set_xlim(0, 82)
    ax.xaxis.set_major_formatter(lambda v, _: f"{v:.0f}%")
    ax.set_xlabel("Share of next-week failure cost inside the weekly list (list size = review capacity)")
    ax.grid(axis="x", color=GRID, lw=0.7)
    ax.set_axisbelow(True)
    ax.plot([], [], "o", color=GREY_D, ms=7, label="Development 2024-25, with 95% interval")
    ax.plot([], [], "D", mfc="white", mec=GREY_D, mew=1.5, ms=6, label="2026 (previously viewed)")
    ax.legend(loc="lower right", frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig2_capture_by_method.png"))
    plt.close(fig)


# ------------------------------------------------------------------ Figure 3: observed / predicted by segment
def fig3():
    rows = [r for r in A["dev"] if r["failures"] >= 8]
    names = {"produce": "Produce", "dairy_bakery": "Dairy & bakery", "protein": "Protein", "peak": "Peak", "shoulder": "Shoulder", "trough": "Trough",
             "linen_laundry": "Linen & laundry", "low (<1/wk)": "Low (<1 / wk)", "large": "Large", "medium": "Medium", "small": "Small", "high (>2.5/wk)": "High (>2.5 / wk)", "none open": "None open",
             "open corrective action": "Open corrective action", "31+": "31 or more", "failed 5-13 wks ago": "Failed 5-13 wks ago",
             "failed within 4 wks": "Failed within 4 wks", "no failure in 13+ wks": "No failure in 13+ wks", "no rejections in last 4 wks": "None",
             "rejections in last 4 wks": "Some", "banquet week": "Banquet week", "no banquet": "No banquet"}
    titles = {"Vendor category": "Category", "Season": "Season", "Vendor size": "Size", "Delivery volume": "Delivery volume", "Corrective action": "Corrective action",
              "History length (deliveries in last 13 wks)": "Deliveries, last 13 wks", "Recent failure": "Recent failure", "Recent rejections": "Rejections, last 4 wks",
              "Banquet this week": "Banquet"}
    fig, ax = plt.subplots(figsize=(8.4, 6.2))
    y = 0.0
    ticks, labels, seps = [], [], []
    last = None
    for r in rows:
        if r["segment"] != last:
            if last is not None:
                y += 0.7
            ax.text(0.26, y - 0.05, titles[r["segment"]].upper(), fontsize=7.4, color=INK2, va="center", fontweight="bold")
            y += 0.9
            last = r["segment"]
        ax.plot([r["oe_lo"], r["oe_hi"]], [y, y], color=BLUE, lw=2, alpha=0.55, solid_capstyle="round")
        ax.plot(r["oe"], y, "o", color=BLUE, ms=6.5, zorder=3)
        ax.text(2.75, y, f"{r['failures']}", fontsize=7.8, va="center", ha="right", color=INK2)
        ticks.append(y)
        labels.append(names.get(r["level"], r["level"]))
        y += 1
    ax.axvline(1, color=INK, lw=1)
    ax.set_xscale("log")
    ax.set_xlim(0.25, 3.0)
    ax.set_xticks([0.3, 0.5, 0.7, 1.0, 1.4, 2.0])
    ax.set_xticklabels(["0.3", "0.5", "0.7", "1.0", "1.4", "2.0"])
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_yticks(ticks)
    ax.set_yticklabels(labels, fontsize=8.2)
    ax.invert_yaxis()
    ax.text(2.75, ax.get_ylim()[1] if False else -0.2, "failures", fontsize=7.4, color=INK2, ha="right", va="bottom")
    ax.set_xlabel("Observed failures divided by forecast failures (1.0 = forecast right on average); 95% interval")
    ax.annotate("\u2190 forecast too high", xy=(0.93, 1.012), xycoords=("data", "axes fraction"), fontsize=8, color=INK2, ha="right", va="bottom")
    ax.annotate("forecast too low \u2192", xy=(1.08, 1.012), xycoords=("data", "axes fraction"), fontsize=8, color=INK2, ha="left", va="bottom")
    ax.grid(axis="x", color=GRID, lw=0.7)
    ax.set_axisbelow(True)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig3_calibration_by_segment.png"))
    plt.close(fig)


fig1()
fig2()
fig3()
print("figures written to", OUT)
