// Builds Week11_Evaluation_Report.docx from the saved evaluation files, so every number in the tables comes from data/*.json.
//   node build_report_w11.js                      -> report/Week11_Evaluation_Report.docx
//   USABILITY_RESULTS=/path/results.json node ... -> also fills section 8 from a real session record
const fs = require('fs');
const path = require('path');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, AlignmentType, LevelFormat, ImageRun, Footer, PageNumber } = require('docx');

const D = p => path.join(__dirname, '..', 'data', p);
const E = JSON.parse(fs.readFileSync(D('wk11_evaluation.json')));
const A = JSON.parse(fs.readFileSync(D('wk11_error_analysis.json')));
const IM = JSON.parse(fs.readFileSync(D('wk11_improvements.json')));
const FIG = n => path.join(__dirname, 'figures', n);
const OUT = process.env.REPORT_OUT || path.join(__dirname, 'Week11_Evaluation_Report.docx');
const URES = process.env.USABILITY_RESULTS || path.join(__dirname, '..', 'usability_test', 'results.json');

// ------------------------------------------------------------------ formatting helpers
const FONT = 'Arial', BODY = 20, INK = '1F2A37', BLUE = '1C4F8F', GREY = '5B6573', LINE = 'C9D1DC', WASH = 'EEF2F8', AMBER = 'FFF4D6', GREEN = 'E6F3EA', RED = 'FBE9E7';
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: o.size || BODY, bold: o.bold, italics: o.italics, color: o.color || INK });
const rich = (s, o = {}) => s.replace(/`/g, '').split(/(\*\*[^*]+\*\*)/).filter(Boolean).map(p => p.startsWith('**') ? run(p.slice(2, -2), { ...o, bold: true }) : run(p, o));
const P = (s, o = {}) => new Paragraph({ children: rich(s, o), spacing: { after: o.after ?? 120, line: o.line ?? 276 }, alignment: o.align, keepNext: o.keepNext });
const H1 = (t, pb) => new Paragraph({ children: [run(t, { bold: true, size: 30, color: BLUE })], spacing: { before: pb ? 0 : 300, after: 120 }, keepNext: true, pageBreakBefore: !!pb });
const H2 = t => new Paragraph({ children: [run(t, { bold: true, size: 23, color: BLUE })], spacing: { before: 220, after: 80 }, keepNext: true });
const CAP = t => new Paragraph({ children: rich(t, { size: 17, color: GREY }), spacing: { before: 40, after: 160, line: 240 } });
const sp = (n = 80) => new Paragraph({ children: [], spacing: { after: n } });
const W = 12240 - 2 * 1200;                       // text width 9840 DXA
const bd = c => ({ style: BorderStyle.SINGLE, size: 4, color: c || LINE });
const borders = { top: bd(), bottom: bd(), left: bd(), right: bd() };
function cell(content, w, o = {}) {
  const kids = (Array.isArray(content) ? content : [content]).map(c => typeof c === 'string'
    ? new Paragraph({ children: rich(c, { size: o.size || 17, bold: o.bold }), spacing: { after: 20, line: 230 }, alignment: o.align }) : c);
  return new TableCell({ width: { size: w, type: WidthType.DXA }, borders, margins: { top: 45, bottom: 45, left: 80, right: 80 },
    shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: 'auto' } : undefined, children: kids });
}
// widths sum to W; numeric columns right-aligned when `num` lists their indexes
function table(widths, header, rows, o = {}) {
  const num = new Set(o.num || []);
  const hdr = header ? [new TableRow({ tableHeader: true, cantSplit: true, children: header.map((h, i) => cell(h, widths[i], { bold: true, fill: WASH, size: o.size, align: num.has(i) ? AlignmentType.RIGHT : undefined })) })] : [];
  const body = rows.map(r => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, widths[i], { size: o.size, align: num.has(i) ? AlignmentType.RIGHT : undefined,
    fill: (o.hl && o.hl(r)) ? o.hlFill || AMBER : (o.firstFill && i === 0 ? WASH : undefined), bold: o.firstBold && i === 0 })) }));
  return new Table({ width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA }, columnWidths: widths, rows: hdr.concat(body) });
}
const box = (lines, fill) => new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [W], rows: [new TableRow({ children: [new TableCell({ width: { size: W, type: WidthType.DXA }, borders, margins: { top: 100, bottom: 60, left: 160, right: 160 }, shading: { fill: fill || WASH, type: ShadingType.CLEAR, color: 'auto' }, children: lines.map(l => typeof l === 'string' ? P(l, { after: 70 }) : l) })] })] });
function pngSize(f) { const b = fs.readFileSync(f); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }
function img(file, widthPx, alt) {
  const [w, h] = pngSize(FIG(file));
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 20 }, keepNext: true,
    children: [new ImageRun({ type: 'png', data: fs.readFileSync(FIG(file)), transformation: { width: widthPx, height: Math.round(widthPx * h / w) }, altText: { title: alt, description: alt, name: file } })] });
}

const pc = (x, d = 1) => (x * 100).toFixed(d) + '%';
const pc0 = x => (x * 100).toFixed(0) + '%';
const sg = (x, d) => { const a = Number(Math.abs(x).toFixed(d)); return (a === 0 ? '' : x >= 0 ? '+' : '\u2212') + a.toFixed(d); };
const pts = x => sg(x * 100, 1);
const ptsci = a => `${pts(a[0])} [${pts(a[1])}, ${pts(a[2])}]`;
const lci = (a, d = 4) => `${sg(a[0], d)} [${sg(a[1], d)}, ${sg(a[2], d)}]`;
const usd = x => '$' + Math.round(x).toLocaleString('en-US');
const usdS = x => (x >= 0 ? '+' : '\u2212') + '$' + Math.abs(Math.round(x)).toLocaleString('en-US');
const f2 = x => (x === undefined || x === null || Number.isNaN(x)) ? '—' : x.toFixed(2);
const f3 = x => (x === undefined || x === null) ? '—' : x.toFixed(3);
const f4 = x => (x === undefined || x === null) ? '—' : x.toFixed(4);

const MODEL = 'Model (this tool)', VOLM = 'Delivery volume (spend proxy)', PRAC = 'Current practice (on-time/fill + loud failure)', RAND = 'Random list';
const dev = E.split, K1 = E.kpi1_dev, K1v = E.kpi1_val, K2 = E.kpi2_dev, K2v = E.kpi2_val, DD = E.decision_dev, DV = E.decision_val;
const cs = E.cost_summary, VER = E.verdicts, OV = A.overall;
const T = A.dev, T6 = A.val2026;
const seg = (arr, s, l) => arr.find(r => r.segment === s && r.level === l);
const seg0 = (s, l) => seg(T, s, l).failures;
const kids = [];

// ================================================================== title + summary
kids.push(new Paragraph({ children: [run('Vendor Failure Forecast', { bold: true, size: 44, color: BLUE })], spacing: { after: 40 } }));
kids.push(new Paragraph({ children: [run('Week 11: model evaluation and decision-support report', { size: 30 })], spacing: { after: 100 } }));
kids.push(P('Mirza Ali and Debra Senteu · MS Analytics, Saint Louis University · for the Purchasing & Receiving Manager of a synthetic independent seasonal resort · all data are synthetic', { size: 17, color: GREY, after: 60 }));
kids.push(P('The Week 10 version of the app and package is kept unchanged in the folder `Week10_frozen`. Everything described here is in `Week11_Vendor_Risk_Forecast`.', { size: 17, color: GREY, after: 200 }));

kids.push(H2('Summary'));
kids.push(P(`Each Monday the tool estimates, for about ${Math.round(E.eligible_per_week.dev)} vendors, the chance of a material failure next week, turns that into expected dollars, and lists the top k vendors, where k is the week's review capacity (as few as 4 in the busiest weeks, up to 12 in quiet ones). We tested it on rolling 13-week blocks of 2023 to 2025 data, where every decision in this report was made, and read 2026 as a confirmation only.`));
kids.push(table([2700, W - 2700], ['Question', 'Answer'], [
  ['Does the weekly list beat what the manager does today?', `**Yes.** The list holds ${pc0(DD.res[MODEL].cost)} of next-week failure cost against ${pc0(DD.res[PRAC].cost)} for today's on-time and fill-rate rules (${ptsci(DD.cmp[PRAC].cost)} points). In 2026: ${pc0(DV.res[MODEL].cost)} against ${pc0(DV.res[PRAC].cost)} (${ptsci(DV.cmp[PRAC].cost)}).`],
  ['Is it better than simple rules that need no model?', `**Not shown.** Ranking vendors by delivery volume alone holds ${pc0(DD.res[VOLM].cost)} (2026: ${pc0(DV.res[VOLM].cost)}). Model minus volume is ${ptsci(DD.cmp[VOLM].cost)} points, and its interval includes zero. The pre-stated rule for a meaningful improvement is not met.`],
  ['Are the percentages right?', `**On average, yes in 2024 to 2025:** forecast ${pc(OV.pred, 2)} against ${pc(OV.obs, 2)} observed, calibration slope ${f2(K1.rows[MODEL].cal.slope)}, and observed over forecast is consistent with 1.0 in every segment we could test. In 2026 failures ran above forecast (${pc(K1v.rows[MODEL].obs_rate, 2)} against ${pc(K1v.rows[MODEL].mean_pred, 2)}, slope ${f2(K1v.rows[MODEL].cal.slope)}) because the data generator shifted; the drift monitor exists for that.`],
  ['Is the dollar estimate useful?', `**Only as an average.** The cost model's typical miss is ${usd(K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae)} per failing vendor-week against ${usd(K2['Average past failure cost'].mae)} for simply using the average past cost. A failure costs between ${usd(cs.dev.p10)} and ${usd(cs.dev.p90)} in 80% of cases and the data give no way to say which one will be expensive.`],
  ['Did we improve the model?', `**No candidate passed the rules we set before running them.** We tested ${IM.variants.length - 1} model and recalibration variants, one cost-ranking change and one change to the dollar estimate (${IM.variants.length + 1} in all), all on development data, and kept the Week 10 model. Two of them came from a team member's separate two-fold screen. We did fix one input mismatch in the cost estimate and added decision-support features to the app (section 7).`]
], { size: 17, firstFill: true, firstBold: true }));
kids.push(sp(100));
kids.push(box([
  '**Bottom line for the manager.** Use the list to decide where to look first; expect it to hold about half of the failure cost next week, not all of it, and do not read a 19% as "will fail". The tool is a ranking aid that clearly beats today\'s rules, is not proven better than reviewing the highest-volume vendors, and is weakest for protein and dairy suppliers, in peak weeks and for vendors under an open corrective action. All of this was measured on synthetic data, so it shows how the method behaves, not how a real property would perform.'
], AMBER));

// ================================================================== 1. How we tested
kids.push(H1('1. How we tested', true));
kids.push(H2('Data split and why it fits the use (1a)'));
kids.push(table([2900, 3470, 3470], ['', 'Development: 2023 to 2025', '2026 holdout'], [
  ['Weeks and scored vendor-weeks', `${dev.dev_weeks} weeks, ${dev.dev_rows.toLocaleString()} vendor-weeks`, `${dev.val_weeks} weeks, ${dev.val_rows.toLocaleString()} vendor-weeks`],
  ['Rows where a material failure happened next week', `${dev.dev_fail_rows} (${pc(dev.dev_rate, 2)})`, `${dev.val_fail_rows} (${pc(dev.val_rate, 2)})`],
  ['Failing vendor-weeks (unit of the cost model)', `${dev.dev_fail_vendor_weeks}`, `${dev.val_fail_vendor_weeks}`],
  ['Rolling out-of-fold test rows (2024 to 2025)', `${K1.n.toLocaleString()} rows, ${K1.fails} failures`, 'not applicable'],
  ['Used for', 'Fitting, every design choice, every comparison', 'Confirmation only: scored with the frozen model']
], { size: 17, firstFill: true, firstBold: true }));
kids.push(sp(80));
kids.push(P('**Why not a random split.** The tool is used forward in time every Monday, and one week\'s record is nearly the next week\'s, so mixing weeks at random would let the model learn from the future. We replay what the manager would have had instead: eight 13-week test blocks (2024 Q1 to 2025 Q4). Each block is predicted by a model fitted only on rows whose outcome was already known on the block\'s first Monday. A row for week t has its outcome (a failure in week t+1) known from Monday of week t+2, so the training rows are those with t at most a−2. Eight blocks give eight separate tests instead of one, which is what lets us ask whether a difference is consistent or a single lucky quarter.'));
kids.push(P('**A caveat we cannot remove.** The 2026 year was already viewed in Week 10, and one design fix (the zero-failure cap for MRO supplies) was made after seeing it. It is therefore not a clean final test. In Week 11 we fitted, tuned and chose everything on 2023 to 2025 only; scripts 20 to 22 never fit on, tune on or select thresholds on 2026, and the pipeline asserts this. We did not regenerate a fresh, unseen year; if the team can run the Week 7 generator, a new year scored once with the frozen model would give the clean final test this design wants.'));
kids.push(P(`**One boundary detail.** The last development row (the week of 22 December 2025) predicts the first week of 2026, so its label, ${E.boundary.failures} failures out of ${E.boundary.dev_failures} in the development labels, is a 2026 outcome that sits in the final fit and in the last test block. Refitting without that week changes the 2026 log loss from ${E.boundary.logloss_with.toFixed(4)} to ${E.boundary.logloss_without.toFixed(4)} and moves no 2026 probability by more than ${(E.boundary.max_abs_dp * 100).toFixed(1)} percentage points. We left the frozen Week 10 model as it was and disclose the overlap here.`));

kids.push(H2('Leakage check: is every input known on Monday? (1b)'));
kids.push(table([2300, 3500, 2840, 1200], ['Input', 'Where it comes from', 'When it is known', 'Available at decision time?'],
  E.leakage_table.map(r => [r.item, r.source, r.known.replace(' (manager action, rule W20/G29/S7)', ' (a manager action)').replace(' (S6/S20)', ''), r.decision_time ? 'Yes' : 'No (never read)']), { size: 16 }));
kids.push(sp(80));
kids.push(P(`All ${(10120).toLocaleString()} vendor-week records (scored or not) carry an as-of date equal to their own Monday (checked). As a negative control we also measured each input as it would look if it had secretly included the target week: a leaked input should look much better than the as-of version, and none of the inputs we use does.`));
kids.push(table([3600, 2000, 2400, 1840], ['Input', 'AUC as of Monday', 'AUC if it included the target week', 'Jump'],
  E.leakage_controls.map(r => [r.name, f3(r.auc_asof), f3(r.auc_if_measured_two_mondays_later), sg(r.auc_if_measured_two_mondays_later - r.auc_asof, 3)]), { size: 17, num: [1, 2, 3] }));
kids.push(CAP('The last row is an input we do not use. It shows what a leak looks like: a jump of about 0.2 AUC. The manager\'s own open corrective action stays out of the model and is used only to decide which vendors are eligible for the list. The generator\'s hidden reliability table is never read.'));
kids.push(P('**One assumption.** The cost estimate uses next week\'s expected occupancy and whether a banquet is booked. We assume those are known on Monday from reservations; they size the dollar cost and never enter the probability or the ranking. A strict version that uses only last week\'s values, with nothing from the week being predicted, performs the same (typical miss $' + Math.round(K2["Same inputs, but last week's occupancy + banquet (decision-time)"].mae).toLocaleString('en-US') + ' against $' + Math.round(K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae).toLocaleString('en-US') + ').'));

kids.push(H2('Rules for "a meaningful improvement", set before the Week 11 numbers were produced'));
kids.push(table([2600, W - 2600 - 1300, 1300], ['KPI', 'The model must…', 'Result'], [
  ['KPI 1: failure probability', 'beat the best simple baseline (category rate or the vendor\'s own history) on log loss, with a 95% paired interval excluding zero, and in at least 6 of 8 blocks', VER.kpi1_probability.met ? 'Met' : 'Not met'],
  ['KPI 1: ranking', 'reach an AUC at least 0.03 above the best simple baseline, interval excluding zero', VER.kpi1_ranking.met ? 'Met' : 'Not met'],
  ['KPI 2: dollar cost of a failure', 'have a typical miss at least 5% lower than "use the average past failure cost", interval excluding zero', VER.kpi2_cost.met ? 'Met' : 'Not met'],
  ['Decision: weekly list', 'hold at least 5 percentage points more next-week failure cost than the strongest simple list, interval excluding zero', VER.decision_capture.met ? 'Met' : 'Not met']
], { size: 17, firstFill: true, firstBold: true }));
kids.push(CAP('2026 is read as confirmation only: the same direction as in development is "consistent", anything else is "not confirmed". We disclose that these thresholds were written after the Week 10 results on 2026 were known to us, so they are a fair reading, not a blind pre-registration.'));

// ================================================================== 2. Measures in plain language
kids.push(H1('2. What the measures mean for the manager (requirement 1c)'));
kids.push(P('Failures happen in about 1 vendor-week in 20, so plain "accuracy" would reward a tool that says nobody will ever fail (about 95% accurate and useless). We use measures that reflect the actual decision: which few vendors to look at.'));
kids.push(table([2000, 3300, 2400, 2140], ['Measure', 'In plain words', 'Why the manager cares', 'How to read it'], [
  ['Share of failure cost inside the list (decision KPI)', 'Of the money lost next week to failures at vendors you could still act on, how much belonged to vendors on the weekly list.', 'It is the whole point: did looking at k vendors cover the expensive trouble?', `A random list of that size holds about ${pc0(DD.res[RAND].cost)}. Higher is better. Always compare at the same list size.`],
  ['Log loss and Brier score (KPI 1)', 'How close the percentages are to what happened. Confident wrong answers cost the most.', 'Percentages feed expected dollars and the what-if tab.', `Lower is better. "Same rate for everyone" scores ${f3(K1.rows['Same rate for every vendor'].logloss)} log loss; the model ${f3(K1.rows[MODEL].logloss)}.`],
  ['AUC (KPI 1, ranking)', 'Pick one vendor that failed and one that did not: how often did the tool give the failing one the higher chance?', 'The list is only as good as the order.', `0.5 is a coin toss, 1.0 is perfect. The model: ${f2(K1.rows[MODEL].auc)}.`],
  ['Observed over forecast, calibration slope', 'Do 5% forecasts come true about 5% of the time?', 'A tool that is consistently too low or too high misleads the planning, even if its order is fine.', 'Observed over forecast of 1.0 is right on average; above 1 means forecasts ran too low, below 1 too high. A slope below 1 means forecasts are too extreme: the high ones too high, the low ones too low.'],
  ['Typical dollar miss (KPI 2)', 'On average, how many dollars the cost estimate is off for a failure that actually happened.', 'Dollars set the cost of a failure for the what-if tab.', 'Compare with using the plain average.'],
  ['Interval coverage', 'The 80% range should contain what happens about 80% of the time.', 'It says how far to trust the range shown next to each number.', 'Well below 80% means the ranges are too narrow.']
], { size: 16, firstFill: true, firstBold: true }));

// ================================================================== 3. KPIs and baselines
kids.push(H1('3. KPIs, baselines and verdicts (1d)', true));
kids.push(P('We kept the Week 10 KPIs. KPI 1 is the chance of a material failure next week for each vendor. KPI 2 is the dollar cost given that a failure happens. The decision-level result combines them: the weekly list is the top k vendors by chance times cost, and because every vendor in a given week shares the same cost multiplier, that is the same list as ranking by chance alone. Baselines come in two kinds: probability baselines (the same rate for every vendor, the category rate, the vendor\'s own smoothed history, a gradient-boosted benchmark, and the model without its rejection inputs) and ranking rules a manager could apply without a model (delivery volume, trailing 13-week rejection rate, and today\'s on-time and fill-rate rules with a "loud recent failure jumps the queue" step).'));

kids.push(H2('KPI 1: chance of a failure next week'));
const k1order = [MODEL, "Vendor's own history (smoothed)", 'Category rate', 'Same rate for every vendor', 'Gradient-boosted trees', 'Model without rejection rates (ablation)'];
const k1name = { [MODEL]: 'This model', "Vendor's own history (smoothed)": "Vendor's own history", 'Category rate': 'Category failure rate', 'Same rate for every vendor': 'Same rate for every vendor', 'Gradient-boosted trees': 'Gradient-boosted trees', 'Model without rejection rates (ablation)': 'Model without rejection rates' };
kids.push(table([2900, 900, 900, 1000, 800, 1000, 1240, 1100], ['Method', 'AUC', 'Brier', 'Log loss', 'Slope', '2026 AUC', '2026 log loss', '2026 slope'],
  k1order.map(k => [k1name[k], f3(K1.rows[k].auc), f4(K1.rows[k].brier), f4(K1.rows[k].logloss), K1.rows[k].cal ? f2(K1.rows[k].cal.slope) : '—', f3(K1v.rows[k].auc), f4(K1v.rows[k].logloss), K1v.rows[k].cal ? f2(K1v.rows[k].cal.slope) : '—']), { size: 16, num: [1, 2, 3, 4, 5, 6, 7], hl: r => r[0] === 'This model', hlFill: 'E3EEFB' }));
kids.push(CAP(`Development columns: ${K1.n.toLocaleString()} rolling out-of-fold vendor-weeks, ${K1.fails} failures. 2026: ${K1v.n.toLocaleString()} vendor-weeks, ${K1v.fails} failures. Slope is the calibration slope (1.0 is ideal). "Same rate for every vendor" has no ranking ability by construction.`));
const bl = ["Vendor's own history (smoothed)", 'Category rate', 'Same rate for every vendor', 'Gradient-boosted trees', 'Model without rejection rates (ablation)'];
kids.push(P('**Model minus baseline, with paired 95% intervals** from a bootstrap over whole weeks. For log loss a negative number favours the model; for AUC a positive number does.', { after: 60, keepNext: true }));
kids.push(table([2500, 1800, 1840, 1800, 1900], ['Against', 'Log loss, 2024-25', 'AUC, 2024-25', 'Log loss, 2026', 'AUC, 2026'],
  bl.map(k => [k1name[k], lci(K1.diffs[k].logloss), lci(K1.diffs[k].auc, 3), lci(K1v.diffs[k].logloss), lci(K1v.diffs[k].auc, 3)]), { size: 15 }));
kids.push(sp(100));
kids.push(P(`**Verdict: not a meaningful improvement by the rule.** The model beats the category rate on log loss (${lci(K1.diffs['Category rate'].logloss)}) and is better than the vendor's own history by a margin whose interval includes zero (${lci(K1.diffs["Vendor's own history (smoothed)"].logloss)}). It beat the better of the two simple baselines in ${VER.kpi1_probability.blocks_better} of 8 blocks, short of the 6 required, and its AUC is only ${sg(K1.diffs["Vendor's own history (smoothed)"].auc[0], 3)} above the vendor's own history (rule: 0.03). The rejection inputs add almost nothing: the model without them is statistically the same (${lci(K1.diffs['Model without rejection rates (ablation)'].logloss)}). In plain terms the forecasts are good and well calibrated, but most of their skill is the category and the vendor's own record, which a simple table also captures. In 2026 the model ties the category rate on log loss (${lci(K1v.diffs['Category rate'].logloss)}), the same direction, so we call the pattern consistent.`));

kids.push(H2('KPI 2: dollar cost when a failure happens'));
const k2 = [['Week 10 cost model (occupancy + banquet of the failure week)', 'Cost model: next week\'s occupancy and banquet (used in the app)'], ["Same inputs, but last week's occupancy + banquet (decision-time)", 'Cost model, strict: last week\'s values only'], ['Average cost by category', 'Average cost by category'], ['Average past failure cost', 'Plain average of past failure costs']];
kids.push(table([3640, 1000, 1000, 1000, 1100, 1000, 1100].slice(0, 7), ['Method', 'Typical miss', 'Bias', '80% range holds', '2026 miss', '2026 bias', '2026 holds'],
  k2.map(([k, n]) => [n, usd(K2[k].mae), f2(K2[k].bias), pc0(K2[k].cover80), usd(K2v[k].mae), f2(K2v[k].bias), pc0(K2v[k].cover80)]), { size: 16, num: [1, 2, 3, 4, 5, 6] }));
kids.push(CAP(`${cs.dev.n} failing vendor-weeks in the 2024-25 tests (mean ${usd(cs.dev.mean)}, median ${usd(cs.dev.median)}, 10th to 90th percentile ${usd(cs.dev.p10)} to ${usd(cs.dev.p90)}) and ${cs.val.n} in 2026 (mean ${usd(cs.val.mean)}). Bias is actual total divided by predicted total (1.00 is unbiased).`));
kids.push(P(`**Verdict: not a meaningful improvement.** The cost model's typical miss is ${pc(Math.abs(K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae_vs_mean_pct), 1)} ${K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae_vs_mean_pct <= 0 ? 'below' : 'above'} the plain average (difference ${sg(K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae_vs_mean, 0)} dollars, 95% interval ${sg(K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae_vs_mean_ci[0], 0)} to ${sg(K2['Week 10 cost model (occupancy + banquet of the failure week)'].mae_vs_mean_ci[1], 0)}); the rule asked for 5%. Failure costs vary widely and the occupancy and banquet inputs do not explain the variation. The practical reading: treat the dollar figure as "a failure here costs about this much, give or take a lot", and rely on the range shown rather than the point value.`));

kids.push(H2('Decision level: the weekly review list'));
kids.push(img('fig2_capture_by_method.png', 600, 'Share of next-week failure cost inside the weekly list by method, with 95% intervals'));
kids.push(CAP('Figure 1. Share of next-week failure cost inside the weekly list, list size equal to the week\'s review capacity (mean 9.7 vendors of about 44 eligible). Filled circles with intervals: 2024-25 tests. Open diamonds: 2026.'));
const meth = [[MODEL, 'This model'], ['Model without rejection rates (ablation)', 'Model without rejection rates'], ['Gradient-boosted trees', 'Gradient-boosted trees'], [VOLM, 'Delivery volume'], ['Category rate', 'Category failure rate'], ["Vendor's own history (smoothed)", "Vendor's own history"], [PRAC, "Today's on-time / fill rules"], ['Trailing 13-week rejection rate', '13-week rejection rate'], [RAND, 'Random list']];
kids.push(table([2800, 1600, 2080, 1600, 1760], ['List built by', 'Cost held, 2024-25', 'Model minus this, 2024-25', 'Cost held, 2026', 'Model minus this, 2026'],
  meth.map(([k, n]) => [n, pc(DD.res[k].cost, 1), k === MODEL ? '' : ptsci(DD.cmp[k].cost), pc(DV.res[k].cost, 1), k === MODEL ? '' : ptsci(DV.cmp[k].cost)]), { size: 16, num: [1, 2, 3, 4], hl: r => r[0] === 'This model', hlFill: 'E3EEFB' }));
kids.push(CAP('Differences are in percentage points with a paired 95% interval from a bootstrap over weeks. Failures caught (the count version of the same measure): model ' + pc0(DD.res[MODEL].fail) + ' in development and ' + pc0(DV.res[MODEL].fail) + ' in 2026, today\'s rules ' + pc0(DD.res[PRAC].fail) + ' and ' + pc0(DV.res[PRAC].fail) + '.'));
const bdn = E.decision_blocks, wins = bdn.filter(b => b.model > b.best_simple).length;
kids.push(P(`**Verdict.** Against today's rules the model is clearly better in both periods (${ptsci(DD.cmp[PRAC].cost)} and ${ptsci(DV.cmp[PRAC].cost)}). Against the strongest simple list, delivery volume, the difference is ${ptsci(DD.cmp[VOLM].cost)} in development and ${ptsci(DV.cmp[VOLM].cost)} in 2026; the point estimate is near the 5-point threshold but the interval includes zero, so the rule is not met. The model's list held more cost than the volume list in ${wins} of 8 blocks. We cannot say that the model finds something volume does not; we can say it matches volume and beats everything the manager uses today.`));
kids.push(img('fig1_list_size.png', 624, 'Share of failure cost inside the list as the list grows, development and 2026'));
kids.push(CAP('Figure 2. What a bigger list buys. Lines are the average share of next-week failure cost inside the list when the list is 0.5, 1, 1.5, 2, 2.5 and 3 times the review capacity. Band: 95% interval for the model.'));
const ls = E.list_size_dev, lv = E.list_size_val;
kids.push(table([2640, 1200, 1200, 1200, 1200, 1200, 1200], ['List size (vendors a week)', 'Model', 'Volume', 'Today\'s rules', 'Random', '2026 model', '2026 volume'],
  ls.map((r, i) => [`${r.mult}× capacity (${r.mean_k.toFixed(1)})`, pc0(r[MODEL].cost), pc0(r[VOLM].cost), pc0(r[PRAC].cost), pc0(r[RAND].cost), pc0(lv[i][MODEL].cost), pc0(lv[i][VOLM].cost)]), { size: 16, num: [1, 2, 3, 4, 5, 6] }));
kids.push(CAP('Left block: 2024-25 tests. The last two columns repeat the model and volume lists for 2026. The model and the volume list meet from about 2.5 times capacity upward.'));
kids.push(P(`**On a fixed target such as 80%.** At the usual capacity the list holds about half of the cost, so a target of 80% is not reached by the weekly list. Reaching about 80% takes roughly twice to two and a half times the capacity (about 19 to 24 reviews a week, around half of the eligible vendors): ${pc0(ls[3][MODEL].cost)} at 2× in development and ${pc0(lv[3][MODEL].cost)} (2×) to ${pc0(lv[4][MODEL].cost)} (2.5×) in 2026. The right comparison for 55% to 58% is the random list at the same size (about 22%) and today's rules (31% to 41%), not a fixed 80%.`));

// ================================================================== 4. Error analysis
kids.push(H1('4. Where the tool does well and badly (1e)', true));
kids.push(P('We cut the rolling out-of-fold predictions (2024 to 2025) by vendor category, season, vendor size, delivery volume, open corrective action, length of recent history, recent failure, recent rejections and banquet weeks. For each group we compared failures that happened with failures forecast (1.0 is right on average) and measured how many of the group\'s failures were on the weekly list.'));
kids.push(img('fig3_calibration_by_segment.png', 560, 'Observed over forecast failures by segment with 95% intervals'));
kids.push(CAP(`Figure 3. Observed failures divided by forecast failures, 2024-25 tests, groups with at least 8 failures. Every interval includes 1.0. Wide bars are small groups. Groups with fewer than 8 failures are not drawn because they cannot be judged: guest amenities (${seg0('Vendor category', 'guest_amenities')}), MRO (${seg0('Vendor category', 'mro')}), non-alcoholic beverage (${seg0('Vendor category', 'nonalc_beverage')}), mid-volume vendors (${seg0('Delivery volume', 'mid (1-2.5/wk)')}) and the two shortest histories (${seg0('History length (deliveries in last 13 wks)', '0-5 deliveries')} and ${seg0('History length (deliveries in last 13 wks)', '6-12')}).`));
const rowsSeg = [
  ['Produce', 'Vendor category', 'produce'], ['Protein', 'Vendor category', 'protein'], ['Dairy and bakery', 'Vendor category', 'dairy_bakery'],
  ['Peak weeks', 'Season', 'peak'], ['Shoulder weeks', 'Season', 'shoulder'], ['Trough weeks', 'Season', 'trough'],
  ['Large vendors', 'Vendor size', 'large'], ['Small vendors', 'Vendor size', 'small'],
  ['Open corrective action', 'Corrective action', 'open corrective action'],
  ['Failed 5 to 13 weeks ago', 'Recent failure', 'failed 5-13 wks ago'], ['No failure in 13+ weeks', 'Recent failure', 'no failure in 13+ wks'],
  ['Rejections in last 4 weeks', 'Recent rejections', 'rejections in last 4 wks'], ['Banquet week', 'Banquet this week', 'banquet week']
];
kids.push(table([2600, 1000, 1500, 1640, 1500, 1600].slice(0, 6), ['Group', 'Failures', 'Observed ÷ forecast', 'Share of its failures on the list', '2026: observed ÷ forecast', '2026: share on the list'],
  rowsSeg.map(([n, s, l]) => { const a = seg(T, s, l), b = seg(T6, s, l); return [n, String(a.failures), f2(a.oe), pc0(a.catch), f2(b.oe), pc0(b.catch)]; }), { size: 16, num: [1, 2, 3, 4, 5] }));
kids.push(CAP(`Overall in 2024-25 the list holds ${pc0(OV.catch_all)} of all failures, or ${pc0(OV.catch_eligible)} of failures at vendors eligible for review. Vendors with an open corrective action are held out of the list by design, so 0% is expected for them.`));
kids.push(H2('What this means for someone using the tool'));
kids.push(P(`**The percentages can be read at face value; the list cannot be read as complete.** Observed over forecast is consistent with 1.0 in every group we could test, and across the eight quarters it stayed between ${Math.min(...Object.values(A.quarter_oe)).toFixed(2)} and ${Math.max(...Object.values(A.quarter_oe)).toFixed(2)}. What varies is how much of a group's failure the list reaches.`));
kids.push(P(`**Produce is where the list works; protein and dairy are where it does not.** Produce suppliers account for ${seg(T, 'Vendor category', 'produce').failures} of the ${OV.failures} failures and the list catches ${pc0(seg(T, 'Vendor category', 'produce').catch)} of them. For protein it catches ${pc0(seg(T, 'Vendor category', 'protein').catch)} of ${seg(T, 'Vendor category', 'protein').failures} and for dairy and bakery ${pc0(seg(T, 'Vendor category', 'dairy_bakery').catch)} of ${seg(T, 'Vendor category', 'dairy_bakery').failures}, although together they carry about ${pc0(seg(T, 'Vendor category', 'protein').cost_share + seg(T, 'Vendor category', 'dairy_bakery').cost_share)} of the failure cost. A manager should keep a separate eye on protein and dairy suppliers. The 2026 table shows the same pattern.`));
kids.push(P(`**Peak weeks are covered least.** Review capacity is smallest when the team is busiest (a list of ${A.peak['peak weeks'].k.toFixed(1)} vendors of ${A.peak['peak weeks'].elig.toFixed(0)} in peak weeks against ${A.peak['other weeks'].k.toFixed(1)} of ${A.peak['other weeks'].elig.toFixed(0)} otherwise), so the list holds ${pc0(A.peak['peak weeks'].catch)} of peak-week failures against ${pc0(A.peak['other weeks'].catch)} in other weeks. The ranking inside peak weeks is as good (AUC ${f2(seg(T, 'Season', 'peak').auc)}); it simply covers less.`));
kids.push(P(`**Vendors under an open corrective action fail more often (${pc(seg(T, 'Corrective action', 'open corrective action').obs, 1)} of vendor-weeks against ${pc(seg(T, 'Corrective action', 'none open').obs, 1)}) and are not on the list.** That is intended, because the manager is already acting, but it means ${seg(T, 'Corrective action', 'open corrective action').failures} failures in 2024 to 2025 occurred where the list was blind by design. The app shows these vendors in a separate "held out" line with their forecasts.`));
kids.push(P(`**Vendors with little recent delivery activity almost never fail.** Under 13 deliveries in the last 13 weeks, there were ${seg(T, 'History length (deliveries in last 13 wks)', '0-5 deliveries').failures + seg(T, 'History length (deliveries in last 13 wks)', '6-12').failures} failures in ${(seg(T, 'History length (deliveries in last 13 wks)', '0-5 deliveries').rows + seg(T, 'History length (deliveries in last 13 wks)', '6-12').rows).toLocaleString()} vendor-weeks, so spending a review on them is rarely worthwhile; vendors with no deliveries at all are shown as "not scored" rather than as zero risk.`));
kids.push(P(`**Drift in 2026 was largest in protein and large vendors.** Failures ran above forecast in most groups, as the declared 2026 shift implies, and observed over forecast was ${f2(seg(T6, 'Vendor category', 'protein').oe)} for protein (95% interval ${f2(seg(T6, 'Vendor category', 'protein').oe_lo)} to ${f2(seg(T6, 'Vendor category', 'protein').oe_hi)}) and ${f2(seg(T6, 'Vendor size', 'large').oe)} for large vendors (${f2(seg(T6, 'Vendor size', 'large').oe_lo)} to ${f2(seg(T6, 'Vendor size', 'large').oe_hi)}), against about 1.0 in development. That is the declared 2026 shift showing up, and it is why the app carries a drift monitor.`));

// ================================================================== 5. Improvements
kids.push(H1('5. Improvements we tried (2a to 2c)', true));
kids.push(P('We chose each candidate because of something the error analysis showed, and judged every one the same way: the same eight rolling blocks, the same rows, the same seeds and the same paired bootstrap, on development data only. The rules were fixed before the experiments ran. A change to the model was kept only if log loss improved by at least 0.001, it did so in at least 6 of 8 blocks, and the share of failure cost inside the list was not more than 1 point lower. A change to recalibration followed the same rule without the list clause. A change to the cost ranking needed 1 point more cost in the list in at least 5 of 8 blocks. A change to the dollar estimate needed a typical miss at least 1% lower, in at least 6 of 8 blocks, with a paired 95% interval that excludes zero. With thirteen comparisons one can win by luck, which is why the block-consistency requirement is there.'));
kids.push(P('**Two of the thirteen came from Debra Senteu\'s screening script** (code/15_select_improvements.py), which compared two ideas on two yearly folds (train 2023, test 2024; train 2023 to 2024, test 2025): treating delivery volume as a fixed multiplier on the failure chance (J), and adding vendor category to the dollar estimate (K). Her script judged them by whether the average was lower, and found no gain for J and a $13 lower typical miss for K ($1,161 against $1,174). That is a good screen but two folds and no interval cannot separate a 1% change from noise, so we ran both on the same eight blocks as everything else, with a stated rule. We wrote the rules for J and K knowing her result, so they are a fair reading, not a blind test. (Her script also hard-coded a vendor-pooling value of 1.0 where the fitted Week 10 model uses 0.01; we corrected that, and her decisions did not change.)'));
const why = { A1: 'Observed over forecast moved between quarters; recent data might matter more', A2: 'As A1, with a longer memory', B1: 'Four-week rejection rates rest on few deliveries and swing', B2: 'As B1, with heavier smoothing', C: 'The list catches 74% of failures that follow a recent failure and 26% of those that do not', D1: 'Rejection groups show little added signal', D2: 'As D1, for the four-week rate', G1: 'Vendor-specific signal is weak; shrink vendors harder toward their category', G2: 'The opposite check: let vendors differ more', F: 'Quarterly drift in observed over forecast', J: 'Debra\'s screen: volume as a fixed multiplier on the failure chance (as in the Week 9 model), with exposure shrunk toward the category mean' };
const ORD = 'ABCDFGJ';
const imp = IM.variants.filter(v => v.kind !== 'base').sort((a, b) => ORD.indexOf(a.name.trim()[0]) - ORD.indexOf(b.name.trim()[0]));
const impRows = imp.map(v => { const id = v.name.split(/\s+/)[0]; return [v.name.replace(/\s{2,}/g, ' '), why[id] || '', sg(v.logloss - IM.variants[0].logloss, 4), `${v.blocks_better}/8`, ptsci([v.cap_diff, v.cap_ci[0], v.cap_ci[1]]), v.keep ? 'Adopted' : 'Rejected']; });
impRows.push(['E. Category-specific failure cost (rank by chance × category cost)', 'Protein and dairy carry about half of the failure cost but little of it is caught', 'unchanged', `${IM.category_cost.blocks_higher}/8`, ptsci([IM.category_cost.diff, IM.category_cost.ci[0], IM.category_cost.ci[1]]), IM.category_cost.keep ? 'Adopted' : 'Rejected']);
const KM = IM.cost_model_k;
impRows.push(['K. Vendor category added to the dollar estimate', `Debra\'s screen: typical miss $13 lower on two folds. Here: ${usdS(KM.diff)} (${sg(KM.pct * 100, 1)}%; interval ${usdS(KM.ci[0])} to ${usdS(KM.ci[1])}). The right-hand column is the list effect of pricing by category`, 'dollars only', `${KM.blocks_better}/8 dollars; ${KM.rank_blocks_higher}/8 list`, ptsci([KM.rank_diff, KM.rank_ci[0], KM.rank_ci[1]]), KM.keep ? 'Adopted' : 'Rejected']);
kids.push(table([2200, 2650, 900, 760, 2200, 1130], ['Candidate', 'Why we tried it', 'Log loss vs Week 10', 'Blocks better', 'Cost held in list vs Week 10 (points)', 'Decision'], impRows, { size: 15, num: [2, 3, 4] }));
kids.push(CAP(`Baseline (the Week 10 model): log loss ${f4(IM.variants[0].logloss)}, ${pc(IM.variants[0].capture, 1)} of failure cost inside the list. Cost-ranking candidate E: cost does not differ by category (Kruskal-Wallis p = ${f2(IM.category_cost.kruskal_p)}), so ranking by chance times category cost gives the same list as ranking by chance.`));
kids.push(P(`**Result: the Week 10 model stays.** None of the candidates reached the log-loss threshold with the required consistency. The closest, weaker vendor effects, raised cost in the list by about two points but made log loss slightly worse and was better in only 2 of 8 blocks. Debra's two ideas fare no better: the shrunk exposure offset is slightly worse on log loss and better in only ${IM.variants.find(v => v.name.startsWith('J')).blocks_better} of 8 blocks, and adding category to the dollar estimate lowers the typical miss by ${usd(Math.abs(IM.cost_model_k.diff))} (${(Math.abs(IM.cost_model_k.pct) * 100).toFixed(1)}%) with an interval of ${usdS(IM.cost_model_k.ci[0])} to ${usdS(IM.cost_model_k.ci[1])}, below the 1% bar and inconsistent across blocks (${IM.cost_model_k.blocks_better} of 8), while pricing the list by category lowers the cost held in it. The pattern across all thirteen is the useful finding: the data contain only a modest amount of vendor-specific signal beyond category and volume, so more tuning does not help.`));
kids.push(P('**What we did change.** First, a correctness fix in the cost estimate: the cost model was fitted on the occupancy and banquet flag of the week a failure happens, but the Week 10 app priced next week\'s failure with the selected week\'s own values. The app now feeds the cost model next week\'s expected occupancy and banquet flag, so the inputs at scoring match those at fitting. It is not an accuracy gain (the difference is noise). Second, the decision-support features in section 7. The probability model and its coefficients are unchanged, and a check that the Week 11 pipeline reproduces the Week 10 2026 predictions agrees to ' + E.parity_w10_2026.toExponential(1) + '.'));

// ================================================================== 6. Remaining limitations
kids.push(H1('6. Remaining limitations (2d)'));
const lim = [
  ['Synthetic data.', 'Every number shows how the method behaves on a generated resort, including a declared 2026 shift. It does not say how a real property would perform.'],
  ['2026 is a previously viewed holdout.', 'It cannot serve as a clean final test. We used it only for confirmation, but the team has seen the Week 10 results, and the "meaningful improvement" thresholds were written after those results were known.'],
  ['The list holds about half the cost, not most of it.', `At capacity the list holds ${pc0(DD.res[MODEL].cost)} (2024 to 2025) and ${pc0(DV.res[MODEL].cost)} (2026) of next-week failure cost. Reaching 80% takes about two to two and a half times the capacity.`],
  ['No demonstrated edge over delivery volume.', 'The model matches ranking by volume within the noise of this data. It may do better with more weeks or richer inputs, but we cannot show it.'],
  ['Weak vendor-specific signal.', 'Recent rejections add little to the ranking, and the model without them is statistically the same. Early deterioration of one vendor is hard to detect with three years of weekly data.'],
  ['Dollar estimates are averages.', 'Failure cost varies from a few hundred to several thousand dollars and the inputs we have do not explain which failures are expensive.'],
  ['Drift.', 'The intervals reflect uncertainty in the fitted coefficients, not a changed world, so they understate risk when conditions shift (weekly dollar intervals covered 71% in 2026, not 80%). The monitor flags this; it does not correct it.'],
  ['Uneven coverage.', 'Protein, dairy, peak weeks and large vendors are covered least, and vendors under open corrective action are held out of the list by design.'],
  ['Scenarios are model arithmetic.', 'The what-if tab shows what the fitted model would say if a record looked different. It does not show that changing an input would change what happens.'],
  ['One outside test.', 'The structured test in section 8 involved one person. It shows what went wrong for that person, not how often.']
];
kids.push(table([2900, W - 2900], null, lim, { size: 17, firstFill: true, firstBold: true }));

// ================================================================== 7. Decision support in the app
kids.push(H1('7. Decision support in the revised app (3a to 3f)', true));
kids.push(H2('What to tell the general manager (3a)'));
kids.push(box([
  `"Each Monday the tool ranks about ${Math.round(E.eligible_per_week.dev)} vendors by the chance of a material failure next week. The vendors at the top (as few as four in the busiest weeks, up to twelve in quiet ones) held about half of next-week failure cost in testing, around two and a half times what a random list of that size would hold and ${Math.round(DD.cmp[PRAC].cost[0] * 100)} to ${Math.round(DV.cmp[PRAC].cost[0] * 100)} points more than the on-time and fill-rate rules we use today. It is not shown to beat simply reviewing our highest-volume vendors, and it cannot say which supplier will fail: a vendor at 19% still does not fail in four of five such weeks. Dollar figures are averages; a real failure cost between ${usd(cs.dev.p10)} and ${usd(cs.dev.p90)} in four cases out of five. It is weakest for protein and dairy suppliers and in peak weeks. All of this was measured on synthetic data."`
], GREEN));
kids.push(sp(60));
kids.push(P('The app states the same limits on its Evaluation tab, in the manager\'s terms, with the baseline tables, the list-size chart, the segment table and the improvements table behind them.'));

kids.push(H2('Which inputs a user can change (3c)'));
kids.push(table([2900, 1700, W - 4600], ['Input', 'Label in the app', 'Why'], [
  ['Deliveries received, last 13 weeks and last 4 weeks', 'You can change', 'They are the record as counted on that Monday. A scenario means "if the record had looked like this".'],
  ['Rejected on delivery, last 13 weeks and last 4 weeks', 'You can change', 'Same. A scenario here is not what a corrective action would achieve: rejections already happened.'],
  ['Vendor category and size; the vendor\'s own 2023 to 2025 record', 'Fixed', 'Part of the vendor, learned from history; cannot be edited in a scenario.'],
  ['Season, review capacity, next week\'s occupancy and banquet booking', 'Outside your control', 'Set by the calendar and the property.'],
  ['Failure-rate shift for all vendors; cost of a failure', 'Outside your control', 'Scenario conditions (a drift like 2026, a price spike), not choices the manager makes.']
], { size: 16, firstFill: true, firstBold: true }));

kids.push(H2('Input checks and the invalid-scenario message (3d)'));
kids.push(P('The what-if inputs are counts, not sliders: deliveries and rejections for the last 13 and last 4 weeks, each shown next to the value recorded for that Monday. The tool computes the rates from the counts, so combinations that could never be recorded cannot be entered. It checks, in this order: whole numbers of at least zero; rejected not above received in each window; the 4-week figures not above the 13-week figures (the last 4 weeks are part of the last 13); and weeks 5 to 13 (the 13-week figure minus the 4-week figure) not holding more rejections than deliveries. A vendor with no deliveries in 13 weeks cannot be scored and the tool never treats it as zero risk. Values that are possible but outside what the model has seen are allowed and flagged as extrapolation. When a scenario is impossible the tool shows no forecast, names every broken rule, and offers a button that moves to the nearest possible scenario.'));
kids.push(table([W / 2, W / 2], null, [[
  [img('app_invalid_answer.png', 330, 'Invalid-scenario message'), CAP('Typing 120 rejected deliveries when 95 were received.')],
  [P('Automated checks (`qa/wk11_whatif.js`) cover decimals, negatives, empty boxes, each relationship above, the no-deliveries case, the repair button, quick scenarios, phone width and console errors: 32 checks, all passing on the delivered build.', { size: 17 })]
]], { size: 16 }));

kids.push(H2('Baseline against scenario, and the automatic summary (3e, 3f)'));
kids.push(P('Changing any input fills a two-column table: the vendor as recorded on that Monday against the scenario, the inputs that changed (shaded), the model\'s answers with 80% intervals, the difference, and where the vendor would land on that week\'s list. Below it the app writes a summary from the inputs, in four parts: what changed, what the model says, trade-offs to weigh, and what the result does and does not tell you, including the line "Model-based, not proven cause".'));
kids.push(img('app_compare.png', 450, 'Side-by-side comparison of the recorded week and a scenario'));
kids.push(CAP('Figure 4. Produce 002, week 26: three more rejected deliveries than recorded. The chance rises from 19.4% to 36.1% and the vendor stays first on the list of five; a warning (not shown here) says the 4-week rejection rate is beyond what the model has seen.'));
kids.push(img('app_summary.png', 450, 'Automatic scenario summary'));
kids.push(CAP('Figure 5. The automatic summary for the same scenario.'));
kids.push(H2('Explaining one prediction (3b)'));
kids.push(P('Built in Week 10 and kept: the tool breaks any forecast into the contribution of each input, walking from a reference vendor-week to this one. Because the model is linear on its link scale, these are exact Shapley values, and they are separate from the overall importance chart on the Model performance tab.'));
kids.push(img('app_contrib.png', 420, 'Contributions to one forecast'));
kids.push(CAP('Figure 6. Produce 002, week 26: category +1.61, the vendor\'s own record +0.31, deliveries +0.45, four-week rejections +0.21, thirteen-week rejections about zero; the contributions add to the distance from the reference vendor-week, and the running chance ends at 19.4%.'));

// ================================================================== 8. Outside test
kids.push(H1('8. Structured test with someone outside the group (4)'));
kids.push(P('We prepared a kit (`usability_test/Week11_Usability_Test_Kit.docx`): a protocol with a neutral script and rules for hints, a one-page task sheet of eight tasks (read the weekly list, read a forecast and its interval, find why a vendor scores what it does, tell changeable from fixed inputs, run a what-if, recover from an impossible scenario, judge whether to rely on the tool, and use the summary), an observation form, post-test questions, a findings log and a facilitator answer key with the places we expected trouble, written before the session.'));
let res = null;
try { res = JSON.parse(fs.readFileSync(URES, 'utf8')); } catch (e) { res = null; }
if (!res) {
  kids.push(box(['**Status: the session has not been run, and this section holds no results.** It will be completed from the real session record (who took part, what happened on each task, what we changed because of it). Nothing has been simulated or filled in.'], AMBER));
} else {
  kids.push(P(`**The session.** ${res.summary}`));
  if (res.tasks && res.tasks.length) kids.push(table([700, 1900, 1100, W - 700 - 1900 - 1100 - 800, 800], ['Task', 'Result', 'Time', 'What happened', 'Severity'], res.tasks.map(t => [String(t.n), t.result, t.time || '', t.notes || '', String(t.severity ?? '')]), { size: 16 }));
  if (res.ratings) kids.push(P('**After the test.** ' + res.ratings));
  if (res.findings && res.findings.length) {
    kids.push(P('**Findings and what we changed.**', { after: 60, keepNext: true }));
    kids.push(table([3000, 700, 2900, W - 6600], ['What happened', 'Sev', 'Decision', 'Change made and retest'], res.findings.map(f => [f.what, String(f.severity ?? ''), f.decision, f.change + (f.retest ? ' Retest: ' + f.retest : '')]), { size: 16 }));
  }
  if (res.limits) kids.push(P('**Limits.** ' + res.limits));
}

// ================================================================== 9. Package
kids.push(H1('9. The package: what is in it and how to run it (5)'));
kids.push(table([3100, W - 3100], ['Item', 'What it is'], [
  ['`Week10_frozen/`', 'The Week 10 submission, unchanged, so the earlier version stays identifiable.'],
  ['`app/index.html`', 'The revised app: one self-contained file with four tabs (Model performance, Evaluation & limits, What-if forecast, Weekly review list). Open it in any browser. `app/artifact_page.html` is the same page for hosting; the Streamlit wrapper in `streamlit/` embeds it.'],
  ['`data/source/` and `data/`', 'The shareable synthetic source tables and the derived tables, the fitted model, the Week 11 evaluation files (`wk11_*.json`, `wk11_dev_oof.csv`).'],
  ['`code/`', 'Pipeline scripts. `bash code/run_all.sh` rebuilds everything in about three minutes: model table, fit, Debra\'s two-fold screen (15), Week 11 evaluation (20), error analysis (21), improvements (22), app data (12, 14) and app (13).'],
  ['`docs/`', 'Logs written by the scripts (`wk11_evaluation_log.txt`, `wk11_error_analysis.txt`, `wk11_improvements_log.txt`), the changelog and the Week 10 documents.'],
  ['`report/`', 'This report (`.docx` and `.pdf`), its figures and the scripts that build them.'],
  ['`usability_test/`', 'The test kit and, after the session, the completed forms and findings log.'],
  ['`video/`', 'The seven-minute video script and the silent screen capture to narrate over.'],
  ['`qa/`', 'Browser tests with Playwright: Python-to-JavaScript parity, the what-if checks, and screenshots.'],
  ['`README.md`, `requirements.txt`, `requirements-tested.txt`', 'Setup and dependencies: Python 3.10 or later with numpy, pandas, scipy and scikit-learn (tested versions are listed); Node with Playwright only for the optional browser tests.']
], { size: 16, firstFill: true, firstBold: true }));
kids.push(sp(100));
kids.push(P('**Reproducibility.** The Week 11 pipeline reproduces the Week 10 2026 predictions to within ' + E.parity_w10_2026.toExponential(1) + '. Some decision-list shares differ from the Week 10 report by up to one point because Week 11 averages over tie-break draws in the rule-based lists and uses the exact expectation for the random list; the conclusions do not change.'));
kids.push(P('**Contributions.** See `CONTRIBUTIONS.md` in the package. It is a draft for the team to confirm; we have not written anything there that the team has not told us.'));
kids.push(P('**Methods references.** Van Calster et al. (2019) BMC Medicine 17:230 on calibration; Hand (2009) Machine Learning 77:103 on the limits of AUC; Elkan (2001) IJCAI on cost-sensitive decisions; Davis et al. (2017) AMIA Annual Symposium on calibration drift; Efron and Morris (1977) on shrinkage; Goodwin, Önkal and Thomson (2010) EJOR 205:195 on prediction intervals in planning.', { size: 17, color: GREY }));

const doc = new Document({
  creator: 'Mirza Ali and Debra Senteu', title: 'Vendor Failure Forecast - Week 11 evaluation report',
  styles: { default: { document: { run: { font: FONT, size: BODY, color: INK } } } },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1100, bottom: 1000, left: 1200, right: 1200 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [run('Vendor Failure Forecast · Week 11 evaluation report · page ', { size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY })] })] }) },
    children: kids
  }]
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log('ok', OUT); });
