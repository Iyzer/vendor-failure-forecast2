// Element screenshots of the Week 11 what-if tab for the evaluation report.
const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const page = await (await b.newContext({ viewport: { width: 1240, height: 900 }, deviceScaleFactor: 2, colorScheme: 'light' })).newPage();
  await page.goto(APP + '#whatif'); await page.waitForTimeout(600);
  const opts = await page.$$eval('#wi-week option', o => o.map(x => [x.value, x.textContent]));
  await page.selectOption('#wi-week', opts[25][0]);
  const vopts = await page.$$eval('#wi-vendor option', o => o.map(x => [x.value, x.textContent]));
  await page.selectOption('#wi-vendor', vopts.find(x => /Produce 002/.test(x[1]))[0]);
  const out = n => path.join(__dirname, 'figures', n);
  await page.click('button[data-q="rej+3"]'); await page.waitForTimeout(250);
  await (await page.$('#wi-answer')).screenshot({ path: out('app_answer.png') });
  await (await page.$('#wi-compare')).screenshot({ path: out('app_compare.png') });
  await (await page.$('#wi-summary')).screenshot({ path: out('app_summary.png') });
  await page.click('button[data-q="reset"]'); await page.waitForTimeout(200);
  await (await page.$('#wi-contrib')).screenshot({ path: out('app_contrib.png') });
  await page.fill('#n-r13', '120'); await page.waitForTimeout(250);
  await (await page.$('#wi-answer')).screenshot({ path: out('app_invalid_answer.png') });
  await (await page.$('aside')).screenshot({ path: out('app_invalid_inputs.png') });
  await b.close();
})();
