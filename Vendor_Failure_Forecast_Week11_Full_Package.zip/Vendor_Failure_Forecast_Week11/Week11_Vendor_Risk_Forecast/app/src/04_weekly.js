/* ------------------------------------------------------------------ SCREEN 3: weekly review list with rank stability and a hindsight check */
const WK = { wi: weekIndex['2026-W26'] ?? 25, reveal: true, all: false };
const SIM_CACHE = {};
const simFor = wi => SIM_CACHE[wi] || (SIM_CACHE[wi] = weekSimulation(wi));

function wkOutcome(wi) {
  const out = {};
  for (let vi = 0; vi < V; vi++) { const i = ri(wi, vi); out[vi] = R.y[i] === null ? null : { y: R.y[i], cost: R.cost[i] || 0 }; }
  return out;
}

function wkRender() {
  const wi = WK.wi, w = D.weeks[wi], sim = simFor(wi), k = w.k, out = wkOutcome(wi);
  const hasOut = !w.w53;
  const elig = sim.vis.filter(vi => sim.scores[vi].cap === 0).sort((a, b) => sim.scores[b].p - sim.scores[a].p);
  const held = sim.vis.filter(vi => sim.scores[vi].cap === 1), unscored = []; for (let vi = 0; vi < V; vi++) if (!sim.scores[vi]) unscored.push(vi);
  const list = elig.slice(0, k), inList = new Set(list);
  const actual = hasOut ? sim.vis.reduce((t, vi) => t + out[vi].y, 0) : null, actualCost = hasOut ? sim.vis.reduce((t, vi) => t + out[vi].cost, 0) : null;
  const addrFail = hasOut ? elig.filter(vi => out[vi].y === 1) : [], addrCost = addrFail.reduce((t, vi) => t + out[vi].cost, 0);
  const caught = addrFail.filter(vi => inList.has(vi)), caughtCost = caught.reduce((t, vi) => t + out[vi].cost, 0);
  const show = WK.reveal && hasOut;

  $('#wk-week').value = String(wi);
  $('#wk-prev').disabled = wi === 0; $('#wk-next').disabled = wi === W - 1;
  const t1 = { v: sim.expCount.toFixed(1), k: 'Vendors expected to fail next week', d: `80% interval ${sim.countLo.toFixed(0)} to ${sim.countHi.toFixed(0)}${show ? ` · actually ${actual}` : ''}` };
  const t2 = { v: usd(sim.expCost), k: 'Expected failure cost next week', d: `80% interval ${usd(sim.costLo)} to ${usd(sim.costHi)}${show ? ` · actually ${usd(actualCost)}` : ''}` };
  const t3 = { v: `${list.length}<small> of ${elig.length}</small>`, k: 'Vendors on the review list', d: `${w.season} week, capacity ${k}. ${held.length} held out (open corrective action), ${unscored.length} not scored.` };
  const t4 = !hasOut ? { v: '—', k: 'Hindsight check unavailable', d: 'The final week has no following week, so it cannot be graded.' }
    : !show ? { v: '—', k: 'Hindsight check hidden', d: 'Switch on "show what actually happened" above.' }
    : addrFail.length === 0 ? { v: 'None', k: 'Addressable failures the following week', d: 'Nothing for the list to catch this week.' }
    : { v: `${caught.length}<small> of ${addrFail.length}</small>`, k: 'Failures the list caught', d: `${usd(caughtCost)} of ${usd(addrCost)} addressable cost.` };
  $('#wk-tiles').innerHTML = [t1, t2, t3, t4].map((t, i) => `<div class="tile${i === 3 && show && addrFail.length ? ' hero' : ''}"><div class="v num">${t.v}</div><div class="k">${t.k}</div><div class="d">${t.d}</div></div>`).join('');

  $('#wk-title').textContent = `${weekLabel(w)} · ${w.season} season`;
  $('#wk-cap').textContent = `A failure next week would cost about ${usd(sim.mu)} (next week's expected occupancy ${pct(w.occ_n, 0)}${w.banq_n ? ', banquet booked' : ', no banquet'}). That figure is the same for every vendor, so the ranking by expected cost is the ranking by chance. Whiskers are 80% intervals.`;

  const rows = WK.all ? elig : elig.slice(0, k + 6), maxHi = niceMax(Math.max(...rows.map(vi => sim.scores[vi].hi), 0.02) * 1.05);
  let tb = `<table><thead><tr><th class="n">#</th><th>Vendor</th><th class="n">Chance</th><th>80% interval</th><th class="n" title="Share of 600 draws from the model's uncertainty in which the vendor makes the list">In list</th>${show ? '<th>Next week</th>' : ''}</tr></thead><tbody>`;
  rows.forEach((vi, i) => {
    const s = sim.scores[vi], v = D.vendors[vi], share = sim.inTopShare[vi], o = out[vi];
    const bar = `<div class="rng" role="img" aria-label="${pct(s.lo, 1)} to ${pct(s.hi, 1)}" data-tip="${esc(`<b>${esc(v.name)}</b>` + tipRow('Chance', pct(s.p, 1)) + tipRow('80% interval', `${pct(s.lo, 1)} to ${pct(s.hi, 1)}`) + tipRow('Deliveries / wk', s.expo.toFixed(2)) + tipRow('Rejections, 4 wks', pct(s.rej4, 1)))}"><span class="whisk" style="left:${s.lo / maxHi * 100}%;width:${Math.max(0.5, (s.hi - s.lo) / maxHi * 100)}%"></span><span class="dot${i < k ? ' in' : ''}" style="left:${s.p / maxHi * 100}%"></span></div>`;
    const res = show ? `<td>${o.y === 1 ? `<span class="pill fail"><span aria-hidden="true">✕</span> Failed · ${usd(o.cost)}</span>` : '<span class="muted">—</span>'}</td>` : '';
    tb += `<tr><td class="n">${i + 1}</td><td class="nw">${esc(v.name)} <span class="muted small hide-sm">${esc(D.cat_labels[v.cat])}</span></td><td class="n">${pct(s.p, 1)}</td><td>${bar}</td><td class="n">${pct(share, 0)}</td>${res}</tr>`;
    if (i === k - 1) tb += `<tr class="capline"><td colspan="${show ? 6 : 5}"></td></tr>`;
  });
  $('#wk-table').innerHTML = tb + '</tbody></table>';
  bindTips($('#wk-table'));
  $('#wk-more').textContent = WK.all ? `Show only the top ${Math.min(elig.length, k + 6)}` : `Show all ${elig.length} eligible vendors`;
  $('#wk-more').hidden = elig.length <= k + 6;
  const heldTxt = held.length ? `Held out, open corrective action: ${held.map(vi => `${D.vendors[vi].name} (${pct(sim.scores[vi].p, 1)})${show && out[vi].y === 1 ? ' ✕ failed' : ''}`).join(', ')}. ` : '';
  const unTxt = unscored.length ? `Not scored, no deliveries in the last 13 weeks (never treated as zero risk): ${unscored.slice(0, 6).map(vi => D.vendors[vi].name).join(', ')}${unscored.length > 6 ? ` and ${unscored.length - 6} more` : ''}.` : '';
  $('#wk-unscored').textContent = heldTxt + unTxt;
}

function initWeekly() {
  const sel = $('#wk-week');
  sel.innerHTML = D.weeks.map((w, i) => `<option value="${i}">${esc(weekLabel(w))} · ${w.season}${w.w53 ? ' · week 53' : ''}</option>`).join('');
  sel.addEventListener('change', () => { WK.wi = Number(sel.value); wkRender(); });
  $('#wk-prev').addEventListener('click', () => { WK.wi = Math.max(0, WK.wi - 1); wkRender(); });
  $('#wk-next').addEventListener('click', () => { WK.wi = Math.min(W - 1, WK.wi + 1); wkRender(); });
  $('#wk-reveal').addEventListener('change', e => { WK.reveal = e.target.checked; wkRender(); });
  $('#wk-more').addEventListener('click', () => { WK.all = !WK.all; wkRender(); });
}
