/* ------------------------------------------------------------------ SCREEN: evaluation and limits (Week 11)
   Everything on this screen is read from D.wk11, which is exported from the same scripts that produced the report
   (code/20_wk11_evaluation.py, 21_wk11_error_analysis.py, 22_wk11_improvements.py). No number is typed in by hand. */
const X11 = D.wk11;
const byName = (arr, n) => arr.find(r => r.name === n);
const M_ = 'Model (this tool)', VOL_ = 'Delivery volume (spend proxy)', PRAC_ = 'Current practice (on-time/fill + loud failure)', RAND_ = 'Random list',
      CAT_ = 'Category rate', VEN_ = "Vendor's own history (smoothed)", GBM_ = 'Gradient-boosted trees', TRAIL_ = 'Trailing 13-week rejection rate';
const f2 = x => x.toFixed(2), f3_ = x => x.toFixed(3), f4 = x => x.toFixed(4);
const sg = (x, d = 4) => (x >= 0 ? '+' : '−') + Math.abs(x).toFixed(d);
const rng_ = (a, d = 4) => `[${sg(a[1], d)}, ${sg(a[2], d)}]`;
const usdS = x => (x >= 0 ? '+' : '−') + '$' + Math.abs(Math.round(x)).toLocaleString();
const ptsci = a => `${pts(a[0])} pts [${pts(a[1])}, ${pts(a[2])}]`;
const pill = (cls, t) => `<span class="pill ${cls}">${t}</span>`;
const lvlName = r => r.segment === 'Vendor category' ? D.cat_labels[D.cats.indexOf(r.level)] : String(r.level).replace(/^./, c => c.toUpperCase());
const segRow = (g, lv) => X11.segments.dev.find(r => r.segment === g && r.level === lv);

function renderEvalStatic() {
  const sp = X11.split, dd = X11.decision.dev, dv = X11.decision.val, ls = X11.list_size;
  const mD = byName(dd, M_), mV = byName(dv, M_), pD = byName(dd, PRAC_), pV = byName(dv, PRAC_), vD = byName(dd, VOL_), vV = byName(dv, VOL_), rD = byName(dd, RAND_), rV = byName(dv, RAND_);
  const k1 = Math.round(ls.dev.find(r => r.mult === 1).mean_k), elig = Math.round(ls.eligible.dev);
  const x2 = ls.dev.find(r => r.mult === 2), x2v = ls.val.find(r => r.mult === 2), x25 = ls.dev.find(r => r.mult === 2.5), x25v = ls.val.find(r => r.mult === 2.5);
  const pk = X11.segments.peak, cs = X11.kpi2.cost_summary, k2 = X11.kpi2.dev, k2n = 'Week 10 cost model (occupancy + banquet of the failure week)', k2a = 'Average past failure cost';
  const ov = X11.segments.overall, ca = segRow('Corrective action', 'open corrective action'), cn = segRow('Corrective action', 'none open');
  const oeAll = ov.failures / (ov.pred * ov.rows);
  const items = [
    `<b>What the list delivers.</b> In a normal week you can review about ${k1} of the roughly ${elig} eligible vendors. In the 2024–25 walk-forward tests those ${k1} accounted for <b>${pct(mD.cost, 0)}</b> of the next week’s failure cost (95% interval ${pct(mD.cost_ci[0], 0)} to ${pct(mD.cost_ci[1], 0)}); in the 2026 hold-out, <b>${pct(mV.cost, 0)}</b>. Today’s rules would have caught ${pct(pD.cost, 0)} and ${pct(pV.cost, 0)}; a random list, ${pct(rD.cost, 0)}.`,
    `<b>Better than today, not clearly better than a simple rule.</b> Against what you do now the list is ${pts(pD.diff[0], 0)} to ${pts(pV.diff[0], 0)} points ahead, and both intervals sit above zero. Against simply reviewing the vendors with the most deliveries it is only ${pts(vD.diff[0], 0)} points ahead in 2024–25 (interval ${pts(vD.diff[1], 0)} to ${pts(vD.diff[2], 0)}) and ${pts(vV.diff[0], 0)} in 2026: the data cannot tell the two apart. Most of the model’s skill is knowing a vendor’s category and how busy it is; recent rejection rates add little.`,
    `<b>How many to review matters more than the model.</b> A list twice as long (about ${Math.round(x2.mean_k)} a week) would catch ${pct(x2['Model (this tool)'].cost, 0)} in 2024–25 and ${pct(x2v['Model (this tool)'].cost, 0)} in 2026; about ${Math.round(x25.mean_k)} a week gets to ${pct(x25['Model (this tool)'].cost, 0)} and ${pct(x25v['Model (this tool)'].cost, 0)}. In peak weeks the list is only ${pk['peak weeks'].k.toFixed(1)} vendors (${pk['other weeks'].k.toFixed(1)} otherwise) and the share of failures caught falls from ${pct(pk['other weeks'].catch, 0)} to ${pct(pk['peak weeks'].catch, 0)}.`,
    `<b>The percentages are about right on average, until the world shifts.</b> Over 2024–25 the model expected ${(ov.pred * ov.rows).toFixed(0)} failures and ${ov.failures} happened (ratio ${f2(oeAll)}). In 2026 failures ran ${((Math.exp(E.holdout.calib.shift) - 1) * 100).toFixed(0)}% above forecast, led by protein; the drift monitor on the Performance tab is the early warning.`,
    `<b>Treat the dollar figure as an average, not a prediction.</b> A failing vendor-week cost $${Math.round(cs.dev.mean).toLocaleString()} on average in 2024–25 and $${Math.round(cs.val.mean).toLocaleString()} in 2026, with a wide spread (the middle 80% ran $${Math.round(cs.dev.p10).toLocaleString()} to $${Math.round(cs.dev.p90).toLocaleString()}). The model’s estimate of that cost misses by about $${Math.round(k2[k2n].mae).toLocaleString()}, the same as always using the average ($${Math.round(k2[k2a].mae).toLocaleString()}). It sizes the problem; it does not change who is on the list.`,
    `<b>Known blind spots.</b> Vendors with an open corrective action are held out of the list by design, yet failed ${pct(ca.obs, 0)} of weeks against ${pct(cn.obs, 0)} for everyone else. The list catches few failures at protein vendors (${pct(segRow('Vendor category', 'protein').catch, 0)}), large vendors (${pct(segRow('Vendor size', 'large').catch, 0)}) and in peak weeks. ${pct(segRow('Recent failure', 'no failure in 13+ wks').failures / ov.failures, 0)} of failures hit vendors with no failure in the previous 13 weeks, and little in the data warns of those.`
  ];
  $('#ev-plain').innerHTML = `<h3>What to take from the testing, in plain terms</h3><ul class="plainlist">${items.map(t => `<li>${t}</li>`).join('')}</ul>
    <p class="small muted" style="margin-top:8px">Numbers on this screen: <b>2024–25 tests</b> = eight walk-forward blocks, each predicted by a model fitted only on earlier weeks (all design choices were made on these). <b>2026</b> = the frozen Week 10 model on the hold-out year; it had already been looked at in Week 10, so it confirms rather than proves.</p>`;

  // ---- design
  $('#ev-design-cap').textContent = `Weeks are linked in time and the tool is used going forward, so rows were never split at random. Each quarter of 2024–25 was predicted by a model fitted only on rows whose outcome was already known on that quarter’s first Monday. 2026 was held back, scored once, and never used to choose anything in Week 11.`;
  $('#ev-design').innerHTML = table(['Data', 'Weeks', 'Vendor-weeks scored', 'Next-week failures', 'Role'], [
    ['2023–2025 (development)', sp.dev_weeks, sp.dev_rows.toLocaleString(), `${sp.dev_fail_rows} (${pct(sp.dev_rate)})`, 'Fit the model; eight walk-forward test blocks (2024 Q1 to 2025 Q4) for every comparison, error analysis and improvement test'],
    ['2026 (hold-out)', sp.val_weeks, sp.val_rows.toLocaleString(), `${sp.val_fail_rows} (${pct(sp.val_rate)})`, 'Frozen Week 10 model scored once; previously viewed, so confirmation only (no fresh year was generated for a clean test)']
  ], [1, 2, 3]);
  const lc = X11.leakage_controls;
  $('#ev-leak').innerHTML = table(['Input', 'Where it comes from', 'When it is known'], X11.leakage_table.map(r => [esc(r.item), esc(r.source), esc(r.known)])) +
    `<p class="small" style="margin-top:8px"><b>Checks run.</b> Every snapshot’s cut-off is the Monday of its own week: ${X11.leakage_checks.asof_ok ? 'yes' : 'NO'}. Every walk-forward block trains only on rows whose outcome was already known: ${X11.leakage_checks.walkforward_ok ? 'yes' : 'NO'}.
    <b>Negative control:</b> if an input were secretly measured after the week it predicts, it would look much better. Measuring each input two Mondays later (so its window includes the target week) lifts its ranking score, which shows the as-of versions are not peeking:
    ${lc.map(c => `${esc(c.name.toLowerCase())} ${f2(c.auc_asof)} → ${f2(c.auc_if_measured_two_mondays_later)}`).join('; ')} (AUC; 0.5 = no skill).</p>`;

  // ---- measure 1
  const K = X11.kpi1, rowsOrder = [M_, VEN_, CAT_, 'Same rate for every vendor', GBM_, 'Model without rejection rates (ablation)'], rk = [VOL_, TRAIL_, PRAC_];
  const rowOf = (blk, n) => byName(blk.rows, n);
  const nice = { [M_]: '<b>This model</b>', [VEN_]: 'Vendor’s own past failure rate', [CAT_]: 'Category average', 'Same rate for every vendor': 'Same chance for every vendor', [GBM_]: 'Gradient-boosted trees', 'Model without rejection rates (ablation)': 'This model without rejection rates', [VOL_]: 'Rank by delivery volume', [TRAIL_]: 'Rank by 13-week rejection rate', [PRAC_]: 'Rank by today’s rules' };
  const kr = n => { const a = rowOf(K.dev, n), b = rowOf(K.val, n); return [nice[n] || n, f3_(a.auc), a.brier == null ? '—' : f4(a.brier), a.logloss == null ? '—' : f4(a.logloss), a.slope == null ? '—' : f2(a.slope), f3_(b.auc), b.brier == null ? '—' : f4(b.brier), b.logloss == null ? '—' : f4(b.logloss)]; };
  $('#ev-k1-cap').innerHTML = `Measure 1 is the model’s chance that a vendor has a material failure next week. <b>Ranking (AUC)</b>: pick one vendor that failed and one that did not; the share of such pairs where the failing one had the higher chance (0.5 is a coin flip). <b>Brier score and log loss</b>: how close the stated chances were to what happened (lower is better). <b>Calibration slope</b>: 1.00 means the chances are neither too bold nor too timid. Rules that give a score rather than a chance have only a ranking.`;
  $('#ev-k1').innerHTML = table(['Method', 'AUC', 'Brier', 'Log loss', 'Calib. slope', 'AUC', 'Brier', 'Log loss'], [...rowsOrder.map(kr), ...rk.map(n => { const a = rowOf(K.dev, n), b = rowOf(K.val, n); return [nice[n], f3_(a.auc), '—', '—', '—', f3_(b.auc), '—', '—']; })], [1, 2, 3, 4, 5, 6, 7])
    .replace('<thead><tr>', '<thead><tr class="grp"><th></th><th class="n" colspan="4">2024–25 tests</th><th class="n" colspan="3">2026 hold-out</th></tr><tr>');
  const dfs = K.dev.diffs, v1 = X11.verdicts;
  const vsC = dfs[CAT_], vsV = dfs[VEN_], vsG = dfs[GBM_], vsA = dfs['Model without rejection rates (ablation)'];
  $('#ev-k1-verdict').innerHTML = `<div class="vh">${pill(v1.kpi1_probability.met ? 'in' : 'held', v1.kpi1_probability.met ? 'Meaningful improvement' : 'Small gain, short of our bar')}</div>
    <p>Model minus baseline in 2024–25, with 95% intervals (negative log loss and positive AUC favour the model): against the <b>category average</b> log loss ${sg(vsC.logloss[0])} ${rng_(vsC.logloss)}, AUC ${sg(vsC.auc[0], 3)} ${rng_(vsC.auc, 3)}; against the <b>vendor’s own history</b> log loss ${sg(vsV.logloss[0])} ${rng_(vsV.logloss)}, AUC ${sg(vsV.auc[0], 3)} ${rng_(vsV.auc, 3)}; against <b>boosted trees</b> log loss ${sg(vsG.logloss[0])} ${rng_(vsG.logloss)}.
    The gain over the category average is small but its interval excludes zero. Against a vendor’s own history the model is no better than we can measure, and it beat the best simple baseline on log loss in only ${v1.kpi1_probability.blocks_better} of 8 blocks (our bar was 6). Dropping both rejection rates changes almost nothing (AUC ${sg(vsA.auc[0], 3)}, ${rng_(vsA.auc, 3)}): the model’s skill comes from category, vendor and volume.</p>
    <details class="tbl"><summary>The bar we set in advance</summary><p class="small">Meaningful improvement on this measure = log loss lower than the best simple baseline, interval excluding zero, and lower in at least 6 of the 8 quarterly blocks; ranking ability = AUC at least 0.03 above it with an interval excluding zero. The 2026 results were already known when these rules were written; they are thresholds for a fair reading, not a blind pre-registration.</p></details>`;

  // ---- measure 2
  const K2 = X11.kpi2, names2 = [['Week 10 cost model (occupancy + banquet of the failure week)', '<b>This model’s cost estimate</b> (occupancy and banquet of the failure week)'], ['Same inputs, but last week’s occupancy + banquet (decision-time)'.replace('’', "'"), 'Same inputs, last week’s values'], ['Average cost by category', 'Average cost by category'], ['Average past failure cost', 'Average of past failure costs']];
  const k2row = ([n, lab]) => { const a = K2.dev[n], b = K2.val[n]; return [lab, '$' + Math.round(a.mae).toLocaleString(), f2(a.bias), pct(a.cover80, 0), '$' + Math.round(b.mae).toLocaleString(), f2(b.bias), pct(b.cover80, 0)]; };
  $('#ev-k2-cap').innerHTML = `Measure 2 is what a failure costs if one happens (sum of emergency premium, lost margin, guest compensation and firefighting labour for a failing vendor-week). <b>Typical miss</b> = average dollar gap between the estimate and what the failure really cost. <b>Over/under</b> = actual total ÷ estimated total (1.00 is unbiased). <b>Inside 80% range</b> = share of real costs that fell within the model’s 80% range (aim: 80%). ${K2.cost_summary.dev.n} failing vendor-weeks in 2024–25 (mean $${Math.round(K2.cost_summary.dev.mean).toLocaleString()}); ${K2.cost_summary.val.n} in 2026 (mean $${Math.round(K2.cost_summary.val.mean).toLocaleString()}).`;
  $('#ev-k2').innerHTML = table(['Method', 'Typical miss', 'Over/under', 'Inside 80% range', 'Typical miss', 'Over/under', 'Inside 80% range'], names2.map(k2row), [1, 2, 3, 4, 5, 6])
    .replace('<thead><tr>', '<thead><tr class="grp"><th></th><th class="n" colspan="3">2024–25 tests</th><th class="n" colspan="3">2026 hold-out</th></tr><tr>');
  const km = K2.dev[names2[0][0]], kmv = K2.val[names2[0][0]];
  const gainV = kmv.mae_vs_mean_ci[1] < 0, gainD = km.mae_vs_mean_ci[1] < 0 && km.mae_vs_mean_pct <= -0.05;
  $('#ev-k2-verdict').innerHTML = `<div class="vh">${pill(gainD ? 'in' : 'held', gainD ? 'Meaningful improvement' : 'No measurable improvement over the average')}</div>
    <p>Against always using the average past failure cost, the model’s typical miss changes by ${usdS(km.mae_vs_mean)} (95% interval ${usdS(km.mae_vs_mean_ci[0])} to ${usdS(km.mae_vs_mean_ci[1])}) in 2024–25, which is ${Math.abs(km.mae_vs_mean_pct * 100).toFixed(1)}% and ${gainD ? 'above' : 'short of'} the 5% we required. In 2026 it is ${usdS(kmv.mae_vs_mean)} (${usdS(kmv.mae_vs_mean_ci[0])} to ${usdS(kmv.mae_vs_mean_ci[1])}), ${gainV ? 'a small gain whose interval excludes zero, but it was not seen in the tests we used to decide' : 'no clear gain'}. Cost per failure varies far more from case to case than occupancy, banquets or category explain, so read the dollar figure as the <b>average size of a failure</b>. Its 80% range held ${pct(km.cover80, 0)} of real costs in 2024–25 and ${pct(kmv.cover80, 0)} in 2026 (aim: 80%).
    The app prices next week’s failure with next week’s occupancy and banquet flag, the same quantities the cost model was fitted on; Week 10 had used the current week’s values.</p>`;

  // ---- decision
  const dec = X11.decision;
  const drow = n => { const a = byName(dec.dev, n), b = byName(dec.val, n); const dif = x => x.diff ? ptsci(x.diff) : '—'; return [n === M_ ? '<b>This model’s list</b>' : (({ [VOL_]: 'Most deliveries first', [PRAC_]: 'Today’s rules', [TRAIL_]: 'Highest recent rejection rate first', [CAT_]: 'Riskiest category first', [VEN_]: 'Vendor’s own failure history first', [GBM_]: 'Gradient-boosted trees', [RAND_]: 'Random list', 'Model without rejection rates (ablation)': 'This model without rejection rates' })[n]), `${pct(a.cost, 0)} <span class="ivl">${pct(a.cost_ci[0], 0)} to ${pct(a.cost_ci[1], 0)}</span>`, dif(a), pct(a.fail, 0), `${pct(b.cost, 0)} <span class="ivl">${pct(b.cost_ci[0], 0)} to ${pct(b.cost_ci[1], 0)}</span>`, dif(b), pct(b.fail, 0)]; };
  $('#ev-dec-cap').innerHTML = `Each Monday the list holds as many vendors as that week’s review capacity (about ${k1} of ${elig} eligible). <b>Cost caught</b> = share of the following week’s failure cost, at vendors not already under corrective action, that fell inside the list; <b>failures caught</b> = the same for the number of failures. “This model minus this list” is in percentage points with a paired 95% interval over weeks. Perfect foresight would catch 100%; a random list ${pct(rD.cost, 0)}.`;
  $('#ev-dec').innerHTML = table(['List built by', 'Cost caught', 'Model minus this list', 'Failures caught', 'Cost caught', 'Model minus this list', 'Failures caught'],
    [M_, 'Model without rejection rates (ablation)', GBM_, VEN_, CAT_, VOL_, TRAIL_, PRAC_, RAND_].map(drow), [1, 2, 3, 4, 5, 6])
    .replace('<thead><tr>', '<thead><tr class="grp"><th></th><th class="n" colspan="3">2024–25 tests</th><th class="n" colspan="3">2026 hold-out</th></tr><tr>');
  const dcap = X11.verdicts.decision_capture, vp = X11.verdicts.decision_vs_practice;
  const bs = dec.best_simple, bsRow = byName(dec.dev, bs);
  const beatNames = blk => [GBM_, VEN_, CAT_, VOL_, TRAIL_].filter(n => { const r = byName(blk, n); return r && r.diff && r.diff[1] > 0; }).map(n => ({ [GBM_]: 'boosted trees', [VEN_]: 'the vendor’s own history', [CAT_]: 'the category-only list', [VOL_]: 'most deliveries first', [TRAIL_]: 'recent rejection rate' })[n]);
  const bD = beatNames(dec.dev), bV = beatNames(dec.val), join = a => a.length ? a.join(', ') : 'none of them';
  const blocksWon = X11.decision.blocks.filter(b => b.model > b.best_simple).length;
  $('#ev-dec-verdict').innerHTML = `<div class="vh">${pill('in', 'Clear gain over today’s rules')} ${pill(dcap.met ? 'in' : 'held', dcap.met ? 'Beats the strongest simple list' : 'Not shown to beat the strongest simple list')}</div>
    <p>Against <b>today’s rules</b> the list catches ${ptsci(vp.dev)} more cost in 2024–25 and ${ptsci(vp.val)} in 2026. Against the <b>strongest simple list</b> in 2024–25 (${esc(({ [VOL_]: 'most deliveries first', [CAT_]: 'riskiest category first', [VEN_]: 'vendor’s own history', [TRAIL_]: 'recent rejection rate', [PRAC_]: 'today’s rules' })[bs] || bs)}, ${pct(bsRow.cost, 0)}) the gain is ${ptsci(dcap.diff)}; our bar was 5 points with an interval above zero, so it is ${dcap.met ? '' : 'not '}met, and the model won ${blocksWon} of 8 quarterly blocks against that list. Lists the model beats with an interval above zero: <b>2024–25</b> ${join(bD)}; <b>2026</b> ${join(bV)}.
    What the model adds beyond a rule of thumb is a probability with an interval for each vendor, a dollar figure, and the what-if tool, not a dramatically better list.</p>`;

  // ---- segments
  const ovl = X11.segments.overall;
  $('#ev-seg-cap').innerHTML = `Out-of-sample forecasts for 2024–25 (${ovl.rows.toLocaleString()} vendor-weeks, ${ovl.failures} failures; the weekly lists caught ${pct(ovl.catch_all, 0)} of all failures and ${pct(ovl.catch_eligible, 0)} of those at eligible vendors). <b>Forecast ÷ actual</b> compares the failures that happened with what the model expected (1.00 = right on average; the range is a 95% interval). <b>Failures caught</b> = share of the segment’s failures that were on the weekly list.`;
  const groups = []; X11.segments.dev.forEach(r => { let g = groups.find(x => x.t === r.segment); if (!g) { g = { t: r.segment, rows: [] }; groups.push(g); } g.rows.push(r); });
  let tb = `<table><thead><tr><th>Segment</th><th class="n">Vendor-weeks</th><th class="n">Failures</th><th class="n">Failure rate</th><th class="n">Actual ÷ forecast</th><th class="n">On the list</th><th>Failures caught</th></tr></thead><tbody>`;
  groups.forEach(g => {
    tb += `<tr class="sec"><td colspan="7">${esc(g.t)}</td></tr>`;
    g.rows.forEach(r => {
      const weak = r.failures >= 15 && r.catch < ovl.catch_all - 0.15 && r.on_list < 0.2, strong = r.failures >= 15 && r.catch > ovl.catch_all + 0.15;
      const oe = r.failures >= 8 ? `${f2(r.oe)} <span class="ivl">${f2(r.oe_lo)} to ${f2(r.oe_hi)}</span>` : `<span class="muted">${r.failures} failures: too few to judge</span>`;
      const lvl = lvlName(r);
      const bar = r.catch == null ? '<span class="muted">—</span>' : `<div class="mini"><i style="width:${(r.catch * 100).toFixed(0)}%" class="${weak ? 'weak' : strong ? 'strong' : ''}"></i></div><span class="mv">${pct(r.catch, 0)}</span>`;
      tb += `<tr><td>${esc(lvl)}${weak ? ' ' + pill('held', 'weak spot') : ''}${strong ? ' ' + pill('in', 'strong') : ''}</td><td class="n">${r.rows.toLocaleString()}</td><td class="n">${r.failures}</td><td class="n">${pct(r.obs, 1)}</td><td class="n">${oe}</td><td class="n">${pct(r.on_list, 0)}</td><td class="catch">${bar}</td></tr>`;
    });
  });
  $('#ev-seg').innerHTML = tb + '</tbody></table>';
  const S = (g, l) => segRow(g, l), pr = S('Vendor category', 'protein'), pr_ = S('Vendor category', 'produce'), dy = S('Vendor category', 'dairy_bakery'), lg = S('Vendor size', 'large'), th = S('History length (deliveries in last 13 wks)', '0-5 deliveries'), nof = S('Recent failure', 'no failure in 13+ wks');
  const s26 = (g, l) => X11.segments.val.find(r => r.segment === g && r.level === l);
  const prv = s26('Vendor category', 'protein'), lgv = s26('Vendor size', 'large');
  $('#ev-seg-impl').innerHTML = [
    `<b>The list works best where failures are frequent.</b> Produce vendors fail ${pct(pr_.obs, 0)} of weeks and the list catches ${pct(pr_.catch, 0)} of their failures. Protein fails ${pct(pr.obs, 0)} of weeks, yet the list catches ${pct(pr.catch, 0)}: protein vendors rarely rank among the few reviewed because other vendors look riskier. If protein failures are costly to you, they need a separate check; the list will not surface them.`,
    `<b>Short lists cost coverage.</b> In peak weeks the list is about half as long and catches ${pct(X11.segments.peak['peak weeks'].catch, 0)} of failures, against ${pct(X11.segments.peak['other weeks'].catch, 0)} otherwise. Forecasts are not worse in peak weeks (actual ÷ forecast ${f2(S('Season', 'peak').oe)}); there are simply fewer slots.`,
    `<b>Large vendors are caught least often</b> (${pct(lg.catch, 0)}) because the model gives them the lowest chance, and in 2026 they failed ${f2(lgv.oe)} times as often as forecast (interval ${f2(lgv.oe_lo)} to ${f2(lgv.oe_hi)}). Protein did the same (${f2(prv.oe)}, ${f2(prv.oe_lo)} to ${f2(prv.oe_hi)}). Those are the places the 2026 shift landed.`,
    `<b>Surprise failures.</b> ${nof.failures} failures (${pct(nof.failures / ovl.failures, 0)}) came at vendors with no failure in the previous 13 weeks, and the list caught ${pct(nof.catch, 0)} of them. No recent signal warned of these.`,
    `<b>Vendors with little recent history almost never fail</b> (${th.failures} failures in ${th.rows.toLocaleString()} vendor-weeks with 0 to 5 deliveries), so setting them aside costs little.`,
    (() => { const off = X11.segments.dev.filter(r => r.failures >= 8 && (r.oe_lo > 1 || r.oe_hi < 1)); return off.length === 0
      ? `<b>Forecasts are well calibrated within each group in 2024–25</b> (no group with at least 8 failures was significantly off), so the list’s misses come from limited information and limited slots rather than from a biased model.`
      : `<b>Calibration is off in some groups in 2024–25:</b> ${off.map(r => esc(String(r.level)) + ' (actual ÷ forecast ' + f2(r.oe) + ')').join(', ')}.`; })()
  ].map(t => `<li>${t}</li>`).join('');
  const rows26 = []; let g26 = '';
  X11.segments.val.forEach(r => { if (r.segment !== g26) { g26 = r.segment; rows26.push(`<tr class="sec"><td colspan="6">${esc(g26)}</td></tr>`); } rows26.push(`<tr><td>${esc(lvlName(r))}</td><td class="n">${r.rows}</td><td class="n">${r.failures}</td><td class="n">${pct(r.obs, 1)}</td><td class="n">${r.failures >= 8 ? f2(r.oe) : '—'}</td><td class="n">${r.catch == null ? '—' : pct(r.catch, 0)}</td></tr>`); });
  $('#ev-seg26').innerHTML = `<table><thead><tr><th>Segment</th><th class="n">Vendor-weeks</th><th class="n">Failures</th><th class="n">Failure rate</th><th class="n">Actual ÷ forecast</th><th class="n">Failures caught</th></tr></thead><tbody>${rows26.join('')}</tbody></table>`;

  // ---- improvements
  const IM = X11.improvements, REASON = {
    'A': 'Failures ran 0.80 to 1.12 times forecast from quarter to quarter, so old weeks may mislead later ones.',
    'B': 'Vendors with few deliveries have rejection rates built on one to three deliveries (one rejection looks like 33%).',
    'C': 'The best-caught group is vendors that failed 5 to 13 weeks ago; is failure history missing from the model?',
    'D': 'Recent rejection rates add almost nothing to the ranking; would one of the two be enough?',
    'G': 'How strongly each vendor’s own record should pull its forecast away from its category.',
    'F': 'Quarter-level drift: rescale every forecast by the recent actual ÷ expected ratio.',
    'J': 'Raised in a two-fold screen by a team member: treat delivery volume as a fixed multiplier on the failure chance (as in the Week 9 model) instead of estimating its effect.'
  };
  const ORD = 'ABCDFGJ', impRows = IM.variants.filter(v => !v.name.startsWith('Week 10 configuration')).sort((a, b) => ORD.indexOf(a.name.trim()[0]) - ORD.indexOf(b.name.trim()[0])).map(v => {
    const dl = v.logloss - IM.variants[0].logloss, key = v.name.trim()[0];
    return [esc(v.name), REASON[key] || '', `log loss ${sg(dl)}; better in ${v.blocks_better} of 8 blocks; list cost caught ${pts(v.cap_diff)} pts (${pts(v.cap_ci[0])} to ${pts(v.cap_ci[1])})`, v.keep ? pill('in', 'Adopted') : pill('out', 'Rejected')];
  });
  const E_ = IM.category_cost;
  impRows.push(['E  Category-specific failure cost (rank by chance × category cost)', 'Protein and dairy are about half of failure cost but few are caught; do costs differ by category?', `cost differs by category? Kruskal-Wallis p = ${f2(E_.kruskal_p)} (no evidence); list cost caught ${pts(E_.diff)} pts (${pts(E_.ci[0])} to ${pts(E_.ci[1])}); better in ${E_.blocks_higher} of 8 blocks`, E_.keep ? pill('in', 'Adopted') : pill('out', 'Rejected')]);
  const K_ = IM.cost_model_k;
  impRows.push(['K  Add vendor category to the dollar estimate', 'The same screen found a slightly lower typical dollar miss with category included; does it hold across all eight blocks, and does it re-order the list?', `typical dollar miss ${usdS(K_.diff)} (${pts(K_.pct)}%; interval ${usdS(K_.ci[0])} to ${usdS(K_.ci[1])}), better in ${K_.blocks_better} of 8 blocks; as a list ranking, list cost caught ${pts(K_.rank_diff)} pts (${pts(K_.rank_ci[0])} to ${pts(K_.rank_ci[1])})`, K_.keep ? pill('in', 'Adopted') : pill('out', 'Rejected')]);
  impRows.push(['H  Price next week’s failure with next week’s occupancy and banquet flag', 'The cost model was fitted on the failure week’s demand, but Week 10’s app fed it the current week’s values.', 'a correctness fix, not an accuracy gain: the estimate is no worse (typical miss about the same) and now consistent with how it was fitted', pill('in', 'Adopted')]);
  impRows.push(['I  Decision-support additions in this app', 'Peak-week short lists and surprise failures limit coverage; users need to see the trade-off.', 'list size against coverage chart, plain-language readout, whole-number inputs with checks, side-by-side scenario table, trade-off and limits summary', pill('in', 'Adopted')]);
  const nMod = IM.variants.length - 1;
  $('#ev-imp-cap').innerHTML = `${nMod + 2} candidate changes (${nMod} to the model or its probabilities, one to how the list is ranked, one to the dollar estimate) were tested on the 2024–25 walk-forward blocks only; 2026 was not touched. Rules set before running: a model change is kept only if log loss improves by at least 0.001, in at least 6 of 8 blocks, without losing more than a point of list cost caught; a cost-ranking change needs at least a point more cost caught in 5 of 8 blocks; a change to the dollar estimate needs a typical miss at least 1% lower, in 6 of 8 blocks, with an interval that excludes zero. Candidates J and K were added after a team member’s two-fold screen, so their rules were written knowing that screen’s result. With this many candidates one could win by luck, which is why block-by-block consistency is required. <b>None passed</b>, so the model is unchanged from Week 10. The adopted changes are to how the app uses and presents it.`;
  $('#ev-imp').innerHTML = table(['Candidate', 'Why we tried it', 'Result, 2024–25 tests', 'Decision'], impRows);

  // ---- limits
  $('#ev-limits').innerHTML = [
    `<b>The data is synthetic</b>, produced by a generator with a declared shift in 2026. These results show how the method behaves and where it is fragile, not how a real property would score.`,
    `<b>No clean final test.</b> 2026 had already been examined in Week 10 and we did not generate a fresh year, so 2026 results are confirmation, and every Week 11 decision rests on the 2024–25 tests. One boundary row: the last 2025 week predicts the first week of 2026, so ${X11.boundary.failures} failures from 2026 are in the fit; leaving that week out moves 2026 log loss from ${X11.boundary.logloss_with.toFixed(4)} to ${X11.boundary.logloss_without.toFixed(4)} and no 2026 chance by more than ${(X11.boundary.max_abs_dp * 100).toFixed(1)} percentage points, so it was left as it was. A new year from the data generator, scored once with the frozen model, would give a clean final test.`,
    `<b>The edge over simple rules is modest.</b> The list is clearly better than today’s rules but is not shown to be better than ranking by delivery volume. Rejection rates add little; the model’s value is probabilities with intervals, dollars and the what-if view.`,
    `<b>Dollar estimates are averages.</b> Cost per failure is not predictable from occupancy, banquets or category in the data, so it cannot re-order the list.`,
    `<b>Vendors under an open corrective action</b> are excluded from the list and from the model, yet failed ${(ca.obs / cn.obs).toFixed(1)} times as often as the rest in 2024–25. The tool says nothing about whether the corrective action is working.`,
    `<b>Drift is not fixed.</b> In 2026 failures ran ${((Math.exp(E.holdout.calib.shift) - 1) * 100).toFixed(0)}% above forecast. A trailing recalibration did not help in 2024–25 and a quarterly refit gave little in 2026; the monitor tells you when to look, it does not repair the model.`,
    `<b>Rejections are history, not levers.</b> The model links recent rejections to failures; it cannot say that reducing rejections (for instance by a corrective action) would reduce failures. No intervention was in the data.`,
    `<b>Next week’s banquet bookings and occupancy are assumed known</b> on Monday when sizing the cost of a failure. They never enter the failure probability or the ranking.`,
    `<b>Outside the tested range</b> (very high delivery counts, rejection rates above the 99th percentile of a category’s history), forecasts are extrapolations and the intervals understate the uncertainty. The What-if tab flags them.`
  ].map(t => `<li>${t}</li>`).join('');
}

/* list size against coverage chart */
function drawListSize() {
  const el = $('#ch-size'), w = chartWidth(el); if (!w) return;
  const L = X11.list_size, dev = L.dev, val = L.val, h = 280, m = { l: 62, r: 16, t: 14, b: 42 };
  const xs = dev.map(r => r.mean_k), X = linScale(xs[0], xs[xs.length - 1], m.l + 6, w - m.r - 6), Y = linScale(0, 1, h - m.b, m.t);
  const line = (rows, key, color, dash) => `<path d="${rows.map((r, i) => (i ? 'L' : 'M') + X(r.mean_k).toFixed(1) + ' ' + Y(r[key].cost).toFixed(1)).join('')}" fill="none" stroke="${color}" stroke-width="2.2" ${dash ? 'stroke-dasharray="5 4"' : ''} stroke-linejoin="round" stroke-linecap="round"/>`;
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Share of failure cost caught against weekly list size">`;
  [0, 0.25, 0.5, 0.75, 1].forEach(t => { s += `<line class="gridline" x1="${m.l}" x2="${w - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${(t * 100).toFixed(0)}%</text>`; });
  dev.forEach(r => { s += `<text x="${X(r.mean_k)}" y="${h - 22}" text-anchor="middle">${Math.round(r.mean_k)}</text>`; });
  s += `<text class="t2" x="${(m.l + w - m.r) / 2}" y="${h - 4}" text-anchor="middle">Vendors reviewed per week (average)</text>`;
  s += `<text class="t2" transform="translate(13 ${(m.t + h - m.b) / 2}) rotate(-90)" text-anchor="middle">Share of failure cost caught</text>`;
  s += line(dev, RAND_, 'var(--mute-mark)') + line(dev, PRAC_, 'var(--alt)') + line(dev, VOL_, 'var(--ink-3)') + line(val, M_, 'var(--accent)', true) + line(dev, M_, 'var(--accent)');
  const norm = dev.find(r => r.mult === 1);
  s += `<circle cx="${X(norm.mean_k)}" cy="${Y(norm[M_].cost)}" r="6" fill="var(--ink)" stroke="var(--surface)" stroke-width="2"/>`;
  s += `<line class="cross" y1="${m.t}" y2="${h - m.b}" stroke="var(--ink-3)" stroke-width="1" style="display:none"/><rect class="hit" x="${m.l}" y="${m.t}" width="${w - m.l - m.r}" height="${h - m.t - m.b}" fill="transparent" style="touch-action:pan-y"/></svg>`;
  el.innerHTML = s;
  const hx0 = X(xs[0]), hx1 = X(xs[xs.length - 1]);
  hoverSeries(el, w, hx0, hx1, dev.length, i => { const a = dev[i], b = val[i];
    return `<b>${a.mean_k.toFixed(1)} vendors a week${a.mult === 1 ? ' (normal list)' : ''}</b>` + tipRow('This model, 2024–25', pct(a[M_].cost, 0)) + tipRow('This model, 2026', pct(b[M_].cost, 0)) + tipRow('Most deliveries first', pct(a[VOL_].cost, 0)) + tipRow('Today’s rules', pct(a[PRAC_].cost, 0)) + tipRow('Random', pct(a[RAND_].cost, 0)); });
  $('#ev-size-cap').innerHTML = `Share of the following week’s failure cost caught if the weekly list were ${L.dev.map(r => '×' + r.mult).join(', ')} the normal capacity (a normal week: about ${Math.round(dev.find(r => r.mult === 1).mean_k)} of ${Math.round(L.eligible.dev)} eligible vendors). Coverage rises steeply at first and then flattens: roughly doubling the list moves the model from ${pct(norm[M_].cost, 0)} to ${pct(dev.find(r => r.mult === 2)[M_].cost, 0)} in 2024–25. In the 2024–25 tests the model’s lead over ranking by delivery volume is largest at the normal size and is gone once the list reaches about half of all eligible vendors.`;
  $('#tb-size').innerHTML = table(['Vendors a week', 'Model 2024–25', '95% interval', 'Model 2026', 'Most deliveries', 'Today’s rules', 'Random'],
    dev.map((r, i) => [`${r.mean_k.toFixed(1)} (×${r.mult})`, pct(r[M_].cost, 0), `${pct(r[M_].cost_ci[0], 0)} to ${pct(r[M_].cost_ci[1], 0)}`, pct(val[i][M_].cost, 0), pct(r[VOL_].cost, 0), pct(r[PRAC_].cost, 0), pct(r[RAND_].cost, 0)]), [1, 3, 4, 5, 6]);
  bindTips(el);
}
