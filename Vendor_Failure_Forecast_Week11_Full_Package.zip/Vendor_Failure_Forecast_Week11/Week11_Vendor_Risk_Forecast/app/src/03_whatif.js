/* ------------------------------------------------------------------ SCREEN 3: what-if forecast with uncertainty
   Week 11: the vendor's recent record is entered as WHOLE-NUMBER COUNTS (deliveries received, deliveries rejected) in two windows, the way a
   receiving clerk would count them. The model's rates are derived from those counts. Every combination is checked before a forecast is shown:
   whole numbers, rejected <= received, the last 4 weeks nested inside the last 13, and weeks 5-13 cannot hold more rejections than deliveries.
   Impossible scenarios get a plain message and no forecast. Possible-but-unusual ones (outside the range the model was trained on) are
   forecast and flagged as extrapolation. */
const WI = { wi: weekIndex['2026-W26'] ?? 25, vi: 0, n13: 0, r13: 0, n4: 0, r4: 0, raw: { n13: '', r13: '', n4: '', r4: '' }, valid: true, errs: {}, problems: [],
             expo: 1, rej4: 0, rej13: 0, shift: 0, cost: 0, level: 80, rec: null };
const WI_FIELDS = ['n13', 'r13', 'n4', 'r4'];
const WI_LABEL = { n13: 'Deliveries received, last 13 weeks', r13: 'Rejected on delivery, last 13 weeks', n4: 'Deliveries received, last 4 weeks', r4: 'Rejected on delivery, last 4 weeks' };
const WI_MAX = 400;

function wiVendorOptions() {
  const sel = $('#wi-vendor'), sc = weekScores(WI.wi), keep = WI.vi;
  let html = '';
  D.cats.forEach((c, ci) => {
    html += `<optgroup label="${esc(D.cat_labels[ci])}">`;
    D.vendors.forEach((v, vi) => {
      if (v.cat !== ci) return;
      const s = sc[vi];
      html += `<option value="${vi}">${esc(v.name)} · ${s ? pct(s.p, 1) : 'not scored'}</option>`;
    });
    html += '</optgroup>';
  });
  sel.innerHTML = html; sel.value = String(keep);
}
function wiWeekMeta() {
  const w = D.weeks[WI.wi];
  $('#wi-week-meta').textContent = `${w.season} season · review capacity ${w.k} vendors · next week: occupancy ${pct(w.occ_n, 0)}${w.banq_n ? ', banquet booked' : ', no banquet'} (outside your control)`;
}
function wiFixedBox() {
  const v = D.vendors[WI.vi];
  $('#wi-fixed').innerHTML = `<div><span class="muted">Category</span> <b>${esc(D.cat_labels[v.cat])}</b></div>` +
    `<div><span class="muted">Size band</span> <b>${esc(v.size)}</b>${v.local ? ' · local' : ''}</div>` +
    `<div class="small muted">The vendor’s own track record from 2023–25 is built into the forecast and cannot be edited here.</div>`;
}

/* ------------------------------------------------------------------ validation */
function wiValidate(raw) {
  const fe = {}, vals = {}, have = f => vals[f] !== undefined;
  for (const f of WI_FIELDS) {
    const s = String(raw[f] == null ? '' : raw[f]).trim();
    if (s === '') { fe[f] = 'Enter a whole number.'; continue; }
    if (!/^\d+$/.test(s)) { fe[f] = /^-/.test(s) ? 'Cannot be negative.' : 'Whole numbers only: no decimals or text.'; continue; }
    const v = Number(s);
    if (v > WI_MAX) { fe[f] = `More than ${WI_MAX} is beyond anything this tool can sensibly check.`; continue; }
    vals[f] = v;
  }
  if (have('n13') && vals.n13 === 0) fe.n13 = 'A vendor with no deliveries in 13 weeks cannot be scored. The tool never treats missing history as zero risk.';
  if (have('n13') && have('r13') && vals.r13 > vals.n13) fe.r13 = `Rejected (${vals.r13}) cannot be more than deliveries received (${vals.n13}).`;
  if (have('n4') && have('r4') && vals.r4 > vals.n4) fe.r4 = `Rejected (${vals.r4}) cannot be more than deliveries received (${vals.n4}).`;
  if (have('n4') && have('n13') && vals.n4 > vals.n13 && !fe.n13) fe.n4 = `The last 4 weeks are part of the last 13, so ${vals.n4} deliveries in 4 weeks cannot exceed ${vals.n13} in 13.`;
  if (have('r4') && have('r13') && vals.r4 > vals.r13 && !fe.r4 && !fe.r13) fe.r4 = `Rejections in the last 4 weeks are part of the 13-week count, so ${vals.r4} cannot exceed ${vals.r13}.`;
  if (WI_FIELDS.every(f => have(f)) && !WI_FIELDS.some(f => fe[f]) && (vals.r13 - vals.r4) > (vals.n13 - vals.n4))
    fe.r13 = `Weeks 5 to 13 would have ${vals.r13 - vals.r4} rejections out of only ${vals.n13 - vals.n4} deliveries.`;
  const problems = WI_FIELDS.filter(f => fe[f]).map(f => ({ f, text: `${WI_LABEL[f]}: ${fe[f]}` }));
  return { ok: problems.length === 0, vals, fe, problems };
}
/* nearest valid scenario for the "adjust" button */
function wiRepair() {
  const rec = WI.rec, num = (f, d) => { const s = String(WI.raw[f] == null ? '' : WI.raw[f]).trim(); return /^\d+$/.test(s) ? Math.min(Number(s), WI_MAX) : d; };
  let n13 = Math.max(1, num('n13', rec.n13)), r13 = num('r13', rec.r13), n4 = num('n4', rec.n4), r4 = num('r4', rec.r4);
  n4 = Math.min(n4, n13); r13 = Math.min(r13, n13); r4 = Math.min(r4, n4, r13);
  if (r13 - r4 > n13 - n4) r13 = r4 + (n13 - n4);
  WI.raw = { n13: String(n13), r13: String(r13), n4: String(n4), r4: String(r4) };
  wiPushRaw(); wiApply(); wiRender();
}

/* read the four boxes -> state */
function wiApply() {
  const res = wiValidate(WI.raw);
  WI.errs = res.fe; WI.problems = res.problems; WI.valid = res.ok;
  if (res.ok) {
    Object.assign(WI, { n13: res.vals.n13, r13: res.vals.r13, n4: res.vals.n4, r4: res.vals.r4 });
    Object.assign(WI, ratesFromCounts(WI.n13, WI.r13, WI.n4, WI.r4));
  }
  wiShowFieldState();
}
function wiPushRaw() { WI_FIELDS.forEach(f => { $('#n-' + f).value = WI.raw[f]; }); }
function wiShowFieldState() {
  const rec = WI.rec;
  WI_FIELDS.forEach(f => {
    const el = $('#n-' + f), msg = WI.errs[f] || '';
    el.classList.toggle('bad', !!msg); el.setAttribute('aria-invalid', msg ? 'true' : 'false');
    $('#e-' + f).textContent = msg;
    const changed = rec && String(WI.raw[f]).trim() !== String(rec[f]);
    el.classList.toggle('changed', !!changed);
    $('#b-' + f).textContent = rec ? `recorded: ${rec[f]}` : '';
  });
  const d = $('#wi-derived');
  if (!rec) { d.textContent = ''; return; }
  if (!WI.valid) { d.innerHTML = '<b class="bad-ink">Fix the highlighted boxes to see a forecast.</b>'; return; }
  const small = WI.n4 > 0 && WI.n4 < 5 ? ` Only ${WI.n4} deliver${WI.n4 === 1 ? 'y' : 'ies'} in 4 weeks, so one rejection moves the 4-week rate by ${(100 / WI.n4).toFixed(0)} points.` : '';
  const none = WI.n4 === 0 ? ' No deliveries in the last 4 weeks, so the model uses the 13-week rate for the 4-week input, as it did in training.' : '';
  d.innerHTML = `= <b>${WI.expo.toFixed(2)}</b> deliveries a week · rejection rate <b>${pct(WI.rej4, 1)}</b> over 4 weeks${WI.n4 > 0 ? ` (${WI.r4} of ${WI.n4})` : ''}, <b>${pct(WI.rej13, 1)}</b> over 13 weeks (${WI.r13} of ${WI.n13}).${small}${none}`;
}

function wiSetEnabled(on) {
  WI_FIELDS.forEach(f => { $('#n-' + f).disabled = !on; });
  $('#s-shift').disabled = !on; $('#s-cost').disabled = !on;
}
function wiRanges() {
  const rg = D.ranges[D.cats[D.vendors[WI.vi].cat]];
  $('#h-n13').innerHTML = `<span>usual range for this category: ${rg.n13[0]} to ${rg.n13[1]}</span>`;
  $('#h-n4').innerHTML = `<span>cannot exceed the 13-week figure</span>`;
}
function wiLoadRecorded() {
  WI.rec = recorded(WI.wi, WI.vi);
  wiFixedBox(); wiRanges(); wiSetEnabled(!!WI.rec);
  if (WI.rec) { WI.raw = { n13: String(WI.rec.n13), r13: String(WI.rec.r13), n4: String(WI.rec.n4), r4: String(WI.rec.r4) }; }
  else WI.raw = { n13: '', r13: '', n4: '', r4: '' };
  wiPushRaw(); wiApply();
  wiSyncSliders();
}
function wiSyncSliders() {
  $('#s-shift').value = Math.round(WI.shift * 100);
  $('#v-shift').textContent = (WI.shift >= 0 ? '+' : '−') + Math.abs(Math.round(WI.shift * 100)) + '%';
  $('#s-cost').value = Math.round(WI.cost * 100);
  $('#v-cost').textContent = (WI.cost >= 0 ? '+' : '−') + Math.abs(Math.round(WI.cost * 100)) + '%';
}
const shiftToEta = s => Math.log(1 + s);           // a +26% change in the failure rate is +0.231 on the log-hazard scale

/* sensitivity charts: x range = usual range stretched to include the scenario */
function wiXRange(kind) {
  const rg = D.ranges[D.cats[D.vendors[WI.vi].cat]];
  if (kind === 'expo') {
    const lo = Math.min(Math.max(0.05, Math.floor(rg.expo[0] * 0.5 * 20) / 20), WI.expo * 0.95, WI.rec ? WI.rec.expo : 1e9);
    const hi = Math.max(Math.ceil(rg.expo[1] * 1.6 * 10) / 10, WI.expo * 1.05);
    return [lo, hi];
  }
  return [0, Math.max(0.3, WI.rej4 * 1.05)];
}
function wiSeries(kind, n = 41) {
  const [lo, hi] = wiXRange(kind), pts_ = [];
  for (let i = 0; i < n; i++) {
    const x = lo + (hi - lo) * i / (n - 1);
    pts_.push(Object.assign({ x }, forecast(WI.vi, kind === 'expo' ? x : WI.expo, kind === 'rej' ? x : WI.rej4, WI.rej13, shiftToEta(WI.shift), Z[WI.level])));
  }
  return pts_;
}

function drawSensitivity(el, kind) {
  const w = chartWidth(el); if (!w || !WI.rec || !WI.valid) { if (el && !(WI.rec && WI.valid)) el.innerHTML = '<p class="muted small">No chart: ' + (WI.rec ? 'fix the scenario first.' : 'not scored this week.') + '</p>'; return; }
  const h = 230, m = { l: 44, r: 14, t: 12, b: 38 }, S = wiSeries(kind), v = D.vendors[WI.vi], rg = D.ranges[D.cats[v.cat]];
  const seenLo = kind === 'expo' ? rg.expo[0] : 0, seenHi = kind === 'expo' ? rg.expo[1] : rg.rej4[1];
  const ymax = niceMax(Math.max(...S.map(d => d.hi)) * 1.05), X = linScale(S[0].x, S[S.length - 1].x, m.l, w - m.r), Y = linScale(0, ymax, h - m.b, m.t);
  const fmtX = kind === 'expo' ? (x => x.toFixed(1)) : (x => pct(x, 0));
  let s = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Forecast chance against ${kind === 'expo' ? 'deliveries per week' : '4-week rejection rate'}, with interval">`;
  for (let i = 0; i <= 4; i++) { const t = ymax * i / 4; s += `<line class="gridline" x1="${m.l}" x2="${w - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${pct(t, t < 0.1 ? 1 : 0)}</text>`; }
  for (let i = 0; i <= 4; i++) { const x = S[0].x + (S[S.length - 1].x - S[0].x) * i / 4; s += `<text x="${X(x)}" y="${h - 20}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${fmtX(x)}</text>`; }
  s += `<text class="t2" x="${(m.l + w - m.r) / 2}" y="${h - 4}" text-anchor="middle">${kind === 'expo' ? 'Deliveries per week (13-week average)' : 'Rejection rate, last 4 weeks'}</text>`;
  s += `<path d="${S.map((d, i) => (i ? 'L' : 'M') + X(d.x).toFixed(1) + ' ' + Y(d.hi).toFixed(1)).join('')}${S.slice().reverse().map(d => 'L' + X(d.x).toFixed(1) + ' ' + Y(d.lo).toFixed(1)).join('')}Z" fill="var(--accent)" opacity="0.2"/>`;
  s += `<path d="${S.map((d, i) => (i ? 'L' : 'M') + X(d.x).toFixed(1) + ' ' + Y(d.p).toFixed(1)).join('')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-dasharray="4 4" stroke-linejoin="round"/>`;
  const inside = S.filter(d => d.x >= seenLo - 1e-9 && d.x <= seenHi + 1e-9);
  if (inside.length > 1) s += `<path d="${inside.map((d, i) => (i ? 'L' : 'M') + X(d.x).toFixed(1) + ' ' + Y(d.p).toFixed(1)).join('')}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>`;
  const recX = kind === 'expo' ? WI.rec.expo : WI.rec.rej4, curX = kind === 'expo' ? WI.expo : WI.rej4;
  const at = x => forecast(WI.vi, kind === 'expo' ? x : WI.expo, kind === 'rej' ? x : WI.rej4, WI.rej13, shiftToEta(WI.shift), Z[WI.level]);
  const rp = at(recX), cp = at(curX);
  s += `<circle cx="${X(recX)}" cy="${Y(rp.p)}" r="5" fill="var(--mute-mark)" stroke="var(--surface)" stroke-width="2"/>`;
  s += `<circle cx="${X(curX)}" cy="${Y(cp.p)}" r="6" fill="var(--alt)" stroke="var(--surface)" stroke-width="2"/>`;
  s += `<line class="cross" y1="${m.t}" y2="${h - m.b}" stroke="var(--ink-3)" stroke-width="1" style="display:none"/><rect class="hit" x="${m.l}" y="${m.t}" width="${w - m.l - m.r}" height="${h - m.t - m.b}" fill="transparent" style="touch-action:pan-y"/></svg>`;
  el.innerHTML = s;
  hoverSeries(el, w, X(S[0].x), X(S[S.length - 1].x), S.length, i => { const d = S[i], seen = d.x >= seenLo && d.x <= seenHi;
    return `<b>${kind === 'expo' ? d.x.toFixed(2) + ' deliveries / week' : pct(d.x, 1) + ' rejected'}</b>` + tipRow('Chance next week', pct(d.p, 1)) + tipRow(WI.level + '% interval', `${pct(d.lo, 1)} to ${pct(d.hi, 1)}`) + (seen ? '' : `<div style="color:var(--warn-ink);margin-top:3px">Beyond the usual range: extrapolated</div>`); });
}

function rankAmong(others, p) { let r = 1; for (const o of others) if (o > p) r++; return r; }
const signed = (x, fmt) => (x > 0 ? '+' : x < 0 ? '−' : '') + fmt(Math.abs(x));
const rg = () => D.ranges[D.cats[D.vendors[WI.vi].cat]];

/* everything the scenario produces, computed once and shared by the answer, the comparison table and the written summary */
function wiCompute() {
  const v = D.vendors[WI.vi], w = D.weeks[WI.wi], r = WI.rec, sh = shiftToEta(WI.shift), z = Z[WI.level], k = w.k;
  const base = forecast(WI.vi, r.expo, r.rej4, r.rej13, 0, z), now = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, sh, z);
  const hl = D.lead[v.cat];
  const base4 = forecast(WI.vi, r.expo, r.rej4, r.rej13, 0, z, 4), now4 = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, sh, z, 4);
  const basel = forecast(WI.vi, r.expo, r.rej4, r.rej13, 0, z, hl), nowl = forecast(WI.vi, WI.expo, WI.rej4, WI.rej13, sh, z, hl);
  const mu0 = costMean(WI.wi), mu1 = mu0 * (1 + WI.cost);
  const scB = weekScores(WI.wi, 0), scN = weekScores(WI.wi, sh), othB = [], othN = [], namesN = [];
  scB.forEach((s, vi) => { if (s && vi !== WI.vi && s.cap === 0) othB.push(s.p); });
  scN.forEach((s, vi) => { if (s && vi !== WI.vi && s.cap === 0) { othN.push(s.p); namesN.push({ vi, p: s.p }); } });
  const held = r.cap === 1;
  const rankB = rankAmong(othB, base.p), rankN = rankAmong(othN, now.p), rankNlo = rankAmong(othN, now.lo), rankNhi = rankAmong(othN, now.hi);
  namesN.sort((a, b) => b.p - a.p);
  return { v, w, r, sh, z, k, base, now, hl, base4, now4, basel, nowl, mu0, mu1, held, rankB, rankN, rankNlo, rankNhi, nOth: othN.length + 1, ranked: namesN };
}

const wiVoid = on => document.querySelector('#view-whatif .results').classList.toggle('void', on);

function wiInvalid() {
  const ans = $('#wi-answer');
  wiVoid(true);
  ans.classList.add('bad');
  ans.innerHTML = `<div class="label">This scenario cannot happen</div>
    <div class="big" style="font-size:24px">No forecast until it is fixed</div>
    <ul class="plainlist">${WI.problems.map(p => `<li><b>${esc(WI_LABEL[p.f])}.</b> ${esc(p.text.split(': ').slice(1).join(': '))}</li>`).join('')}</ul>
    <div class="line">The forecast is only shown for counts that could really have been recorded. <button class="btn link" type="button" id="wi-fix">Adjust to the nearest possible scenario</button></div>`;
  ['#wi-compare', '#wi-notes', '#wi-summary', '#wi-contrib', '#wi-queue', '#ch-s-expo', '#ch-s-rej'].forEach(s => { $(s).innerHTML = ''; });
  $('#wi-queue-cap').textContent = '';
  $('#wi-compare').innerHTML = '<p class="muted small">The comparison with the recorded week appears once the counts are possible.</p>';
  $('#wi-fix').addEventListener('click', wiRepair);
}

function wiRender() {
  const v = D.vendors[WI.vi], w = D.weeks[WI.wi], cat = D.cats[v.cat], ans = $('#wi-answer'), notes = $('#wi-notes');
  ans.classList.remove('bad');
  wiVoid(!WI.rec);
  if (!WI.rec) {
    ans.innerHTML = `<div class="label">${esc(v.name)} · ${esc(w.id)}</div><div class="big" style="font-size:26px">Not enough data to score</div><div class="line">This vendor had no deliveries in the 13 weeks before this Monday. The tool marks it "insufficient data" instead of treating missing history as zero risk. Pick another week or vendor.</div>`;
    ['#wi-compare', '#wi-notes', '#wi-summary', '#wi-contrib', '#wi-queue', '#ch-s-expo', '#ch-s-rej'].forEach(s => { $(s).innerHTML = ''; }); $('#wi-queue-cap').textContent = ''; return;
  }
  if (!WI.valid) { wiInvalid(); return; }
  const C = wiCompute(), { sh, z, k, base, now: f, mu0, mu1, held } = C;
  const dlt = f.p - base.p, dcls = Math.abs(dlt) < 0.0005 ? 'flat' : dlt > 0 ? 'up' : 'down', dic = dcls === 'flat' ? '=' : dlt > 0 ? '▲' : '▼';
  const per100 = f.p * 100, lo100 = f.lo * 100, hi100 = f.hi * 100, r0 = x => x < 10 ? x.toFixed(1).replace('.0', '') : Math.round(x);
  ans.innerHTML = `<div class="label">Chance of a material failure next week · ${esc(v.name)} · ${esc(w.id)}</div>
    <div class="big">${pct(f.p, 1)}<small>${WI.level}% interval ${pct(f.lo, 1)} to ${pct(f.hi, 1)}</small></div>
    <div class="line">About <b>${r0(per100)} in 100</b> weeks with these conditions end with a material failure at this vendor. We are ${WI.level}% sure the true figure lies between <b>${r0(lo100)}</b> and <b>${r0(hi100)}</b> in 100.</div>
    <div class="line"><span class="delta ${dcls}"><span aria-hidden="true">${dic}</span> ${dcls === 'flat' ? 'No change' : pts(dlt, 1) + ' points'}</span> against the recorded values (${pct(base.p, 1)}).${WI.shift ? ` Includes a ${WI.shift > 0 ? '+' : '−'}${Math.abs(Math.round(WI.shift * 100))}% shift in everyone's failure rate.` : ''}</div>`;

  wiRenderCompare(C);

  // where it lands on the week's list
  const sc = weekScores(WI.wi, sh), rk = C.rankN, rkLo = C.rankNlo, rkHi = C.rankNhi, nAll = C.nOth;
  const N = [];
  if (held) N.push(['warn', '!', `This vendor already has an open corrective action in ${w.id}, so the weekly list would hold it out. The forecast above still applies.`]);
  else if (rkLo <= k) N.push(['', 'i', `<b>Review candidate.</b> It ranks ${rk} of ${nAll} against a list of ${k}, and still ranks ${rkLo} at the low end of its interval.`]);
  else if (rk <= k) N.push(['warn', '!', `<b>Borderline.</b> It makes the list at the point estimate (rank ${rk} of ${nAll}, list of ${k}) but would fall to rank ${rkLo} if the true risk is at the low end of the interval.`]);
  else if (rkHi <= k) N.push(['warn', '!', `<b>Watch.</b> It sits outside the list at the point estimate (rank ${rk}) but would reach rank ${rkHi} if the true risk is at the high end of the interval. A cheap precaution fits better than a corrective action.`]);
  else N.push(['', 'i', `<b>Outside the list</b> across the whole interval (rank ${rk}, best case ${rkHi}, list of ${k}).`]);
  if (ZCAP[cat] === undefined && f.lo > 0.002 && f.hi / f.lo > 2.5) N.push(['', 'i', `<b>The interval is wide</b> (its top is ${(f.hi / f.lo).toFixed(1)} times its bottom). The model cannot separate this vendor from its category average, so act on the cheap end of the interval for low-cost precautions and wait for the low end to clear the bar before costly ones such as qualifying an alternate.`]);
  const q = [];
  if (WI.expo < rg().expo[0] || WI.expo > rg().expo[1]) q.push(`deliveries per week (${WI.expo.toFixed(2)}; usual range ${rg().expo[0]} to ${rg().expo[1]})`);
  if (WI.rej4 > rg().rej4[1] + 1e-9) q.push(`4-week rejection rate (${pct(WI.rej4, 1)}; only 1% of this category's history was above ${pct(rg().rej4[1], 1)})`);
  if (WI.rej13 > rg().rej13[1] + 1e-9) q.push(`13-week rejection rate (${pct(WI.rej13, 1)}; only 1% of this category's history was above ${pct(rg().rej13[1], 1)})`);
  if (q.length) N.push(['crit', '!', `<b>Outside what the model has seen:</b> ${q.join('; ')}. The forecast is an extrapolation and the interval understates the real uncertainty.`]);
  if (WI.n4 > 0 && WI.n4 < 5) N.push(['', 'i', `<b>Thin evidence in the 4-week window.</b> With ${WI.n4} deliver${WI.n4 === 1 ? 'y' : 'ies'}, the 4-week rejection rate swings by ${(100 / WI.n4).toFixed(0)} points per rejection. Treat it as a hint, not a trend.`]);
  if (WI.cost) N.push(['', 'i', `The cost change is a scenario you set (for example a price spike), not a forecast. Dollar figures scale with it; the dollar interval does not include any uncertainty about it.`]);
  if (WI.shift) N.push(['', 'i', `A shift multiplies every vendor's failure rate. It changes the level of risk and the dollars at stake but not the ranking. The 2026 value (+26%) was measured on the same weeks it describes, so treat it as a scenario, not a validated correction.`]);
  if (ZCAP[cat] !== undefined) { const nz = D.ranges[cat].n, up = 1 - Math.pow(0.05, 1 / nz); N.push(['warn', '!', `No failure was ever recorded in ${esc(D.cat_labels[v.cat])} (${nz.toLocaleString()} vendor-weeks of history), so the model has almost nothing to learn a rate from. What the data do rule out is a high rate: the exact 95% upper limit on the weekly chance is about ${pct(up, 1)}. Read it as "unknown, probably very low".`]); }
  notes.innerHTML = N.map(n => `<div class="note ${n[0]}"><span class="ic" aria-hidden="true">${n[1]}</span><span>${n[2]}</span></div>`).join('');

  drawSensitivity($('#ch-s-expo'), 'expo'); drawSensitivity($('#ch-s-rej'), 'rej');

  // list preview with the scenario inserted
  const rowsAll = []; sc.forEach((s, vi) => { if (s && vi !== WI.vi && s.cap === 0) rowsAll.push({ vi, p: s.p, scen: false }); });
  if (!held) rowsAll.push({ vi: WI.vi, p: f.p, scen: true });
  rowsAll.sort((a, b) => b.p - a.p);
  const showN = k + 3, idxScen = rowsAll.findIndex(r => r.scen);
  const view = rowsAll.slice(0, showN).map((r, i) => ({ ...r, rank: i + 1 }));
  if (idxScen >= showN) view.push({ ...rowsAll[idxScen], rank: idxScen + 1, gap: true });
  $('#wi-queue-cap').textContent = `${w.id} is a ${w.season} week with room to review ${k} vendors. ${held ? 'The chosen vendor is held out, so the list shown is the real one.' : 'Your scenario is highlighted; everyone else keeps their recorded values.'} Vendors under an open corrective action are not ranked.`;
  let tb = `<table><thead><tr><th class="n">#</th><th>Vendor</th><th class="hide-sm">Category</th><th class="n">Chance next week</th><th>Status</th></tr></thead><tbody>`;
  view.forEach((r, i) => {
    if (r.gap) tb += `<tr><td colspan="5" class="muted" style="text-align:center">…</td></tr>`;
    const vv = D.vendors[r.vi];
    tb += `<tr class="${r.scen ? 'sel' : ''}"><td class="n">${r.rank}</td><td>${esc(vv.name)}${r.scen ? ' <span class="pill in">your scenario</span>' : ''}</td><td class="hide-sm">${esc(D.cat_labels[vv.cat])}</td><td class="n">${pct(r.p, 1)}</td><td>${r.rank <= k ? '<span class="pill in">In list</span>' : '<span class="pill out">Not in list</span>'}</td></tr>`;
    if (r.rank === k && !r.gap) tb += `<tr class="capline"><td colspan="5"></td></tr>`;
  });
  $('#wi-queue').innerHTML = tb + '</tbody></table>';
  renderExplain(C);   // per-prediction contributions + the automatic scenario summary
}

/* ------------------------------------------------------------------ baseline against scenario, side by side */
function wiRenderCompare(C) {
  const { base, now, base4, now4, basel, nowl, mu0, mu1, r, k, held, rankB, rankN, nOth, hl } = C;
  const iv = (a, lo, hi, fm) => `${fm(a)}<span class="ivl">${fm(lo)} to ${fm(hi)}</span>`;
  const p1 = x => pct(x, 1), p0 = x => pct(x, 0);
  const rows = [];
  const sec = t => rows.push(`<tr class="sec"><td colspan="4">${t}</td></tr>`);
  const add = (label, a, b, chg, changed, cls = '') => rows.push(`<tr class="${changed ? 'chg' : ''} ${cls}"><td>${label}</td><td class="n">${a}</td><td class="n">${b}</td><td class="n dcol">${chg}</td></tr>`);
  const ch = (x, y) => Math.abs(x - y) > 1e-9;
  sec('What you changed');
  add('Deliveries per week (13-week average)', r.expo.toFixed(2), WI.expo.toFixed(2), ch(r.expo, WI.expo) ? signed(WI.expo - r.expo, x => x.toFixed(2)) : '—', ch(r.expo, WI.expo));
  add('Rejected, last 4 weeks', r.n4 > 0 ? `${r.r4} of ${r.n4} (${pct(r.rej4, 1)})` : `none delivered (uses ${pct(r.rej4, 1)})`, WI.n4 > 0 ? `${WI.r4} of ${WI.n4} (${pct(WI.rej4, 1)})` : `none delivered (uses ${pct(WI.rej4, 1)})`, ch(r.rej4, WI.rej4) ? signed(WI.rej4 - r.rej4, x => (x * 100).toFixed(1)) + ' pts' : '—', ch(r.rej4, WI.rej4));
  add('Rejected, last 13 weeks', `${r.r13} of ${r.n13} (${pct(r.rej13, 1)})`, `${WI.r13} of ${WI.n13} (${pct(WI.rej13, 1)})`, ch(r.rej13, WI.rej13) ? signed(WI.rej13 - r.rej13, x => (x * 100).toFixed(1)) + ' pts' : '—', ch(r.rej13, WI.rej13));
  add('Failure-rate shift, all vendors', '0%', signed(WI.shift, x => Math.round(x * 100) + '%').replace(/^$/, '0%'), WI.shift ? signed(WI.shift, x => Math.round(x * 100) + '%') : '—', !!WI.shift);
  add('Cost of a failure, all vendors', 'as fitted', WI.cost ? signed(WI.cost, x => Math.round(x * 100) + '%') : 'as fitted', WI.cost ? signed(WI.cost, x => Math.round(x * 100) + '%') : '—', !!WI.cost);
  sec(`What the model says (${WI.level}% intervals)`);
  add('<b>Chance of a material failure next week</b>', iv(base.p, base.lo, base.hi, p1), iv(now.p, now.lo, now.hi, p1), signed(now.p - base.p, x => (x * 100).toFixed(1)) + ' pts', ch(now.p, base.p), 'key');
  add('Expected cost next week', iv(base.p * mu0, base.lo * mu0, base.hi * mu0, usd), iv(now.p * mu1, now.lo * mu1, now.hi * mu1, usd), signed(now.p * mu1 - base.p * mu0, usd), ch(now.p * mu1, base.p * mu0), 'key');
  add('Cost if it does fail (typical; 80% of cases)', `${usd(mu0)}<span class="ivl">${usd(mu0 * RQ[10])} to ${usd(mu0 * RQ[90])}</span>`, `${usd(mu1)}<span class="ivl">${usd(mu1 * RQ[10])} to ${usd(mu1 * RQ[90])}</span>`, mu1 !== mu0 ? signed(mu1 - mu0, usd) : '—', mu1 !== mu0);
  add('Chance of at least one failure in 4 weeks (corrective-action window)', iv(base4.p, base4.lo, base4.hi, p0), iv(now4.p, now4.lo, now4.hi, p0), signed(now4.p - base4.p, x => (x * 100).toFixed(1)) + ' pts', ch(now4.p, base4.p));
  add(`Chance in ${hl} weeks (time to qualify an alternate)`, iv(basel.p, basel.lo, basel.hi, p0), iv(nowl.p, nowl.lo, nowl.hi, p0), signed(nowl.p - basel.p, x => (x * 100).toFixed(1)) + ' pts', ch(nowl.p, basel.p));
  if (held) add('Place on the weekly review list', 'held out', 'held out', '—', false);
  else {
    add(`Place on the weekly review list (of ${nOth})`, `${rankB}`, `${rankN}`, rankN === rankB ? '—' : (rankN < rankB ? `up ${rankB - rankN}` : `down ${rankN - rankB}`), rankN !== rankB);
    const inB = rankB <= k, inN = rankN <= k;
    add(`On the list of ${k}?`, inB ? '<span class="pill in">Yes</span>' : '<span class="pill out">No</span>', inN ? '<span class="pill in">Yes</span>' : '<span class="pill out">No</span>', inB === inN ? '—' : (inN ? 'enters the list' : 'drops off the list'), inB !== inN);
  }
  $('#wi-compare').innerHTML = `<h3>Recorded week against your scenario</h3>
    <p class="cap">Left: the vendor as recorded on that Monday, with no shift or cost change. Right: everything you have changed. Rows you changed or that moved are shaded. Model-based estimates, not proof that a change would cause the result.</p>
    <div class="tscroll"><table class="cmp"><thead><tr><th></th><th class="n">As recorded</th><th class="n">Your scenario</th><th class="n">Change</th></tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
}

function initWhatIf() {
  const wsel = $('#wi-week');
  wsel.innerHTML = D.weeks.map((w, i) => `<option value="${i}">${esc(weekLabel(w))} · ${w.season}</option>`).join('');
  wsel.value = String(WI.wi);
  // default vendor: the top-ranked eligible vendor of the default week
  const sc = weekScores(WI.wi); let best = -1, bp = -1;
  sc.forEach((s, vi) => { if (s && s.cap === 0 && s.p > bp) { bp = s.p; best = vi; } });
  WI.vi = Math.max(best, 0);
  wiVendorOptions(); wiWeekMeta(); wiLoadRecorded(); wiRender();

  wsel.addEventListener('change', () => { WI.wi = Number(wsel.value); wiVendorOptions(); wiWeekMeta(); wiLoadRecorded(); wiRender(); });
  $('#wi-vendor').addEventListener('change', e => { WI.vi = Number(e.target.value); wiLoadRecorded(); wiRender(); });
  WI_FIELDS.forEach(f => $('#n-' + f).addEventListener('input', e => { WI.raw[f] = e.target.value; wiApply(); wiRender(); }));
  const bind = (id, key, conv) => $(id).addEventListener('input', e => { WI[key] = conv(Number(e.target.value)); wiSyncSliders(); wiRender(); });
  bind('#s-shift', 'shift', x => x / 100); bind('#s-cost', 'cost', x => x / 100);
  $('#q-drift').addEventListener('click', () => { WI.shift = 0.26; wiSyncSliders(); wiRender(); });
  $('#wi-quick').addEventListener('click', e => {
    const b = e.target.closest('button[data-q]'); if (!b || (!WI.rec && b.dataset.q !== 'reset')) return;
    const q = b.dataset.q;
    if (q === 'reset') { WI.shift = 0; WI.cost = 0; wiLoadRecorded(); wiRender(); return; }
    const c = WI.valid ? { n13: WI.n13, r13: WI.r13, n4: WI.n4, r4: WI.r4 } : { n13: WI.rec.n13, r13: WI.rec.r13, n4: WI.rec.n4, r4: WI.rec.r4 };
    if (q === 'rej+1' || q === 'rej+3') {
      const add = q === 'rej+1' ? 1 : 3, r4 = Math.min(c.n4, c.r4 + add), got = r4 - c.r4;
      c.r4 = r4; c.r13 = Math.min(c.n13, c.r13 + got);          // a rejection in the last 4 weeks is also one of the last 13
    }
    if (q === 'expo+25') { c.n13 = Math.min(WI_MAX, Math.round(c.n13 * 1.25)); c.n4 = Math.min(c.n13, Math.round(c.n4 * 1.25)); }
    if (q === 'calm') { c.r4 = 0; c.r13 = 0; }
    WI.raw = { n13: String(c.n13), r13: String(c.r13), n4: String(c.n4), r4: String(c.r4) };
    wiPushRaw(); wiApply(); wiRender();
  });
  $('#seg-level').addEventListener('click', e => {
    const b = e.target.closest('button[data-level]'); if (!b) return;
    WI.level = Number(b.dataset.level); $$('#seg-level button').forEach(x => x.setAttribute('aria-pressed', String(x === b))); wiRender();
  });
}
