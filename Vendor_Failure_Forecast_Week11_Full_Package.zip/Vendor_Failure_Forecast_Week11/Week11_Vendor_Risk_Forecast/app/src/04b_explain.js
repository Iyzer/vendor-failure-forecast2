/* ==================================================================
   Per-prediction contributions, overall importance, and the automatic
   scenario summary.

   The forecast is linear in its link, so the Shapley value of each input
   is exactly beta_j * (x_j - mean_j). 14_add_explanations.py computes the
   baseline and asserts the decomposition closes on every training row
   (worst residual 2e-15), so nothing here is approximated or sampled.

   Two different quantities are shown, and the app says which is which:
     - OVERALL importance: mean |contribution| across the 6,978 training
       vendor-weeks. How much each input moves forecasts in general.
     - THIS prediction's contributions: the decomposition of the single
       vendor-week on screen. How much each input moved THIS number.
   ================================================================== */

const EXP = D.explain;

/* contributions for one vendor-week, on the log-hazard scale.
   Returns the terms in the fixed order the waterfall walks them. */
function contributions(vi, expo, rej4, rej13) {
  const v = D.vendors[vi], cat = D.cats[v.cat];
  const bCat = BETA[IDX['cat:' + cat]];
  const bVen = IDX['v:' + v.id] === undefined ? 0 : BETA[IDX['v:' + v.id]];
  return [
    { key: 'category', label: 'Category: ' + D.cat_labels[v.cat],
      val: bCat - EXP.mean_cat,
      why: 'How this category compares with the average category in the training data.' },
    { key: 'vendor', label: 'This vendor specifically',
      val: bVen - EXP.mean_ven,
      why: 'What is left once the category is accounted for — this vendor’s own record, shrunk toward its category.' },
    { key: 'log_exposure', label: 'Deliveries per week',
      val: BETA[IDX.log_exposure] * zf('log_exposure', Math.log(Math.max(expo, 1e-3))),
      why: 'More deliveries means more chances to fail. Not a judgement about the vendor.' },
    { key: 'rej_4wk', label: 'Rejection rate, last 4 weeks',
      val: BETA[IDX.rej_4wk] * zf('rej_4wk', rej4),
      why: 'Recent quality. The only input carrying vendor-specific deterioration.' },
    { key: 'rej_13wk', label: 'Rejection rate, last 13 weeks',
      val: BETA[IDX.rej_13wk] * zf('rej_13wk', rej13),
      why: 'Longer-run quality. Its fitted coefficient is near zero, so it rarely moves a forecast.' }
  ];
}

/* ---------------------------------------- overall importance (performance tab) */
function renderImportance() {
  const el = $('#imp-panel'); if (!el) return;
  const d1 = D.wk11.improvements.variants.find(v => v.name.startsWith('D1')), base = D.wk11.improvements.variants[0];
  $('#imp-note').textContent = `The 13-week rejection rate contributes almost nothing: its fitted coefficient is 0.0004. Week 11 tested dropping it on the 2024–25 walk-forward blocks: log loss moved by ${(d1.logloss - base.logloss).toFixed(4)} and was better in ${d1.blocks_better} of 8 blocks, short of the bar we set (0.001, in 6 of 8), so it stays. Removing inputs after seeing the hold-out would also overstate how well the model was specified in advance.`;
  const LBL = { category: 'Category', log_exposure: 'Deliveries per week', vendor: 'Vendor identity',
                rej_4wk: 'Rejection rate, last 4 weeks', rej_13wk: 'Rejection rate, last 13 weeks' };
  const rows = Object.entries(EXP.importance).map(([k, v]) => ({ k, v, lbl: LBL[k] || k }))
                     .sort((a, b) => b.v - a.v);
  const max = rows[0].v;
  el.innerHTML = rows.map(r => {
    const w = Math.max(1, (r.v / max) * 100);
    return `<div class="imp-row">
      <div class="imp-lbl">${esc(r.lbl)}</div>
      <div class="imp-track"><i style="width:${w.toFixed(1)}%"></i></div>
      <div class="imp-val">${r.v.toFixed(3)}</div>
    </div>`;
  }).join('');
}

/* ---------------------------------------- this prediction (what-if tab) */
function renderContributions() {
  const el = $('#wi-contrib'); if (!el) return;
  if (!WI.rec) { el.innerHTML = '<p class="muted small">This vendor was not scored in this week, so there is no prediction to break down.</p>'; return; }

  const terms = contributions(WI.vi, WI.expo, WI.rej4, WI.rej13);
  const shiftEta = shiftToEta(WI.shift);
  const base = EXP.eta_base;
  const maxAbs = Math.max(...terms.map(t => Math.abs(t.val)), 1e-6);

  // cumulative walk, so the reader can follow the baseline to the final number
  let run = base;
  const steps = terms.map(t => { run += t.val; return { ...t, cum: run }; });
  if (Math.abs(shiftEta) > 1e-9) {
    run += shiftEta;
    steps.push({ key: 'shift', label: 'Your failure-rate shift', val: shiftEta, cum: run,
                 why: 'A condition you set on the left, not something the model learned.' });
  }
  const pAt = e => pOf(e);

  const row = (lbl, val, cum, why, isTotal) => {
    const pos = val >= 0, w = Math.min(50, (Math.abs(val) / maxAbs) * 50);
    // The total is a SUM of the rows above, not another contribution, so it gets no
    // bar: drawn on the same scale it exceeds the axis and spills into the numbers.
    const bar = isTotal ? '' : `<i class="${pos ? 'pos' : 'neg'}" style="${pos ? 'left:50%' : 'right:50%'};width:${w.toFixed(1)}%"></i>`;
    return `<div class="cb-row${isTotal ? ' cb-total' : ''}">
      <div class="cb-lbl">${esc(lbl)}${why ? `<span class="cb-why">${esc(why)}</span>` : ''}</div>
      <div class="cb-bar"><span class="cb-mid"></span>${bar}</div>
      <div class="cb-num">${val >= 0 ? '+' : '−'}${Math.abs(val).toFixed(2)}</div>
      <div class="cb-cum">${pct(pAt(cum), 1)}</div>
    </div>`;
  };

  el.innerHTML = `
    <div class="cb-head">
      <div></div><div>Contribution<br><span class="cb-unit">log-hazard</span></div><div>Running<br><span class="cb-unit">chance</span></div>
    </div>
    <div class="cb-row cb-base">
      <div class="cb-lbl">Reference vendor-week: every input at its training average<span class="cb-why">Where the walk starts. It sits below the ${((D.meta.pos_dev / D.meta.n_dev) * 100).toFixed(1)}% overall failure rate because it averages the inputs on the log-hazard scale, where most vendor-weeks are low-risk and a few high-risk ones pull the average chance up.</span></div>
      <div class="cb-bar"><span class="cb-mid"></span></div>
      <div class="cb-num">—</div>
      <div class="cb-cum">${pct(pAt(base), 1)}</div>
    </div>
    ${steps.map(s => row(s.label, s.val, s.cum, s.why, false)).join('')}
    ${row('This vendor-week, all terms added', run - base, run, '', true)}
  `;
}

/* ---------------------------------------- the automatic scenario summary
   Week 11: written from the same numbers as the comparison table. Four parts: what was changed (tagged changeable / outside your control),
   what the model says, the trade-offs the manager faces, and what the result does and does not establish. */
function changedInputs() {
  const r = WI.rec; if (!r || !WI.valid) return [];
  const out = [];
  const add = (changed, lbl, from, to, tag) => { if (changed) out.push({ lbl, from, to, tag }); };
  add(WI.n13 !== r.n13, 'Deliveries received, last 13 weeks', `${r.n13} (${r.expo.toFixed(2)}/wk)`, `${WI.n13} (${WI.expo.toFixed(2)}/wk)`, 'chg');
  add(WI.r13 !== r.r13, 'Rejected, last 13 weeks', `${r.r13} (${pct(r.rej13, 1)})`, `${WI.r13} (${pct(WI.rej13, 1)})`, 'chg');
  add(WI.n4 !== r.n4, 'Deliveries received, last 4 weeks', String(r.n4), String(WI.n4), 'chg');
  add(WI.r4 !== r.r4, 'Rejected, last 4 weeks', `${r.r4} (${pct(r.rej4, 1)})`, `${WI.r4} (${pct(WI.rej4, 1)})`, 'chg');
  add(Math.abs(WI.shift) > 1e-9, 'Failure-rate shift, all vendors', '0%', (WI.shift >= 0 ? '+' : '−') + Math.abs(Math.round(WI.shift * 100)) + '%', 'ext');
  add(Math.abs(WI.cost) > 1e-9, 'Cost of a failure, all vendors', 'as fitted', (WI.cost >= 0 ? '+' : '−') + Math.abs(Math.round(WI.cost * 100)) + '%', 'ext');
  return out;
}
const TAGTXT = { chg: 'you can change', ext: 'outside your control' };

function renderSummary(C) {
  const el = $('#wi-summary'); if (!el) return;
  const r = WI.rec;
  if (!r) { el.innerHTML = '<p class="muted small">No recorded values for this vendor in this week, so there is no baseline to compare a scenario against.</p>'; return; }
  if (!WI.valid) { el.innerHTML = ''; return; }
  C = C || wiCompute();
  const { v, w, base, now, base4, now4, k, held, rankB, rankN, rankNlo, nOth, mu0, mu1, ranked } = C;
  const ch = changedInputs(), dp = now.p - base.p, rel = base.p > 0 ? dp / base.p : 0;

  // 1. what was changed
  const inputs = ch.length === 0
    ? `<li>Nothing was changed. The scenario is the week as recorded: ${r.expo.toFixed(2)} deliveries a week, ${r.r4} of ${r.n4} rejected over 4 weeks, ${r.r13} of ${r.n13} over 13.</li>`
    : ch.map(c => `<li><b>${esc(c.lbl)}</b>: ${esc(c.from)} → ${esc(c.to)} <span class="tag ${c.tag}">${TAGTXT[c.tag]}</span></li>`).join('');

  // 2. what the model says
  const movement = ch.length === 0
    ? `The forecast is the baseline: <b>${pct(base.p, 1)}</b> (${WI.level}% interval ${pct(base.lo, 1)} to ${pct(base.hi, 1)}).`
    : Math.abs(dp) < 0.0005
      ? `The chance of a failure next week stays at <b>${pct(now.p, 1)}</b>: the change is smaller than a tenth of a percentage point.`
      : `The chance of a failure next week moves from <b>${pct(base.p, 1)}</b> to <b>${pct(now.p, 1)}</b>, a change of <b>${dp >= 0 ? '+' : '−'}${(Math.abs(dp) * 100).toFixed(1)}</b> percentage points (${rel >= 0 ? 'up' : 'down'} ${Math.abs(rel * 100).toFixed(0)}% in relative terms). The ${WI.level}% interval moves from ${pct(base.lo, 1)}–${pct(base.hi, 1)} to ${pct(now.lo, 1)}–${pct(now.hi, 1)}${(now.lo <= base.hi && base.lo <= now.hi) ? ', and the two overlap, so the data cannot firmly separate them' : ''}.`;
  const ecB = base.p * mu0, ecN = now.p * mu1, dEc = ecN - ecB;
  const costMove = Math.abs(dEc) < 0.5
    ? `Expected cost next week is <b>${usd(ecN)}</b> (chance × about ${usd(mu1)} if it fails).`
    : `Expected cost next week moves from <b>${usd(ecB)}</b> to <b>${usd(ecN)}</b> (${dEc >= 0 ? '+' : '−'}${usd(Math.abs(dEc))}); a failure costs about ${usd(mu1)}, give or take a lot (80% of cases ${usd(mu1 * RQ[10])} to ${usd(mu1 * RQ[90])}).`;
  const win4 = `If conditions persisted, the chance of at least one failure over a 4-week corrective-action window is ${pct(now4.p, 0)} (${pct(now4.lo, 0)}–${pct(now4.hi, 0)}).`;

  // 3. trade-offs
  const T = [];
  const nm = o => o ? `${esc(D.vendors[o.vi].name)} (${pct(o.p, 1)})` : 'the next vendor';
  if (held) T.push(`This vendor already has an open corrective action in ${esc(w.id)}, so the weekly list holds it out whatever the scenario says.`);
  else {
    const inB = rankB <= k, inN = rankN <= k, edge = ranked[k - 1];
    if (!inB && inN) T.push(`<b>List capacity.</b> The scenario moves this vendor from place ${rankB} to ${rankN}, onto the list of ${k}. That takes a review slot from ${nm(edge)}, who falls to the first place off the list. Reviewing one more vendor means reviewing one fewer elsewhere unless capacity grows.`);
    else if (inB && !inN) T.push(`<b>List capacity.</b> The scenario moves this vendor from place ${rankB} to ${rankN}, off the list of ${k}. The slot passes to ${nm(edge)}. The risk has not gone away; the vendor is just no longer among the ${k} the team can review.`);
    else T.push(`<b>List capacity.</b> ${inN ? `The vendor stays on` : `The vendor stays off`} the list of ${k} (place ${rankB} → ${rankN} of ${nOth}). ${inN ? (rankNlo <= k ? 'It stays on even at the low end of its interval.' : `At the low end of its interval it would rank ${rankNlo} and drop off.`) : 'Capacity for the week is unchanged.'}`);
  }
  if (WI.n13 !== r.n13) T.push(`<b>Volume.</b> ${WI.n13 > r.n13 ? 'More' : 'Fewer'} deliveries ${WI.n13 > r.n13 ? 'raise' : 'lower'} the forecast mainly because there are ${WI.n13 > r.n13 ? 'more' : 'fewer'} deliveries that can go wrong, not because the vendor became ${WI.n13 > r.n13 ? 'less' : 'more'} reliable (a 10% change in deliveries changes the failure rate by about ${((D.effects[0].est - 1) * 100).toFixed(0)}%). Changing volume also has costs and benefits this model does not see: price, continuity of supply, qualification of an alternate.`);
  if (WI.r4 !== r.r4 || WI.r13 !== r.r13) T.push(`<b>Rejections.</b> In past data, vendors with more recent rejections failed somewhat more often, and the model carries that pattern. Rejections already happened, so this scenario means "if the record had looked like this", not "what a corrective action would achieve". Recent rejection rates add little to the weekly ranking overall (see the Evaluation tab).`);
  if (Math.abs(WI.shift) > 1e-9 || Math.abs(WI.cost) > 1e-9) T.push(`<b>Conditions.</b> A failure-rate shift or a cost change scales the level of risk and the dollars at stake for every vendor equally. It does not change who is at the top of the list.`);
  T.push(win4);

  // 4. limits
  const rgn = D.ranges[D.cats[v.cat]], oor = [];
  if (WI.expo > rgn.expo[1] || WI.expo < rgn.expo[0]) oor.push(`${WI.expo.toFixed(2)} deliveries a week is outside the ${rgn.expo[0].toFixed(2)}–${rgn.expo[1].toFixed(2)} range seen for ${D.cat_labels[v.cat].toLowerCase()}`);
  if (WI.rej4 > rgn.rej4[1]) oor.push(`a 4-week rejection rate of ${pct(WI.rej4, 1)} is above the ${pct(rgn.rej4[1], 1)} the model has seen`);
  if (WI.rej13 > rgn.rej13[1]) oor.push(`a 13-week rejection rate of ${pct(WI.rej13, 1)} is above the ${pct(rgn.rej13[1], 1)} the model has seen`);
  const W11 = D.wk11, vol = W11.decision.dev.find(x => x.name === 'Delivery volume (spend proxy)');
  const limits = [
    '<b>Model-based, not proven cause.</b> This is the fitted model’s arithmetic under changed inputs. It does not show that changing an input would change what actually happens.',
    `The interval covers uncertainty in the fitted coefficients only. It does not cover a wrong model, a changed regime, or drift like the 2026 drift the monitor flagged in week 22. Overall the model ranks vendors only modestly better than ranking by delivery volume (${pts(vol.diff[0])} points in the 2024–25 tests, interval ${pts(vol.diff[1])} to ${pts(vol.diff[2])}).`
  ];
  if (oor.length) limits.unshift(`<b>Outside the trained range:</b> ${oor.join('; ')}. The forecast there is an extrapolation and the interval understates the real uncertainty.`);
  if (D.model.zero_cap && D.model.zero_cap[D.cats[v.cat]] !== undefined) limits.unshift(`${esc(D.cat_labels[v.cat])} recorded no failures in training, so the upper end of this interval is an exact statistical limit rather than a fitted one.`);

  el.innerHTML = `
    <h3>Scenario summary</h3>
    <p class="cap">Written automatically from the inputs on the left, each time you change one.</p>
    <div class="sum-grid">
      <div><h4>What you changed</h4><ul class="sum-list">${inputs}</ul>
        <p class="sum-ctx">${esc(v.name)} · ${esc(weekLabel(w))} · ${esc(w.season)} season · review capacity ${k}</p></div>
      <div><h4>What the model says</h4>
        <p class="sum-move">${movement}</p>
        <p class="sum-move">${costMove}</p></div>
    </div>
    <div class="sum-lim"><h4>Trade-offs to weigh</h4>
      <ul class="sum-list sum-plain">${T.map(l => `<li>${l}</li>`).join('')}</ul></div>
    <div class="sum-lim"><h4>What this does and does not tell you</h4>
      <ul class="sum-list">${limits.map(l => `<li>${l}</li>`).join('')}</ul></div>`;
}

function renderExplain(C) { renderContributions(); renderSummary(C); }
