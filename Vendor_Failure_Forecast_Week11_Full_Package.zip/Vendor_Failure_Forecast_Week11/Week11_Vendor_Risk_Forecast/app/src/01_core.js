'use strict';
/* ------------------------------------------------------------------ data & helpers */
const D = JSON.parse(document.getElementById('app-data').textContent);
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pct = (x, d = 1) => (x * 100).toFixed(d) + '%';
const pts = (x, d = 1) => (x >= 0 ? '+' : '−') + Math.abs(x * 100).toFixed(d);
const usd = x => '$' + Math.round(x).toLocaleString('en-US');
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const E = D.eval;
const V = D.vendors.length;
const W = D.weeks.length;
const R = D.rows;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const weekIndex = {}; D.weeks.forEach((w, i) => { weekIndex[w.id] = i; });
const shortDate = s => { const [y, m, d] = s.split('-').map(Number); return MONTHS[m - 1] + ' ' + d; };
const weekLabel = w => w.id.replace('2026-', '') + ' · ' + shortDate(w.start);

/* ------------------------------------------------------------------ the fitted model (complementary log-log, Laplace posterior) */
const M = D.model, NAMES = M.names, BETA = M.beta, COV = M.cov;
const IDX = {}; NAMES.forEach((n, i) => { IDX[n] = i; });
const Z = { 50: 0.6745, 80: 1.2816, 95: 1.96 };
const ZCAP = M.zero_cap || {};
const zf = (f, v) => { const s = M.scaler[f]; return (v - s[0]) / s[1]; };

function design(vi, expo, rej4, rej13) {
  const v = D.vendors[vi];
  return {
    ix: [0, IDX['cat:' + D.cats[v.cat]], IDX['v:' + v.id], IDX.log_exposure, IDX.rej_4wk, IDX.rej_13wk],
    xv: [1, 1, 1, zf('log_exposure', Math.log(Math.max(expo, 1e-3))), zf('rej_4wk', rej4), zf('rej_13wk', rej13)]
  };
}
function etaSe(d) {
  let e = 0, v = 0; const n = d.ix.length;
  for (let i = 0; i < n; i++) {
    e += BETA[d.ix[i]] * d.xv[i];
    for (let j = 0; j < n; j++) v += d.xv[i] * d.xv[j] * COV[d.ix[i]][d.ix[j]];
  }
  return [e, Math.sqrt(Math.max(v, 0))];
}
const pOf = e => -Math.expm1(-Math.exp(e));
/* chance of >=1 material failure within h weeks if conditions persist; interval from eta +/- z*se; shift = change in log-hazard */
function forecast(vi, expo, rej4, rej13, shift = 0, z = Z[80], h = 1) {
  const [e0, se] = etaSe(design(vi, expo, rej4, rej13));
  const e = e0 + shift;
  const f = x => 1 - Math.pow(1 - pOf(x), h);   // accumulate over h weeks
  // a category with no failures in training (MRO): the data rule out high rates, so the upper end is clipped (see zero_event_cap)
  const cd = ZCAP[D.cats[D.vendors[vi].cat]];
  const eHi = cd === undefined ? e + z * se : Math.min(e + z * se, e + cd);
  return { eta: e, se, p: f(e), lo: f(e - z * se), hi: f(eHi) };
}
const ri = (wi, vi) => wi * V + vi;
/* The model's inputs are RATES; the manager works with COUNTS (deliveries received, deliveries rejected). Rates are derived from counts and
   rounded to four decimals with round-half-to-even, exactly as the source snapshot stores them, so the model sees the same numbers as in training. */
function round4(x) {
  const y = x * 1e4, f = Math.floor(y), d = y - f;
  if (Math.abs(d - 0.5) < 1e-9) return (f % 2 === 0 ? f : f + 1) / 1e4;
  return Math.round(y) / 1e4;
}
function ratesFromCounts(n13, r13, n4, r4) {
  const rej13 = round4(r13 / n13);
  return { expo: n13 / 13, rej13, rej4: n4 > 0 ? round4(r4 / n4) : rej13 };      // no deliveries in 4 weeks: the 13-week rate stands in (as in training)
}
function recorded(wi, vi) {
  const i = ri(wi, vi);
  if (!R.scored[i]) return null;
  const c = { n13: R.n13[i], r13: R.r13[i], n4: R.n4[i], r4: R.r4[i] };
  return Object.assign({ cap: R.cap[i] }, c, ratesFromCounts(c.n13, c.r13, c.n4, c.r4));
}

/* ------------------------------------------------------------------ cost of a failing vendor-week (OLS on the demand of the week the failure happens)
   The forecast made on Monday wi is about week wi+1, so the cost model is fed wi+1's occupancy and banquet flag. Week 10 used wi's own values here,
   which did not match how the cost model was fitted (and differed from the Python evaluation). Assumption, stated in the app: next week's banquet
   bookings and occupancy forecast are known on Monday. They size the cost only; they never enter the failure probability or the ranking. */
function costMean(wi) { const w = D.weeks[wi], b = D.cost.beta; return b[0] + b[1] * w.occ_n + b[2] * w.banq_n; }
function costSe(wi) {
  const w = D.weeks[wi], x = [1, w.occ_n, w.banq_n], C = D.cost.cov; let v = 0;
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) v += x[i] * x[j] * C[i][j];
  return Math.sqrt(Math.max(v, 0));
}
const RQ = D.cost.ratio_q;                          // empirical quantiles (0..100) of cost / fitted mean
function ratioAt(u) { const x = clamp(u, 0, 1) * 100, i = Math.min(99, Math.floor(x)); return RQ[i] + (RQ[i + 1] - RQ[i]) * (x - i); }

/* ------------------------------------------------------------------ seeded randomness, Cholesky draws of the coefficients */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function gauss(r) { let u = 0; while (u === 0) u = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * r()); }
function cholesky(A) {
  const n = A.length; let jitter = 0;
  for (let attempt = 0; attempt < 8; attempt++) {
    const L = Array.from({ length: n }, () => new Float64Array(n)); let ok = true;
    for (let i = 0; i < n && ok; i++) {
      for (let j = 0; j <= i; j++) {
        let s = A[i][j] + (i === j ? jitter : 0);
        for (let k = 0; k < j; k++) s -= L[i][k] * L[j][k];
        if (i === j) { if (s <= 0) { ok = false; break; } L[i][i] = Math.sqrt(s); } else L[i][j] = s / L[j][j];
      }
    }
    if (ok) return L;
    jitter = jitter ? jitter * 10 : 1e-9;
  }
  throw new Error('covariance is not positive definite');
}
const CHOL = cholesky(COV);
function drawBetas(S, seed) {
  const r = mulberry32(seed), n = BETA.length, out = [];
  for (let s = 0; s < S; s++) {
    const z = new Float64Array(n); for (let i = 0; i < n; i++) z[i] = gauss(r);
    const b = new Float64Array(n);
    for (let i = 0; i < n; i++) { let t = BETA[i]; const Li = CHOL[i]; for (let j = 0; j <= i; j++) t += Li[j] * z[j]; b[i] = t; }
    for (const c in ZCAP) { const j = IDX['cat:' + c]; b[j] = Math.min(b[j], BETA[j] + ZCAP[c]); }   // zero-failure categories: clip the upper tail
    out.push(b);
  }
  return out;
}
function quantile(sortedArr, q) {
  const n = sortedArr.length, x = q * (n - 1), i = Math.floor(x), f = x - i;
  return i + 1 < n ? sortedArr[i] * (1 - f) + sortedArr[i + 1] * f : sortedArr[n - 1];
}

/* ------------------------------------------------------------------ one week's scores for every scored vendor */
function weekScores(wi, shift = 0) {
  const out = new Array(V).fill(null);
  for (let vi = 0; vi < V; vi++) {
    const rec = recorded(wi, vi); if (!rec) continue;
    out[vi] = Object.assign({ vi, wi }, rec, forecast(vi, rec.expo, rec.rej4, rec.rej13, shift, Z[80]));
  }
  return out;
}

/* Monte Carlo for a week: draws of the coefficients -> rank stability, count and dollar predictive intervals */
const DRAWS = 600;
let BETA_DRAWS = null;
function weekSimulation(wi) {
  if (!BETA_DRAWS) BETA_DRAWS = drawBetas(DRAWS, 20261026);
  const scores = weekScores(wi), vis = [];
  for (let vi = 0; vi < V; vi++) if (scores[vi]) vis.push(vi);
  const designs = vis.map(vi => { const s = scores[vi]; return design(vi, s.expo, s.rej4, s.rej13); });
  const k = D.weeks[wi].k, mu = costMean(wi), muSe = costSe(wi);
  const elig = vis.map(vi => scores[vi].cap === 0);
  const inTop = new Array(vis.length).fill(0), counts = [], dollars = [];
  const rr = mulberry32(777 + wi);
  for (let s = 0; s < DRAWS; s++) {
    const b = BETA_DRAWS[s], ps = new Array(vis.length);
    for (let a = 0; a < vis.length; a++) {
      const d = designs[a]; let e = 0; for (let c = 0; c < d.ix.length; c++) e += b[d.ix[c]] * d.xv[c];
      ps[a] = pOf(e);
    }
    const order = []; for (let a = 0; a < vis.length; a++) if (elig[a]) order.push(a);
    order.sort((x, y) => ps[y] - ps[x]);
    for (let r = 0; r < Math.min(k, order.length); r++) inTop[order[r]]++;
    let n = 0, dol = 0; const muS = mu + muSe * gauss(rr);
    for (let a = 0; a < vis.length; a++) if (rr() < ps[a]) { n++; dol += Math.max(muS, 0) * ratioAt(rr()); }
    counts.push(n); dollars.push(dol);
  }
  counts.sort((x, y) => x - y); dollars.sort((x, y) => x - y);
  const exp = vis.reduce((t, vi) => t + scores[vi].p, 0);
  return {
    scores, vis, inTopShare: Object.fromEntries(vis.map((vi, a) => [vi, inTop[a] / DRAWS])),
    expCount: exp, countLo: quantile(counts, 0.1), countHi: quantile(counts, 0.9),
    expCost: exp * mu, costLo: quantile(dollars, 0.1), costHi: quantile(dollars, 0.9), mu, k
  };
}

/* ------------------------------------------------------------------ tooltip + generic SVG helpers */
const tipEl = document.createElement('div'); tipEl.className = 'tip'; tipEl.hidden = true; document.body.appendChild(tipEl);
function showTip(html, ev) {
  tipEl.innerHTML = html; tipEl.hidden = false; tipEl.style.position = 'fixed';
  const pad = 12, w = tipEl.offsetWidth, h = tipEl.offsetHeight;
  let x = ev.clientX + pad, y = ev.clientY + pad;
  if (x + w > window.innerWidth - 8) x = ev.clientX - w - pad;
  if (y + h > window.innerHeight - 8) y = ev.clientY - h - pad;
  tipEl.style.left = Math.max(8, x) + 'px'; tipEl.style.top = Math.max(8, y) + 'px';
}
const hideTip = () => { tipEl.hidden = true; };
document.addEventListener('scroll', hideTip, true);
function bindTips(root) {
  root.addEventListener('pointermove', ev => {
    const t = ev.target.closest && ev.target.closest('[data-tip]');
    if (t && root.contains(t)) showTip(t.getAttribute('data-tip'), ev); else hideTip();
  });
  root.addEventListener('pointerleave', hideTip);
}
const tipRow = (k, v) => `<div class="r"><span>${k}</span><b>${v}</b></div>`;
const f1 = x => x.toFixed(1);
function niceMax(x) { const p = Math.pow(10, Math.floor(Math.log10(x))); for (const m of [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]) if (m * p >= x) return m * p; return 10 * p; }
function linScale(d0, d1, r0, r1) { const f = x => r0 + (x - d0) / (d1 - d0) * (r1 - r0); f.inv = y => d0 + (y - r0) / (r1 - r0) * (d1 - d0); return f; }
function chartWidth(el) { return Math.max(0, Math.floor(el.getBoundingClientRect().width)); }
function peakRuns() {
  const runs = []; let s = null;
  D.weeks.forEach((w, i) => { if (w.season === 'peak') { if (s === null) s = i; } else if (s !== null) { runs.push([s, i - 1]); s = null; } });
  if (s !== null) runs.push([s, W - 1]);
  return runs;
}
function monthTicks(weekIds) {
  const out = []; let last = -1;
  weekIds.forEach((id, i) => {
    const w = D.weeks[weekIndex[id]], m = Number(w.start.slice(5, 7)) - 1;
    if (m !== last && m % 3 === 0) out.push([i, MONTHS[m]]);
    last = m;
  });
  return out;
}
const table = (head, rows, numCols = []) =>
  `<table><thead><tr>${head.map((h, i) => `<th class="${numCols.includes(i) ? 'n' : ''}">${h}</th>`).join('')}</tr></thead><tbody>` +
  rows.map(r => `<tr>${r.map((c, i) => `<td class="${numCols.includes(i) ? 'n' : ''}">${c}</td>`).join('')}</tr>`).join('') + `</tbody></table>`;
