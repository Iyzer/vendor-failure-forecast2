// Builds Week11_Usability_Test_Kit.docx : protocol, task sheet, observation form, post-test questions, findings log.
// Blank forms only. Nothing in this file is a result: results are written in by the team from the real session.
const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, AlignmentType, LevelFormat, PageBreak, Footer, PageNumber } = require('docx');

const FONT = 'Arial', BODY = 20;                 // 10 pt
const INK = '1F2A37', BLUE = '1C4F8F', GREY = '5B6573', LINE = 'C9D1DC', WASH = 'EEF2F8', AMBER = 'FFF4D6';
const run = (t, o = {}) => new TextRun({ text: t, font: FONT, size: o.size || BODY, bold: o.bold, italics: o.italics, color: o.color || INK });
const rich = (s, o = {}) => s.split(/(\*\*[^*]+\*\*)/).filter(Boolean).map(p => p.startsWith('**') ? run(p.slice(2, -2), { ...o, bold: true }) : run(p, o));
const P = (s, o = {}) => new Paragraph({ children: rich(s, o), spacing: { after: o.after ?? 100, line: o.line ?? 264 }, alignment: o.align, keepNext: o.keepNext });
const H1 = t => new Paragraph({ children: [run(t, { bold: true, size: 32, color: BLUE })], spacing: { before: 0, after: 120 }, keepNext: true, pageBreakBefore: true });
const H2 = t => new Paragraph({ children: [run(t, { bold: true, size: 24, color: BLUE })], spacing: { before: 220, after: 80 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: LINE, space: 2 } }, keepNext: true });
const H3 = t => new Paragraph({ children: [run(t, { bold: true, size: 21 })], spacing: { before: 140, after: 50 }, keepNext: true });
const B = (s, lvl = 0) => new Paragraph({ children: rich(s), numbering: { reference: 'b', level: lvl }, spacing: { after: 60, line: 260 } });
const N = s => new Paragraph({ children: rich(s), numbering: { reference: 'n', level: 0 }, spacing: { after: 60, line: 260 } });
const brk = () => new Paragraph({ children: [new PageBreak()] });
const sp = (n = 80) => new Paragraph({ children: [], spacing: { after: n } });

const W = 12240 - 2 * 1080;                      // 10080 DXA text width
const bd = c => ({ style: BorderStyle.SINGLE, size: 4, color: c || LINE });
const borders = { top: bd(), bottom: bd(), left: bd(), right: bd() };
function cell(content, w, o = {}) {
  const kids = (Array.isArray(content) ? content : [content]).map(c => typeof c === 'string' ? new Paragraph({ children: rich(c, { size: o.size || 18, bold: o.bold }), spacing: { after: 30, line: 240 } }) : c);
  return new TableCell({ width: { size: w, type: WidthType.DXA }, borders, margins: { top: 50, bottom: 50, left: 90, right: 90 },
    shading: o.fill ? { fill: o.fill, type: ShadingType.CLEAR, color: 'auto' } : undefined, verticalAlign: o.valign, children: kids });
}
function table(widths, header, rows, o = {}) {
  const tw = widths.reduce((a, b) => a + b, 0);
  const trs = [];
  if (header) trs.push(new TableRow({ tableHeader: true, cantSplit: true, children: header.map((h, i) => cell(h, widths[i], { bold: true, fill: WASH, size: o.size })) }));
  rows.forEach(r => trs.push(new TableRow({ cantSplit: true, height: o.rowH ? { value: o.rowH, rule: 'atLeast' } : undefined, children: r.map((c, i) => cell(c, widths[i], { size: o.size, fill: o.firstFill && i === 0 ? WASH : undefined, bold: o.firstBold && i === 0 })) })));
  return new Table({ width: { size: tw, type: WidthType.DXA }, columnWidths: widths, rows: trs });
}
const blank = n => Array.from({ length: n }, () => '');
const box = (lines, fill) => new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [W], rows: [new TableRow({ children: [new TableCell({ width: { size: W, type: WidthType.DXA }, borders, margins: { top: 90, bottom: 60, left: 140, right: 140 }, shading: { fill: fill || WASH, type: ShadingType.CLEAR, color: 'auto' }, children: lines.map(l => typeof l === 'string' ? P(l, { after: 60 }) : l) })] })] });

const kids = [];

// ------------------------------------------------------------------ cover
kids.push(new Paragraph({ children: [run('Vendor Failure Forecast', { bold: true, size: 44, color: BLUE })], spacing: { before: 600, after: 60 } }));
kids.push(new Paragraph({ children: [run('Week 11 usability test kit', { size: 32 })], spacing: { after: 160 } }));
kids.push(P('Protocol, task sheet, observation form, post-test questions and findings log for the structured test with a person outside the group.', { color: GREY, after: 200 }));
kids.push(P('Mirza Ali and Debra Senteu · MS Analytics, Saint Louis University · all vendor names, dates and amounts in the app are synthetic.', { size: 18, color: GREY, after: 300 }));
kids.push(table([2400, W - 2400], null, [
  ['Part A', 'Protocol for the facilitator: who to recruit, set-up, the words to read aloud, the rules for staying neutral, and what to do afterwards.'],
  ['Part B', 'Task sheet for the participant (print this page separately; it contains no answers).'],
  ['Part C', 'Observation form: one row per task, filled in by hand during the session.'],
  ['Part D', 'Post-test questions: five ratings, two comprehension checks, open questions.'],
  ['Part E', 'Findings and change log, plus the paragraph skeleton for the evaluation report.'],
  ['Part F', 'Facilitator answer key (do not show to the participant) and the places we expect trouble, written before the session.']
], { firstFill: true, firstBold: true, size: 20 }));
kids.push(sp(240));
kids.push(box([
  '**How to use this kit honestly.** The forms are blank on purpose. Everything that goes in them must come from the real session: the times as observed, the participant\'s own words, the problems that actually happened. If the session shows no problem with an item, write that; if a task was skipped, write why. The report must say who the participant was and that one session is a small sample.'
], AMBER));

// ------------------------------------------------------------------ Part A
kids.push(H1('Part A. Protocol for the facilitator'));
kids.push(H2('A1. What this test is for'));
kids.push(P('Week 11 asks us to learn from someone outside the group before we call the app finished. The question is not "does it work" (our own tests cover that) but **can a person who has never seen it read the weekly list, understand a forecast and how sure it is, try a what-if, and recognise an impossible scenario, without us explaining anything?** We are testing the app, not the person. A mistake by the participant is information about the app.'));
kids.push(H2('A2. Who to ask'));
kids.push(B('**Best:** someone who works, or has worked, in hotel or restaurant purchasing, receiving, food and beverage, or resort operations. They know what a late delivery or a rejected case costs.'));
kids.push(B('**Acceptable substitute:** any adult who buys, plans or manages supplies for a team or business and has not followed this project. If we use a substitute, the report says so and lists what that limits (they will not know the field\'s vocabulary or the real cost of a missed delivery).'));
kids.push(B('**Not acceptable:** a classmate who has seen the app or the Week 10 video, or anyone on the team.'));
kids.push(B('Record the participant by **role and experience only** (for example "assistant F&B manager, 6 years"). Use a name in the report only if they agree.'));
kids.push(H2('A3. Set-up (30 to 40 minutes)'));
kids.push(B('Open the app on the **Model performance** tab in a fresh browser window, at a normal laptop size. Use the hosted link or `app/index.html`. Write the exact link or file and the browser on the observation form.'));
kids.push(B('In person: the participant uses the laptop; the facilitator sits slightly behind and to the side. Remote: the participant shares their screen and controls the app themselves; they must not be talked through the clicks.'));
kids.push(B('Two team members if possible: one facilitates and speaks, one only takes notes. A phone timer is enough for task times.'));
kids.push(B('Record the screen or audio **only with the participant\'s agreement**, and say that it will be deleted after the report is written. Nothing real is exposed because the data are synthetic; do not ask for company names or personal information.'));
kids.push(B('Have Part B printed (or open on a second device) and Part C ready. Keep Part F closed in front of the participant.'));
kids.push(H2('A4. Words to read aloud at the start'));
kids.push(box([
  '"Thank you for helping. We built a tool that helps a purchasing and receiving manager decide which suppliers to look at closely each Monday. We want to find out where it is confusing, so please be critical. **You cannot do anything wrong: if something is hard, that is our mistake, not yours.**',
  'The suppliers, dates and numbers are all made up. I will give you some small tasks. Please **think aloud**: say what you are looking at, what you expect, and what you are confused by. I will not be able to help or explain while you work, because I want to see what the tool does on its own, but I will write everything down. If you get stuck for more than a few minutes I will ask you to move on. You can stop at any time. Is it all right if I take notes (and record the screen, if you agree)?"'
]));
kids.push(H2('A5. Rules while the participant works'));
kids.push(B('**Do not explain, defend, or point.** Do not say "it is on the next tab".'));
kids.push(B('**Neutral prompts only:** "What are you thinking?", "What did you expect to happen?", "What would you do next?", "Is that what you expected?", "Say more about that."'));
kids.push(B('**Hints, only after about 90 seconds of silence or looping, and always recorded.** Level 1: "Take another look at the page." Level 2: name the tab or area. Level 3: tell them what to do. On the observation form write the level that was needed.'));
kids.push(B('**Stop a task at 4 minutes** and mark it "not completed"; move on so the participant is not left feeling they failed.'));
kids.push(B('**Write verbatim quotes.** Wording such as "I thought that meant…" is the most useful evidence we collect.'));
kids.push(B('**Do not answer questions about results** ("is 19% high?") until the end; say "I will come back to that". After the post-test questions, answer anything they asked.'));
kids.push(H2('A6. Scoring each task'));
kids.push(table([2400, W - 2400], ['Result', 'Meaning'], [
  ['Unaided', 'Gave the correct answer or finished the action with no hint. Correct means matches the answer key in Part F; partial answers are written out, not rounded up.'],
  ['With hint (L1, L2, L3)', 'Needed a hint; write the level and what it was.'],
  ['Not completed', 'Gave up, ran past 4 minutes, or gave an answer that would lead to a wrong decision.']
], { size: 18 }));
kids.push(sp(60));
kids.push(P('**Severity of each problem noticed:** 0 not a problem; 1 cosmetic or wording that did not slow them; 2 slowed or confused them but they recovered; 3 led to a wrong answer or they could not continue (this could cause a wrong decision in real use).', { size: 18 }));
kids.push(H2('A7. After the session'));
kids.push(N('Thank them. Ask the post-test questions (Part D). Then answer what they asked and explain the tool if they want.'));
kids.push(N('Within 24 hours, both team members sit together and fill in Part E from the notes, before memories fade. Cite the task and the quote for every finding.'));
kids.push(N('Decide, finding by finding, **change** or **no change with a reason**. Severity 3 findings and any severity 2 finding that appears in more than one task get a change.'));
kids.push(N('**Make at least one app change that traces to an observation**, rebuild the app, and note the change in `docs/CHANGELOG.md` and in Part E (what the participant did, what we changed, where in the app).'));
kids.push(N('If at all possible, **retest the changed element** for five minutes with the same participant or a second outsider, and write what happened. If a retest is not possible, say so.'));
kids.push(N('If the session produces no problem worth a change, do not invent one. Write that, and describe what was observed that makes us confident (for example "completed 8 of 8 tasks unaided; no hesitation on the interval wording").'));

// ------------------------------------------------------------------ Part B
kids.push(H1('Part B. Task sheet (for the participant)'));
kids.push(P('You are the **Purchasing & Receiving Manager** at a seasonal resort. Each Monday you have time to look closely at only a few of your roughly 45 active suppliers: about 5 in a busy summer week and up to 12 in a quiet one. The tool you are about to use is meant to help you choose which ones. All suppliers, dates and amounts are made up.', { after: 120 }));
kids.push(P('Please think aloud as you go. If something is unclear, say so: that is exactly what we are here to find out. There are no right or wrong impressions.', { after: 160 }));
const tasks = [
  ['1', '**The weekly list.** Open the tab **Weekly review list** and choose **week 26 (June 22)**. Which suppliers would you review this week, and how many can you review? What do the dot and the line beside each supplier tell you?'],
  ['2', '**Read a forecast.** Open the tab **What-if forecast** and choose **Produce 002** in **week 26**. In your own words, what is the tool telling you about next week for this supplier?'],
  ['3', '**Why this score?** Find where the tool explains why this supplier scores what it does. Name the one or two things that raise its risk the most.'],
  ['4', '**What can I change?** Looking at the boxes and controls on the left, which ones could you or your team actually influence, and which could you not? How can you tell?'],
  ['5', '**Try a what-if.** Suppose this supplier had **3 more rejected deliveries** than the record shows. Use the tool to see what changes. What happens to the chance of failure and to the supplier\'s place on the review list? Does the tool say the extra rejections would cause failures?'],
  ['6', '**A mistake.** Now type **120** into the box for rejected deliveries in the last 13 weeks. What happens? How would you get a forecast back?'],
  ['7', '**Can I rely on it?** Open **Evaluation & limits**. Would you use this tool to decide which suppliers to review? What would make you trust it more or less? What does the page say it cannot do?'],
  ['8', '**Use the summary.** (If time allows.) Back on the what-if tab, use the written summary to say one sentence you would tell your chef or general manager about this supplier.']
];
kids.push(table([700, W - 700], ['Task', 'What to do'], tasks, { size: 21, rowH: 700 }));
kids.push(sp(160));
kids.push(P('Thank you. There is a short set of questions at the end.', { color: GREY }));

// ------------------------------------------------------------------ Part C
kids.push(H1('Part C. Observation form'));
kids.push(P('Fill in by hand during the session. One row per task. Write what happened, not what should have happened.', { color: GREY }));
kids.push(table([2700, W - 2700], null, [
  ['Date and time', ''], ['Facilitator / note-taker', ''], ['Participant role and experience (no name)', ''],
  ['Device, screen size, browser', ''], ['App link or file used', ''], ['Screen / audio recorded? (agreed: yes / no)', ''], ['Start and end time', '']
], { firstFill: true, firstBold: true, size: 18, rowH: 330 }));
kids.push(sp(120));
const obsH = ['Task', 'Result (U / H1 H2 H3 / N)', 'Time (m:ss)', 'Wrong turns, quotes, behaviour (verbatim)', 'Sev 0-3'];
const obsW = [650, 1500, 950, W - 650 - 1500 - 950 - 800, 800];
kids.push(table(obsW, obsH, ['1', '2', '3', '4', '5', '6', '7', '8'].map(t => [t, '', '', '', '']), { size: 18, rowH: 760 }));
kids.push(sp(100));
kids.push(P('**U** unaided · **H1 / H2 / H3** hint level needed · **N** not completed', { size: 17, color: GREY }));
kids.push(H3('Spontaneous comments, questions, and moments of confusion not tied to a task'));
kids.push(table([W], null, [[''], ['']], { size: 18, rowH: 800 }));

// ------------------------------------------------------------------ Part D
kids.push(H1('Part D. Post-test questions'));
kids.push(P('Ask aloud and write the answers down, or hand over the page. Take care not to explain anything until all have been answered.', { color: GREY }));
kids.push(H2('D1. Ratings (1 = strongly disagree, 5 = strongly agree)'));
kids.push(table([W - 1000, 1000], ['Statement', 'Rating'], [
  ['I understood what the percentages mean.', ''],
  ['I could tell which suppliers I should review.', ''],
  ['I understood how sure the tool is about each number.', ''],
  ['I would be comfortable using this on a Monday morning.', ''],
  ['When something went wrong, the message helped me fix it.', '']
], { size: 20, rowH: 460 }));
kids.push(H2('D2. Comprehension checks (write the answer exactly as given)'));
kids.push(table([W - 2400, 2400], ['Question', 'Answer'], [
  ['"If a supplier shows 20% for next week, roughly how many weeks out of 100 like this one would you expect it to fail?"', ''],
  ['"Does the tool prove that more rejected deliveries make a supplier fail? Yes, no, or not sure, and why?"', '']
], { size: 20, rowH: 800 }));
kids.push(H2('D3. Open questions'));
kids.push(table([W], null, [
  ['**What was the most confusing part?**'], ['**What was the most useful part?**'], ['**What would you change first?**'],
  ['**What would you want it to show that it does not?**'], ['**Would you base a real decision on this alone? Why or why not?**']
], { size: 20, rowH: 900 }));

// ------------------------------------------------------------------ Part E
kids.push(H1('Part E. Findings and change log'));
kids.push(P('Complete within 24 hours of the session. One row per finding. Every change must point to an observation.', { color: GREY }));
kids.push(table([450, 2300, 650, 650, 2300, 2230, 1500], ['#', 'What happened (quote, evidence)', 'Task', 'Sev', 'Decision and reason (change / no change)', 'App change made (tab, element, file)', 'Retest result'],
  [1, 2, 3, 4, 5, 6].map(n => [String(n), '', '', '', '', '', '']), { size: 17, rowH: 800 }));
kids.push(sp(120));
kids.push(H3('Paragraph skeleton for the evaluation report (fill every blank from the forms; delete nothing that is awkward)'));
kids.push(box([
  'We ran one structured session on [date] with [role, experience; recruited because …]. The participant used [device, browser] and worked through eight tasks while thinking aloud; [one / two] team members observed. They completed [n] of 8 tasks unaided, [n] with a hint, and [n] not at all. The most serious problems were […, severity, task, quote]. In response we changed […] (see CHANGELOG), and [retest outcome, or why there was no retest]. Ratings after the test were […] and the comprehension checks were answered […].',
  '**Limits:** one participant (so we can say what went wrong for one person, not how often); [background versus a real purchasing manager]; the tool was tested on synthetic data in a short session; the team facilitated, which can make people polite.'
]));

// ------------------------------------------------------------------ Part F
kids.push(H1('Part F. Facilitator key (keep away from the participant)'));
kids.push(P('Values shown by the app version in this folder. Check them on screen before the session; a rebuild may change the last digit.', { size: 17, color: GREY, after: 40 }));
kids.push(H2('F1. What a correct answer looks like'));
kids.push(table([650, W - 650], ['Task', 'Correct or acceptable'], [
  ['1', 'Five suppliers in the list for week 26: **Produce 002 (19.4%), Produce 003 (16.1%), Produce 010 (12.1%), Produce 005 (8.5%), Protein 015 (8.3%)**. Capacity is 5 in this peak week. Dot = chance of a material failure next week; line = the 80% interval (how sure the tool is). Good extra: notices that two suppliers are held out for open corrective action and three are not scored.'],
  ['2', 'About 19 in 100 weeks like this end with a failure at this supplier; the tool is 80% sure the true figure is between about 15 and 24 in 100. Must not say it **will** fail, and must not treat 19% as a certainty or as "low".'],
  ['3', 'The **category (Produce)** is by far the largest contribution (+1.61), then **deliveries per week** (+0.45), then the supplier\'s own record (+0.31) and the 4-week rejection rate (+0.21). The 13-week rejection rate adds nothing. Accept "produce suppliers are riskier and this one delivers a lot".'],
  ['4', 'Boxes tagged **You can change** (recent deliveries and rejections: the record as counted on that Monday); **Fixed** (category, size, the supplier\'s own history); **Outside your control** (season, failure-rate shift, cost of a failure, next week\'s occupancy). Correct if they use the tags or reason about it sensibly; record whether they noticed the tags.'],
  ['5', 'Chance rises from **19.4% to 36.1%** (80% interval 25.3% to 49.6%); the supplier stays at place 1 of 45 and stays on the list of 5. A warning says the 4-week rate is outside what the model has seen. The tool states **model-based, not proven cause**; correct if the participant says it does not prove cause.'],
  ['6', 'Red message: "This scenario cannot happen … Rejected (120) cannot be more than deliveries received (95)", no forecast shown. Recovery: type a number up to 95 or press **Adjust to the nearest possible scenario**, or **Reset**.'],
  ['7', 'Understands that the list is a ranking aid, not a guarantee: it catches about half of the next-week failure cost (about 55%), clearly beats current practice (about +18 to +24 points), but is **not shown to beat simply ranking by delivery volume**; dollar estimates are close to the average past cost; the data are synthetic; list size matters. Any hedged "useful, not alone" reading is fine; "perfect" or "useless" both mean the page did not land.'],
  ['8', 'One sentence that includes the chance **and** a caution (the interval, or that it is model-based). Record the sentence verbatim.']
], { size: 17 }));
kids.push(H2('F2. Where we expect trouble (written before the session, to be compared with what happens)'));
kids.push(P('Guesses, not findings. After the session mark each confirmed, not seen, or contradicted.', { size: 17, color: GREY, after: 60 }));
kids.push(table([450, W - 450 - 2100, 2100], ['#', 'Our guess', 'Confirmed / not seen / contradicted'], [
  ['a', 'The column "In list" (share of 600 draws in which the supplier makes the list) is hard to read.', ''],
  ['b', '"80% interval" is read as "80% chance of failure".', ''],
  ['c', 'On the what-if tab the participant does not see the written summary because it sits below the comparison table.', ''],
  ['d', 'The three tags (You can change / Fixed / Outside your control) are not noticed, or "You can change" is read as "do this to reduce risk".', ''],
  ['e', 'Counts are entered as percentages, or the 4-week box is edited without noticing the 13-week box also matters.', ''],
  ['f', 'The Evaluation tab is too dense; the "not shown to beat ranking by volume" verdict is missed.', ''],
  ['g', 'Peak-week lists of 5 look arbitrary: the participant asks why 5.', '']
], { size: 17, rowH: 380 }));

const doc = new Document({
  creator: 'Mirza Ali and Debra Senteu', title: 'Vendor Failure Forecast - Week 11 usability test kit',
  styles: { default: { document: { run: { font: FONT, size: BODY, color: INK } } } },
  numbering: { config: [
    { reference: 'b', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 420, hanging: 260 } } } }] },
    { reference: 'n', levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 460, hanging: 320 } } } }] }
  ] },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1000, bottom: 1000, left: 1080, right: 1080 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [run('Vendor Failure Forecast · Week 11 usability test kit · page ', { size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY })] })] }) },
    children: kids
  }]
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(__dirname + '/Week11_Usability_Test_Kit.docx', b); console.log('ok'); });
