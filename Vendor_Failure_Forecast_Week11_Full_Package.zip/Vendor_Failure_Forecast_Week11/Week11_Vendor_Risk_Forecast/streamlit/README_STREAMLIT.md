# Vendor Failure Forecast on Streamlit

`vendor_failure_forecast.html` is the Week 11 app: one self-contained page whose model, charts and what-if controls run in the
browser (a copy of `app/index.html` from the Week 11 package). `streamlit_app.py` serves that page full-width inside a Streamlit app.
Nothing is recomputed in Python, so the app behaves exactly like the offline copy. The data is synthetic.

The Week 10 page is kept unchanged in `week10/vendor_failure_forecast_week10.html`. Add `?version=week10` to the app's address to
open it (for example `https://your-app.streamlit.app/?version=week10`).

## Files (keep them together at the root of the repository)

- `streamlit_app.py`: the Streamlit entry point
- `vendor_failure_forecast.html`: the Week 11 app
- `week10/vendor_failure_forecast_week10.html`: the Week 10 app, unchanged
- `requirements.txt`: just `streamlit`
- `.streamlit/config.toml`: hides Streamlit's toolbar clutter
- `make_single_file_app.py`: writes one self-contained `streamlit_app.py` with both pages embedded, for deploying from a repository that holds only a few files (`python3 make_single_file_app.py`)

## Run it on your computer first

```
pip install -r requirements.txt
streamlit run streamlit_app.py
```

It opens at http://localhost:8501. Check all four tabs (Model performance, Evaluation & limits, What-if forecast, Weekly review list),
try a scenario, and try a narrow browser window.

## Update the app you already deployed

You already have a GitHub repository connected to Streamlit Community Cloud. To switch it to Week 11:

1. In the repository, replace `streamlit_app.py` and `vendor_failure_forecast.html` with the versions from this folder.
2. Add the `week10` folder (with the Week 10 page inside) so the old version stays reachable.
3. Commit. Streamlit Community Cloud redeploys on its own within a minute or two; use "Reboot app" in its menu if it does not.

## If something looks off

- **The page is cut off, or leaves a gap at the bottom, after switching tabs or changing a scenario:** open `streamlit_app.py` and set
  `SELF_FIT = True`. The page then resizes its own frame. (Older Streamlit versions use this mode automatically.)
- **Colours look wrong against Streamlit's background:** the page copies Streamlit's light or dark theme when Streamlit reports it.

## What was tested

The wrapper was syntax-checked and exercised against a stand-in for the Streamlit API, and the page was tested inside a sandboxed
iframe at desktop and phone width, light and dark. It was **not** run on a real Streamlit server (the package could not be installed
in the build environment), so run it locally once before relying on it.

## Deploying from a small repository

If the repository holds only `streamlit_app.py` (the single-file build made by `make_single_file_app.py`), set the main file path to `streamlit_app.py`. No `requirements.txt` is needed: Community Cloud then installs just Streamlit, which is all this app uses. Run the script again after any change to the page.
