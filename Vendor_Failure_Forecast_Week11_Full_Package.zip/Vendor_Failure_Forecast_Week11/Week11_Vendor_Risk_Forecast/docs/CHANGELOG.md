# Change log

## Week 11 (29 Oct 2026): evaluation and decision support

The Week 10 package is kept unchanged in `Week10_frozen/`. This folder is the Week 11 version.

**Added**

- `code/wk11_lib.py` and scripts `20_wk11_evaluation.py`, `21_wk11_error_analysis.py`, `22_wk11_improvements.py`: rolling-origin
  (walk-forward) evaluation on 2023 to 2025, leakage controls, baselines with paired week-cluster bootstrap intervals, error analysis by
  segment, thirteen improvement candidates judged by stated rules (eleven set before they were run; two added after Debra's screen, see below). 2026 is used for confirmation only.
- **Evaluation & limits** tab in the app (`app/src/02b_eval.js`).
- What-if tab: whole-number count inputs with the recorded value beside each, tags (*You can change / Fixed / Outside your control*),
  rules between related inputs, a clear invalid-scenario message with an "adjust" button, baseline-versus-scenario table, rewritten
  automatic summary (`app/src/03_whatif.js`, `04b_explain.js`).
- Report (`report/Week11_Evaluation_Report`), usability test kit (`usability_test/`), seven-minute video script and silent screen
  captures (`video/`), Streamlit files (`streamlit/`), `CONTRIBUTIONS.md` (draft), browser tests `qa/wk11_*.js`.

**Changed**

- **Visual refresh of the app (1 Nov 2026), appearance only.** New navy header band with an icon tab bar, KPI cards with a highlighted headline
  figure, card-based layout on a cool grey page, restyled tables (sticky headers, hover rows), controls, sliders, switches, callouts and charts
  (same palette values, validated again on the new card surfaces), a designed dark theme, a phone layout with a bottom-style four-icon tab bar,
  keyboard focus rings, a skip link and a footer. The Inter typeface is now embedded (`app/src/fonts/`, SIL Open Font License) instead of loaded
  from Google Fonts, so the page makes no network request. No number, label, id or behaviour changed: all browser tests (`qa/`) and the text/data
  cross-checks pass unchanged, and the model files are untouched. Files: `app/src/style.css`, `body.html`, `05_main.js` (skip link), `code/13_build_app.py` (font embedding).
  Report screenshots, the Streamlit copy of the page and both demo recordings were regenerated from the refreshed app.
- Cost estimate: the app now feeds the cost model next week's expected occupancy and banquet flag (the week being priced), matching how
  the model was fitted. Previously it used the selected week's own values. Accuracy is unchanged (typical miss $1,163 against $1,172
  for the strict last-week version); this is a correctness fix.
- The weekly list caption says that the dollar figure is for next week.
- Case weights are accepted by `glm_cloglog.py` and `modeling_common.py` (used only by one rejected experiment; results are
  identical when unused).
- `12_export_app_data.py` exports the integer counts the what-if inputs need, and takes the capture figures from the Week 11
  evaluation (they differ from the Week 10 report by up to one point because Week 11 averages tie-breaks and uses the exact expectation
  for the random list).

**Added after Debra's screening script (1 Nov 2026)**

- `code/15_select_improvements.py` (Debra Senteu): a two-fold screen of two ideas, a fixed exposure offset on shrunk exposure and category intercepts in the
  dollar model. Included as she wrote it with one change: it hard-coded `LAM_CAT = 1.0` as "Week 10's selected pooling strength", but the fitted Week 10 model uses
  0.01 (`model_params.json`); it now reads the fitted values (baseline log loss 0.1603 instead of 0.1607; her decisions are unchanged). Output: `docs/improvement_selection_wk11.txt`.
- Both ideas were then run on the eight rolling blocks as candidates J and K in `code/22_wk11_improvements.py`, with stated rules (written knowing her two-fold result).
  J (exposure offset): log loss +0.0003, better in 3 of 8 blocks, rejected. K (category in the dollar estimate): typical miss $10 (0.8%) lower, interval -$37 to +$14,
  better in 5 of 8 blocks, and as a list ranking it holds 2.3 points less cost; rejected. Her script, judging by "lower is better" on two folds, would have adopted K.
- The report (section 5), the Evaluation tab, the README and the video script now say thirteen candidates. The model is unchanged.
- Disclosed boundary: the last development row (2025-W52) has its label in 2026-W01, so two failures from the first 2026 week are in the fit and in the last test block.
  Refitting without that row changes the 2026 log loss from 0.19438 to 0.19431 and no 2026 probability by more than 0.0075; the frozen model was left as it was.

**Not changed:** the model, its coefficients and the 2026 predictions (the Week 11 pipeline reproduces the Week 10 2026 predictions to
1e-16).

## v3 (26 Oct 2026) — Mirza, after reviewing Debra's package

Checked Debra's package against the first submission before changing anything: her rebuild
reproduced exactly (all derived files, her gradient-boosting figures of 0.742 and 41.4%, the
decomposition residual of 2e-15, and the app's JavaScript against the Python model to 1e-7).

**Changed**

- Reference-vendor-week label in the contribution panel. It used to say "average training
  vendor-week" at 1.6%, which read as contradicting the 4.6% overall failure rate. It now
  says why they differ (the walk averages inputs on the log-hazard scale).
- Scenario summary gained an expected-cost line, so both KPIs (chance of a failure, cost of
  a failure) are stated in the summary, not only on the cards.
- `docs/Week10_KPIs_and_Progress.md`: worked example corrected to the figures the app shows
  (4-week rejection term +0.21, running chance 19.4%, total +2.59); reproducibility paragraph
  reworded to what was and was not established.
- One-page report: boosted-trees benchmark updated to 2026 AUC 0.742 and 41% of cost.
- README: reproducibility wording, private-link note, placeholder for the shared repository.
- Added `requirements-tested.txt`.
- QA scripts and the video capture script read the browser path from `CHROMIUM_PATH` when set.

**Not changed:** the model, the data, the evaluation, or any holdout figure other than the
boosted-trees benchmark.

## v2 — Debra

Pinned `OMP_NUM_THREADS=1` in `run_all.sh`; added predictor importance, per-prediction
contributions with an exactness check (`code/14_add_explanations.py`, `app/src/04b_explain.js`),
automatic scenario summaries, and `docs/Week10_KPIs_and_Progress.md`.

## v1 — Mirza

First Week 10 package: model, evaluation, three-screen app, report, video script.
