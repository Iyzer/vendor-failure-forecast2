// Records the silent Week 11 screen capture that follows Week11_Video_Script.md (timings from segments.json).
//   node capture_w11.js            clean recording, no captions   -> raw_clean/
//   CAPTIONS=1 node capture_w11.js caption bar with the narration -> raw_guide/
//   TIME_SCALE=0.15 ...            quick selector test (not a real recording)
const path = require('path');
const fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
const SEG = JSON.parse(fs.readFileSync(path.join(__dirname, 'segments.json')));
const CAPTIONS = !!process.env.CAPTIONS, SCALE = Number(process.env.TIME_SCALE || 1);
const MODE = CAPTIONS ? 'guide' : 'clean';
const NAME = { M: 'Mirza', D: 'Debra' };

(async () => {
  const rawDir = path.join(__dirname, 'raw_' + MODE);
  fs.rmSync(rawDir, { recursive: true, force: true });
  const browser = await chromium.launch();
  const tCtx = Date.now();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, recordVideo: { dir: rawDir, size: { width: 1280, height: 720 } }, colorScheme: 'light' });
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGE ERROR', e.message)); page.on('console', m => { if (/^missing/.test(m.text())) console.log('PAGE', m.text()); });
  await page.goto(APP + '#performance'); await page.waitForTimeout(700);
  await page.evaluate(([caps]) => {
    const c = document.createElement('div');
    c.style.cssText = 'position:fixed;left:-50px;top:-50px;width:18px;height:18px;border-radius:50%;background:rgba(235,104,52,.55);border:2px solid #eb6834;z-index:100000;pointer-events:none;transform:translate(-50%,-50%)';
    document.body.appendChild(c);
    document.addEventListener('mousemove', e => { c.style.left = e.clientX + 'px'; c.style.top = e.clientY + 'px'; }, true);
    if (caps) {
      const k = document.createElement('div');
      k.style.cssText = 'position:fixed;left:50%;bottom:8px;transform:translateX(-50%);width:min(1220px,96vw);background:rgba(10,10,10,.86);color:#fff;font:13.5px/1.4 system-ui,sans-serif;padding:8px 14px;border-radius:8px;z-index:100000;pointer-events:none';
      document.body.style.paddingBottom = '110px';
      document.body.appendChild(k);
      window.__cap = (who, txt) => { k.innerHTML = '<b style="color:#8ab8f0">' + who + '</b> · ' + txt; };
    }
  }, [CAPTIONS]);
  const t0 = Date.now(), offset = (t0 - tCtx) / 1000;
  const until = async t => { const w = t * SCALE * 1000 - (Date.now() - t0); if (w > 0) await page.waitForTimeout(w); };
  const scrollTo = async (sel, off = 100) => { await page.evaluate(([s, o]) => { const e = document.querySelector(s); if (e) window.scrollTo({ top: e.getBoundingClientRect().top + window.scrollY - o, behavior: 'smooth' }); else console.log('missing', s); }, [sel, off]); };
  const top = () => page.evaluate(() => window.scrollTo({ top: 0, behavior: 'smooth' }));
  const moveTo = async (sel, fx = 0.5, fy = 0.5, steps = 28) => { const h = await page.$(sel); if (!h) { console.log('MISSING', sel); return; } const b = await h.boundingBox(); if (b) await page.mouse.move(b.x + b.width * fx, b.y + b.height * fy, { steps }); };
  const click = async sel => { await moveTo(sel); await page.waitForTimeout(250); await page.click(sel); };
  await page.mouse.move(640, 300);
  const S = i => SEG[i].start, at = (i, off) => until(S(i) + off);
  const caption = i => CAPTIONS ? page.evaluate(([w, t]) => window.__cap(w, t), [NAME[SEG[i].who], SEG[i].text]) : null;

  // 0 intro
  await caption(0); await at(0, 2); await moveTo('#perf-tiles .tile.hero', 0.5, 0.4); await at(0, 20); await moveTo('#perf-tiles .tile:nth-child(3)', 0.5, 0.4);
  await at(0, 31); await scrollTo('#ch-capture', 150); await at(0, 37); await moveTo('#ch-capture .brow:nth-child(1) .track', 0.4, 0.5);
  // 1 design and leakage
  await at(1, 0); await caption(1); await click('#tab-evaluation'); await at(1, 2); await top(); await moveTo('#ev-plain', 0.3, 0.4, 20);
  await at(1, 16); await scrollTo('#ev-design', 110); await at(1, 20); await moveTo('#ev-design', 0.5, 0.5, 30);
  await at(1, 32); await scrollTo('#ev-leak', 110); await at(1, 38); await moveTo('#ev-leak', 0.5, 0.5, 30);
  // 2 KPIs and verdicts
  await at(2, 0); await caption(2); await scrollTo('#ev-k1', 120); await at(2, 6); await moveTo('#ev-k1 tbody tr:nth-child(1)', 0.5, 0.5, 30);
  await at(2, 18); await scrollTo('#ev-k1-verdict', 220); await at(2, 24); await moveTo('#ev-k1-verdict', 0.3, 0.5, 20);
  await at(2, 32); await scrollTo('#ev-k2-verdict', 220); await at(2, 38); await moveTo('#ev-k2-verdict', 0.3, 0.5, 20);
  await at(2, 44); await scrollTo('#ev-dec', 120); await at(2, 48); await moveTo('#ev-dec tbody tr:nth-child(1)', 0.5, 0.5, 30);
  await at(2, 55); await scrollTo('#ev-dec-verdict', 220);
  // 3 error analysis
  await at(3, 0); await caption(3); await scrollTo('#ch-size', 130); await at(3, 8); await moveTo('#ch-size svg', 0.35, 0.45, 40);
  await at(3, 20); await scrollTo('#ev-seg', 120); await at(3, 26); await moveTo('#ev-seg tbody tr:nth-child(2)', 0.5, 0.5, 30);
  await at(3, 36); await scrollTo('#ev-seg-impl', 120);
  // 4 improvements and limits
  await at(4, 0); await caption(4); await scrollTo('#ev-imp', 120); await at(4, 8); await moveTo('#ev-imp tbody tr:nth-child(3)', 0.5, 0.5, 30);
  await at(4, 22); await scrollTo('#ev-limits', 110); await at(4, 28); await moveTo('#ev-limits', 0.5, 0.5, 30);
  // 5 what-if
  await at(5, 0); await caption(5); await click('#tab-whatif'); await at(5, 2); await top(); await at(5, 5); await moveTo('#wi-fixed', 0.5, 0.5, 30);
  await at(5, 14); await moveTo('#wi-answer .big', 0.1, 0.5, 30);
  await at(5, 24); await click('button[data-q="rej+3"]');
  await at(5, 30); await scrollTo('#wi-compare', 110); await at(5, 36); await moveTo('#wi-compare tbody tr:nth-child(9)', 0.6, 0.5, 30);
  await at(5, 44); await scrollTo('#wi-notes', 110); await at(5, 48); await scrollTo('#wi-summary', 110); await at(5, 52); await moveTo('#wi-summary', 0.4, 0.4, 30);
  await at(5, 58); await scrollTo('#wi-contrib', 120); await at(5, 62); await moveTo('#wi-contrib', 0.5, 0.35, 30);
  // 6 invalid scenario
  await at(6, 0); await caption(6); await top(); await at(6, 2); await click('button[data-q="reset"]'); await at(6, 4);
  await page.click('#n-r13'); await page.fill('#n-r13', ''); await page.type('#n-r13', '120', { delay: 220 });
  await at(6, 10); await moveTo('#wi-answer', 0.3, 0.5, 30);
  await at(6, 17); await click('#wi-fix'); await at(6, 23); await click('button[data-q="reset"]');
  // 7 weekly list
  await at(7, 0); await caption(7); await click('#tab-weekly'); await at(7, 2); await page.selectOption('#wk-week', '25'); await at(7, 8); await moveTo('#wk-tiles .tile:nth-child(3)', 0.5, 0.4, 30);
  await at(7, 16); await scrollTo('#wk-table', 110); await at(7, 20); await moveTo('#wk-table tbody tr:nth-child(2) .rng', 0.5, 0.5, 30);
  await at(7, 27); await scrollTo('#wk-unscored', 400); await at(7, 33); await top(); await moveTo('#wk-tiles .tile:nth-child(4)', 0.5, 0.4, 30);
  // 8 close
  await at(8, 0); await caption(8); await click('#tab-evaluation'); await at(8, 3); await scrollTo('#ev-limits', 110); await at(8, 8); await moveTo('#ev-limits', 0.5, 0.5, 30);
  await until(420);
  await ctx.close();
  const vid = fs.readdirSync(rawDir).filter(f => f.endsWith('.webm')).map(f => path.join(rawDir, f))[0];
  fs.writeFileSync(path.join(__dirname, `offset_${MODE}.txt`), String(offset));
  fs.renameSync(vid, path.join(__dirname, `capture_${MODE}.webm`));
  await browser.close(); console.log('done', MODE, 'offset', offset);
})();
