"""Builds Week11_Video_Script.md and segments.json (timings used by capture.js) from the narration text below.
Pace: 2.0 words per second (about 120 words a minute, a comfortable speaking speed), scaled to a 7:00 total."""
import json, math

SEG = [
 ("M", "Model performance tab, top. Rest the cursor on the headline tile, then the third tile.",
  "Each Monday our purchasing and receiving manager can look closely at only a handful of vendors: as few as four in a busy peak week and up to twelve off-season. Our tool estimates, for every vendor, the chance of a material failure next week and what a failure would cost. This week's question is whether the tool deserves to be trusted for that decision. We judge it on three results: the failure chance, the dollar cost of a failure, and how much failure cost the weekly review list actually covers."),
 ("D", "Evaluation & limits tab: the plain-language panel, the test-design table, then the leakage table.",
  "We tested the way the tool is used, forward in time. Every decision was made on 2023 to 2025, in eight rolling thirteen-week blocks, and each block is predicted only from what was known on its first Monday. 2026 was already viewed in Week 10, so it is confirmation only, not a clean final test. The leakage table lists every input and when it is known, and a negative control shows that a leaked input would look much better than ours do. We wrote down our rules for a meaningful improvement before running Week 11, and we say openly that they came after the Week 10 results."),
 ("M", "KPI 1 table and verdict, KPI 2 verdict, then the weekly-list table and its verdict.",
  "Against the best simple baseline, the failure chance is not a meaningful improvement by our rule. The model beats the category rate on log loss overall, but it beats the better of the two simple baselines in only five of eight blocks, not the six we required, and the rejection inputs add almost nothing. The dollar estimate is no better than the plain average: a typical miss of 1,163 dollars against 1,170. The weekly list is where the value is. It holds fifty-eight percent of next-week failure cost, against forty-one percent for today's on-time and fill rules, and in 2026 fifty-five against thirty-one. But ranking by delivery volume alone holds fifty-three percent, and the model's edge over it cannot be told apart from zero."),
 ("D", "The list-size chart, then the segment table and its implications.",
  "The error analysis shows where that coverage comes from. The percentages are right on average in every group we could test. But the list is strong for produce, catching seventy-eight percent of failures, and weak for protein at eleven percent and dairy at thirty-three. In peak weeks capacity is smaller, so it catches a third of failures instead of over half. Vendors under an open corrective action fail more often but are held out by design. And this chart shows the price of coverage: reaching about eighty percent of failure cost takes roughly twice the usual capacity."),
 ("M", "The improvements table, then the limits box.",
  "We tried thirteen improvements, chosen from those findings and from a screening script Debra wrote: recency weighting, smoothed rejection rates, adding failure history, dropping inputs, stronger or weaker vendor effects, recalibration, a fixed exposure term, and category in the cost model. The keep-or-reject rules were written before we ran the eight-block tests. None passed, so the Week 10 model stays. What we did change is a mismatch in the cost estimate, and we added decision support. The limits box says the rest in plain words: synthetic data, a holdout we had already seen, about half the cost covered, and no proven edge over volume."),
 ("D", "What-if tab: Produce 002, week 26 (preselected). Point at the tags. Click +3 rejections. Scroll to the side-by-side table, the summary and the contributions panel.",
  "Now the what-if screen. Every input is labelled: you can change it, it is fixed, or it is outside your control. Scenarios use counts rather than sliders, so the tool works out the rates itself. Here is Produce 002 in peak week 26: a nineteen percent chance of failure, and we are eighty percent sure it lies between fifteen and twenty-four. Suppose it had three more rejected deliveries. The chance goes to thirty-six percent, and the side-by-side table shows what changed, with intervals and the vendor's place on the list. The summary is written automatically, with trade-offs to weigh, and says plainly that this is model-based, not proven cause. And this panel explains the single forecast: the produce category does most of the work, then delivery volume, then the vendor's own record."),
 ("M", "Type 120 rejected deliveries in the 13-week box. Show the message. Click the adjust button, then Reset.",
  "Inputs are checked. If I type a hundred and twenty rejections when only ninety-five deliveries were received, the tool refuses to forecast, says which rule is broken, and offers a button that moves to the nearest possible scenario. It also rejects decimals, negative numbers, and a four-week count that is larger than the thirteen-week count."),
 ("D", "Weekly review list tab, week 26. Tiles, table, the held-out and not-scored line, the hindsight tile.",
  "On the weekly list for week 26, five vendors fit this week's capacity. Two more are held out for an open corrective action, and three are not scored because they had no recent deliveries, which the tool never treats as zero risk. The hindsight check shows what actually happened the following week, and in this peak week the list caught none of the one failure. That is why we describe the list as an aid, not a guarantee."),
 ("M", "Back to Evaluation & limits, the limits box.",
  "[OUTSIDE TEST: fill this from the real session. Say who took part by role, what they struggled with, and the one change we made because of it.] To close: the tool clearly beats today's rules, is not proven better than ranking by delivery volume, and is weakest where capacity is tightest. All figures are synthetic, so they validate our method, not a real resort."),
]
WPS, TOTAL = 2.0, 420.0
words = [len(s[2].split()) for s in SEG]
raw = [w / WPS for w in words]
scale = TOTAL / sum(raw)
dur = [r * scale for r in raw]
starts, t = [], 0.0
for d in dur:
    starts.append(t); t += d
def mmss(x): x = int(round(x)); return f"{x // 60}:{x % 60:02d}"
rows = []
for i, ((who, screen, say), s, d, w) in enumerate(zip(SEG, starts, dur, words)):
    rows.append(f"| {mmss(s)}–{mmss(s + d)} | {who} | {screen} | {say} |")
md = f"""# Week 11 Video Script: Seven-Minute Evaluation and Decision-Support Demo

**Vendor Failure Forecast** · Mirza Ali (M) and Debra Senteu (D) · {sum(words)} words at a relaxed 120 words a minute is about 7:00.

How to record: open the app (`app/index.html`, or the hosted copy) at 1280 × 720. `Week11_Demo_Screen_Capture_clean.mp4` is a silent screen recording that follows this script second for second, with no captions on screen: lay your narration over it. `Week11_Demo_Guide_captioned.mp4` is the same recording with the narration as captions, for pacing while you speak. Record audio separately from the screen, then join them.

**Week 9 feedback, built into this checklist**

- **No labels such as "Screen 1" or "Slide 2" anywhere on screen or in the narration.** The captured screen shows only the app.
- **Audio loud enough to hear without turning the volume up.** Record in a quiet room with the microphone close, then normalise the file before submitting, for example `ffmpeg -i narration.wav -af loudnorm=I=-16:TP=-1.5:LRA=11 narration_loud.wav`. Play the finished video once at normal volume on a laptop speaker.
- **No faces on top of the screen.** If you want to appear, put the camera in a separate strip beside the screen, or leave faces out and use audio only. Do not overlay a face on the app.
- Keep the app at 1280 × 720 so the text is readable when the video is shrunk.

| Time | Who | On screen | Say |
|---|---|---|---|
""" + "\n".join(rows) + f"""

The last row contains a bracketed instruction. Replace it with two or three sentences from the real session with the outside person: who took part (by role), what they struggled with, and the app change we made because of it. Do not describe a session that has not happened.

## What the video covers (assignment checklist)

- The data split and why it fits the use; the leakage check. *(row 2)*
- The KPIs, baseline comparisons and the verdict on a meaningful improvement for each. *(row 3)*
- Error analysis by condition and segment, and what it means for users. *(row 4)*
- Improvements tried, compared consistently on development data, kept or rejected; remaining limitations. *(row 5)*
- Decision support: performance and limits in the manager's terms, individual-prediction explanation, changeable / fixed / external inputs, input checks with a clear invalid-scenario message, baseline against scenario side by side with intervals, automatic summary. *(rows 6–8)*
- The outside test and the change it led to. *(row 9)*

## Numbers to have ready for questions

| Question | Answer |
|---|---|
| Share of failure cost in the weekly list? | 58.3% [48.8, 67.7] in 2024–25 tests; 54.7% [43.0, 66.2] in 2026. Today's rules 40.7% and 30.6%. Random about 22%. |
| Better than ranking by delivery volume? | Volume holds 52.6% and 50.4%. Model minus volume: +5.7 [−3.0, +14.0] and +4.3 [−2.6, +12.1] points. The interval includes zero. |
| Why is "a meaningful improvement" not met for the failure chance? | Log loss beats the category rate (−0.0023 [−0.0042, −0.0005]) but only 5 of 8 blocks beat the best simple baseline (6 required) and AUC is +0.004 [−0.005, +0.011] above the vendor's own history (0.03 required). |
| Dollar estimate? | Typical miss $1,163 against $1,170 for the plain average; the 5% improvement rule is not met. |
| How many reviews to reach about 80%? | About two to two and a half times capacity (19 to 24 vendors a week). |
| Why does 2026 look different? | The generator shifted in 2026: failures ran 5.57% against 4.44% forecast; the drift monitor flagged it in week 22. Protein and large vendors drifted most. |
| What did you try to improve the model? | Thirteen candidates (recency weighting, smoothed rejections, failure history, dropping inputs, vendor-effect strength, recalibration, category cost ranking, and, from Debra's screening script, a fixed exposure term and category in the dollar estimate). None met the stated rules. |
| Is 2026 a clean test? | No. It was viewed in Week 10. Week 11 decisions use 2023–2025 only. |
"""
open("Week11_Video_Script.md", "w").write(md)
json.dump([dict(who=w, screen=sc, text=tx, start=round(s, 2), dur=round(d, 2), words=wd) for (w, sc, tx), s, d, wd in zip(SEG, starts, dur, words)], open("segments.json", "w"), indent=1)
print(sum(words), "words;", [(mmss(s), round(d), w) for s, d, w in zip(starts, dur, words)])
