// Week 11 what-if tests: whole-number inputs, relationship checks, invalid-scenario message, quick scenarios, comparison table.
const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
let fails = 0;
const ok = (name, cond, extra = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  -- ' + extra : '')); if (!cond) fails++; };
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  const errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await page.goto(APP + '#whatif'); await page.waitForTimeout(500);
  const big = () => page.$eval('#wi-answer .big', e => e.textContent).catch(() => null);
  const ansText = () => page.$eval('#wi-answer', e => e.textContent);
  const setv = async (id, v) => { await page.fill(id, ''); if (v !== '') await page.type(id, String(v)); };
  const err = id => page.$eval('#e-' + id, e => e.textContent);
  const vals = () => page.evaluate(() => ['n13', 'r13', 'n4', 'r4'].map(f => document.querySelector('#n-' + f).value));
  const start = await big(); const rec = await vals();
  ok('opens on a valid forecast', /%/.test(start || ''), `${start} recorded ${rec.join('/')}`);

  // 1 whole numbers
  await setv('#n-r4', '1.5'); ok('decimal rejected', /Whole numbers only/.test(await err('r4')), await err('r4'));
  ok('no forecast shown for a decimal', /cannot happen/i.test(await ansText()));
  await setv('#n-r4', '-2'); ok('negative rejected', /negative/i.test(await err('r4')));
  await setv('#n-r4', 'abc'); ok('letters never reach the forecast (number field refuses them; empty is flagged)', /Enter a whole number|Whole numbers only/.test(await err('r4')), await err('r4'));
  await setv('#n-r4', ''); ok('empty rejected', /Enter a whole number/.test(await err('r4')));
  await setv('#n-r4', String(rec[3])); ok('restoring the record restores the forecast', (await big()) === start);

  // 2 relationships
  await setv('#n-r13', '999'); ok('rejected > received (13w)', /cannot be more than deliveries/.test(await err('r13')) || /beyond anything/.test(await err('r13')), await err('r13'));
  await setv('#n-r13', String(Number(rec[0]) + 1)); ok('rejected = received+1 (13w)', /cannot be more than deliveries received/.test(await err('r13')), await err('r13'));
  await setv('#n-r13', rec[1]);
  await setv('#n-n4', String(Number(rec[0]) + 5)); ok('4-week deliveries > 13-week deliveries', /part of the last 13/.test(await err('n4')), await err('n4'));
  await setv('#n-n4', rec[2]);
  await setv('#n-r4', String(Number(rec[2]) + 1)); ok('rejected > received (4w)', /cannot be more than deliveries received/.test(await err('r4')), await err('r4'));
  await setv('#n-r4', '0'); await setv('#n-r13', '0'); await setv('#n-n13', rec[2]); // n13 = n4, r13 = r4 = 0 : valid
  ok('equal windows valid', (await big()) !== null && !/cannot happen/i.test(await ansText()));
  await setv('#n-n13', '10'); await setv('#n-n4', '3'); await setv('#n-r13', '8'); await setv('#n-r4', '0');
  ok('weeks 5-13 cannot hold more rejections than deliveries', /Weeks 5 to 13/.test(await err('r13')), await err('r13'));
  await setv('#n-r13', '2'); await setv('#n-r4', '3'); ok('4-week rejections > 13-week rejections', /part of the 13-week count/.test(await err('r4')), await err('r4'));
  await setv('#n-n13', '0'); ok('no deliveries in 13 weeks -> not scored message', /cannot be scored/.test(await err('n13')), await err('n13'));
  await page.screenshot({ path: 'screenshots_w11/whatif_invalid.png', fullPage: false });
  // repair button
  await setv('#n-n13', '40'); await setv('#n-n4', '12'); await setv('#n-r13', '1'); await setv('#n-r4', '6');
  ok('invalid before repair', /cannot happen/i.test(await ansText()));
  await page.click('#wi-fix');
  const after = await vals();
  ok('repair produces a valid scenario', !/cannot happen/i.test(await ansText()) && (await big()) !== null, after.join('/'));

  // 3 quick scenarios and the comparison table
  await page.click('button[data-q="reset"]'); ok('reset returns the recorded record', (await vals()).join() === rec.join() && (await big()) === start);
  await page.click('button[data-q="rej+3"]'); const b3 = await big(); const v3 = await vals();
  ok('+3 rejections raises the chance', parseFloat(b3) > parseFloat(start), `${start} -> ${b3} (${v3.join('/')})`);
  const cmp = await page.$eval('#wi-compare', e => e.textContent);
  ok('comparison table mentions both columns', /As recorded/.test(cmp) && /Your scenario/.test(cmp));
  ok('summary says model-based, not proven cause', /not proven cause/i.test(await page.$eval('#wi-summary', e => e.textContent)));
  await page.click('button[data-q="expo+25"]'); const v4 = await vals(); ok('deliveries +25% gives whole numbers', v4.every(x => /^\d+$/.test(x)), v4.join('/'));
  await page.click('button[data-q="calm"]'); const bc = await big(); ok('clean record lowers the chance', parseFloat(bc) < parseFloat(b3), bc);
  await page.screenshot({ path: 'screenshots_w11/whatif_scenario.png', fullPage: true });
  await page.click('button[data-q="reset"]');

  // 4 out-of-range is allowed but flagged
  await setv('#n-n13', '300'); await setv('#n-n4', '100');
  const notes = await page.$$eval('#wi-notes .note', n => n.map(x => x.textContent));
  ok('very high deliveries forecast with an extrapolation note', notes.some(t => /Outside what the model has seen/.test(t)), (await big()));

  // 5 not-scored vendor
  await page.click('button[data-q="reset"]');
  await page.selectOption('#wi-vendor', '0');
  ok('not-scored vendor shows the insufficient-data message and disables inputs', /Not enough data/.test(await ansText()) && await page.$eval('#n-n13', e => e.disabled));
  // 6 week switch recomputes counts
  await page.selectOption('#wi-week', '10'); await page.selectOption('#wi-vendor', '5');
  ok('week/vendor change loads that record', (await vals()).every(x => /^\d+$/.test(x)), (await vals()).join('/'));
  // 7 phone width
  const m = await (await browser.newContext({ viewport: { width: 390, height: 800 } })).newPage();
  await m.goto(APP + '#whatif'); await m.waitForTimeout(400);
  const overflow = await m.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  ok('no horizontal page scroll at 390px', overflow <= 1, 'overflow ' + overflow);
  await m.screenshot({ path: 'screenshots_w11/whatif_mobile.png', fullPage: true });
  for (const v of ['performance', 'evaluation', 'weekly']) { await m.evaluate(v => window.__vr.showView(v), v); await m.waitForTimeout(250); const o = await m.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok(`no horizontal page scroll on ${v} at 390px`, o <= 1, 'overflow ' + o); }
  console.log('page errors', JSON.stringify(errs));
  ok('no page errors', errs.length === 0);
  await browser.close();
  console.log(fails ? `${fails} FAILED` : 'ALL PASSED');
})();
