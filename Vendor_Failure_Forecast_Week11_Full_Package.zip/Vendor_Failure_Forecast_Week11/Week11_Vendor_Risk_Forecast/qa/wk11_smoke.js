// Week 11 smoke test: loads the app, checks parity, errors, and walks every tab; saves screenshots.
const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, colorScheme: 'light' });
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', m => { if ((m.type() === 'error') && !/ERR_TUNNEL|Failed to load resource|fonts\./.test(m.text())) errs.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await page.goto(APP); await page.waitForTimeout(700);
  console.log('parity', JSON.stringify(await page.evaluate(() => window.__vr.parityReport())));
  for (const v of ['performance', 'evaluation', 'whatif', 'weekly']) {
    await page.evaluate(v => window.__vr.showView(v), v); await page.waitForTimeout(400);
    await page.screenshot({ path: `screenshots_w11/${v}.png`, fullPage: true });
  }
  console.log('errors', JSON.stringify(errs, null, 1));
  await browser.close();
})();
