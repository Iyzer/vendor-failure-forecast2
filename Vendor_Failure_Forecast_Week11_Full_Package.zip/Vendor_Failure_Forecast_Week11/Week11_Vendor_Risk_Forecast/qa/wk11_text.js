// Cross-checks key figures in the rendered app text against the saved evaluation files.
const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const E = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/wk11_evaluation.json')));
const pc = (x, d = 1) => (x * 100).toFixed(d), M = 'Model (this tool)';
let fails = 0; const ok = (n, c, x = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!c) fails++; };
(async () => {
  const b = await chromium.launch(); const page = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  await page.goto(APP); await page.waitForTimeout(600);
  const txt = {};
  for (const v of ['performance', 'evaluation', 'whatif', 'weekly']) { await page.evaluate(v => window.__vr.showView(v), v); await page.waitForTimeout(300); txt[v] = await page.$eval('#view-' + v, e => e.innerText); }
  const ev = txt.evaluation, perf = txt.performance;
  const dd = E.decision_dev.res, dv = E.decision_val.res;
  ok('eval: dev model capture', ev.includes(pc(dd[M].cost, 0) + '%'), pc(dd[M].cost));
  ok('eval: 2026 model capture', ev.includes(pc(dv[M].cost, 0) + '%'));
  ok('eval: model minus practice dev', ev.includes('+' + pc(E.decision_dev.cmp['Current practice (on-time/fill + loud failure)'].cost[0]) ));
  ok('eval: model minus volume dev', ev.includes('+' + pc(E.decision_dev.cmp['Delivery volume (spend proxy)'].cost[0])));
  ok('eval: model minus volume 2026', ev.includes('+' + pc(E.decision_val.cmp['Delivery volume (spend proxy)'].cost[0])));
  ok('eval: AUC dev', ev.includes(E.kpi1_dev.rows[M].auc.toFixed(3)));
  ok('eval: log loss dev', ev.includes(E.kpi1_dev.rows[M].logloss.toFixed(4)));
  ok('eval: cost MAE', ev.includes('$' + Math.round(E.kpi2_dev['Week 10 cost model (occupancy + banquet of the failure week)'].mae).toLocaleString('en-US')));
  ok('eval: no raw NaN/undefined', !/NaN|undefined|null/.test(ev + txt.whatif + txt.weekly + perf));
  ok('eval: not claiming generator unavailable', !/generator was not available|generator is not available/.test(ev));
  ok('perf: 2026 capture tile shows the Week 11 figure', perf.includes(pc(dv[M].cost, 0) + '%'));
  ok('perf: today\'s rules 31%', perf.includes(pc(dv['Current practice (on-time/fill + loud failure)'].cost, 0) + '%'));
  ok('perf: old Week 10 random figure gone (21.3%)', !perf.includes('21.3%') && !ev.includes('21.3%'));
  ok('perf: old Week 10 trailing-rejection figure gone (29.4%)', !perf.includes('29.4%'));
  await b.close(); console.log(fails ? fails + ' FAILED' : 'ALL PASSED');
})();
