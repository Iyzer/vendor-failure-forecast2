// Dark-mode and phone-width screenshots of every tab (visual review aid, not a pass/fail test).
const APP = 'file://' + require('path').resolve(__dirname, '../app/index.html');
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  for (const [name, vp, scheme] of [['dark', { width: 1280, height: 900 }, 'dark'], ['phone', { width: 390, height: 800 }, 'light'], ['phone_dark', { width: 390, height: 800 }, 'dark']]) {
    const page = await (await browser.newContext({ viewport: vp, colorScheme: scheme })).newPage();
    await page.goto(APP); await page.waitForTimeout(600);
    for (const v of ['performance', 'evaluation', 'whatif', 'weekly']) {
      await page.evaluate(v => window.__vr.showView(v), v); await page.waitForTimeout(350);
      await page.screenshot({ path: `screenshots_w11/${name}_${v}.png`, fullPage: true });
    }
  }
  await browser.close();
})();
