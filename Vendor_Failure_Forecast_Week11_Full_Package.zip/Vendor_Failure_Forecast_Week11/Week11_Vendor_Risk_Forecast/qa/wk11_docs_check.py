"""
Cross-checks the key figures typed in README.md, the report (docx text), the video script and the changelog against the saved result files
(data/wk11_evaluation.json, wk11_improvements.json, wk11_error_analysis.json, model_eval.json). Run after any rebuild:

    python3 qa/wk11_docs_check.py

Needs pandoc to read the report. Prints PASS/FAIL per check and exits non-zero on any failure.
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
D = os.path.join(ROOT, "data")
E = json.load(open(os.path.join(D, "wk11_evaluation.json")))
IM = json.load(open(os.path.join(D, "wk11_improvements.json")))
A = json.load(open(os.path.join(D, "wk11_error_analysis.json")))
M10 = json.load(open(os.path.join(D, "model_eval.json")))
M = "Model (this tool)"
VOL, PRAC, RND, CAT = "Delivery volume (spend proxy)", "Current practice (on-time/fill + loud failure)", "Random list", "Category rate"
MINUS = "−"


def read(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()


def report_text():
    return subprocess.run(["pandoc", "-t", "plain", "--wrap=none", os.path.join(ROOT, "report", "Week11_Evaluation_Report.docx")], capture_output=True, text=True, check=True).stdout


def fmt_pts(x):                                  # +17.6
    return f"{'+' if x >= 0 else MINUS}{abs(x * 100):.1f}"


def cmp_str(c):                                  # +17.6 [+6.9, +28.6]
    return f"{fmt_pts(c[0])} [{fmt_pts(c[1])}, {fmt_pts(c[2])}]"


def usd(x):
    return "${:,.0f}".format(x)


DOCS = {"readme": read("README.md"), "report": report_text(), "script": read("video/Week11_Video_Script.md"), "changelog": read("docs/CHANGELOG.md")}
fails = 0


def check(name, needle, where):
    global fails
    for w in where:
        txt = DOCS[w]
        ok = needle in txt
        if not ok:
            # the typed docs use ASCII hyphen-minus in some places; accept either minus sign
            ok = needle.replace(MINUS, "-") in txt
        print(("PASS " if ok else "FAIL ") + f"{name} [{w}]  '{needle}'")
        if not ok:
            fails += 1


dd, dv = E["decision_dev"], E["decision_val"]
check("model list share dev", f"{dd['res'][M]['cost'] * 100:.1f}%", ["readme", "report"])
check("model list share 2026", f"{dv['res'][M]['cost'] * 100:.1f}%", ["readme", "report"])
check("volume list share dev", f"{dd['res'][VOL]['cost'] * 100:.1f}%", ["readme", "report"])
check("volume list share 2026", f"{dv['res'][VOL]['cost'] * 100:.1f}%", ["readme", "report"])
check("practice list share dev", f"{dd['res'][PRAC]['cost'] * 100:.1f}%", ["readme", "report"])
check("practice list share 2026", f"{dv['res'][PRAC]['cost'] * 100:.1f}%", ["readme", "report"])
check("random list share dev", f"{dd['res'][RND]['cost'] * 100:.1f}%", ["readme", "report"])
check("model minus practice dev", cmp_str([dd["cmp"][PRAC]["cost"][0], dd["cmp"][PRAC]["cost"][1], dd["cmp"][PRAC]["cost"][2]]), ["report"])
check("model minus practice dev (README wording)", cmp_str([dd["cmp"][PRAC]["cost"][0], dd["cmp"][PRAC]["cost"][1], dd["cmp"][PRAC]["cost"][2]]).replace(" [", " points [", 1), ["readme"])
check("model minus practice 2026", cmp_str(dv["cmp"][PRAC]["cost"]), ["report"])
check("model minus practice 2026 (README wording)", cmp_str(dv["cmp"][PRAC]["cost"]).replace(" [", " points [", 1), ["readme"])
check("model minus volume dev", cmp_str(dd["cmp"][VOL]["cost"]), ["report"])
check("model minus volume dev (README wording)", cmp_str(dd["cmp"][VOL]["cost"]).replace(" [", " points [", 1), ["readme"])
check("model minus volume 2026", cmp_str(dv["cmp"][VOL]["cost"]), ["report"])
check("model minus volume 2026 (README wording)", cmp_str(dv["cmp"][VOL]["cost"]).replace(" [", " points [", 1), ["readme"])
r1, r2 = E["kpi1_dev"]["rows"], E["kpi1_val"]["rows"]
check("AUC dev", f"{r1[M]['auc']:.3f}", ["readme", "report"])
check("log loss dev", f"{r1[M]['logloss']:.4f}", ["readme", "report"])
check("AUC 2026", f"{r2[M]['auc']:.3f}", ["readme", "report"])
check("log loss 2026", f"{r2[M]['logloss']:.4f}", ["readme", "report"])
check("category rate AUC dev", f"{r1[CAT]['auc']:.3f}", ["readme", "report"])
check("category rate log loss dev", f"{r1[CAT]['logloss']:.4f}", ["readme", "report"])
check("calibration slope dev", f"{r1[M]['cal']['slope']:.2f}", ["readme", "report"])
check("calibration slope 2026", f"{r2[M]['cal']['slope']:.2f}", ["readme", "report"])
check("forecast rate dev", f"{r1[M]['mean_pred'] * 100:.2f}%", ["readme"])
check("observed rate dev", f"{r1[M]['obs_rate'] * 100:.2f}%", ["readme"])
check("forecast rate 2026", f"{r2[M]['mean_pred'] * 100:.2f}%", ["readme"])
check("observed rate 2026", f"{r2[M]['obs_rate'] * 100:.2f}%", ["readme"])
k2d, k2v = E["kpi2_dev"], E["kpi2_val"]
w10c = "Week 10 cost model (occupancy + banquet of the failure week)"
avg = "Average past failure cost"
check("cost miss dev", usd(k2d[w10c]["mae"]), ["readme", "report"])
check("cost miss avg dev", usd(k2d[avg]["mae"]), ["readme", "report"])
check("cost miss 2026", usd(k2v[w10c]["mae"]), ["readme", "report"])
check("cost miss avg 2026", usd(k2v[avg]["mae"]), ["readme", "report"])
cs = E["cost_summary"]
check("failure cost p10", usd(cs["dev"]["p10"]), ["report"])
check("failure cost p90", usd(cs["dev"]["p90"]), ["report"])
check("weekly dollar interval coverage 2026", f"{M10['weekly_cost_cov80'] * 100:.0f}%" if not isinstance(M10["weekly_cost_cov80"], dict) else f"{list(M10['weekly_cost_cov80'].values())[0] * 100:.0f}%", ["readme", "report"])

# improvements
n_model = len(IM["variants"]) - 1
check("thirteen candidates (README)", "Thirteen improvement candidates", ["readme"])
check("thirteen candidates (report)", "thirteen comparisons", ["report"])
check("thirteen candidates (script)", "thirteen improvements", ["script"])
print(("PASS " if n_model + 2 == 13 else "FAIL ") + f"candidate count in data = {n_model} model/probability variants + E + K = {n_model + 2}")
fails += 0 if n_model + 2 == 13 else 1
K = IM["cost_model_k"]
check("K typical miss difference", f"{MINUS if K['diff'] < 0 else '+'}${abs(K['diff']):,.0f}", ["report"])
check("K interval", f"{MINUS if K['ci'][0] < 0 else '+'}${abs(K['ci'][0]):,.0f} to +${abs(K['ci'][1]):,.0f}", ["report"])
check("K blocks", f"{K['blocks_better']} of 8", ["report"])
Jv = [v for v in IM["variants"] if v["name"].startswith("J")][0]
check("J blocks", f"{Jv['blocks_better']} of 8", ["report"])
for name, ok_ in (("J rejected", not Jv["keep"]), ("K rejected", not K["keep"]), ("E rejected", not IM["category_cost"]["keep"]),
                  ("no variant adopted", not any(v.get("keep") for v in IM["variants"]))):
    print(("PASS " if ok_ else "FAIL ") + name)
    fails += 0 if ok_ else 1

# boundary
B = E["boundary"]
check("boundary log loss", f"{B['logloss_with']:.4f} to {B['logloss_without']:.4f}", ["report"])
check("boundary failures", f"{B['failures']} failures out of {B['dev_failures']}", ["report"])

# error analysis numbers quoted in prose
dev = {(r["segment"], r["level"]): r for r in A["dev"]}
prod, prot, dairy = dev[("Vendor category", "produce")], dev[("Vendor category", "protein")], dev[("Vendor category", "dairy_bakery")]
check("produce failures", f"{prod['failures']} of the {A['overall']['failures']} failures", ["report"])
check("produce catch", f"{prod['catch'] * 100:.0f}%", ["report"])
check("protein catch", f"{prot['catch'] * 100:.0f}% of {prot['failures']}", ["report"])
check("overall catch", f"{A['overall']['catch_all'] * 100:.0f}%", ["report"])
check("peak catch", f"{A['peak']['peak weeks']['catch'] * 100:.0f}%", ["report"])

# list capacity statement
check("list size 4 to 12", "as few as", ["report", "script"])

print("\n" + ("ALL PASSED" if not fails else f"{fails} FAILED"))
sys.exit(1 if fails else 0)
